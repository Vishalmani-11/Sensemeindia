<?php
include "smadmin/function/config.php"; 
include "smadmin/db/db_connect.php"; 
include "smadmin/function/function.php"; 
require_once 'smadmin/admin/class.user_2.php';

$reg_user = new USER();

if($reg_user->is_logged_in())
{
	$reg_user->redirect('index.php');
}

?>
<!doctype html>
<html class="no-js" lang="en">
   <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Payment Refund Policy | SenseMe India</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Favicon -->
        <link rel="shortcut icon" type="image/x-icon" href="<?php echo $url; ?>assets/img/favicon.png">

        <!-- All css here -->
        <link rel="stylesheet" href="<?php echo $url; ?>assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo $url; ?>assets/css/font-awesome.min.css">
        <link rel="stylesheet" href="<?php echo $url; ?>assets/css/ie7.css">
        <link rel="stylesheet" href="<?php echo $url; ?>assets/css/plugins.css">
        <link rel="stylesheet" href="<?php echo $url; ?>assets/css/style.css">
	       <link rel="stylesheet" href="<?php echo $url; ?>assets/css/menu/style.css">        
        <script src="<?php echo $url; ?>assets/js/vendor/modernizr-3.5.0.min.js"></script>

<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-WWCJ4NT');</script>
<!-- End Google Tag Manager -->
    </head>
    <body>
        	<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-WWCJ4NT"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
  <div id="loadAjax" class="ui-front loader ui-widget-overlay bg-gray opacity-50" style="display:none">
           <img src="assets/img/loader-light.gif" alt="">
        </div>
        
         <?php include("sm_header.php"); ?>
        <div class="breadcrumb-area bg-12 text-center">
            <div class="container">
                <h1>Payment Refund Policy</h1>
                <nav aria-label="breadcrumb">
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Payment Refund Policy</li>
                    </ul>
                </nav>
            </div>
        </div>
        <!-- Breadcrumb Area End -->
        <!-- Cart Area Start -->
        <div class="post-area blog-area pt-110 pb-95 post-details">
            <div class="container">
                <div class="row">
                    <div class="order-xl-2 order-lg-2 col-xl-12 col-lg-12">
                        <div class="single-post-item pb-70">
                            <div class="single-post-info-text text-justify">
<h3 class="single-post-title">How do I pay for a SensemeIndia purchase?</h3>
Mylal Exports offers you multiple payment methods. Whatever your online mode of payment, you can rest assured that Sense me India 's trusted payment gateway partners use secure encryption technology to keep your transaction details confidential at all times.You may use Internet Banking, E-Gift Voucher (eGV), Cash on Delivery and Wallet to make your purchase. Sense me India also accepts payments made using Visa, MasterCard, Maestro and American Express credit/debit cards in India.
<br>
<br>

Are there any hidden charges (Octroi or Sales Tax) when I make a purchase on Sense me India?
There are NO hidden charges when you make a purchase on Sensemeindia. The prices listed for all the items are final and all-inclusive. The price you see on the product page is exactly what you pay.
<br>
<br>

<h3 class="single-post-title">What is Cash on Delivery?</h3>
If you are not comfortable making an online payment on shoptrendindia.com, you can opt for the Cash on Delivery (C-o-D) payment method instead. With C-o-D you can pay in cash at the time of actual delivery of the product at your doorstep, without requiring you to make any advance payment online.The maximum order value for a Cash on Delivery (C-o-D) payment is Rs.15,000. It is strictly a cash-only payment method. E-Gift Vouchers or store credit cannot be used for C-o-D orders. Foreign currency cannot be used to make a C-o-D payment. Only Indian Rupees accepted.
<br>
<br>

<h3 class="single-post-title">How do I pay using a credit/debit card?</h3>
We accept payments made by credit/debit cards issued in India
<br><br>


<h3 class="single-post-title">Credit cards</h3>

We accept payments made using Visa, MasterCard and American Express credit cards. To pay using your credit card at checkout, you will need your card number, expiry date, three-digit CVV number (found on the backside of your card). After entering these details, you will be redirected to the bank's page for entering the online 3D Secure password.
<br>
<br>

<h3 class="single-post-title">Debit cards</h3>

We accept payments made using Visa, MasterCard and Maestro debit cards. To pay using your debit card at checkout, you will need your card number, expiry date (optional for Maestro cards), three-digit CVV number (optional for Maestro cards). You will then be redirected to your bank's secure page for entering your online password (issued by your bank) to complete the payment.
<br>
<br>

<h3 class="single-post-title">Is it safe to use my credit/debit card on Sense me India?</h3>
Your online transaction on Senseme India is secure with the highest levels of transaction security currently available on the Internet. We uses 256-bit encryption technology to protect your card information while securely transmitting it to the respective banks for payment processing. All credit card and debit card payments on Senseme India are processed through secure and trusted payment gateways managed by leading banks. Banks now use the 3D Secure password service for online transactions, providing an additional layer of security through identity verification.
<br>
<br>

<h3 class="single-post-title">What steps does Sense me India take to prevent card fraud?</h3>
Mylal Exports  realizes the importance of a strong fraud detection and resolution capability. We and our online payments partners monitor transactions continuously for suspicious activity and flag potentially fraudulent transactions for manual verification by our team. In the rarest of rare cases, when our team is unable to rule out the possibility of fraud categorically, the transaction is kept on hold, and the customer is requested to provide identity documents. The ID documents help us ensure that the purchases were indeed made by a genuine card holder. We apologise for any inconvenience that may be caused to customers and request them to bear with us in the larger interest of ensuring a safe and secure environment for online transactions.
<br>
<br>

<h3 class="single-post-title">What is a 3D Secure password?</h3>
The 3D Secure password is implemented by VISA and MasterCard in partnership with card issuing banks under the "Verified by VISA" and "Mastercard SecureCode" services, respectively. The 3D Secure password adds an additional layer of security through identity verification for your online credit/debit card transactions. This password, which is created by you, is known only to you. This ensures that only you can use your card for online purchases.
<br>
<br>

<h3 class="single-post-title">Can I use my bank's Internet Banking feature to make a payment?</h3>
Yes. Sense me India offers you the convenience of using your bank's Internet Banking service to make a payment towards your order. With this you can directly transfer funds from your bank account, while conducting a highly secure transaction
<br>
<br>

                            </div>
                            
                        </div>
                        
                        
                    </div>
                    
                </div>
            </div>
        </div>
        <?php include("sm_footer.php"); ?>
 <script src="<?php echo $url; ?>assets/js/vendor/jquery-3.2.1.min.js"></script>
        <script src="<?php echo $url; ?>assets/js/popper.min.js"></script>
        <script src="<?php echo $url; ?>assets/js/bootstrap.min.js"></script>
        <script src="<?php echo $url; ?>assets/js/plugins.js"></script>        
        <script src="<?php echo $url; ?>assets/js/main.js"></script>
    </body>
</html>
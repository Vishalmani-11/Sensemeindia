<h1>Return Policy – SenseMe India</h1>

<p>We offer a 7-day return policy from the date of delivery (the day the customer receives the product).</p>

<h3>Eligibility for Return</h3>
<ul>
<li>The product must be unused and unopened</li>
<li>The seal must be intact</li>
<li>The product should be in original condition</li>
</ul>

<h3>Non-returnable Items</h3>
<ul>
<li>Opened or used essential oils</li>
<li>Products damaged due to misuse</li>
</ul>

<h3>Return Process</h3>
<p>Customers must contact us within 7 days of delivery with order details and reason for return.</p>

<h3>Shipping Charges</h3>
<p>Return shipping cost will be borne by the customer.</p>

<h3>Refund</h3>
<p>Refund will be processed after inspection of the returned product.</p>
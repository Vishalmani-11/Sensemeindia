<?php include "smadmin/function/config.php"; 
include "smadmin/db/db_connect.php"; 
include "smadmin/function/function.php"; 
?>
<!doctype html>
<html class="no-js" lang="en">
   <head>
       <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-PJDLLCD');</script>
<!-- End Google Tag Manager -->
       <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-S72J9WT5RK"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-S72J9WT5RK');
</script>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>View Cart | SenseMe India</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Favicon -->
        <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.png">

        <!-- All css here -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/css/font-awesome.min.css">
        <link rel="stylesheet" href="assets/css/ie7.css">
        <link rel="stylesheet" href="assets/css/plugins.css">
        <link rel="stylesheet" href="assets/css/style.css">
        <script src="assets/js/vendor/modernizr-3.5.0.min.js"></script>

<script language="javascript">


/////////////////////////////////////////////
function updateqty(id,action)
{
var qty = $("#cqty"+id).val();	
 var url = "cartsingle.php";
   $.ajax({
     type: "POST",
     url: url,
     data: { id:id, caction:action, qty:qty},
     success: function(data)
     { 
		 location.reload();
     }               
   }); 

  return false;
}    

////////////////////////////////////////////////
function remove(id,action)
{
 var url = "cartsingle.php";
   $.ajax({
     type: "POST",
     url: url,
     data: { rid:id, caction:action},
     success: function(data)
     { 
		 location.reload();
     }               
   }); 

  return false;
}
	</script>
        
<!-- Facebook Pixel Code -->
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '327668741988781');
  fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
  src="https://www.facebook.com/tr?id=327668741988781&ev=PageView&noscript=1"
/></noscript>
<!-- End Facebook Pixel Code -->       
    </head>
    <body>
        <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-PJDLLCD"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
  <div id="loadAjax" class="ui-front loader ui-widget-overlay bg-gray opacity-50" style="display:none">
           <img src="assets/img/loader-light.gif" alt="">
        </div>
        
         <?php include("sm_header.php"); ?>
        <!-- Breadcrumb Area End -->
        <!-- Cart Area Start -->
        <div class="cart-area table-area pt-110 pb-95 mt-50">
            
            <div class="container"> 
                <h3 class="green pb-10"><strong>Cart details</strong></h3>
             <?php 
                $sn = 0;
		if(isset($_SESSION['cartsingle'])&&count($_SESSION['cartsingle'])!=0)
	{ 
            $sn++;
		?>
            
            <div class="table-responsive">
                    <table class="table product-table text-center">
                                    <thead>
                                        <tr>
                                            <th class="table-remove" width="5%">S.No</th>
                                            <th class="table-remove"width="10%">remove</th>
                                <th class="table-image">image</th>
                                <th class="table-p-name" width="30%">product</th>
                                <th class="table-p-price">price</th>
                                <th class="table-p-qty">quantity</th>
                                <th class="table-total">total</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        
        <?php 
							
							$no =0;
		 	 			  $totalcost=0;  
			
						  			if(isset($_SESSION['cartsingle']))
				                  { 
  						    if(count($_SESSION['cartsingle'])!=0)
							{
								$no = count($_SESSION['cartsingle']);
							       foreach($_SESSION['cartsingle'] as $id=>$value)
								  {
									   
									   /////////////////////////////////
								  
$scquery = "SELECT t1.*, t2.name, t6.name as psize FROM bb_products_stock as t1 INNER JOIN bb_products as t2 ON t1.parent_id = t2.id INNER JOIN bb_sizes as t6 ON t1.size = t6.id WHERE t1.id = ?";
	
if(!$scstmt = $con->prepare($scquery))
{
	echo $error = "product data listing execution failed!".$con->error;			
}

 if(!$scstmt->bind_param('i',$id))
 {
 	echo	$error = "product data listing execution failed!".$con->error;			
 }
 
 if(!$scstmt->execute())
	{
	echo $error = "product data deletion execution failed!".$con->error;		

	}
	
		if(!$scresult = $scstmt->get_result())
		{
			echo $error = "cart data listing execution failed!".$con->error;					
		}
		
		if(!$prdata = $scresult->fetch_assoc())
		{
			echo $error = "cart data listing execution failed!".$con->error;					
		}
		
									   ?>                                        
                                        <tr>
                                            <td class="table-remove"><?php echo $sn; ?></td>
                                           <td class="table-remove"><span style="cursor:pointer !important" onClick="remove('<?php echo $id; ?>', 'remove')"><i class="fa fa-trash-o"></i></span></td>
                                            <td class="table-image"><a href="javascript:;"><img src="smadmin/<?php echo $prdata['pic1']; ?>" alt="<?php echo $prdata['name'];?>" width="25%"></a></td>
                                            <td class="table-p-name"><?php echo $prdata['name'];?><p><?php echo "Size: ".$prdata['psize'];?></p></td>
                                            <td class="table-p-price"><p>&#x20b9; <?php echo $prdata['price']; ?></p></td>
                                            <td class="table-p-qty"><input min="1" max="100" value="<?php echo $value;?>" type="number" id="cqty<?php echo $id; ?>" onChange="updateqty('<?php echo $id; ?>', 'update')"></td>
                                            <td class="table-total"><p>&#x20b9; <?php echo currencyIndia($total = $value * $prdata['price']);?></p></td>
                                        </tr>
                                        
                                        <?php 
									   $totalcost += $total; 
								   }
							}
									}
			//$_SESSION['postage'] =  $postage;
			//$_SESSION['totalvalue'] =  $totalcost + $postage;
			//$gst = (15*$totalcost)/100; 
			//$_SESSION['gst'] =  $gst;
			$_SESSION['total'] =  $totalcost;
			$_SESSION['totalitems'] = count($_SESSION['cartsingle']);	
					?>				   
                                    </tbody>
                                </table>   
                            </div>  
            
               
           
        </div>
            <div class="container">
                <div class="table-total-wrapper d-flex justify-content-end pt-60">
                    <div class="table-total-content">
                        <h2>Cart totals</h2>
                        <div class="table-total-amount">
                            <div class="single-total-content d-flex justify-content-between">
                                <span>Subtotal</span>
                                <span class="c-total-price">&#x20b9; <?php echo $totalcost;?></span>
                            </div>
                            <div class="single-total-content d-flex justify-content-between">
                                <span>Shipping</span>
                                <span class="c-total-price">Free*</span>
                            </div>
                            <div class="single-total-content d-flex justify-content-between">
                                <span>Total</span>
                                <span class="c-total-price">&#x20b9; <?php echo $totalcost; ?></span>
                            </div>
                            <a href="checkout-action.php?action=checkout">Proceed to Buy</a>
                            
                            <div class="product-tag-cat mt-20">
                                    <div class="single-tag-cat">
                                        <span class="p-d-title justify-content-center">*Free Delivery within India | GST included <br>
<span class="green_text">20% FLAT additional offer on first order!</span><br>
 Discount will be applied automatically at checkout page</span> 
                                    </div>
                                
                               
                                </div>
                            
                        </div>
                    </div>
                </div>
            </div>
                     
            
            <?php } else { echo "<h3>No products in cart. Let's add some to buy.</h3>"; } ?>
        </div>
        <?php include("sm_footer.php"); ?>
        <!-- Footer Area End -->
        
        <!-- QUICKVIEW PRODUCT -->
        
        <!-- END QUICKVIEW PRODUCT -->
        
        <!-- All js here -->
        <script src="assets/js/vendor/jquery-3.2.1.min.js"></script>
        <script src="assets/js/popper.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/plugins.js"></script>
        <script src="assets/js/ajax-mail.js"></script>
        <script src="assets/js/main.js"></script>
    </body>
</html>
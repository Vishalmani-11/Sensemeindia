<script language="javascript">

$(document).ready(function(){
 
    var getUrlParameter = function getUrlParameter(sParam) {
    var sPageURL = window.location.search.substring(1),
        sURLVariables = sPageURL.split('&'),
        sParameterName,
        i;

    for (i = 0; i < sURLVariables.length; i++) {
        sParameterName = sURLVariables[i].split('=');

        if (sParameterName[0] === sParam) {
            return typeof sParameterName[1] === undefined ? true : decodeURIComponent(sParameterName[1]);
        }
    }
   // return false;
};
    
var msg = getUrlParameter('msg');
    if(msg=='cartview')
        {
        $(".overlay").fadeIn();   
    $(".cart-slide-menu").toggleClass("slide-right");
            $(".overlay").fadeOut(); 
           
        }
    
    
});
    

/////////////////////////////////////////////
function updateqty(id,action)
{
var qty = $("#cqty"+id).val();	
 var url = "<?php echo $url; ?>cartsingle.php";
   $.ajax({
     type: "POST",
     url: url,
     data: { id:id, caction:action, qty:qty},
        beforeSend: function(){
            $(".overlay").fadeIn(); 
     //$(elt).html("adding to cart");
   },   
     success: function(data)
     { 
         window.location.search += '&msg=cartview';
		// location.reload();
     }               
   }); 

  return false;
}    
////////////////////////////////////////////////////////////////////////
   function continue_shopping()
    {
        $(".cart-slide-menu").toggleClass("slide-right");
    }
/////////////////////////////////////////////////////////////////////////
	function addqtys(id, action)
{
    
var qty = $("#cqty"+id).val();
	qty = ++qty;
 var url = "<?php echo $url; ?>cartsingle.php";
   $.ajax({
     type: "POST",
     url: url,
     data: { id:id, caction:action, qty:qty},
       beforeSend: function(){
            $(".overlay").fadeIn(); 
     //$(elt).html("adding to cart");
   },   
       complete: function(){
     //$(elt).html("Added to cart");
   },
       
     success: function(data)
     { 
     //    $(".overlay").fadeIn();          
		  window.location.search += '&msg=cartview';
     }               
   }); 

  return false;
}
///////////////////////////////////////////////////////////////////////
function remvqtys(id,action)
{
    
var qty = $("#cqty"+id).val();
	qty = ++qty;
 var url = "<?php echo $url; ?>cartsingle.php";
   $.ajax({
     type: "POST",
     url: url,
     data: { id:id, caction:action, qty:qty},
         beforeSend: function(){
            $(".overlay").fadeIn(); 
     //$(elt).html("adding to cart");
   },
     success: function(data)
     { //$(".overlay").fadeIn();          
		  window.location.search += '&msg=cartview';
     }               
   }); 

  return false;
}    
////////////////////////////////////////////////
    
function remove(id,action)
{
 var url = "<?php echo $url; ?>cartsingle.php";
   $.ajax({
     type: "POST",
     url: url,
     data: { rid:id, caction:action},
        beforeSend: function(){			
            $(".overlay").fadeIn();      
   },   
     success: function(data)
     { //$(".overlay").fadeIn();          
          window.location.search += '&msg=cartview';             
		// location.reload();
     },
	   error: function (jqXHR, exception) {
        var msg = '';
        if (jqXHR.status === 0) {
            msg = 'Not connect.\n Verify Network.';
        } else if (jqXHR.status == 404) {
            msg = 'Requested page not found. [404]';
        } else if (jqXHR.status == 500) {
            msg = 'Internal Server Error [500].';
        } else if (exception === 'parsererror') {
            msg = 'Requested JSON parse failed.';
        } else if (exception === 'timeout') {
            msg = 'Time out error.';
        } else if (exception === 'abort') {
            msg = 'Ajax request aborted.';
        } else {
            msg = 'Uncaught Error.\n' + jqXHR.responseText;
        }
        alert(msg);
    },
   }); 

  return false;
}
	</script>
<script type="text/javascript"> 
     
     function showbanner(mcid,image)
{
    var id = mcid;
     var img = image;    
    //alert(img);
    $("#img"+id).attr('src', img);
    
}

    function hidebanner(mcid,image)
{
    var id = mcid;
    var img = image;
    $("#img"+id).attr('src', img);
    
}


$(document).ready(function(){
    $('.search-box input[type="text"]').on("keyup input", function(){
        
        if (location.hostname === "localhost" || location.hostname === "127.0.0.1")
    {
        var host = window.location.origin+'/sm';        
    }
    else
    {   var host = window.location.origin; 
         
        }
        
        var urlpath = host+'/store-search.php';
        /* Get input value on change */
        var inputVal = $(this).val();
        var resultDropdown = $(this).siblings(".result");
        if(inputVal.length){
            $.get(urlpath, {term: inputVal}).done(function(data){
                // Display the returned data in browser
                resultDropdown.html(data);
            });
        } else{
            resultDropdown.empty();
        }
    });
    
    // Set search input value on click of result item
    $(document).on("click", ".result p", function(){
        $(this).parents(".search-box").find('input[type="text"]').val($(this).text());
        $(this).parents('form').submit();
        $(this).parent(".result").empty();
        
        
    });
});
</script>

<?php
$mquery = "SELECT id, name, banner FROM bb_categories WHERE active = ? ORDER BY id ASC";

if(!$mstmt = $con->prepare($mquery))
{
	echo "prepare failed: (" . $con->errno . ") " . $con->error;	exit();
}
$menu_active = 1;
 if ( !$mstmt->bind_param( 'i', $menu_active) ) {
            echo $error = "Product data listing preparation failed!" . $con->error;
            exit();
        }

	if(!$mstmt->execute())
	{
		$error = "categories list failed!".$con->error;		exit();
		
	}

		if(!$mstmt->store_result())
		{
			$error = "categories list failed!".$con->error;		exit();			
		}
	
		$mnum_of_rows = $mstmt->num_rows;

if($mnum_of_rows==0)
{
	$terror = "No categories found";		
}

?>

<header class="header-area header-two header-sticky mobile-sticky">
            <div class="header-container">
                <div class="row">
                   
                    <div class="col-lg-2 col-sm-12">
                         <div class="left menu-icon">
                            
                <a href="#" id="hamburger-icon" title="Menu">
                   <span class="fa fa-bars"></span>
                </a>
    
    </div>
                        <div class="logo text-center">
                          <img id="dlogo" src="<?php echo $url; ?>assets/img/logo/logo.png" alt="SenseMe India" fetchpriority="high">
                          <img id="mlogo" src="<?php echo $url; ?>assets/img/logo/mlogo.png" alt="SenseMe India">
                        </div>
                                                    
      <div id="mheader-content" class="header-content">
                           
                            
                               
         <?php if(isset($_SESSION['userSession'])&&$_SESSION['userSession']!=false)
{
	?>
		
                            <div class="cart-wrapper">
                                
                                <a href="<?php echo $url; ?>users/" class="text-white font13">My Account</a>
                            </div>
                            
                            <?php } else {  ?>
                            
                              <div class="cart-wrapper">
                                
                                <a href="<?php echo $url; ?>users/"><i class="fa fa-user"></i></a>
                            </div>
                            <?php } ?>
                            
                            <div class="cart-wrapper">
                                <a href="#" class="cart_view">
                                    <i class="fa fa-shopping-cart"></i>
                                    <span class="busket-amount"><?php
		$cartno = 0;
		if(isset($_SESSION['cartsingle'])) 
		{
			$cartno = count($_SESSION['cartsingle']);
		}
			echo $cartno;	
		?> </span>
                                    </a>
                               
                                </div>
                        </div>
                        
                        
                    </div>
                    <div class="col-lg-8 display-none-md display-none-xs">
                        <div class="ht-main-menu">
                            <nav class="d-flex justify-content-center">
                                <ul>
                                     <li><a href="<?php echo $url; ?>">Home</a></li>
                                    
                                      <?php      
			if(isset($merror))
			{
				?>
			     <option value=""><?php echo $merror; ?></option>	
			<?php 
						} 
						else
						{
			?>   
                  <?php 
                            $sn = 0;
	$mstmt->bind_result($mcid, $mcname, $mbanner);
	while ($mstmt->fetch()) 
	{
        $sn = $sn + 1;
		$mcname_url = URL_trim($mcname);
		
	?>          
                                     <li><a href="javascript:;"><?php echo $mcname; ?> <i class="fa fa-angle-down"></i></a>
                                        <ul class="ht-mega-menu">
                                             <li>
                                                <ul>
                  
       <?php
		
    ////////////////////////////////////////sub category////////////////////////////////////////////
        
    $scquery = "SELECT id, name, banner FROM bb_sub_categories WHERE mc_id = ? AND active = ? ORDER BY id ASC";

if(!$scstmt = $con->prepare($scquery))
{
	echo "prepare failed: (" . $con->errno . ") " . $con->error;	exit();
}
	if(!$scstmt->bind_param("ii", $mcid, $menu_active))
{
	echo "Param pass failed: (" . $con->errno . ") " . $con->error;exit();
}

	if(!$scstmt->execute())
	{
		$error = "sub categories list failed!".$con->error;		exit();
		
	}

		if(!$scstmt->store_result())
		{
			$error = "sub categories list failed!".$con->error;	exit();				
		}
	
		$scnum_of_rows = $scstmt->num_rows;

if($scnum_of_rows==0)
{
    ?>
                      
	 <li> <a href="javascript:;">No sub categories found!</a></li> </ul>
                      <?php
} else {
    
	$scstmt->bind_result($scid, $scname, $banner);
	while ($scstmt->fetch()) 
	{   
		$scname_url = URL_trim($scname);
		
        ?>
                                         
                      <li> <a id="link<?php echo $scid; ?>" 
							  href="<?php echo $url; ?><?php echo $mcname_url; ?>/<?php echo $scname_url; ?>/<?php echo $mcid; ?>/<?php echo $scid; ?>/" 
							  title="<?php echo $scname; ?>" onMouseOver="showbanner('<?php echo $mcid; ?>', '<?php echo $url; ?>smadmin/<?php echo $banner; ?>')" onMouseOut="hidebanner('<?php echo $mcid; ?>', '<?php echo $url; ?>assets/img/banner/menu-<?php echo $mcid; ?>.jpg')"> <i class="glyph-icon icon-laptop"></i><?php echo $scname; ?></a></li>
                      
<?php
        
        
    }
    ?>     </ul>
                                            </li>
                                    
                                    
                                    <li>
                                                <ul>
                                                     
                                                    <li><a href="javascript:;"><img id="img<?php echo $mcid; ?>" src="<?php echo $url; ?>assets/img/<?php echo $mbanner; ?>" alt=""></a></li>
                                           </ul>
                                            </li>
                                    
                                    
            </ul>
        <?php 
    
}
        
////////////////////////////////////////////////////////////////////////////////////////////////////////        
    } 
                         } 
     	?>            

                           <li><a href="javascript:;">Contact <i class="fa fa-angle-down"></i></a>
                                        <ul>
                                            <li><a href="<?php echo $url; ?>contact-us/">For Bulk Purchase</a></li>
                                            <li><a href="<?php echo $url; ?>contact-us/">For Own Labeling</a></li>
                                            <li><a href="<?php echo $url; ?>contact-us/">For Signature Items</a></li>
                                            
                                        </ul>
                                    </li>
                                   
                                </ul>
                            </nav>
                        </div>
                    </div>
                    <div class="col-lg-2 col-sm-12">
                         <div id="msearch" class="header-content d-flex justify-content-end dhide">
                            <div class="search-wrapper">
                                <form action="<?php echo $url; ?>product-details.php" method="post" id="searchform1" class="search-form search-box active" target="_blank">
                                    <input type="text" name="product_name" placeholder="Search entire store ..." autocomplete="off">
                                    <input type="hidden" name="live_search" value="1">
                                    <button type="submit"><i class="fa fa-search searchicon"></i></button>
                                    <div class="result"></div>
                                </form>
                            </div>
                        </div>
                        <div class="header-content d-flex justify-content-end mhide">
                            <div class="search-wrapper">
                                <a href="#" title="Search products"><span class="icon icon-Search"></span></a>
                                <form action="<?php echo $url; ?>product-details.php" method="post" id="searchform" class="search-form search-box" target="_blank">
                                    <input type="text" name="product_name" placeholder="Search entire store..." autocomplete="off">
                                    <input type="hidden" name="live_search" value="1">
                                    <button type="submit">Search</button>
                                    <div class="result"></div>
                                </form>
                            </div>
                            
                            
                            <div class="cart-wrapper">
                                 <a href="#" class="cart_view" title="View Cart">
                                    <i class="icon icon-FullShoppingCart font-black"></i>
                                    <span class="busket-amount"><?php
		$cartno = 0;
		if(isset($_SESSION['cartsingle'])) 
		{
			$cartno = count($_SESSION['cartsingle']);
		}
			echo $cartno;	
		?> </span>
                                    </a>
                               
                                </div>
                        </div>
                    </div>
                </div>
            </div>

            
        </header>
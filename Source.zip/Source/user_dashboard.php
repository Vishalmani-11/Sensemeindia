<?php
include "session_user.php"; 
include "../smadmin/function/config.php";  
include "../smadmin/db/db_connect.php"; 
require_once '../smadmin/admin/class.user_2.php';
include "../smadmin/function/function.php";
////////////////////////////////update profile//////////////////////////////////////
if(isset($_POST['update_profile']))
{
extract($_POST);	

    $cid = $_SESSION['userSession'];     
    $address = secure_input($con,$address); 
    $city = secure_input($con,$city); 
    $country = secure_input($con,$country); 
    $zipcode = secure_input($con,$zipcode); 
    
    $up_query = "UPDATE bb_users SET address = ?, city = ?, country = ?, zipcode = ? WHERE id = ?";
    
if(!$up_stmt = $con->prepare($up_query))
{
	echo $error = "preparation failed!".$con->error; exit();
}

if(!$up_stmt->bind_param("ssssi", $address, $city, $country, $zipcode, $cid))
{
	echo "Param pass failed: (" . $con->errno . ") " . $con->error; exit();
}
	
	if(!$up_stmt->execute())
	{
		echo $error = "Profile update failed!".$con->error;		 exit();
		
	}
    else
    {
         $success = "<strong>Profile updated successfully!</strong>";
    header("location:user_dashboard.php?&success=".$success);
    }
}
//////////////////////delete from wishlist////////////////////////
if(isset($_GET['wishlist_id'])&&$_GET['wishlist_id']!=''&&isset($_GET['action'])&&$_GET['action']=='remove')
{
extract($_GET);	

    $wishlist_id = secure_input($con,$wishlist_id); 
    
$rw_query = "DELETE FROM wishlist WHERE id = ?";

    if(!$rw_stmt = $con->prepare($rw_query))
{
	echo "Prepare failed: (" . $con->errno . ") " . $con->error; exit();
}

if(!$rw_stmt->bind_param("i", $wishlist_id))
{
	echo "Param pass failed: (" . $con->errno . ") " . $con->error; exit();
}

if(!$rw_stmt->execute()) {
    
	$error = "wishlist update failed!".$con->error; exit();   
    
}
else
{
    $success = "<strong>Product removed from your wishlist</strong>";
    header("location:user_dashboard.php?&success=".$success);
}

} 
//////////////////////cancel request////////////////////////
if(isset($_GET['id'])&&$_GET['id']!=''&&isset($_GET['action'])&&$_GET['action']=='cancel')
{
extract($_GET);	

    $order_id = secure_input($con,$id); 
    
    $status = "Cancellation Requested";
    
    $caquery = "UPDATE bb_orders SET orderstatus = ? WHERE id = ?";
    
if(!$castmt = $con->prepare($caquery))
{
	echo $error = "categories data listing preparation failed!".$con->error; exit();
}

if(!$castmt->bind_param("si", $status, $order_id))
{ 
	echo "Param pass failed: (" . $con->errno . ") " . $con->error; 	 exit();
}
	
	if(!$castmt->execute())
	{
		echo $error = "categories data listing execution failed!".$con->error;		 exit();
		
	}
    else
    {
   
        $ostatus = $status;
///////////////////////////////mail/////////////////////////////////////////////////////
	$message = "";
	$message = "
	<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>
<html xmlns='http://www.w3.org/1999/xhtml'>
<head>
<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
<title>Your have requested cancellation for order #BB".$id."</title>
<style type='text/css'>
body {
	padding-top: 0 !important;
	padding-bottom: 0 !important;
	padding-top: 0 !important;
	padding-bottom: 0 !important;
	margin: 0 !important;
	width: 100% !important;
	-webkit-text-size-adjust: 100% !important;
	-ms-text-size-adjust: 100% !important;
	-webkit-font-smoothing: antialiased !important;
}
.tableContent img {
	border: 0 !important;
	display: block !important;
	outline: none !important;
}
a {
	color: #382F2E;
}
p, h1 {
	color: #382F2E;
	margin: 0;
}
p {
	text-align: left;
	color: #999999;
	font-size: 14px;
	font-weight: normal;
	line-height: 19px;
}
a.link1 {
	color: #382F2E;
}
a.link2 {
	font-size: 16px;
	text-decoration: none;
	color: #ffffff;
}
h2 {
	text-align: left;
	color: #222222;
	font-size: 19px;
	font-weight: normal;
}
div, p, ul, h1 {
	margin: 0;
}
.bgBody {
	background: #ffffff;
}
.bgItem {
	background: #ffffff;
}

@media only screen and (max-width:480px) {
table[class='MainContainer'], td[class='cell'] {
	width: 100% !important;
	height: auto !important;
}
td[class='specbundle'] {
	width: 100% !important;
	float: left !important;
	font-size: 13px !important;
	line-height: 17px !important;
	display: block !important;
	padding-bottom: 15px !important;
}
td[class='spechide'] {
	display: none !important;
}
img[class='banner'] {
	width: 100% !important;
	height: auto !important;
}
td[class='left_pad'] {
	padding-left: 15px !important;
	padding-right: 15px !important;
}
}

@media only screen and (max-width:540px) {
table[class='MainContainer'], td[class='cell'] {
	width: 100% !important;
	height: auto !important;
}
td[class='specbundle'] {
	width: 100% !important;
	float: left !important;
	font-size: 13px !important;
	line-height: 17px !important;
	display: block !important;
	padding-bottom: 15px !important;
}
td[class='spechide'] {
	display: none !important;
}
img[class='banner'] {
	width: 100% !important;
	height: auto !important;
}
.font {
	font-size: 18px !important;
	line-height: 22px !important;
}
.font1 {
	font-size: 18px !important;
	line-height: 22px !important;
}
}
</style>

</head>
<body paddingwidth='0' paddingheight='0'   style='padding-top: 0; padding-bottom: 0; padding-top: 0; padding-bottom: 0; background-repeat: repeat; width: 100% !important; -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; -webkit-font-smoothing: antialiased;' offset='0' toppadding='0' leftpadding='0'>
<table bgcolor='#ffffff' width='100%' border='0' cellspacing='0' cellpadding='0' class='tableContent' align='center'  style='font-family:Helvetica, Arial,serif;'>
  <tbody>
    <tr>
      <td><table width='600' border='0' cellspacing='0' cellpadding='0' align='center' bgcolor='#ffffff' class='MainContainer'>
          <tbody>
            <tr>
              <td><table width='100%' border='0' cellspacing='0' cellpadding='0'>
                  <tbody>
                    <tr>
                      <td valign='top' width='40'>&nbsp;</td>
                      <td><table width='100%' border='0' cellspacing='0' cellpadding='0'>
                          <tbody>
                            <!-- =============================== Header ====================================== -->
                            <tr>
                              <td height='30' class='spechide'></td>
                              
                              <!-- =============================== Body ====================================== --> 
                            </tr>
                            <tr>
                              <td class='movableContentContainer ' valign='top'><div class='movableContent' style='border: 0px; padding-top: 0px; position: relative;'>
                                  <table width='100%' border='0' cellspacing='0' cellpadding='0'>
                                    <tbody>
                                      <tr>
                                        <td height='35'></td>
                                      </tr>
                                      <tr>
                                        <td><table width='100%' border='0' cellspacing='0' cellpadding='0'>
                                            <tbody>
                                              <tr>
                                                <td valign='top' align='center' style='text-align:center;' class='specbundle'><div class='contentEditableContainer contentTextEditable'>
                                                    <div class='contentEditable'>
                                                      <p><img src='https://sensemeindia.com/assets/img/logo/logo.png' alt='Visit SenseMe India'/> </p>
                                                    </div>
                                                  </div></td>
                                              </tr>
                                              <tr>
                                                <td height='35'></td>
                                              </tr>
                                              <tr>
                                                <td valign='top' class='specbundle'><div class='contentEditableContainer contentTextEditable'>
                                                    <div class='contentEditable'>
                                                      <p style='text-align:left;margin:0;font-family:Georgia,Time,sans-serif;font-size:26px;color:#222222;'><span class='specbundle2'><span class='font1'>Dear ".$_SESSION['userName'].", We have received your order #SM".$id." cancellation request&nbsp;</span></p>
                                                    </div>
                                                  </div></td>
                                              </tr>
                                            </tbody>
                                          </table></td>
                                      </tr>
                                    </tbody>
                                  </table>
                                </div>
                                <div class='movableContent' style='border: 0px; padding-top: 0px; position: relative;'>
                                  <table width='100%' border='0' cellspacing='0' cellpadding='0' align='center'>
                                    <tr>
                                      <td height='25'></td>
                                    </tr>
                                    <tr>
                                      <td align='left'><div class='contentEditableContainer contentTextEditable'>
                                          <div class='contentEditable' align='left'>
                                            <h2>Greetings from SenseMe India!</h2>
                                          </div>
                                        </div></td>
                                    </tr>
                                    <tr>
                                      <td align='left'><div class='contentEditableContainer contentTextEditable'>
                                          <div class='contentEditable' align='left'>
                                            <p >";
	
	if($ostatus=='Shipped')
	{
		$message .= "We would like to inform you that We have shipped your order item(s) to your address! Please find your order items(s) details as below. <br />
                                              <br />";
	}
	elseif($ostatus=='Delivered')
	{
	$message .= "We would like to inform you that We have delivered your order item(s) to your address! Please find your order items(s) details as below. <br />
                                              <br />";
	}
    elseif($ostatus=='Cancellation Requested')
	{
	$message .= "We would like to inform you that We have received your cancellation request for your order. We will get back to you within 48 hrs! Please login to our website for more details on your order. <br />
                                              <br />";
	}
		
	if($sdate!="")
	{
	 	$message .= "<strong>Shipped Date: </strong> ".date('l - dS M, Y', strtotime($sdate))."<br>
";
	}
	elseif($esdate!="")
	{
			$message .= "<strong>Shipped Date: </strong> ".date('l - dS M, Y', strtotime($esdate))."<br>
";
		
	}
	
	if($ostatus=="Delivered"&&$ddate!="")
	   {
	$message .= "<strong>Delivered Date: </strong> ".date('l - dS M, Y', strtotime($ddate))."<br>";	   
	   }
	elseif($ostatus=="Delivered"&&$eddate!="")
	{
		$message .= "<strong>Delivered Date: </strong> ".date('l - dS M, Y', strtotime($eddate))."<br>";	   
	}
	
	
		if($courier!="")
	{
	 	$message .= "<strong>Courier name: </strong> ".$courier."<br>";
	}
	
    if($ccode!="")
	{
	 	$message .= "<strong>Courier Tracking: </strong> <a href='".$ccode."' target='_blank'>Track status</a><br>";
	}
	
    
		$message .= "
											  <br><br>

                                              For any queries kindly call us on: +91 9150870543. <br />
                                              <br />
                                              Thank you for your order. </p>
                                          </div>
                                        </div></td>
                                    </tr>
                                    <tr>
                                      <td height='15'></td>
                                    </tr>
                                  ";
									
								$message .= "
                                  </table>
                                </div>
                                <table width='100%' border='0' cellspacing='0' cellpadding='0'>
                                  <tbody>
                                    <tr>
                                      <td height='25'></td>
                                    </tr>
                                    <tr>
                                      <td><table width='100%' border='0' cellspacing='0' cellpadding='0'>
                                          <tbody>
                                            <tr>
                                              <td valign='top' class='specbundle'><div class='contentEditableContainer contentTextEditable'>
                                                  <div class='contentEditable' align='center'>
                                                    <p  style='text-align:left;color:#CCCCCC;font-size:12px;font-weight:normal;line-height:20px;'> <span style='font-weight:bold;'>Phone: +61 123456789</span> <br>
                                                      <a target='_blank' href='https://sensemeindia.com'>www.sensemeindia.com</a><br>
                                                    </p>
                                                  </div>
                                                </div></td>
                                              <td valign='top' width='30' class='specbundle'>&nbsp;</td>
                                              <td valign='top' class='specbundle'><table width='100%' border='0' cellspacing='0' cellpadding='0'>
                                                  <tbody>
                                                    <tr>
                                                      <td valign='top' width='52'><div class='contentEditableContainer contentFacebookEditable'>
                                                          <div class='contentEditable'> </div>
                                                        </div></td>
                                                      <td valign='top' width='16'>&nbsp;</td>
                                                      <td valign='top' width='52'></td>
                                                    </tr>
                                                  </tbody>
                                                </table></td>
                                            </tr>
                                          </tbody>
                                        </table></td>
                                    </tr>
                                    <tr>
                                      <td height='88'></td>
                                    </tr>
                                  </tbody>
                                </table>
                                </div>
                                
                                </td>
                            </tr>
                          </tbody>
                        </table></td>
                      <td valign='top' width='40'>&nbsp;</td>
                    </tr>
                  </tbody>
                </table></td>
            </tr>
          </tbody>
        </table></td>
    </tr>
  </tbody>
</table>
</body>
</html>
";		
	$from = "order@sensemeindia.com";
	$to = $email;
	$subject = "Your order #SM".$id." is ".$ostatus."!";							
	$oscuccess = send_html_mail($from,$to,$message,$subject);
	
            $success= "order cancellation request sent successfully! <br>
We will get back to you within 48 hrs.";
        header("location:user_dashboard.php?success=".$success);
    }

} 

/////////////////////////////////listing orders//////////////////////////////////////////

$query = "SELECT id, mc_gross, titems, orderdate, orderstatus FROM bb_orders WHERE cid = ? AND order_placed = ? ORDER BY orderdate DESC";

$cid = $_SESSION['userSession'];

$order_flag = 1;

if(!$ostmt = $con->prepare($query))
{
	echo $error = "categories data listing preparation failed!".$con->error; exit();
}

if(!$ostmt->bind_param("ii", $cid, $order_flag))
{
	echo "Param pass failed: (" . $con->errno . ") " . $con->error; exit();
}
	
	if(!$ostmt->execute())
	{
		echo $error = "categories data listing execution failed!".$con->error;	 exit();	
		
	}
		if(!$ostmt->store_result())
		{
			echo $error = "categories data listing execution failed!".$con->error;	 exit();				
		}
	
	$onum_of_rows = $ostmt->num_rows;

	if($onum_of_rows==0)
{
	$onum_error = "No orders found!";		
}
/////////////////////////////////////////list wishlist///////////////////////////    
  
$cw_query = "SELECT t1.id, t1.pid, t1.price, t1.image, t3.name from wishlist as t1 INNER JOIN bb_products_stock as t2 ON t1.pid = t2.id INNER JOIN bb_products as t3 ON t2.parent_id = t3.id WHERE t1.cid = ?";    

if(!$cw_stmt = $con->prepare($cw_query))
{
	echo "prepare failed:" . $cw_stmt->error;	exit();
}

	if(!$cw_stmt->bind_param("i", $cid))
{
	echo "Param pass failed: (" . $con->errno . ") " . $con->error; exit();
}   

	if(!$cw_stmt->execute())
	{
		echo $error = "wishlist listing failed!".$cw_stmt->error;		exit();
		
	}

		if(!$cw_stmt->store_result())
		{
			echo $error = "categories list failed!".$con->error;	exit();				
		}
	
	$cw_num_of_rows = $cw_stmt->num_rows; 

if($cw_num_of_rows==0)
{
	$cw_error = "No products found in your wishlist! Start adding some!";			
}

/////////////////////////////user profile////////////////////////////////////////////
    
$uquery = "SELECT * from bb_users WHERE id = ?";
	
if(!$ustmt = $con->prepare($uquery))
{
	echo "query failed: (" . $con->errno . ") " . $con->error; exit();
}

if(!$ustmt->bind_param("i", $cid))
{
	echo "Param pass failed: (" . $con->errno . ") " . $con->error; exit();
}

	if(!$ustmt->execute())
	{
		echo $error = "child product details execution failed!".$con->error;		 exit();
	}
		if(!$uresult = $ustmt->get_result())
		{
			echo $error = "child product details listing failed!".$con->error;		 exit();			
		}
	 
	 $unum_of_rows = $uresult->num_rows;

if($unum_of_rows==0)
{
	echo $uerror = "Profile details not found"; exit();		
}
else
{
    
    	if(!$user_data = $uresult->fetch_assoc())
		{
			echo $udata = "error".$con->error; exit();
		}
    
}

?>

<!doctype html>
<html class="no-js" lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Customer Dashboard | SenseMe India</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Favicon -->
        <link rel="shortcut icon" type="image/x-icon" href="../assets/img/favicon.png">

        <!-- All css here -->
        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/css/font-awesome.min.css">
        <link rel="stylesheet" href="../assets/css/ie7.css">
        <link rel="stylesheet" href="../assets/css/plugins.css">
        <link rel="stylesheet" href="../assets/css/style.css">
        <script src="../assets/js/vendor/modernizr-3.5.0.min.js"></script>
           <script src="../assets/js/vendor/jquery-3.2.1.min.js"></script>
         <script type="text/javascript">
        
        $(document).ready(function ()
    {
            
        $( "#close_details" ).click(function() {
 $( "#view_order_details" ).fadeOut();
});
       
            
  });
                       
    </script>
    
        
    </head>
    <body>
        
        
  <div id="loadAjax" class="ui-front loader ui-widget-overlay bg-gray opacity-50" style="display:none">
           <img src="../assets/img/loader-light.gif" alt="">
        </div>
    
        
        <!-- Header Area Start -->
         <?php include("../sm_header.php"); ?>
        <div class="breadcrumb-area bg-12 text-center">
            <div class="container">
                <h1><span class="green">Customer Login</span></h1>
                <nav aria-label="breadcrumb">
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">My Account</li>
                    </ul>
                </nav>
            </div>
        </div>
        
          <div class="wishlist-area table-area pt-80 pb-95">
            <div class="col-lg-7 col-md-7 offset-3">
        <div class="account_dashboard">
                <div class="row">
                    <div class="col-sm-12 col-md-3 col-lg-3">
                        <!-- Nav tabs -->
                        <div class="dashboard_tab_button">
                            <ul role="tablist" class="nav flex-column dashboard-list">
                                <li><a href="#dashboard" data-toggle="tab" class="nav-link active"><i class="fa fa-chevron-circle-right pr-2"></i> Dashboard</a></li>
                                <li> <a href="#orders" data-toggle="tab" class="nav-link"><i class="fa fa-chevron-circle-right pr-2"></i>Orders</a></li>
                                <li> <a href="#wishlist" data-toggle="tab" class="nav-link"><i class="fa fa-chevron-circle-right pr-2"></i>Wishlist</a></li>
                                <li><a href="#change" data-toggle="tab" class="nav-link"><i class="fa fa-chevron-circle-right pr-2"></i>Change password</a></li>
                                <li><a href="#account-details" data-toggle="tab" class="nav-link"><i class="fa fa-chevron-circle-right pr-2"></i>Account details</a></li>
                                <li><a href="logout.php" class="nav-link"><i class="fa fa-chevron-circle-right pr-2"></i>logout</a></li>
                            </ul>
                        </div>    
                    </div>
                    <div class="col-sm-12 col-md-9 col-lg-9 bg-color">
                        <!-- Tab panes -->
                        <div class="tab-content dashboard_content p-5">
                            <div class="tab-pane fade show active" id="dashboard">
                                <p><?php
                                    
                                    if(isset($_GET['success'])) 
                                        
                                        echo "<h3>".$_GET['success']."</h3><br>";
		{
                                    }
                                    
		$cartno = 0;
		if(isset($_SESSION['cartsingle'])) 
		{
			$cartno = count($_SESSION['cartsingle']);
		}
		if($cartno>0){ echo "<h4>You have ".$cartno." item in your cart, <strong><a href='../checkout.php'>Checkout now</strong></a></h4>"; } else { echo "<strong>You have 0 item in your cart. Start shopping now!</strong>";	}
                                    ?> </p>
 <p>From your account dashboard. you can easily check &amp; view your recent orders</a>, manage your account details such as profile, address and change your password, etc.</a></p>
                            </div>
                
                            <div class="tab-pane fade" id="orders">
                                <h3>Orders</h3>
                                <div>
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>Order</th>
                                                <th>Date</th>
                                                <th>Status</th>
                                                <th>Total</th>
                                                <th>Actions</th>	 	 	 	
                                            </tr>
                                        </thead>
                                        <tbody>
                                            
                                            <?php 
                                            if(isset($onum_error)&&$onum_error!="")
                                            { ?>
                                            
                                            <tr>
                                                <td colspan="5"><?php echo $onum_error; ?></td>
                                                </tr>
                                                
                                        <?php } else { 
	$sn = 0;
	$ostmt->bind_result($id, $cost, $items, $orderdate, $orderstatus);
	while ($ostmt->fetch()) 
	{
			$sn = 	$sn + 1;		
	?>
                                            
                                            <tr>
                                                <td><?php echo $sn; ?></td>
                                                <td><?php echo date('D - dS M, Y', strtotime($orderdate)); ?></td>
                                                <td><span class="success"><?php echo $orderstatus; ?></span></td>
                                                <td>&#x20b9; <?php echo $cost. " (".$items." item)"; ?> </td>
                                                <td>
                                                    <a href="javascript:;" class="view-order-details" id="<?php echo $id; ?>" title="View details">
                                               View
                                                
                                            </a>    
                                                    
                                                    <?php if($orderstatus=="Delivered")
    {
        ?>
 
                                                   | <a href="order_invoice.php?order_id=<?php echo $id; ?>" target="_blank" title="Download Invoice">Download Invoice</a>        <?php } ?>
                                                    
                                                    </td>
                                            </tr>
                                            
                                            
                                            
                                       <?php } } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                
                            <div class="tab-pane fade" id="wishlist">
                                <h3>Your Wishlist</h3>
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th width="35%">Product</th>
                                                <th>Image</th>
                                                <th width="25%">Price</th>
                                                <th width="20%">Action</th>	 	 	 	
                                            </tr>
                                        </thead>
                                        <tbody>
                                            
<?php 
                                            if(isset($cw_error)&&$cw_error!="")
                                            { ?>
                                            
                                            <tr>
                                                <td colspan="4"><?php echo $cw_error; ?></td>
                                                </tr>
                                                
                                        <?php } else { 
	$sn = 0;
	$cw_stmt->bind_result($id, $pid, $price, $image, $name);
	while ($cw_stmt->fetch()) 
	{
			$sn = 	$sn + 1;		
	?>                                            
                                            
                                            
                                            <tr>
                                                <td><?php echo $name; ?></td>
                                                <td><img src="../smadmin/<?php echo $image; ?>" width="50%"></td>
                                                <td>&#x20b9; <?php echo $price; ?> (When added)</td>
                                                <td><a href="../product-details.php?product_id=<?php echo $pid; ?>" target="_blank" class="view" title="View details">View </a> | <a href="user_dashboard.php?wishlist_id=<?php echo $id; ?>&action=remove" title="Remove item" onclick="return confirm('Are you sure you want to remove this item from your wishlist?');">Remove</a>  </td>
                                            </tr>
                                            
      
                                       <?php } } ?>
                                          
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="change">
                                <h3>Change Password </h3>
                                <div class="login">
                                    <div class="login_form_container">
                                        <div class="account_login_form">
                                            <form action="change_password_action.php" method="post" onSubmit="return pacheck()">
                                                 <p>   
                                <label>New Password <span>*</span></label>
                                <input type="password" id="pass11" name="password1" pattern=".{8,}" title="8 characters minimum required" required class="bg-color2">
                             </p>
                             <p>   
                                <label>Re-type New Password <span>*</span></label>
                                <input type="password" id="pass21" name="password2" pattern=".{8,}" title="8 characters minimum required" class="bg-color2">
                             </p>
                                                <div class="save_button primary_btn default_button">
                                                    <button type="submit" class="default-btn-2" name="update_security"> Update </button>
                                                </div>
                                            </form>
                                            
 <script type="text/javascript">

function pacheck()
{	
var pa1 = $('#pass11').val();
var pa2 = $('#pass21').val();

  if(pa1!=""&&pa2!=""&&pa1==pa2)
        {
        return true;
        }
        else
        {
        alert("Passwords not match! please try again!");		
        return false;
        }

}
</script>                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="account-details">
                                <h3>Account details </h3>
                                <div class="login">
                                    <div class="login_form_container">
                                        <div class="account_login_form"><br>

                                            <form id="update-profile" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
                                                                                      <p>               
                                <label><strong>Name:</strong> <?php echo $user_data['fname']." ".$user_data['lname']; ?></label>
                              </p>
                            
                              <p> 
                                <label><strong>Phone No:</strong> <?php echo $user_data['phone']; ?> </label>
                                </p>
                                     <p>              
                                 <label><strong>Street Address</strong>  <span>*</span>(Default for shipping)</label>
                                 <input type="text" name="address" value="<?php echo $user_data['address']; ?>" required class="bg-color2"> </p>
                                
                             <p>   
                                <label><strong>City</strong>  <span>*</span></label>
                                <input type="text" name="city" value="<?php echo $user_data['city']; ?>" required class="bg-color2">
                             </p>
                             <p>   
                                <label><strong>Country</strong>  <span>*</span></label>
                                <input type="text" name="country" value="<?php echo $user_data['country']; ?>" required class="bg-color2">
                             </p>
                                                <label><strong>Zipcode</strong>  <span>*</span></label>
                                 <input type="text" name="zipcode" value="<?php echo $user_data['zipcode']; ?>" required class="bg-color2">
                                                <br>
                                             
                                                <div class="save_button primary_btn default_button">
                                                    <button type="submit" class="default-btn-2" name="update_profile">Update Profile</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                
                
                
                        </div>
                    </div>
                </div>
            </div>
                </div>
        </div>
        
          <?php include("../sm_footer.php"); ?>
        <!-- Footer Area End -->
        <!-- All js here -->
        
        <script src="../assets/js/popper.min.js"></script>
        <script src="../assets/js/bootstrap.min.js"></script>
        <script src="../assets/js/plugins.js"></script>
        <script src="../assets/js/ajax-mail.js"></script>
        <script src="../assets/js/main.js"></script>
    </body>
</html>
<div class="modal" id="view_order_details" tabindex="-1" role="dialog"  aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div id="order-details" class="modal-content">
      <button type="button" id="close_details" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
      <div class="modal_body">
        <div class="container">
          <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
              <div id="show_data">
                
              </div>
            </div>
            
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<script type="text/javascript">
////////////////////////////view order details///////////////////////	
	 $(function() {
		
         $( ".view-order-details" ).click(function() {
			 
			 var cid = $(this).attr("id"); 
             
           $.ajax({  
                url:"fetch_order_details.php",  
                method:"post",  
                data:{cid:cid},
			 beforeSend: function(){
				$('#limage').fadeIn();
			    },
        complete: function(){
				$('#limage').hide();
				},
				success:function(data){  
                //alert(data);
				$('#show_data').html(data);
				$( "#view_order_details" ).fadeIn();
				
                }  
           });  
		   
         });
		 
    });
</script>
 

<?php
include "smadmin/function/config.php"; 
include "smadmin/db/db_connect.php"; 
include "smadmin/function/function.php"; 
require_once 'smadmin/admin/class.user_2.php';

$reg_user = new USER();

if($reg_user->is_logged_in())
{
	$reg_user->redirect('index.php');
}

?>
<!doctype html>
<html class="no-js" lang="en">
   <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Privacy Policy | SenseMe India</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Favicon -->
        <link rel="shortcut icon" type="image/x-icon" href="<?php echo $url; ?>assets/img/favicon.png">

        <!-- All css here -->
        <link rel="stylesheet" href="<?php echo $url; ?>assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo $url; ?>assets/css/font-awesome.min.css">
        <link rel="stylesheet" href="<?php echo $url; ?>assets/css/ie7.css">
        <link rel="stylesheet" href="<?php echo $url; ?>assets/css/plugins.css">
        <link rel="stylesheet" href="<?php echo $url; ?>assets/css/style.css">
	       <link rel="stylesheet" href="<?php echo $url; ?>assets/css/menu/style.css">        
        <script src="<?php echo $url; ?>assets/js/vendor/modernizr-3.5.0.min.js"></script>

<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-WWCJ4NT');</script>
<!-- End Google Tag Manager -->
    </head>
    <body>
        	<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-WWCJ4NT"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
  <div id="loadAjax" class="ui-front loader ui-widget-overlay bg-gray opacity-50" style="display:none">
           <img src="assets/img/loader-light.gif" alt="">
        </div>
        
         <?php include("sm_header.php"); ?>
        <div class="breadcrumb-area bg-12 text-center">
            <div class="container">
                <h1>Privacy Policy</h1>
                <nav aria-label="breadcrumb">
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Privacy Policy</li>
                    </ul>
                </nav>
            </div>
        </div>
        <!-- Breadcrumb Area End -->
        <!-- Cart Area Start -->
        <div class="post-area blog-area pt-110 pb-95 post-details">
            <div class="container">
                <div class="row">
                    <div class="order-xl-2 order-lg-2 col-xl-12 col-lg-12">
                        <div class="single-post-item pb-70">
                            <h3 class="single-post-title">1. Introduction</a></h3>
                            <div class="single-post-info-text text-justify">

<strong>Welcome to SenseMe India!</strong><br>

This Privacy Policy was written to help you better understand how we collect, use and store your information. Since technology and privacy laws are always changing, we may occasionally update this policy. If a significant change is made, we will be sure to post a notice on our home page. If you continue to use Mylal Exports after these changes are posted, you agree to the revised policy.
<br>
<br>

By signing up for any of the products or services offered by Mylal Exports Services, you are agreeing to the terms of this Privacy Policy and, as applicable, the Mylal Exports Terms of Service. This policy is a legally binding agreement between Customers and Mylal Exports and its affiliates, including but not limited to Mylal Exports Data Processing. If we add any new features or tools to our Services, they will also be subject to this policy.
<br>
<br>

We will keep your Personal Information accurate, complete and up-to-date with the information that you provide to us. If you request access to your Personal Information, we will inform you of the existence, use and disclosure of your Personal Information as allowed by law, and provide you access to that information. When we use the term “Personal Information” in this policy, it means any information related to an identifiable individual, but does not include the name, title, business address, or telephone number of an employee of an organization.
<br>
<br>


<h3 class="single-post-title">2. Information from Senseme India website visitors and support users</h3>
<strong>What information does us collect and why?</strong><br>

From Mylal Exports website visitors, we collect information about the device and browser you use, your network connection and your IP address. We may also receive Personal Information when you purchase or make other requests to Mylal Exports via any of our websites.
<br>

From telephone support users, we collect your phone number and call audio.
<br>

From chat support users, we collect your name, email address, information about the device and browser you use, your network connection and your IP address.
<br>

From forum users, we collect your name, email address and website URL.
<br>

We use this information to service your account, enhance our Services, and answer any questions you may have.
<br>
<br>

<strong>When do we collect this information?</strong>
We collect this information when you visit Sensemeindia -hosted webpages or engage with us either by email, web form, instant message, phone, or post content on our website (including forums & blogs). We also collect any additional information that you might provide to us.
<br>
<br>

“<strong>DoubleClick:</strong> We use Google Analytics remarketing codes to log when users view specific pages or take specific actions on a website. This allows us to provide targeted advertising in the future. If you do not wish to receive this type of advertising from us in the future you can opt out using the <a href="https://www.google.com/settings/ads/onweb#display_optout" target="_blank"><strong>DoubleClick opt-out page</strong></a> or the <a href="http://www.networkadvertising.org/managing/opt_out.asp" target="_blank"><strong>Network Advertising Initiative opt-out page</strong></a>.”
<br><br>


<h3 class="single-post-title">3. Information from cookies</h3>
What is a cookie? A cookie is a small amount of data, which may include a unique identifier. Cookies are sent to your browser from a website and stored on your device. Every device that accesses our website is assigned a different cookie by us.
<br>
<br>

<strong>Why does Mylal Exports use cookies?</strong><br>

We use cookies to recognize your device and provide you with a personalized experience We also use cookies to serve customized ads from Google and other third-party vendors.

Our third-party advertisers use cookies to track your prior visits to our website and elsewhere on the Internet in order to serve you customized ads.

Opting out: You may be able to opt out of customized ads by visiting the Ads Preferences Manager, and the Google Analytics Opt-out Browser Add-on. If you use our website without opting out, this means that you understand and agree to data collection for the purpose of providing you with remarketing ads.

<br>
<br>

<h3 class="single-post-title">4. When and why do we share Personal Information with third parties?</h3>
Mylal Exports works with third parties to help provide you with our Services and we may share Personal Information with them to support these efforts. In certain limited circumstances, we may also be required by law to share information with third parties. We may also receive Personal Information from our partners and third parties. Personal information may be shared with third parties to prevent, investigate, or take action regarding illegal activities, suspected fraud, and situations involving potential threats to the physical safety of any person, violations of our Terms of Service or any other agreement related to the Services, or as otherwise required by law.<br>
<br>

Personal information may also be shared with a company that acquires our business, whether through merger, acquisition, bankruptcy, dissolution, reorganization, or other similar transaction or proceeding. If this happens, we will post a notice on our home page. Except when required by law, Mylal Exports will never disclose your Personal Information without obtaining your consent. Learn more about third parties
<br>
<br>


<h3 class="single-post-title">5. What do we do with your Personal Information when you terminate your relationship with us?</h3>
We will continue to store archived copies of your Personal Information for legitimate business purposes and to comply with the law. We will continue to store anonymous or anonym zed information, such as website visits, without identifiers, in order to improve our Services.

<br>
<br>

<h3 class="single-post-title">6. What we don’t do with your Personal Information</h3>
We do not and will never share, disclose, sell, rent, or otherwise provide Personal Information to other companies for the marketing of their own products or services. We do not use the Personal Information we collect from you or your customers to contact or market to your customers or directly compete with you. However, Mylal Exports may contact or market to your customers if we obtain their information from another source, such as from the customers themselves.

<br>
<br>

<h3 class="single-post-title">7. How do we keep your Personal Information secure?</h3>
We follow industry standards on information security management to safeguard sensitive information, such as financial information, intellectual property, employee details and any other Personal Information entrusted to us. Our information security systems apply to people, processes and information technology systems on a risk management basis.
<br>
<br>

We perform annual audits to ensure our handling of your credit card information aligns with industry guidelines. We are certified as a PCI DSS Level 1 compliant service provider, which is the highest level of compliance available, and our platform is audited annually by a third-party qualified security assessor. No method of transmission over the Internet, or method of electronic storage, is 100% secure. Therefore, we cannot guarantee the absolute security of your Personal Information.
<br>
<br>


<h3 class="single-post-title">8. How do we protect your information across borders?</h3>
Mylal Exports may transmit Personal Information outside of your jurisdiction of residence. Mylal Exports remains responsible for Personal Information that is transferred to a third party abroad for processing or to support our efforts. Any Personal Information transferred to a third party for data processing is subject, by law, to a comparable level of protection as that provided by Mylal Exports. A “comparable level of protection” means a level of protection generally equivalent to that provided by Mylal Exports. Learn more
<br>
<br>


<h3 class="single-post-title">9. Access to your personal information</h3>
You retain all rights to your Personal Information and can access it anytime. In addition, Mylal Exports takes reasonable steps to allow you to correct, amend or delete personal information that is shown to be inaccurate or incomplete.
<br>
<br>
If you have any questions about your Personal Information or this policy, please contact us.

                                

                            </div>
                            
                        </div>
                        
                        
                    </div>
                    
                </div>
            </div>
        </div>
        <?php include("sm_footer.php"); ?>
<script src="<?php echo $url; ?>assets/js/vendor/jquery-3.2.1.min.js"></script>
        <script src="<?php echo $url; ?>assets/js/popper.min.js"></script>
        <script src="<?php echo $url; ?>assets/js/bootstrap.min.js"></script>
        <script src="<?php echo $url; ?>assets/js/plugins.js"></script>        
        <script src="<?php echo $url; ?>assets/js/main.js"></script>
    </body>
</html>
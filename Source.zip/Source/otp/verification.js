function sendOTP() {    
	$(".error").html("").hide();
	var number = $("#mobile").val();
	dataLayer.push({'event': 'OTP_click','OTP_phone': number});	
	if (number.length == 10 && number != null) {
		var input = {
			"mobile_number" : number,
			"action" : "send_otp"
		};
		$.ajax({
			url : 'otp/controller.php',
			type : 'POST',
			data : input,
             beforeSend: function(){
     $(".btnSubmit").html("<i class='fa fa-spinner fa-spin text-white font25 pr-2'></i> Sending OTP...");
   },   
       complete: function(){
     $(".btnSubmit").html("OTP Sent");
   },
			success : function(response) {
				$(".OTP_container").html(response);
			}
		});
	} else {
		$(".error").html('Please enter a valid phone number. No spaces allowed.')
		$(".error").show();
	}
}

function resendOTP() {    
	$(".error").html("").hide();
		var input = {
			"action" : "resend_otp"
		};
		$.ajax({
			url : 'otp/controller.php',
			type : 'POST',
			data : input,
             beforeSend: function(){
                  $(".success2").hide();
     $("#resend").html("<i class='fa fa-spinner fa-spin text-white font25 pr-2'></i> Resending OTP...");
   },   
       complete: function(){
     $(".btnSubmit").html("OTP Sent");
   },
			success : function(response) {
				$(".OTP_container").html(response);
                $(".success2").html("New OTP is resent to Your Mobile Number");
                 $(".success2").show();
			}
		});

}

function verifyOTP() {
	$(".error").html("").hide();
	$(".success").html("").hide();
	var otp = $("#mobileOtp").val();
    //alert("otp: "+otp);
	var input = {
		"otp" : otp,
		"action" : "verify_otp"
	};
	if (otp.length == 4 && otp != null) {
		$.ajax({
			url : 'otp/controller.php',
			type : 'POST',	
            dataType : "json",
			data : input,
             beforeSend: function(){
     $("#verify").html("<i class='fa fa-spinner fa-spin text-white font25 pr-2'></i> Verifying...");
   },   
       complete: function(){
           $(".success2").hide();    
   },
			success : function(response) {                
                $("#resend").hide();
                if(response.type=="success")
                    {
                        window.location.replace(response.url);
                    }
                else
                    {
                $("." + response.type).html(response.message)
				$("." + response.type).show();    
                $("#resend").show();
                $("#verify").html("Verify");        
                        
                    }
				
                
			},
			error : function() {
				alert("error in verifying OTP");
			}
		});
	} else {
        $(".success2").hide();
        $(".success").hide();
		$(".error").html('Please check & enter the correct OTP. No spaces allowed.')
		$(".error").show();
         $("#resend").show();
        $("#verify").html("Verify");
	}
}

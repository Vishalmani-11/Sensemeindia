<?php
session_start();
error_reporting( E_ALL & ~E_NOTICE );

include "../smadmin/function/config.php";
require_once '../smadmin/admin/class.user_2.php';
require "../smadmin/function/function.php";


class Controller {
    function __construct() {
        $this->processMobileVerification();
    }
    function processMobileVerification() {
        switch ( $_POST[ "action" ] ) {
            case "send_otp":

                $mobile_number = $_POST[ 'mobile_number' ];

                $otp = rand( 1000, 9999 );
                $_SESSION[ 'session_otp' ] = $otp;
                $_SESSION[ 'mobile_number' ] = $mobile_number;
                $message = $otp . " is OTP for your mobile confirmation on sensemeindia.com. OTP is valid for 5 mins. Do not share it with anyone. - Mylal Exports";

                try {
                     $result = PostRequest( $mobile_number, $message );
                    if($result !=0)
                    {
                        echo "error in sending OTP"; exit();
                    }
////////////////////////////////////store phone no////////////////////////////////////////////////////////                     
include "../smadmin/db/db_connect.php";                    
$pquery = "INSERT into otp_phone (phone) values (?)";	
if(!$pstmt = $con->prepare($pquery)){ echo "Prepare failed: (" . $con->errno . ") " . $con->error;  } if(!$pstmt->bind_param("s", $mobile_number)) { echo "Param pass failed: (" . $con->errno . ") " . $con->error;  }
if(!$pstmt->execute()) { echo $error = "saving failed!".$con->error; $pstmt->close(); 	}                    
//////////////////////////////////////////////////////////////////////////////////////////////////////////                     
                    require_once( "verification-form.php" );
                    exit();
                } catch ( Exception $e ) {
                    die( 'Error: ' . $e->getMessage() );
                }
                break;

            case "resend_otp":

                $mobile_number = $_SESSION[ 'mobile_number' ];
                $otp = rand( 1000, 9999 );
                $_SESSION[ 'session_otp' ] = $otp;
                $message = $otp . " is OTP for your mobile confirmation on sensemeindia.com. OTP is valid for 5 mins. Do not share it with anyone. - Mylal Exports";

                try {
                    $result = PostRequest( $mobile_number, $message );
                    if($result !=0)
                    {
                        echo "error in resending OTP"; exit();
                    }
                    require_once( "verification-form.php" );
                    exit();
                } catch ( Exception $e ) {
                    die( 'Error: ' . $e->getMessage() );
                }
                break;

            case "verify_otp":
                $otp = $_POST[ 'otp' ];                
                if ( $otp == $_SESSION[ 'session_otp' ] ) {
                    echo json_encode( array( "type" => "success", "message" => "Your mobile number is verified successfully!", "url" => "checkout_process.php?votp=" . $_SESSION[ 'session_otp' ] . "&vphone=" . $_SESSION[ 'mobile_number' ] . "&success" ) );
                } else {
                    echo json_encode( array( "type" => "error", "message" => "Mobile number verification failed. Please check & enter the correct OTP. No spaces allowed." ) );
                }
                break;

        }
    }
}
$controller = new Controller();
?>
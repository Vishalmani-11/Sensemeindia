<script>
	 
	  $( document ).ready(function() {
///////////////////////////////////////////
                // Get the input field
var input = document.getElementById("mobileOtp");

// Execute a function when the user releases a key on the keyboard
input.addEventListener("keyup", function(event) {
  // Number 13 is the "Enter" key on the keyboard
  if (event.keyCode === 13) {
    // Cancel the default action, if needed
    //  alert("enter");
    //event.preventDefault();
      //alert("before");
    // Trigger the button element with a click
    verifySigninOTP();
	  return false;
      //document.getElementById("login_otp").click();
  }
});
            
});
	 

</script>
<div class="error"></div>
<div class="success"></div>
<div class="success2">OTP is sent to Your Mobile Number: <strong><?php echo $_SESSION[ 'mobile_number' ]; ?></strong></div>
<form id="frm-mobile-verification">

	<div class="form-row">
		<input type="text" pattern="[0-9]{4}" id="mobileOtp" class="form-input" placeholder="Enter the 4 digit OTP - no spaces allowed" autocomplete="off" required oninvalid="this.setCustomValidity('Enter 4 digit OTP. No spaces allowed.')" oninput="this.setCustomValidity('')">		
	</div>

	<div class="row mb-10">
		<a id="verify" class="btnVerify" onClick="verifySigninOTP();">Verify</a>		
	</div>
    <div class="row">
		<a id="resend" class="btnVerify" onClick="resendOTP();">Resend OTP</a>		
	</div>
</form>


function sendOTP() {    
	$(".error").html("").hide();
	var number = $("#mobile").val();
    //alert(number);
	if (number.length == 10 && number != null) {
		var input = {
			"mobile_number":number,
			"action":"send_otp"
		};
		$.ajax({
			url : '../otp/login_controller.php',
			type : 'POST',
			data : input,
             beforeSend: function(){
     $(".btnSubmit").html("<i class='fa fa-spinner fa-spin text-white font25 pr-2'></i> Sending OTP...");
   },   
       complete: function(){
     $(".btnSubmit").html("OTP Sent");
   },
			success : function(response) {
				$(".OTP_container").html(response);
			},
            error: function (jqXHR, exception) {
        var msg = '';
        if (jqXHR.status === 0) {
            msg = 'Not connect.\n Verify Network.';
        } else if (jqXHR.status == 404) {
            msg = 'Requested page not found. [404]';
        } else if (jqXHR.status == 500) {
            msg = 'Internal Server Error [500].';
        } else if (exception === 'parsererror') {
            msg = 'Requested JSON parse failed.';
        } else if (exception === 'timeout') {
            msg = 'Time out error.';
        } else if (exception === 'abort') {
            msg = 'Ajax request aborted.';
        } else {
            msg = 'Uncaught Error.\n' + jqXHR.responseText;
        }
        $('.OTP_container').html(msg);
    }
		});
	} else {
		$(".error").html('Please enter a valid phone number(10 digits only. No spaces allowed.')
		$(".error").show();
	}
}

function resendOTP() {    
	$(".error").html("").hide();
		var input = {
			"action" : "resend_otp"
		};
		$.ajax({
			url : '../otp/login_controller.php',
			type : 'POST',
			data : input,
             beforeSend: function(){
                  $(".success2").hide();
     $("#resend").html("<i class='fa fa-spinner fa-spin text-white font25 pr-2'></i> Resending OTP...");
   },   
       complete: function(){
     $(".btnSubmit").html("OTP Sent");
   },
			success : function(response) {
				$(".OTP_container").html(response);
                $(".success2").html("New OTP is resent to Your Mobile Number: ");
                 $(".success2").show();
			}
		});

}

function verifySigninOTP() {
	$(".error").html("").hide();
	$(".success").html("").hide();
	var otp = $("#mobileOtp").val();
    //alert("OTP:"+otp);
	var input = {
		"otp" : otp,
		"action" : "verify_otp"
	};
	if (otp.length == 4 && otp != null) {
		$.ajax({
			url : '../otp/login_controller.php',
			type : 'POST',
			dataType : 'json',
			data : input,
             beforeSend: function(){
     $("#verify").html("<i class='fa fa-spinner fa-spin text-white font25 pr-2'></i> Verifying...");
   },   
       complete: function(){
           $(".success2").hide();    
   },
			success : function(response) {    
                $("#resend").hide();
                if(response.type=="success")
                    {
                        window.location.replace(response.url);
                    }
                else
                    {
                $("." + response.type).html(response.message)
				$("." + response.type).show();    
                $("#resend").show();
                $("#verify").html("Verify");        
                        
                    } 
				
                
			},
			error : function(jqXHR, exception) {
				
        var msg = '';
        if (jqXHR.status === 0) {
            msg = 'Not connect.\n Verify Network.';
        } else if (jqXHR.status == 404) {
            msg = 'Requested page not found. [404]';
        } else if (jqXHR.status == 500) {
            msg = 'Internal Server Error [500].';
        } else if (exception === 'parsererror') {
            msg = 'Requested JSON parse failed.';
        } else if (exception === 'timeout') {
            msg = 'Time out error.';
        } else if (exception === 'abort') {
            msg = 'Ajax request aborted.';
        } else {
            msg = 'Uncaught Error.\n' + jqXHR.responseText;
        }
                $('.error').html("error in verifying OTP "+msg);
                $('.error').show();
                    
			}
		});
	} else {
        $(".success2").hide();
        $(".success").hide();
		$(".error").html('Please check & enter the correct OTP. No spaces allowed.')
		$(".error").show();
         $("#resend").show();
        $("#verify").html("Verify");
	}
}


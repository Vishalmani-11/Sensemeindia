<?php
include "smadmin/function/config.php"; 
include "smadmin/db/db_connect.php"; 
include "smadmin/function/function.php"; 
require_once 'smadmin/admin/class.user_2.php';

$reg_user = new USER();

if($reg_user->is_logged_in())
{
	$reg_user->redirect('index.php');
}

?>
<!doctype html>
<html class="no-js" lang="en">
   <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Conatct Us | SenseMe India</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Favicon -->
        <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.png">

        <!-- All css here -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/css/font-awesome.min.css">
        <link rel="stylesheet" href="assets/css/ie7.css">
        <link rel="stylesheet" href="assets/css/plugins.css">
        <link rel="stylesheet" href="assets/css/style.css">
        <script src="assets/js/vendor/modernizr-3.5.0.min.js"></script>

<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-WWCJ4NT');</script>
<!-- End Google Tag Manager -->
    </head>
    <body>
        	<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-WWCJ4NT"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
  <div id="loadAjax" class="ui-front loader ui-widget-overlay bg-gray opacity-50" style="display:none">
           <img src="assets/img/loader-light.gif" alt="">
        </div>
        
         <?php include("sm_header.php"); ?>
        <div class="breadcrumb-area bg-12 text-center">
            <div class="container">
                <h1>cancellation &amp; returns</h1>
                <nav aria-label="breadcrumb">
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Contact</li>
                    </ul>
                </nav>
            </div>
        </div>
        <!-- Breadcrumb Area End -->
        <!-- Cart Area Start -->
        <div class="post-area blog-area pt-110 pb-95 post-details">
            <div class="container">
                <div class="row">
                    <div class="order-xl-2 order-lg-2 col-xl-12 col-lg-12">
                        <div class="single-post-item pb-70">
                            <h3 class="single-post-title">For Bulk Purchase, Own Labeling &amp; Signature Products</a></h3>
                            <div class="single-post-info-text text-justify">
Please send your inquiry for bulk purchases, relabeling &amp; Signature products with complete details to: <strong>contact@sensemeindia.com</strong><br> We will get back to you within 48 hrs.  
Thank you.
                                

                            </div>
                            
                        </div>
                        
                        
                    </div>
                    
                </div>
            </div>
        </div>
        <?php include("sm_footer.php"); ?>
        <!-- Footer Area End -->
        
        <!-- QUICKVIEW PRODUCT -->
        
        <!-- END QUICKVIEW PRODUCT -->
        
        <!-- All js here -->
        <script src="assets/js/vendor/jquery-3.2.1.min.js"></script>
        <script src="assets/js/popper.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/plugins.js"></script>
        <script src="assets/js/ajax-mail.js"></script>
        <script src="assets/js/main.js"></script>
    </body>
</html>
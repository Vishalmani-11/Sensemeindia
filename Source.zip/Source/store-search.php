<?php
include "smadmin//function/config.php"; 
include "smadmin/db/db_connect.php"; 
include "smadmin/function/function.php"; 

if(isset($_REQUEST["term"])){
    // Prepare a select statement
    $searchsql = "SELECT * FROM bb_products WHERE name LIKE ?";
    
    if($searchstmt = $con->prepare($searchsql)){
        // Bind variables to the prepared statement as parameters
        $searchstmt->bind_param("s", $param_term);
        
        // Set parameters
        $param_term = $_REQUEST["term"] . '%';
        
        // Attempt to execute the prepared statement
        if($searchstmt->execute()){
            $result = $searchstmt->get_result();
            
            // Check number of rows in the result set
            if($result->num_rows > 0){
                // Fetch result rows as an associative array
                while($row = $result->fetch_array(MYSQLI_ASSOC)){
                    echo "<p>" . $row["name"] . "</p>";
                }
            } else{
                echo "<p>No matches found</p>";
            }
        } else{
            echo "ERROR: Could not able to execute $searchsql. " . mysqli_error($con);
        }
    }
    else{
            echo "ERROR: Could not able to execute $searchsql. " . mysqli_error($con);
        }
     
    
}

?>
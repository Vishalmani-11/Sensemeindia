<?php
include "smadmin/function/config.php"; 
include "smadmin/db/db_connect.php"; 
include "smadmin/function/function.php"; 
require_once 'smadmin/admin/class.user_2.php';

$reg_user = new USER();

if($reg_user->is_logged_in())
{
	$reg_user->redirect('index.php');
}

?>
<!doctype html>
<html class="no-js" lang="en">
   <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Shipping Policy | SenseMe India</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Favicon -->
        <link rel="shortcut icon" type="image/x-icon" href="<?php echo $url; ?>assets/img/favicon.png">

        <!-- All css here -->
        <link rel="stylesheet" href="<?php echo $url; ?>assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo $url; ?>assets/css/font-awesome.min.css">
        <link rel="stylesheet" href="<?php echo $url; ?>assets/css/ie7.css">
        <link rel="stylesheet" href="<?php echo $url; ?>assets/css/plugins.css">
        <link rel="stylesheet" href="<?php echo $url; ?>assets/css/style.css">
	       <link rel="stylesheet" href="<?php echo $url; ?>assets/css/menu/style.css">        
        <script src="<?php echo $url; ?>assets/js/vendor/modernizr-3.5.0.min.js"></script>

<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-WWCJ4NT');</script>
<!-- End Google Tag Manager -->
    </head>
    <body>
        	<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-WWCJ4NT"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
		
  <div id="loadAjax" class="ui-front loader ui-widget-overlay bg-gray opacity-50" style="display:none">
           <img src="assets/img/loader-light.gif" alt="">
        </div>
        
         <?php include("sm_header.php"); ?>
        <div class="breadcrumb-area bg-12 text-center">
            <div class="container">
                <h1>Shipping Policy</h1>
                <nav aria-label="breadcrumb">
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Shipping Policy</li>
                    </ul>
                </nav>
            </div>
        </div>
        <!-- Breadcrumb Area End -->
        <!-- Cart Area Start -->
        <div class="post-area blog-area pt-110 pb-95 post-details">
            <div class="container">
                <div class="row">
                    <div class="order-xl-2 order-lg-2 col-xl-12 col-lg-12">
                        <div class="single-post-item pb-70">
                            <div class="single-post-info-text text-justify">
<h3 class="single-post-title">What are the available shipping speeds for the orders?</h3>
Orders are dispatched directly by us. These items are indicated by the message "Shipping by us”. The delivery speeds available are between 2-4 Business Days or 4-7 Business Days or 5-14 Business Days. We may take additional time to pack and dispatch the item. This time is added to the applicable delivery speed. Delivery charges vary by Product weight and distance. We usually display our delivery charges on the product page. You can visit the page by clicking product detail page.
<br>
<br>


<h3 class="single-post-title">On which days do you not deliver?</h3>
Items are only delivered on business days. Apart from Sundays, there are certain holidays throughout the year that are not considered as business days. Deliveries will not happen on these days. For Guaranteed Morning/Same/One/Two-Day deliveries, delivery holidays differ depending upon the local or regional holidays of the state in which the order is delivered. Please note that our courier partners will delivers on Sundays at select residential locations.
<br>
<br>


<h3 class="single-post-title">International Delivery</h3>
We will deliver internationally only for bulk purchase of value above 1 lakh Rupees.For More details Contact us.
<br>
<br>


<h3 class="single-post-title">Why is the CoD option not offered in my location?</h3>
Availability of CoD depends on the ability of our courier partner servicing your location to accept cash as payment at the time of delivery.

Our courier partners have limits on the cash amount payable upto Rs.15000 total value, on delivery depending on the destination and if your order value exceeds this limit, then you have to go for prepaid.

                                

                            </div>
                            
                        </div>
                        
                        
                    </div>
                    
                </div>
            </div>
        </div>
        <?php include("sm_footer.php"); ?>
<script src="<?php echo $url; ?>assets/js/vendor/jquery-3.2.1.min.js"></script>
        <script src="<?php echo $url; ?>assets/js/popper.min.js"></script>
        <script src="<?php echo $url; ?>assets/js/bootstrap.min.js"></script>
        <script src="<?php echo $url; ?>assets/js/plugins.js"></script>        
        <script src="<?php echo $url; ?>assets/js/main.js"></script>
    </body>
</html>
/* ------------------------------------ */	
/*  MTD Menu
/* ------------------------------------ */	
$(document).ready(function(){
  

    
// Menu Add Class Left
	$("#hamburger-icon").click(function(e){
    e.stopPropagation();
	$(".slide-menu").toggleClass("slide-left");
    $(".overlay").fadeIn();    
});

    $('.slide-menu').click(function(e){
    e.stopPropagation();
});
    
    $('body,html').click(function(e){
       $('.slide-menu').removeClass('slide-left');
        $(".overlay").fadeOut();
});
        
//  Menu Add Class Close 		
$('.slide-close-button button').click(function(){
    $(".slide-menu").removeClass("slide-left");
    $(".overlay").fadeOut();  
});
// Menu Dropdown menu active
	$(".dropdownmenu").click(function(){
    $(this).next(".sub-menu").slideToggle(300,"swing");
    
	//$(".sub-menu").toggleClass("active");
});

///////////////////////////////////////////////////////////////////////////

	$(".cart_view").click(function(e){        
         e.stopPropagation();
        $(".overlay").fadeIn();          
         window.location.search += '&msg=cartview';
	//$(".cart-slide-menu").toggleClass("slide-right");
    //$(".overlay").fadeIn();  

        
});

    $('#cart_menu').click(function(e){
    e.stopPropagation();
});
    
    $('body,html').click(function(e){
       $('#cart_menu').removeClass('slide-right');
        $(".overlay").fadeOut();
});
//  Menu Add Class Close 		
$('.slide-close-button button').click(function(){
    $("#cart_menu").removeClass("slide-right");
    $(".overlay").fadeOut();  
});
    
    });
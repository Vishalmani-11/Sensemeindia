<footer class="footer-area">
            <div class="footer-bottom-area pt-30 pb-30">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6 d-flex col-md-6">
                            <div class="footer-text-bottom">
                                <p>&copy; <?php echo date('Y'); ?>@sensemeindia.com. All Rights Reserved</p> 
                                <!-- Developed by <a href="https://htsuite.com" target="_blank"><strong>HTS</strong> Web Solutions</a>.  -->
                            </div>
                        </div>
                
                    </div>
                </div>
            </div>
            <!-- Footer Bottom Area End -->
        </footer>


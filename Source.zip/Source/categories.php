<?php 
include "smadmin/function/config.php";
include "smadmin/db/db_connect.php";
include "smadmin/function/function.php";
include "smadmin/function/pagination.php";
if (!isset($_GET['mc_id']) || !isset($_GET['sc_id'])) {
    http_response_code(404);
    include("404.php");
    exit();
}
//////////////////////////sub_category////////////////////////////////////////////////////////////////
if (isset($_GET['sc_id']) && $_GET['sc_id'] != "" && isset($_GET['mc_id']) && $_GET['mc_id'] != "") {
    extract($_GET);
    $mc_id = secure_input($con, $mc_id);
    $sc_id = secure_input($con, $sc_id);
    $mc_name = secure_input($con, $mc_name);
    $sc_name = secure_input($con, $sc_name);
    $p_type = secure_input($con, $p_type);
    if (isset($_GET['variation']) && $_GET['variation'] != "") {
        $variation = secure_input($con, $_GET['variation']);
    } else {
        $variation = "normal";
    }
    if (isset($_GET['color_name'])) {
        $color_name = secure_input($con, $_GET['color_name']);
    }
    if (isset($_GET['color_id'])) {
        $color_id = secure_input($con, $_GET['color_id']);
    }
    if (isset($_GET['size_name'])) {
        $size_name = secure_input($con, $_GET['size_name']);
    }
    if (isset($_GET['size_id'])) {
        $size_id = secure_input($con, $_GET['size_id']);
    }
    if (isset($_GET['min_original']) && $_GET['min_original'] != "") {
        $min_original = secure_input($con, $_GET['min_original']);
        if (isset($_GET['min']) && $_GET['min'] != "") {
            $min = secure_input($con, $_GET['min']);
        } else {
            $min = $min_original;
        }
    }
    if (isset($_GET['max_original']) && $_GET['max_original'] != "") {
        $max_original = secure_input($con, $_GET['max_original']);
        if (isset($_GET['max']) && $_GET['max'] != "") {
            $max = secure_input($con, $_GET['max']);
        } else {
            $max = $max_original;
        }
    }


    //////////////////////////////////////////////////////////////////////    

    $active = 1;

// VALIDATE CURRENT CATEGORY URL
$validate_query = "SELECT t1.id, t1.name, t1.mc_id, t2.name
                   FROM bb_sub_categories AS t1
                   INNER JOIN bb_categories AS t2 ON t1.mc_id = t2.id
                   WHERE t1.id = ? AND t1.mc_id = ? AND t1.active = ?";

if (!$validate_stmt = $con->prepare($validate_query)) {
    http_response_code(500);
    exit();
}

if (!$validate_stmt->bind_param("iii", $sc_id, $mc_id, $active)) {
    http_response_code(500);
    exit();
}

if (!$validate_stmt->execute()) {
    http_response_code(500);
    exit();
}

$validate_stmt->store_result();

if ($validate_stmt->num_rows == 0) {
    http_response_code(404);
    include("404.php");
    exit();
}

$validate_stmt->bind_result(
    $db_sc_id,
    $db_sc_name,
    $db_mc_id,
    $db_mc_name
);

$validate_stmt->fetch();

/*
 * URL names are generated with URL_trim():
 * "Car Diffuser Oil" -> "Car-Diffuser-Oil"
 */
$expected_sc_name = URL_trim($db_sc_name);
$expected_mc_name = URL_trim($db_mc_name);

if (
    strcasecmp($expected_sc_name, $sc_name) !== 0 ||
    strcasecmp($expected_mc_name, $mc_name) !== 0
) {
    http_response_code(404);
    include("404.php");
    exit();
}

$validate_stmt->close();

    //$query = "SELECT id, name FROM bb_sub_categories WHERE mc_id = ? AND active = ? ORDER BY name ASC";

    //$query = "SELECT id, name FROM bb_sub_categories WHERE mc_id = ? AND active = ? ORDER BY id ASC";   

    $query = "SELECT t1.id, t1.name, COUNT(t2.id) as total FROM bb_sub_categories as t1 LEFT JOIN bb_products as t2 ON t1.id = t2.sc_id WHERE t1.mc_id = ? AND t1.active = ? GROUP BY t1.id, t1.name";

    if (!$sstmt = $con->prepare($query)) {
        echo "prepare failed: (" . $con->errno . ") " . $con->error;
        exit();
    }
    if (!$sstmt->bind_param("ii", $mc_id, $active)) {
        echo "Param pass failed: (" . $con->errno . ") " . $con->error;
        exit();
    }

    if (!$sstmt->execute()) {
        echo    $error = "categories list failed!" . $con->error;
        exit();
    }

    if (!$sstmt->store_result()) {
        echo $error = "categories list failed!" . $con->error;
        exit();
    }

    $snum_of_rows = $sstmt->num_rows;

    if ($snum_of_rows == 0) {
        $serror = "No categories found";
    }


    ////////////////////////////sizes///////////////////////////////////////////////////////


    $si_query = "SELECT id, name FROM bb_sizes WHERE active = ? ORDER BY name ASC";

    if (!$si_stmt = $con->prepare($si_query)) {
        echo "prepare failed: (" . $con->errno . ") " . $con->error;
        exit();
    }
    if (!$si_stmt->bind_param("i", $active)) {
        echo "Param pass failed: (" . $con->errno . ") " . $con->error;
        exit();
    }

    if (!$si_stmt->execute()) {
        echo $error = "categories list failed!" . $con->error;
        exit();
    }

    if (!$si_stmt->store_result()) {
        echo $error = "categories list failed!" . $con->error;
        exit();
    }

    $si_num_of_rows = $si_stmt->num_rows;

    if ($si_num_of_rows == 0) {
        $si_error = "No sizes found";
    }

    ////////////////////////////min-max///////////////////////////////////////////////////////


    $mm_query = "SELECT MIN(t1.mrp) as minimum, MAX(t1.mrp) as maximum FROM bb_products_stock as t1 INNER JOIN bb_products as t2 ON t1.parent_id = t2.id WHERE t2.sc_id = ? AND t1.active = ?";

    if (!$mm_stmt = $con->prepare($mm_query)) {
        echo "prepare failed: (" . $con->errno . ") " . $con->error;
        exit();
    }
    if (!$mm_stmt->bind_param("ii", $sc_id, $active)) {
        echo "Param pass failed: (" . $con->errno . ") " . $con->error;
        exit();
    }

    if (!$mm_stmt->execute()) {
        echo $error = "categories list failed!" . $con->error;
        exit();
    }

    if (!$mmqresult = $mm_stmt->get_result()) {
        echo $error = "child product details listing failed!" . $con->error;
        exit();
    }

    $mmnum_of_rows = $mmqresult->num_rows;

    if ($mmnum_of_rows == 0) {
        echo $serror = "Product details not found";
        exit();
    } else {

        if (!$mmdata = $mmqresult->fetch_assoc()) {
            echo $cdata = "error" . $con->error;
            exit();
        }
    }

    /////////////////////////left all products///////////////////////


    $es_query = "SELECT t1.id, t1.name, t2.id FROM bb_products as t1 INNER JOIN bb_products_stock as t2 ON t1.id = t2.parent_id WHERE t1.sc_id = ? AND t1.active = ? GROUP BY t2.parent_id ORDER BY t1.name";

    if (!$es_stmt = $con->prepare($es_query)) {
        echo $error = "Product data listing preparation failed 3!" . $con->error;
        exit();
    }
    if (!$es_stmt->bind_param('ii', $sc_id, $active)) {
        echo $error = "Product data listing preparation failed2!" . $con->error;
        exit();
    }

    if (!$es_stmt->execute()) {
        echo $error = "Product data listing execution failed!" . $con->error;
        exit();
    }
    if (!$es_stmt->store_result()) {
        echo $error = "Product data listing execution failed!" . $con->error;
        exit();
    }

    $es_num_of_rows = $es_stmt->num_rows;

    if ($es_num_of_rows == 0) {
        $es_error = "No products available";
    }


    ///////////////////////////sorting//////////////////////////////////
    if (isset($_GET["sorting"])) {
        $sorting = filter_var($_GET["sorting"], FILTER_SANITIZE_NUMBER_INT, FILTER_FLAG_STRIP_HIGH); //filter number
        if (!is_numeric($sorting)) {
            die('Invalid sorting!');
        }
    } else {
        $sorting = 0;
    }

    /////////////////////pagination//////////////////////////////////

    if (isset($_GET['pcount']) && $_GET['pcount'] != "") {
        extract($_GET);
        $pcount = secure_input($con, $pcount);
        $item_per_page      = $pcount; //item to display per page
    } else {
        $item_per_page      = 12; //item to display per page
    }

    if (isset($_GET["page"])) { //Get page number from $_GET["page"]
        $page_number = filter_var($_GET["page"], FILTER_SANITIZE_NUMBER_INT, FILTER_FLAG_STRIP_HIGH); //filter number
        if (!is_numeric($page_number)) {
            die('Invalid page number!');
        } //incase of invalid page number
    } else {
        $page_number = 1; //if there's no page number, set it to 1
    }

    $product_active = 1;

    /////////////////////////////////////paging////////////////////////////////////////////////    
    switch ($variation) {

        case "size":
            $page_url = $url . "categories.php?mc_id=" . $mc_id . "&mc_name=" . $mc_name . "&sc_id=" . $sc_id . "&sc_name=" . $sc_name . "&size_id=" . $size_id . "&size_name=" . $size_name . "&variation=size&sorting=" . $sorting;

            $pagequery = "SELECT COUNT(*) FROM bb_products as t1 INNER JOIN bb_products_stock as t2 ON t1.id = t2.parent_id WHERE t1.sc_id = ? AND t1.mc_id = ? AND t1.active = ? AND t2.size = ? GROUP BY t2.parent_id";

            if (!$pagestmt = $con->prepare($pagequery)) {
                echo $error = "product data listing execution failed!" . $con->error;
                exit();
            }

            if (!$pagestmt->bind_param('iiii', $sc_id, $mc_id, $product_active, $size_id)) {
                echo $error = "paging data listing preparation failed!" . $con->error;
                exit();
            }
            break;

        case "price_range":
            $page_url = $url . "categories.php?mc_id=" . $mc_id . "&mc_name=" . $mc_name . "&sc_id=" . $sc_id . "&sc_name=" . $sc_name . "&min=" . $min . "&max=" . "&min_original=" . $min_original . "&max_original=" . $max_original . "&variation=price_range&sorting=" . $sorting;

            $pagequery = "SELECT COUNT(*) FROM bb_products as t1 INNER JOIN bb_products_stock as t2 ON t1.id = t2.parent_id WHERE t1.sc_id = ? AND t1.mc_id = ? AND t1.active = ? AND t2.price >= ? AND t2.price <= ? GROUP BY t2.parent_id";

            if (!$pagestmt = $con->prepare($pagequery)) {
                echo $error = "product data listing execution failed!" . $con->error;
                exit();
            }

            if (!$pagestmt->bind_param('iiiii', $sc_id, $mc_id, $product_active, $min, $max)) {
                echo $error = "paging data listing preparation failed!" . $con->error;
                exit();
            }
            break;

        default:
         $page_url = $url . URL_trim($mc_name) . "/" . URL_trim($sc_name) . "/" . $mc_id . "/" . $sc_id . "/";
            $pagequery = "SELECT COUNT(*) FROM bb_products WHERE sc_id = ? AND mc_id = ? AND active = ?";

            if (!$pagestmt = $con->prepare($pagequery)) {
                echo $error = "product data listing execution failed!" . $con->error;
                exit();
            }

            if (!$pagestmt->bind_param('iii', $sc_id, $mc_id, $product_active)) {
                echo $error = "paging data listing preparation failed!" . $con->error;
                exit();
                exit();
            }
    }
    /////////////////////////////////////////////////////////////////////////////////////////////////  

    if (!$pagestmt->execute()) {
        echo $error = "product data deletion execution failed!" . $con->error;
        exit();
    } else {
        if (!$pagestmt->bind_result($totalcount)) {
            echo $error = "categories data listing execution failed!" . $con->error;
            exit();
        }
        $pagestmt->fetch();
        $get_total_rows = $totalcount;
        $pagestmt->free_result();
    }
    $total_pages = ceil($get_total_rows / $item_per_page); //break records into pages
    $page_position = (($page_number - 1) * $item_per_page); //get starting position to fetch the records

    /////////////////////////////////////////////listing products//////////////////////////////////////////////////////////// 

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////   
    $limit = " LIMIT ?,?";
    switch ($variation) {
        case "color":

            $query = "SELECT t1.id, t1.name, t1.description, t2.id, t2.mrp, t2.price, t2.pic1, t2.pic2, t2.featured, t2.cdate, t3.name FROM bb_products as t1 INNER JOIN bb_products_stock as t2 ON t1.id = t2.parent_id INNER JOIN bb_sizes as t3 ON t2.size = t3.id WHERE t1.sc_id = ? AND t1.mc_id = ? AND t1.active = ? AND t2.color = ? GROUP BY t2.parent_id";

            switch ($sorting) {
                case 1:
                    $query .= " ORDER BY t2.mrp ASC" . $limit;
                    break;

                case 2:
                    $query .= " ORDER BY t2.mrp DESC" . $limit;
                    break;

                case 3:
                    $query .= " ORDER BY t1.name ASC" . $limit;
                    break;

                case 4:
                    $query .= " ORDER BY t1.name DESC" . $limit;
                    break;

                default:
                    $query .= " ORDER BY t1.id DESC" . $limit;
                    break;
            }

            if (!$stmt = $con->prepare($query)) {
                echo $error = "Product data listing preparation failed 1!" . $con->error;
                exit();
            }
            if (!$stmt->bind_param('iiiiii', $sc_id, $mc_id, $product_active, $color_id, $page_position, $item_per_page)) {
                echo $error = "Product data listing preparation failed!" . $con->error;
                exit();
            }

            break;

        case "size":

            $query = "SELECT t1.id, t1.name, t1.description, t2.id, t2.mrp, t2.price, t2.pic1, t2.pic2,  t2.featured, t2.cdate, t3.name FROM bb_products as t1 INNER JOIN bb_products_stock as t2 ON t1.id = t2.parent_id INNER JOIN bb_sizes as t3 ON t2.size = t3.id WHERE t1.sc_id = ? AND t1.mc_id = ? AND t1.active = ? AND t2.size = ? GROUP BY t2.parent_id";

            switch ($sorting) {
                case 1:
                    $query .= " ORDER BY t2.mrp ASC" . $limit;
                    break;

                case 2:
                    $query .= " ORDER BY t2.mrp DESC" . $limit;
                    break;

                case 3:
                    $query .= " ORDER BY t1.name ASC" . $limit;
                    break;

                case 4:
                    $query .= " ORDER BY t1.name DESC" . $limit;
                    break;

                default:
                    $query .= " ORDER BY t1.id DESC" . $limit;
                    break;
            }

            if (!$stmt = $con->prepare($query)) {
                echo $error = "Product data listing preparation failed 2!" . $con->error;
                exit();
            }
            if (!$stmt->bind_param('iiiiii', $sc_id, $mc_id, $product_active, $size_id, $page_position, $item_per_page)) {
                echo $error = "Product data listing preparation failed!" . $con->error;
                exit();
            }


            break;

        case "price_range":

            $query = "SELECT t1.id, t1.name, t1.description, t2.id, t2.mrp, t2.price, t2.pic1, t2.pic2,  t2.featured, t2.cdate, t3.name FROM bb_products as t1 INNER JOIN bb_products_stock as t2 ON t1.id = t2.parent_id INNER JOIN bb_sizes as t3 ON t2.size = t3.id WHERE t1.sc_id = ? AND t1.mc_id = ? AND t1.active = ? AND t2.price >= ? AND t2.price <= ? GROUP BY t2.parent_id";

            switch ($sorting) {
                case 1:
                    $query .= " ORDER BY t2.mrp ASC" . $limit;
                    break;

                case 2:
                    $query .= " ORDER BY t2.mrp DESC" . $limit;
                    break;

                case 3:
                    $query .= " ORDER BY t1.name ASC" . $limit;
                    break;

                case 4:
                    $query .= " ORDER BY t1.name DESC" . $limit;
                    break;

                default:
                    $query .= " ORDER BY t1.id DESC" . $limit;
                    break;
            }

            if (!$stmt = $con->prepare($query)) {
                echo $error = "Product data listing preparation failed 2!" . $con->error;
                exit();
            }
            if (!$stmt->bind_param('iiiiiii', $sc_id, $mc_id, $product_active, $min, $max, $page_position, $item_per_page)) {
                echo $error = "Product data listing preparation failed!" . $con->error;
                exit();
            }


            break;

        default:
            $query = "SELECT t1.id, t1.name, t1.description, t2.id, t2.mrp, t2.price, t2.pic1, t2.pic2, t2.featured, t2.cdate, t3.name FROM bb_products as t1 INNER JOIN bb_products_stock as t2 ON t1.id = t2.parent_id INNER JOIN bb_sizes as t3 ON t2.size = t3.id WHERE t1.sc_id = ? AND t1.mc_id = ? AND t1.active = ? GROUP BY t2.parent_id";

            switch ($sorting) {
                case 1:
                    $query .= " ORDER BY t2.mrp ASC" . $limit;
                    break;

                case 2:
                    $query .= " ORDER BY t2.mrp DESC" . $limit;
                    break;

                case 3:
                    $query .= " ORDER BY t1.name ASC" . $limit;
                    break;

                case 4:
                    $query .= " ORDER BY t1.name DESC" . $limit;
                    break;

                default:
                    $query .= " ORDER BY t1.name ASC" . $limit;
                    break;
            }

            if (!$stmt = $con->prepare($query)) {
                echo $error = "Product data listing preparation failed 3!" . $con->error;
                exit();
            }
            if (!$stmt->bind_param('iiiii', $sc_id, $mc_id, $product_active, $page_position, $item_per_page)) {
                echo $error = "Product data listing preparation failed!" . $con->error;
                exit();
            }
    }

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////    

    if (!$stmt->execute()) {
        echo $error = "Product data listing execution failed!" . $con->error;
        exit();
    }
    if (!$stmt->store_result()) {
        echo $error = "Product data listing execution failed!" . $con->error;
        exit();
    }

    $num_of_rows = $stmt->num_rows;

    if ($num_of_rows == 0) {
        $error = "No products available";
    }
}


?>
<!doctype html>
<html class="no-js" lang="en">

<head>
  <?php
  echo "<!-- CATEGORY FILE WORKING -->";
$canonical_url = $url . URL_trim($db_mc_name) . "/" . URL_trim($db_sc_name) . "/" . $db_mc_id . "/" . $db_sc_id . "/";
?>

<link rel="canonical" href="<?php echo htmlspecialchars($canonical_url, ENT_QUOTES, 'UTF-8'); ?>" />
    <!-- Google Tag Manager -->
    <script>
        (function(w, d, s, l, i) {
            w[l] = w[l] || [];
            w[l].push({
                'gtm.start': new Date().getTime(),
                event: 'gtm.js'
            });
            var f = d.getElementsByTagName(s)[0],
                j = d.createElement(s),
                dl = l != 'dataLayer' ? '&l=' + l : '';
            j.async = true;
            j.src =
                'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
            f.parentNode.insertBefore(j, f);
        })(window, document, 'script', 'dataLayer', 'GTM-WWCJ4NT');
    </script>
    <!-- End Google Tag Manager -->

    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title><?php echo $mc_name; ?> | SenseMe India</title>
   <meta name="description" content="Buy <?php echo ucwords(str_replace('-', ' ', htmlspecialchars($sc_name, ENT_QUOTES, 'UTF-8'))); ?> online from SenseMe India. Premium quality <?php echo ucwords(str_replace('-', ' ', htmlspecialchars($sc_name, ENT_QUOTES, 'UTF-8'))); ?> for soap making, candle making, cosmetics, aromatherapy, incense and personal care manufacturing in India.">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo $url; ?>assets/img/favicon.png">

    <!-- All css here -->
    <link rel="stylesheet" href="<?php echo $url; ?>assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $url; ?>assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo $url; ?>assets/css/ie7.css">
    <link rel="stylesheet" href="<?php echo $url; ?>assets/css/plugins.css">
    <link rel="stylesheet" href="<?php echo $url; ?>assets/css/style.css">
    <link rel="stylesheet" href="<?php echo $url; ?>assets/css/menu/style.css">
    <script src="<?php echo $url; ?>assets/js/vendor/modernizr-3.5.0.min.js"></script>
    <script src="<?php echo $url; ?>assets/js/vendor/jquery-3.2.1.min.js"></script>
    <script src="<?php echo $url; ?>assets/css/menu/script.js"></script>
    <!-- Meta Pixel Code -->
    <script>
        ! function(f, b, e, v, n, t, s) {
            if (f.fbq) return;
            n = f.fbq = function() {
                n.callMethod ?
                    n.callMethod.apply(n, arguments) : n.queue.push(arguments)
            };
            if (!f._fbq) f._fbq = n;
            n.push = n;
            n.loaded = !0;
            n.version = '2.0';
            n.queue = [];
            t = b.createElement(e);
            t.async = !0;
            t.src = v;
            s = b.getElementsByTagName(e)[0];
            s.parentNode.insertBefore(t, s)
        }(window, document, 'script',
            'https://connect.facebook.net/en_US/fbevents.js');
        fbq('init', '6089330044459882');
        fbq('track', 'PageView');
        fbq('track', 'ViewContent');
        fbq('track', 'Search');
        fbq('track', 'AddToCart');
        fbq('track', 'InitiateCheckout');
        fbq('track', 'AddPaymentInfo');
        fbq('track', 'Purchase');
        fbq('track', 'CompleteRegistration');
        fbq('track', 'Contact');
        fbq('track', 'FindLocation');
        fbq('track', 'Lead');
        fbq('track', 'SubmitApplication');
    </script>
    <noscript><img height="1" width="1" style="display:none"
            src="https://www.facebook.com/tr?id=6089330044459882&ev=PageView&noscript=1" /></noscript>
    <!-- End Meta Pixel Code -->
</head>

<body>
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-WWCJ4NT"
            height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->
    <?php include("sm_header.php"); ?>
    
    <!-- Breadcrumb Area End -->
    <!-- Shop Area Start -->
    <div class="shop-area pt-110 pb-100 bg-gray mb-95">
        <div class="container">
            <div class="row">
                <div class="order-xl-2 order-lg-2 col-xl-9 col-lg-8 mobile_plr0">
                    <div class="ht-product-tab">
                        <!--<div class="ht-tab-content">-->
                        <!--    <div class="nav" role="tablist">-->
                        <!--        <a class="active grid" href="#grid" data-toggle="tab" role="tab" aria-selected="true" aria-controls="grid"><i class="fa fa-th"></i></a>-->
                        <!--        <a class="list" href="#list" data-toggle="tab" role="tab" aria-selected="false" aria-controls="list"><i class="fa fa-list"></i></a>-->
                        <!--    </div>-->
                        <!--    <div class="shop-items">-->
                        <!--        <span>(<?php echo $totalcount; ?> products) </span>-->
                        <!--    </div>-->
                        <!--</div>-->
               <h1 class="ht-tab-content" style="text-align:center; font-family: Arial, sans-serif; font-size:20px; font-weight:600;">
    <?php 
        $formatted_name = ucwords(str_replace('-', ' ', $sc_name)); 
        echo $formatted_name;
    ?>
</h1>
                        <div class="shop-results-wrapper">
                            <!--<div class="shop-results"><span>Show:</span>-->
                            <!--    <div class="shop-select">-->
                            <!--        <form id="paging_form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="get">-->
                            <!--            <select name="pcount" id="pcount_id" onchange="myFunction()">-->
                            <!--                <option value="1">Default</option>-->
                            <!--                <option value="12">12</option>-->
                            <!--                <option value="20">20</option>-->
                            <!--                <option value="40">40</option>-->
                            <!--            </select>-->
                            <!--            <input type="hidden" name="sc_id" value="<?php echo $sc_id; ?>">-->
                            <!--            <input type="hidden" name="sc_name" value="<?php echo $sc_name; ?>">-->
                            <!--            <input type="hidden" name="mc_id" value="<?php echo $mc_id; ?>">-->
                            <!--            <input type="hidden" name="mc_name" value="<?php echo $mc_name; ?>">-->
                            <!--            <input type="hidden" name="variation" value="<?php echo $variation; ?>">-->
                            <!--            <?php if (isset($_GET['color_name'])) { ?> <input type="hidden" name="color_name" value="<?php echo $color_name; ?>"> <?php } ?>-->
                            <!--            <?php if (isset($_GET['color_id'])) { ?> <input type="hidden" name="color_id" value="<?php echo $color_id; ?>"> <?php } ?>-->
                            <!--            <?php if (isset($_GET['size_name'])) { ?> <input type="hidden" name="size_name" value="<?php echo $size_name; ?>"> <?php } ?>-->
                            <!--            <?php if (isset($_GET['size_id'])) { ?> <input type="hidden" name="size_id" value="<?php echo $size_id; ?>"> <?php } ?>-->
                            <!--            <?php if (isset($_GET['min'])) { ?> <input type="hidden" name="min" value="<?php echo $min; ?>"> <?php } ?>-->
                            <!--            <?php if (isset($_GET['max'])) { ?> <input type="hidden" name="max" value="<?php echo $max; ?>"> <?php } ?>-->
                            <!--            <?php if (isset($_GET['min_original'])) { ?> <input type="hidden" name="min_original" value="<?php echo $min_original; ?>"> <?php } ?>-->
                            <!--            <?php if (isset($_GET['max_original'])) { ?> <input type="hidden" name="max_original" value="<?php echo $max_original; ?>"> <?php } ?>-->
                            <!--        </form>-->
                            <!--    </div>-->
                            <!--</div>-->
                            <!--<div class="shop-results"><span>Sort By:</span>-->
                            <!--    <div class="shop-select">-->
                            <!--        <form id="sorting_form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="get">-->
                            <!--            <select name="sorting" id="sorting_id" onchange="myFunction2()">-->
                            <!--                <option value="0">Select Sorting</option>-->
                            <!--                <option value="1">Sort by price: low to high</option>-->
                            <!--                <option value="2">Sort by price: high to low</option>-->
                            <!--                <option value="3">Product Name:A-Z</option>-->
                            <!--                <option value="4">Product Name:Z-A</option>-->
                            <!--            </select>-->
                            <!--            <input type="hidden" name="sc_id" value="<?php echo $sc_id; ?>">-->
                            <!--            <input type="hidden" name="sc_name" value="<?php echo $sc_name; ?>">-->
                            <!--            <input type="hidden" name="mc_id" value="<?php echo $mc_id; ?>">-->
                            <!--            <input type="hidden" name="mc_name" value="<?php echo $mc_name; ?>">-->
                            <!--            <input type="hidden" name="variation" value="<?php echo $variation; ?>">-->
                            <!--            <?php if (isset($_GET['color_name'])) { ?> <input type="hidden" name="color_name" value="<?php echo $color_name; ?>"> <?php } ?>-->
                            <!--            <?php if (isset($_GET['color_id'])) { ?> <input type="hidden" name="color_id" value="<?php echo $color_id; ?>"> <?php } ?>-->
                            <!--            <?php if (isset($_GET['size_name'])) { ?> <input type="hidden" name="size_name" value="<?php echo $size_name; ?>"> <?php } ?>-->
                            <!--            <?php if (isset($_GET['size_id'])) { ?> <input type="hidden" name="size_id" value="<?php echo $size_id; ?>"> <?php } ?>-->
                            <!--            <?php if (isset($_GET['min'])) { ?> <input type="hidden" name="min" value="<?php echo $min; ?>"> <?php } ?>-->
                            <!--            <?php if (isset($_GET['max'])) { ?> <input type="hidden" name="max" value="<?php echo $max; ?>"> <?php } ?>-->
                            <!--            <?php if (isset($_GET['min_original'])) { ?> <input type="hidden" name="min_original" value="<?php echo $min_original; ?>"> <?php } ?>-->
                            <!--            <?php if (isset($_GET['max_original'])) { ?> <input type="hidden" name="max_original" value="<?php echo $max_original; ?>"> <?php } ?>-->

                            <!--        </form>-->
                            <!--    </div>-->
                            <!--</div>-->
                        </div>
                    </div>
                    <div class="ht-product-shop tab-content text-center">
                        <div class="tab-pane active show fade" id="grid" role="tabpanel">
                            <div class="custom-row">



                                <?php
                                if (isset($error)) {
                                ?>
                                    <a class="pl-3" href="javascript:;"><?php echo $error; ?>!</a>
                                    <?php
                                } else {

                                    $stmt->bind_result($parent_id, $name, $description, $product_id, $mrp, $price, $pic1, $pic2, $featured, $cdate, $p_size);
                                    while ($stmt->fetch()) {
                                        $product_url = build_product_url($url, $mc_name, $sc_name, $name, $product_id);
                                    ?>


                                        <div class="custom-col">
                                            <div class="single-product-item">
                                                <div class="product-image">
                                                    <a href="<?php echo $product_url; ?>" target="_blank">
                                                        <img src="<?php echo $url; ?>smadmin/<?php echo $pic1; ?>" alt="">
                                                    </a>
                                                    <div class="double_base">

                                                        <?php $price_class = "product_sale";
                                                        if ($price != 0 && $price < $mrp) {
                                                            $discount = round(($mrp - $price) / $mrp * 100); ?>

                                                            <?php if ($discount >= 25) { ?>

                                                                <!-- <div class="label_product">
                                                                    <span>Hot Deal</span>
                                                                </div>
                                                                <div class="<?php echo $price_class; ?> top_55">
                                                                    <span>- <?php echo $discount; ?>% Off</span>
                                                                </div> -->
                                                            <?php } else { ?>

                                                                <!-- <div class="<?php echo $price_class; ?>">
                                                                    <span>- <?php echo $discount; ?>% Off</span>
                                                                </div> -->

                                                        <?php }
                                                        } ?>



                                                    </div>
                                                </div>
                                                <div class="product-text">

                                                    <h5> <a href="<?php echo $product_url; ?>" target="_blank"><?php echo $name; ?> (<?php echo $p_size; ?><?php if ($mc_id == 4) {
                                                                                                                                                                                                                                                                        echo 'shots';
                                                                                                                                                                                                                                                                    } else {
                                                                                                                                                                                                                                                                        echo 'ml';
                                                                                                                                                                                                                                                                    }   ?>
                                                            ) </a></h5>
                                                    <div class="pro-price">

                                                        <?php if ($price != 0 && $price < $mrp) { ?>
                                                            <span class="new-price">&#x20b9; <?php echo $price; ?></span>
                                                            <span class="old-price">MRP &#x20b9;<?php echo $mrp; ?></span>
                                                        <?php } else { ?>
                                                            <span class="new-price">&#x20b9; <?php echo $price; ?></span>
                                                        <?php } ?>



                                                    </div>
                                                    <?php if ($price != 0 && $price < $mrp) { ?>
                                                        <div class="pro-price save-tag">

                                                            You save:<strong> &#x20b9;<?php echo $mrp - $price; ?></strong> (<?php echo $discount; ?>% Off)

                                                        </div> <?php } ?>

                                                    <a href="<?php echo $product_url; ?>" target="_blank" class="mt-10"><button type="submit" class="submit-btn default-btn" name="signup">Buy Now</button> </a>
                                                </div>

                                            </div>
                                        </div>

                                <?php }
                                }

                                ?>

                            </div>
                        </div>
                        <div class="tab-pane fade text-left" id="list" role="tabpanel">

                            <?php
                            if (isset($error)) {
                            ?>
                                <a class="pl-3" href="javascript:;"><?php echo $error; ?>!</a>
                                <?php
                            } else {
                                $stmt->data_seek(0);
                                if (!$stmt->bind_result($parent_id, $name, $description, $product_id, $mrp, $price, $pic1, $pic2, $featured, $cdate, $p_size)) {
                                    echo "error" . $con->error;
                                    exit();
                                }
                                while ($stmt->fetch()) {

                                    $product_url = build_product_url($url, $mc_name, $sc_name, $name, $product_id);
                                    $max_length = 170;
                                    if (strlen($description) > $max_length) {
                                        $offset = ($max_length - 3) - strlen($description);
                                        $description = substr($description, 0, strrpos($description, ' ', $offset)) . '...';
                                    }

                                ?>

                                    <div class="single-product-item">
                                        <div class="product-image">

                                            <a href="<?php echo $product_url; ?>" target="_blank"> <img src="<?php echo $url; ?>smadmin/<?php echo $pic1; ?>" alt="">
                                            </a>
                                            <div class="double_base">

                                                <?php $price_class = "product_sale";
                                                if ($price != 0 && $price < $mrp) {
                                                    $discount = round(($mrp - $price) / $mrp * 100); ?>

                                                    <?php if ($discount >= 25) { ?>

                                                        <!-- <div class="label_product left_30 top__5">
                                                            <span>Hot Deal</span>
                                                        </div>
                                                        <div class="<?php echo $price_class; ?> left_30">
                                                            <span>- <?php echo $discount; ?>% Off</span>
                                                        </div> -->
                                                    <?php } else { ?>

                                                        <!-- <div class="<?php echo $price_class; ?> left_30 top_0">
                                                            <span>- <?php echo $discount; ?>% Off</span>
                                                        </div> -->

                                                <?php }
                                                } ?>


                                            </div>

                                        </div>
                                        <div class="product-text">
                                            <h5><a href="<?php echo $product_url; ?>" target="_blank"><?php echo $name; ?> (<?php echo $p_size; ?><?php if ($mc_id == 4) {
                                                                                                                                                                                                                                                                echo 'shots';
                                                                                                                                                                                                                                                            } else {
                                                                                                                                                                                                                                                                echo 'ml';
                                                                                                                                                                                                                                                            }   ?>
                                                    ) </a></h5>

                                            <div class="pro-price">

                                                <?php if ($price != 0 && $price < $mrp) { ?>
                                                    <span class="new-price">&#x20b9; <?php echo $price; ?></span>
                                                    <span class="old-price">MRP &#x20b9; <?php echo $mrp; ?></span>
                                                <?php } else { ?>
                                                    <span class="new-price">&#x20b9; <?php echo $mrp; ?></span>
                                                <?php } ?>



                                            </div>
                                            <p><?php echo nl2br(htmlspecialchars_decode(($description))); ?></p>
                                            <a href="<?php echo $product_url; ?>" target="_blank"><button type="button" class="p-cart-btn default-btn">Buy Now</button></a>
                                        </div>
                                    </div>


                            <?php }
                            }

                            ?>



                        </div>
                    </div>

                    <?php
                    if ($total_pages > 0 && $total_pages != 1) {
                    ?>
                        <div class="pagination-wrapper">
                            <p>(<?php echo $totalcount; ?> products)</p>
                            <nav aria-label="navigation">
                                <?php
                                echo paginate($item_per_page, $page_number, $get_total_rows[0], $total_pages, $page_url);
                                ?>
                            </nav>
                        </div>
                    <?php } ?>

                </div>
                <div class="col-xl-3 col-lg-4">
                    <div class="sidebar-wrapper">
                        <h3>Shop Navigation</h3>

                        <div class="sidebar-widget price-widget">
                            <h3>Price Filter</h3>
                            <div class="price-slider-container">
                                <form id="price_form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="get">
                                    <div id="slider-range"></div>
                                    <div class="price_slider_amount">
                                        <div class="slider-values">

                                            <input type="text" id="amount" name="amount" placeholder="Add Your Price" onChange="priceUpdate()" />
                                            <input type="hidden" name="min" id="min">
                                            <input type="hidden" name="max" id="max">
                                            <input type="hidden" name="min_original" value="<?php echo $mmdata['minimum']; ?>">
                                            <input type="hidden" name="max_original" value="<?php echo $mmdata['maximum']; ?>">
                                            <input type="hidden" name="sc_id" value="<?php echo $sc_id; ?>">
                                            <input type="hidden" name="sc_name" value="<?php echo $sc_name; ?>">
                                            <input type="hidden" name="mc_id" value="<?php echo $mc_id; ?>">
                                            <input type="hidden" name="mc_name" value="<?php echo $mc_name; ?>">
                                            <input type="hidden" name="variation" value="price_range">
                                            <button type="submit" class="float-right">Show</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="sidebar-widget">
                            <h3>Categories</h3>
                            <div class="sidebar-widget-option-wrapper">
                                <div class="sidebar-widget-option">
                                    <ul class="all_categories">
                                        <?php
                                        if (isset($serror)) {
                                        ?>
                                            <li><a href="javascript:;"><?php echo $serror; ?></a> </li>
                                            <?php
                                        } else {

                                            $sstmt->bind_result($id, $scname, $total);
                                            while ($sstmt->fetch()) {
                                                $left_scname_url = URL_trim($scname);
                                            ?>
                                                <li class="pb-10"><i class="fa fa-arrow-circle-right green"></i>

                                                    <a href="<?php echo $url; ?><?php echo $mc_name; ?>/<?php echo $left_scname_url; ?>/<?php echo $mc_id; ?>/<?php echo $id; ?>/">

                                                        <?php echo $scname; ?>(<?php echo $total; ?>)</a>
                                                </li>

                                        <?php }
                                        }
                                        $sstmt->free_result();
                                        ?>
                                    </ul>

                                </div>

                            </div>
                        </div>

                        <div class="sidebar-widget">
                            <h3>All <?php echo $sc_name; ?> Products</h3>
                            <div class="sidebar-widget-option-wrapper">
                                <div class="sidebar-widget-option">
                                    <ul class="all_products">
                                        <?php
                                        if (isset($es_error)) {
                                        ?>
                                            <li><a href="javascript:;"><?php echo $es_error; ?></a> </li>
                                            <?php
                                        } else {

                                            $es_stmt->bind_result($product_main_id, $product_name, $product_child_id);
                                            while ($es_stmt->fetch()) {
                                                $product_url = build_product_url($url, $mc_name, $sc_name, $product_name, $product_child_id);
                                            ?>
                                                <li class="pb-10"><i class="fa fa-arrow-circle-right green"></i> <a href="<?php echo $product_url; ?>" target="_blank">
                                                        <?php echo $product_name; ?></a> </li>

                                        <?php }
                                        }
                                        $es_stmt->free_result();
                                        ?>
                                    </ul>

                                </div>

                            </div>
                        </div>
                    </div>
                    <!--  <div class="sidebar-banner-img">
                            <a href="#"><img src="assets/img/banner/6.png" alt=""></a>
                        </div>-->
                </div>
            </div>
        </div>
    </div>
    <div class="testimonial-area pt-110 pb-95 bg-white">
        <div class="container">
            <div class="testimonial-slider-wrapper">
                <div class="text-carousel text-center">
                    <div class="slider-text">
                        <span class="testi-quote">
                            <img src="<?php echo $url; ?>assets/img/icon/quote.png" alt="">
                        </span>
                        <p>Initially, I bought an ultrasonic aroma diffuser from him. Wooow! Quality of diffuser is outstanding. I swear, nowhere else we can get such a product. It so elegant and comes with a REMOTE CONTROL. The main part is its pricing. Highly competitive for such a world class diffuser. Many thanks for additional support for selling me THERAPEUTIC GRADE 👌 ESSENTIAL OILS at a best rate. REALLY EXCEEDING THE MARK 👍👍👍👍👍 iam highly satisfied and this is a highly recommended place for all essential oil requirements. Vazhga vazhamudan 🙏</p>
                    </div>
                    <div class="slider-text">
                        <span class="testi-quote">
                            <img src="<?php echo $url; ?>assets/img/icon/quote.png" alt="">
                        </span>
                        <p>We bought aroma diffuser in 3 different flavors. The quality is good and value for money. We recommend all to buy this product.</p>
                    </div>
                    <div class="slider-text">
                        <span class="testi-quote">
                            <img src="<?php echo $url; ?>assets/img/icon/quote.png" alt="">
                        </span>
                        <p>Genuine and outstanding quality. Good at fulfilling the customer needs (oil blending).The aroma fragrance which i received are awesome...</p>
                    </div>

                    <div class="slider-text">
                        <span class="testi-quote">
                            <img src="<?php echo $url; ?>assets/img/icon/quote.png" alt="">
                        </span>
                        <p>I have purchased diffuser and essential oils from Mylal Exports. It's an amazing product, a must buy for every house. Affordable, it's worth every penny spent on it.
                            Diffuser was provided with replacement and service warranty, which is very convenient. The quality of oils is amazing and pure. You can choose to buy organic or non organic essential oils.</p>
                    </div>
                    <div class="slider-text">
                        <span class="testi-quote">
                            <img src="<?php echo $url; ?>assets/img/icon/quote.png" alt="">
                        </span>
                        <p>Excellent Quality, perfect product delivery timing. Business relationship is good.</p>
                    </div>
                    <div class="slider-text">
                        <span class="testi-quote">
                            <img src="<?php echo $url; ?>assets/img/icon/quote.png" alt="">
                        </span>
                        <p>I ordered 32 Essential oils. Today i got as soon as i opened my courier really i am cloud nine. Bcoz each and every product packed well without any leakage. For lesser quantity products they pack another one box for safety and lowest amount 1ml-5ml they put into a box which fully unmovable and not leakage. And also wrap in cover. And they send In DTDC courier thats also good service. Thank you so much. I am very happy for these products and excellent packing😍😍😍😍.</p>
                    </div>
                </div>
                <div class="image-carousel">
                    <div class="testi-img">
                        <h4>saravana kumar</h4>
                    </div>
                    <div class="testi-img">
                        <h4>Leo Robinson</h4>
                    </div>
                    <div class="testi-img">
                        <h4>focus industries</h4>
                    </div>

                    <div class="testi-img">
                        <h4>Kavya K</h4>
                    </div>
                    <div class="testi-img">

                        <h4>Aruachalam Dhamodaran</h4>
                    </div>
                    <div class="testi-img">

                        <h4>Hasina Shaj</h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include("sm_footer.php"); ?>
    <!-- Footer Area End -->

    <!-- QUICKVIEW PRODUCT -->

    <!-- END QUICKVIEW PRODUCT -->

    <!-- All js here -->
    <script src="<?php echo $url; ?>assets/js/popper.min.js"></script>
    <script src="<?php echo $url; ?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo $url; ?>assets/js/plugins.js"></script>
    <script src="<?php echo $url; ?>assets/js/ajax-mail.js"></script>
    <script src="<?php echo $url; ?>assets/js/main.js"></script>

    <script type="text/javascript">
        function myFunction() {
            $("#paging_form").submit();
        }

        function myFunction2() {
            $("#sorting_form").submit();
        }
    </script>

    <script type="text/javascript">
        $(document).ready(function() {

            /*-------------------------------------
                Price Slider
            ---------------------------------------*/
            $("#slider-range").slider({
                range: true,
                min: <?php echo $mmdata['minimum']; ?>,
                max: <?php echo $mmdata['maximum']; ?>,
                values: [<?php echo $mmdata['minimum']; ?>, <?php echo $mmdata['maximum']; ?>],
                slide: function(event, ui) {
                    $("#amount").val("" + ui.values[0] + " - " + ui.values[1]);
                    $("#min").val(ui.values[0]);
                    $("#max").val(ui.values[1]);

                }
            });
            $("#amount").val("" + $("#slider-range").slider("values", 0) +
                " - " + $("#slider-range").slider("values", 1));

        });
    </script>
</body>

</html>
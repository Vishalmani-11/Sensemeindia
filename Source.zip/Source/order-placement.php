<?php 
include "smadmin/function/config.php"; 
include "smadmin/db/db_connect.php"; 
include "smadmin/function/function.php"; 
var_dump($_POST); //exit(); 
//////////////////////////////This function is used to double check payment//////////////////////////////////////////////////////////////////////////
function verifyPayment($key,$salt,$txnid,$status)
{
	$command = "verify_payment"; //mandatory parameter
	
	$hash_str = $key  . '|' . $command . '|' . $txnid . '|' . $salt ;
	$hash = strtolower(hash('sha512', $hash_str)); //generate hash for verify payment request

    $r = array('key' => $key , 'hash' =>$hash , 'var1' => $txnid, 'command' => $command);
	    
    $qs= http_build_query($r);
	
	//for production
    $wsUrl = "https://info.payu.in/merchant/postservice.php?form=2";
   
	//for test
	//$wsUrl = "https://test.payu.in/merchant/postservice.php?form=2";
	
	try 
	{		
		$c = curl_init();
		curl_setopt($c, CURLOPT_URL, $wsUrl);
		curl_setopt($c, CURLOPT_POST, 1);
		curl_setopt($c, CURLOPT_POSTFIELDS, $qs);
		curl_setopt($c, CURLOPT_CONNECTTIMEOUT, 30);
		curl_setopt($c, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($c, CURLOPT_SSLVERSION, 6); //TLS 1.2 mandatory
		curl_setopt($c, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($c, CURLOPT_SSL_VERIFYPEER, 0);
		$o = curl_exec($c);
		if (curl_errno($c)) {
			$sad = curl_error($c);
			throw new Exception($sad);
		}
		curl_close($c);
		
		/*
		Here is json response example -
		
		{"status":1,
		"msg":"1 out of 1 Transactions Fetched Successfully",
		"transaction_details":</strong>
		{	
			"Txn72738624":
			{
				"mihpayid":"403993715519726325",
				"request_id":"",
				"bank_ref_num":"670272",
				"amt":"6.17",
				"transaction_amount":"6.00",
				"txnid":"Txn72738624",
				"additional_charges":"0.17",
				"productinfo":"P01 P02",
				"firstname":"Viatechs",
				"bankcode":"CC",
				"udf1":null,
				"udf3":null,
				"udf4":null,
				"udf5":"PayUBiz_PHP7_Kit",
				"field2":"179782",
				"field9":" Verification of Secure Hash Failed: E700 -- Approved -- Transaction Successful -- Unable to be determined--E000",
				"error_code":"E000",
				"addedon":"2019-08-09 14:07:25",
				"payment_source":"payu",
				"card_type":"MAST",
				"error_Message":"NO ERROR",
				"net_amount_debit":6.17,
				"disc":"0.00",
				"mode":"CC",
				"PG_TYPE":"AXISPG",
				"card_no":"512345XXXXXX2346",
				"name_on_card":"Test Owenr",
				"udf2":null,
				"status":"success",
				"unmappedstatus":"captured",
				"Merchant_UTR":null,
				"Settled_At":"0000-00-00 00:00:00"
			}
		}
		}
		
		Decode the Json response and retrieve "transaction_details" 
		Then retrieve {txnid} part. This is dynamic as per txnid sent in var1.
		Then check for mihpayid and status.
		
		*/
		$response = json_decode($o,true);
		
		if(isset($response['status']))
		{
			// response is in Json format. Use the transaction_detailspart for status
			$response = $response['transaction_details'];
			$response = $response[$txnid];
			
			if($response['status'] == $status) //payment response status and verify status matched
				return true;
			else
				return false;
		}
		else {
			return false;
		}
	}
	catch (Exception $e){
		return false;	
	}
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////
$postdata = $_POST;
if(isset($postdata['key'])) {
	
	$key				=   $postdata['key'];
	$txnid 				= 	$postdata['txnid'];
    $amount      		= 	$postdata['amount'];
	$productInfo  		= 	$postdata['productinfo'];
	$firstname    		= 	$postdata['firstname'];
	$email        		=	$postdata['email'];
	$udf1				=   $postdata['udf1'];	
	$udf2				=   $postdata['udf2'];	
	$udf3				=   $postdata['udf3'];	
	$udf4				=   $postdata['udf4'];	
	$status				= 	$postdata['status'];
	$resphash			= 	$postdata['hash'];
	
	$paymentSuccess = 0;
	$msg = '';
	//test salt
	//$salt="UnJ0FGO0kt3dUgnHo9Xgwi0lpipBV0hB";
	
	
	
	//production
	$salt="YGvnOBQvdw";		
	
	//Calculate response hash to verify	
	$keyString 	  		=  	$key.'|'.$txnid.'|'.$amount.'|'.$productInfo.'|'.$firstname.'|'.$email.'|'.$udf1.'|'.$udf2.'|'.$udf3.'|'.$udf4.'||||||';
	$keyArray 	  		= 	explode("|",$keyString);
	$reverseKeyArray 	= 	array_reverse($keyArray);
	$reverseKeyString	=	implode("|",$reverseKeyArray);
	$CalcHashString 	= 	strtolower(hash('sha512', $salt.'|'.$status.'|'.$reverseKeyString)); //hash without additionalcharges
	
	//check for presence of additionalcharges parameter in response.
	$additionalCharges  = 	"";
	
	If (isset($postdata["additionalCharges"])) {
       $additionalCharges=$postdata["additionalCharges"];
	   //hash with additionalcharges
	   $CalcHashString 	= 	strtolower(hash('sha512', $additionalCharges.'|'.$salt.'|'.$status.'|'.$reverseKeyString));
	}
	//Comapre status and hash. Hash verification is mandatory.
	if ($status == 'success'  && $resphash == $CalcHashString) {
		$msg = "Transaction Successful, Hash Verified...<br />";
		//Do success order processing here...
		//Additional step - Use verify payment api to double check payment.
		if(verifyPayment($key,$salt,$txnid,$status))
		{
			$paymentSuccess = 1;
		$msg = "Transaction Successful, Hash Verified...Payment Verified..."; 
		}
		else
		{
		$msg = "Transaction Successful, Hash Verified...Payment Verification failed..."; exit();
		}
	}
	else {
		//tampered or failed
		$msg = "Payment failed for Hash not verified..."; exit();
	} 
}
//else exit(0);

//////////////////////////////////////////////////////////////////////////////////  
if(!empty($_POST)&&isset($_POST['amount']))
{
    
    $msg = '';
/////////////////////////////////////////////////////////////////////////////////    
$status=$_POST["status"];
$lastname=$_POST["lastname"];
$firstname=$_POST["firstname"];
$amount=$_POST["amount"];
$amount_paid = $_POST["net_amount_debit"];
$udf1=$_POST["udf1"];
$udf2=$_POST["udf2"];
$udf3=$_POST["udf3"];
$udf4=$_POST["udf4"];
$txnid=$_POST["txnid"]; 
$posted_hash=$_POST["hash"];
$key=$_POST["key"];
$productinfo=$_POST["productinfo"];
$email=$_POST["email"];
$phone=$_POST["phone"]; 
$payu_id=$_POST["mihpayid"];
$payment_mode=$_POST["mode"];
$payment_date = $_POST['addedon'];	
	$mc_gross = $amount_paid;	
	$payment_status = $status;	
	$payment_type = $payment_mode;		
    $txn_id = $payu_id;
    $cid = $udf1;
    $cost = $udf2;

$_SESSION['total'] = $amount;	
$_SESSION['userlastlogintime'] = $udf3;						
$_SESSION['userlogintime'] = $udf4;						
$_SESSION['userSession'] = $cid;
$_SESSION['mobile_number'] = $phone;    
$_SESSION['userEmail'] = $email;		
$_SESSION['userName'] = $firstname." ".$lastname;	

if($paymentSuccess) 
      { 
   
/////////////////////////////////update order/////////////////////////////////////////// 

   $exdate = date('Y-m-d', strtotime("+3 days"));
	
           
if($_SESSION['total']==$mc_gross)
{
     
$orderstatus = "Confirmed";        
//////////////////////////get order details////////////////////////////////////////
$query = "SELECT * FROM pending_orders WHERE verify_sign = ?";

if(!$rstmt = $con->prepare($query))
{
	echo $error = "order details preparation failed!".$con->error;
}
	if(!$rstmt->bind_param("s", $txnid))
{
	echo "Param pass failed: (" . $con->errno . ") " . $con->error;
}
	
	if(!$rstmt->execute())
	{
		echo $error = "order details execution failed!".$con->error;		
		
	}    
    
    if(!$qresult = $rstmt->get_result())
		{
			echo $error = "order data failed!".$con->error;	exit();				
		}
    else
    {
        $order_data = $qresult->fetch_assoc();		
    }

//////////////////////////////////insert success order data/////////////////////////////////////

$myquery = "INSERT into bb_orders (cid, pending_id, fname, lname, pincode, cost, shipping, titems, address, sdays, exdate, orderstatus, sold, order_notes, mc_currency, mc_gross, payment_status, payment_type, payment_date, verify_sign, txn_id, order_placed) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?, ?, ?, ?, ?, ?, ?, ?)";

 $order_placed = 1;

if(!$ostmt = $con->prepare($myquery))
{
	echo "Prepare failed: (" . $con->errno . ") " . $con->error; exit();
}

if(!$ostmt->bind_param("iissiiiisssssssisssssi", $order_data['cid'], $order_data['id'], $order_data['fname'], $order_data['lname'], $order_data['pincode'], $order_data['cost'], $order_data['shipping'], $order_data['titems'], $order_data['address'], $order_data['sdays'], $order_data['exdate'], $orderstatus, $order_data['sold'], $order_data['order_notes'], $order_data['mc_currency'], $mc_gross, $payment_status, $payment_type, $payment_date, $order_data['verify_sign'], $txn_id, $order_placed))
{
	echo "Param pass failed2: (" . $con->errno . ") " . $con->error; exit();
}

if(!$ostmt->execute()) {
	echo $error = "New order saving failed!".$con->error; exit();
	
}
else
{
 
	$success= "New order data saved successfully!";
	$oid = $ostmt->insert_id;
//////////////////////delete pending order/////////////////////////////////////////////////
$dquery = "DELETE FROM pending_orders WHERE id = ?";
	
if(!$dstmt = $con->prepare($dquery))
{
	echo "Prepare failed: (" . $con->errno . ") " . $con->error; exit();
}

if(!$dstmt->bind_param("i", $order_data['id']))
{
	echo "Param pass failed2: (" . $con->errno . ") " . $con->error; exit();
}

if(!$dstmt->execute()) {
	echo $error = "order clearing failed!".$con->error; exit();
	
}
  
  /////////////////////////////product details//////////////////////////////////////////   
	
$oquery = "SELECT t1.id, t1.orderid, t1.pid, t1.sku, t1.name, t1.category, t1.sub_category, t1.product_type, t1.picture, t1.color, t1.size, t1.qty, t1.price, t1.cost, t1.reviewed, t2.parent_id, t3.address FROM bb_order_products as t1 INNER JOIN bb_products_stock as t2 ON t1.pid = t2.id INNER JOIN bb_orders as t3 ON t1.orderid = t3.pending_id WHERE t3.verify_sign = ?";

	 
if(!$orstmt = $con->prepare($oquery))
{
	echo $error = "order details preparation failed!".$con->error;exit();		
}
	if(!$orstmt->bind_param("s", $txnid))
{
	echo "Param pass failed: (" . $con->errno . ") " . $con->error;exit();		
}
	
	if(!$orstmt->execute())
	{
		echo $error = "order details execution failed!".$con->error;		exit();		
		
	}
	
	if(!$orstmt->store_result())
		{
			echo $error = "order listing execution failed!".$con->error;					exit();		
		}
	
	
	$ornum_of_rows = $orstmt->num_rows;

	if($ornum_of_rows==0)
{
	echo $ornum_error = "No products available"; exit();		
}
	
/////////////////////////////////////////////////////////////////////////////////////////////     
     
	
	$soldIDs = array();
	$pmessage = "";
    
    $orstmt->bind_result($id, $orderid, $pid, $sku, $name, $category, $sub_category, $product_type, $picture, $color, $size, $qty, $price, $cost, $reviewed, $parent_id, $address);
	while ($orstmt->fetch()) 
	{
         
			$sn = 	$sn + 1;
		    $name = ucwords($name);
            $soldIDs[] = $id;	
          $ptcost = $qty * $price;
//        $oid = $orderid;
        $fulladdress = $address;
		
		
 ////////////////////////update product stock/////////////////////////////////////////////////////
	$upquery = "UPDATE bb_products_stock SET qty = qty - ? WHERE id = ?";
								
			if(!$upstmt = $con->prepare($upquery))
		{
			echo $error = "products update failed!".$con->error;	exit();	
		}
		
		if(!$upstmt->bind_param('ii',$qty, $id))
		{
				echo $error = "products stock update failed!".$con->error;		exit();
		}

			if(!$upstmt->execute())
			{
				echo $error = "products stock update failed!".$con->error;		exit();

			}	
    
    ///////////////////////////////////////////////////////////////////
       
    $subtotal = $qty*$price;
	$pmessage .= "<tr>
                                      <td align='left'><div class='contentEditableContainer contentTextEditable'>
                                          <div class='contentEditable' align='center'>
                                            <p > <span style='color:#222222;'>".$name."</span>(".$size.")
 </p>
                                          </div>
                                        </div></td>
                                      <td align='left'><div class='contentEditableContainer contentTextEditable'>
                                          <div class='contentEditable' align='center'>
                                            <p > <span style='color:#222222;'>".$qty."</span> </p>
                                          </div>
                                        </div></td>
                                    </tr>";
	
								   
                                   }

	
	///////////////////////////////mail/////////////////////////////////////////////////////
	$message = "";
	$message = "
	<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>
<html xmlns='http://www.w3.org/1999/xhtml'>
<head>
<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
<title>Your order#SM".$oid." is confirmed!</title>
<style type='text/css'>
body {
	padding-top: 0 !important;
	padding-bottom: 0 !important;
	padding-top: 0 !important;
	padding-bottom: 0 !important;
	margin: 0 !important;
	width: 100% !important;
	-webkit-text-size-adjust: 100% !important;
	-ms-text-size-adjust: 100% !important;
	-webkit-font-smoothing: antialiased !important;
}
.tableContent img {
	border: 0 !important;
	display: block !important;
	outline: none !important;
}
a {
	color: #382F2E;
}
p, h1 {
	color: #382F2E;
	margin: 0;
}
p {
	text-align: left;
	color: #999999;
	font-size: 14px;
	font-weight: normal;
	line-height: 19px;
}
a.link1 {
	color: #382F2E;
}
a.link2 {
	font-size: 16px;
	text-decoration: none;
	color: #ffffff;
}
h2 {
	text-align: left;
	color: #222222;
	font-size: 19px;
	font-weight: normal;
}
div, p, ul, h1 {
	margin: 0;
}
.bgBody {
	background: #ffffff;
}
.bgItem {
	background: #ffffff;
}

@media only screen and (max-width:480px) {
table[class='MainContainer'], td[class='cell'] {
	width: 100% !important;
	height: auto !important;
}
td[class='specbundle'] {
	width: 100% !important;
	float: left !important;
	font-size: 13px !important;
	line-height: 17px !important;
	display: block !important;
	padding-bottom: 15px !important;
}
}
img[class='banner'] {
	width: 100% !important;
	height: auto !important;
}
td[class='left_pad'] {
	padding-left: 15px !important;
	padding-right: 15px !important;
}
}

@media only screen and (max-width:540px) {
table[class='MainContainer'], td[class='cell'] {
	width: 100% !important;
	height: auto !important;
}
td[class='spechide'] {
	display: none !important;
td[class='specbundle'] {
	width: 100% !important;
	float: left !important;
	font-size: 13px !important;
	line-height: 17px !important;
	display: block !important;
	padding-bottom: 15px !important;
}
td[class='spechide'] {
	display: none !important;
}
img[class='banner'] {
	width: 100% !important;
	height: auto !important;
}
.font {
	font-size: 18px !important;
	line-height: 22px !important;
}
.font1 {
	font-size: 18px !important;
	line-height: 22px !important;
}
}
</style>

</head>
<body paddingwidth='0' paddingheight='0'   style='padding-top: 0; padding-bottom: 0; padding-top: 0; padding-bottom: 0; background-repeat: repeat; width: 100% !important; -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; -webkit-font-smoothing: antialiased;' offset='0' toppadding='0' leftpadding='0'>
<table bgcolor='#ffffff' width='100%' border='0' cellspacing='0' cellpadding='0' class='tableContent' align='center'  style='font-family:Helvetica, Arial,serif;'>
  <tbody>
    <tr>
      <td><table width='600' border='0' cellspacing='0' cellpadding='0' align='center' bgcolor='#ffffff' class='MainContainer'>
          <tbody>
            <tr>
              <td><table width='100%' border='0' cellspacing='0' cellpadding='0'>
                  <tbody>
                    <tr>
                      <td valign='top' width='40'>&nbsp;</td>
                      <td><table width='100%' border='0' cellspacing='0' cellpadding='0'>
                          <tbody>
                            <!-- =============================== Header ====================================== -->
                            <tr>
                              <td height='30' class='spechide'></td>
                              
                              <!-- =============================== Body ====================================== --> 
                            </tr>
                            <tr>
                              <td class='movableContentContainer ' valign='top'><div class='movableContent' style='border: 0px; padding-top: 0px; position: relative;'>
                                  <table width='100%' border='0' cellspacing='0' cellpadding='0'>
                                    <tbody>
                                      <tr>
                                        <td height='35'></td>
                                      </tr>
                                      <tr>
                                        <td><table width='100%' border='0' cellspacing='0' cellpadding='0'>
                                            <tbody>
                                              <tr>
                                                <td valign='top' align='center' style='text-align:center;' class='specbundle'><div class='contentEditableContainer contentTextEditable'>
                                                    <div class='contentEditable'>
                                                      <p><img src='http://sensemeindia.com/assets/img/logo/logo.png' alt='Visit SenseMe India'/> </p>
                                                    </div>
                                                  </div></td>
                                              </tr>
                                              <tr>
                                                <td height='35'></td>
                                              </tr>
                                              <tr>
                                                <td valign='top' class='specbundle'><div class='contentEditableContainer contentTextEditable'>
                                                    <div class='contentEditable'>
                                                      <p style='text-align:left;margin:0;font-family:Georgia,Time,sans-serif;font-size:26px;color:#222222;'><span class='specbundle2'><span class='font1'>Dear ".$firstname." ".$lastname.", your order#SM".$oid." is confirmed!&nbsp;</span></p>
                                                    </div>
                                                  </div></td>
                                              </tr>
                                            </tbody>
                                          </table></td>
                                      </tr>
                                    </tbody>
                                  </table>
                                </div>
                                <div class='movableContent' style='border: 0px; padding-top: 0px; position: relative;'>
                                  <table width='100%' border='0' cellspacing='0' cellpadding='0' align='center'>
                                    <tr>
                                      <td height='25'></td>
                                    </tr>
                                    <tr>
                                      <td align='left'><div class='contentEditableContainer contentTextEditable'>
                                          <div class='contentEditable' align='left'>
                                            <h2>Greetings from SenseMe India!</h2>
                                          </div>
                                        </div></td>
                                    </tr>
                                    <tr>
                                      <td align='left'><div class='contentEditableContainer contentTextEditable'>
                                          <div class='contentEditable' align='left'>
                                            <p > We would like to inform you that We have received your order and will be shipped to your address soon! Please find your order details as below. <br />
                                              <br />
                                              For any queries kindly e-mail us to: order@sensemeindia.com <br />
                                              <br />
                                              Thank you for your order. </p>
                                          </div>
                                        </div></td>
                                    </tr>
                                    <tr>
                                      <td height='15'></td>
                                    </tr>
                                    <tr>
                                      <td align='left'><div class='contentEditableContainer contentTextEditable'>
                                          <div class='contentEditable' align='left'>
                                            <h2>Order detail</h2>
                                          </div>
                                        </div></td>
                                    </tr>
                                    <tr>
                                      <td  style='border-bottom:1px solid #DDDDDD;'></td>
                                    </tr>
                                    <tr>
                                      <td height='15'></td>
                                    </tr>
                                    <tr>
                                      <td align='left'><div class='contentEditableContainer contentTextEditable'>
                                          <div class='contentEditable' align='left'>
                                            <p > <span style='color:#222222;'><strong>Order ID:</strong> </span>#SM".$oid."<br />
                                              <span style='color:#222222;'><strong>Order value:</strong> </span>&#x20b9;".$amount."<br />
                                              <span style='color:#222222;'><strong>Amount paid:</strong> </span>&#x20b9;".bcdiv($mc_gross,1,2)."<br />
                                              <span style='color:#222222;'><strong>Payment mode:</strong> </span>Payu(".$payment_mode.")<br />
                                              <span style='color:#222222;'><strong>Transcation ID:</strong> </span>".$txnid."<br />
                                              <span style='color:#222222;'><strong>Order status: </strong></span> Confirmed<br />
                                              <span style='color:#222222;'><strong>Shipping cost:</strong> </span> Free <br />
                                              <span style='color:#222222;'><strong>Shipping address:</strong> </span>".$fulladdress." <br />
											  <span style='color:#222222;'><strong>Expected shipping date:</strong> </span>".date("F jS\, Y",strtotime($exdate))."<br />                                              
                                          </div>
                                        </div></td>
                                    </tr>
                                    <tr>
                                      <td height='15'></td>
                                    </tr>
                                  </table>
                                  <table width='100%' border='0' cellspacing='0' cellpadding='0' align='center'>
                                    <tr>
                                      <td align='left'><div class='contentEditableContainer contentTextEditable'>
                                          <div class='contentEditable' align='center'>
                                            <h2 >Item(s) detail</h2>
                                          </div>
                                        </div></td>
                                    </tr>
                                    <tr>
                                      <td  style='border-bottom:1px solid #DDDDDD;'></td>
                                      <td  style='border-bottom:1px solid #DDDDDD;'></td>
                                     
                                    </tr>
                                   
								   <tr>
                                      <td align='left'><div class='contentEditableContainer contentTextEditable'>
                                          <div class='contentEditable' align='center'>
                                            <h3 > Product </h3>
                                          </div>
                                        </div></td>
                                      <td align='left'><div class='contentEditableContainer contentTextEditable'>
                                          <div class='contentEditable' align='left'>
                                            <h3 > QTY </h3>
                                          </div>
                                        </div></td>
                                
                                    </tr>";
									
                               $message .= $pmessage;   

								$message .= "
                                    <tr>
                                      <td  style='border-bottom:1px solid #DDDDDD;'></td>
                                      <td  style='border-bottom:1px solid #DDDDDD;'></td>                                      
                                    </tr>
                                  </table>
                                </div>
                                <table width='100%' border='0' cellspacing='0' cellpadding='0'>
                                  <tbody>
                                    <tr>
                                      <td height='25'></td>
                                    </tr>
                                    <tr>
                                      <td><table width='100%' border='0' cellspacing='0' cellpadding='0'>
                                          <tbody>
                                            <tr>
                                              <td valign='top' class='specbundle'><div class='contentEditableContainer contentTextEditable'>
                                                  <div class='contentEditable' align='center'>
                                                    <p  style='text-align:left;color:#CCCCCC;font-size:12px;font-weight:normal;line-height:20px;'> <span style='font-weight:bold;'>E-mail: order@sensemeindia.com</span> <br>
                                                      <a target='_blank' href='https://sensemeindia.com'>www.sensemeindia.com</a><br>
                                                    </p>                        
                                                  </div>
                                                </div></td>
                                              <td valign='top' width='30' class='specbundle'>&nbsp;</td>
                                              <td valign='top' class='specbundle'><table width='100%' border='0' cellspacing='0' cellpadding='0'>
                                                  <tbody>
                                                    <tr>
                                                      <td valign='top' width='52'><div class='contentEditableContainer contentFacebookEditable'>
                                                          <div class='contentEditable'> </div>
                                                        </div></td>
                                                      <td valign='top' width='16'>&nbsp;</td>
                                                      <td valign='top' width='52'></td>
                                                    </tr>
                                                  </tbody>
                                                </table></td>
                                            </tr>
                                          </tbody>
                                        </table></td>
                                    </tr>
                                    <tr>
                                      <td height='88'></td>
                                    </tr>
                                  </tbody>
                                </table>
                                </div>
                                
                                </td>
                            </tr>
                          </tbody>
                        </table></td>
                      <td valign='top' width='40'>&nbsp;</td>
                    </tr>
                  </tbody>
                </table></td>
            </tr>
          </tbody>
        </table></td>
    </tr>
  </tbody>
</table>
</body>
</html>
";	

////////////////////////update offer/////////////////////////////////////////////////////
	$uo_pquery = "UPDATE bb_users SET offer = ? WHERE id = ?";
			
        $offer_flag = 1;
                                
                                
			if(!$uo_stmt = $con->prepare($uo_pquery))
		{
			echo $error = "user update failed!".$con->error;	exit();	
		}
		
		if(!$uo_stmt->bind_param('ii',$offer_flag, $cid))
		{
				echo $error = "user stock update failed!".$con->error;		exit();
		}

			if(!$uo_stmt->execute())
			{
				echo $error = "user stock update failed!".$con->error;		exit();

			}	
    
                                
    ///////////////////////////////////////////////////////////////////
                                
	$_SESSION['ordersuccess'] = $oid;
	$_SESSION['exdate'] = $exdate;
	$_SESSION['txn_id'] = $txnid;
	$_SESSION['name'] = $firstname." ".$lastname;	
	$from = "order@sensemeindia.com";
	$to = $email; 
    if(empty($to))
    {
        echo "customer email is missing!"; exit();
    }
	$subject = "Your order #SM".$oid." is confirmed!";							
	if(!$mail_result = send_html_mail($from,$to,$message,$subject))
    {
        echo $mail_result."error sending mail";  exit();
    }
	
	
	$to = "order@sensemeindia.com";								
	
	$subject = "Online order received from ".$_SESSION['name']." - #SM".$oid;							
	if(!$mail_result = send_html_mail($from,$to,$message,$subject))
    {
        echo $mail_result."error sending mail2";  exit();
    }    
                               
///////////////////////////////SMS notification////////////////////////////////////////////   
$sms_message = "Greetings from SenseMe India! Your order #SM".$oid." is confirmed! Your order will be shipped soon. Thank you for ordering! - Mylal Exports";    
$result = PostRequest( $phone, $sms_message );
$result = PostRequest( $phone, $sms_message );
                    
     if($result !=0)
                    {
                        echo "error in sending SMS"; exit();
                    }

///////////////////////////Admin SMS/////////////////////////////

	
$sms_message_1 = "New order placed from sensemeindia.com. order id: #SM".$oid.". ".$_SESSION['name']." - ".$phone.". Amount - Rs ".$_SESSION['total']." - Mylal Exports";

$admin_phone = "9150870543";
                             
$result2 = PostRequest( $admin_phone, $sms_message_1 );
$result2 = PostRequest( $admin_phone, $sms_message_1 );
                    if($result2 !=0)
                    {
                        echo "error in sending SMS2"; exit();
                    }
    
////////////////////////////////////////////////////////////////////	
    $success = "<strong>order placed successfully!</strong>"; 
header("location:order-placement.php?osuccess=".$success."&exdate=".$_SESSION['exdate']."&total=".$_SESSION['total']."&orderid=".$_SESSION['ordersuccess']."&txnid=".$_SESSION['txn_id']."&name=".$_SESSION['name']."&value=".$amount);
  
	$_POST = array(); 

}

}
       }

}

?>

<!doctype html>
<html class="no-js" lang="en">
   <head>
	   <script>
window.dataLayer = window.dataLayer || [];
dataLayer.push({
 'event': 'purchaseMade'});
</script>
		   
       <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-WWCJ4NT');</script>
<!-- End Google Tag Manager -->
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Order Confirmation | SenseMe India</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Favicon -->
        <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.png">

        <!-- All css here -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/css/font-awesome.min.css">
        <link rel="stylesheet" href="assets/css/ie7.css">
        <link rel="stylesheet" href="assets/css/plugins.css">
        <link rel="stylesheet" href="assets/css/style.css">
       <link rel="stylesheet" href="assets/css/menu/style.css">     
        <script src="assets/js/vendor/modernizr-3.5.0.min.js"></script>
           <script src="assets/js/vendor/jquery-3.2.1.min.js"></script>
       <script src="assets/css/menu/script.js"></script>
<!-- Facebook Pixel Code -->
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '327668741988781');
  fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
  src="https://www.facebook.com/tr?id=327668741988781&ev=PageView&noscript=1"
/></noscript>
<!-- End Facebook Pixel Code -->
        
    </head>
    <body>
      	<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-WWCJ4NT"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
  <div id="loadAjax" class="ui-front loader ui-widget-overlay bg-gray opacity-50" style="display:none">
           <img src="assets/img/loader-light.gif" alt="">
        </div>
        
         <?php include("sm_header.php"); ?>
        <div class="breadcrumb-area bg-12 text-center">
            <div class="container">
                <h1>Order Confirmation</h1>
                <nav aria-label="breadcrumb">
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Order Confirmation</li>
                    </ul>
                </nav>
            </div>
        </div>
        <!-- Breadcrumb Area End -->
        <!-- Cart Area Start -->
		
        <div class="cart-area table-area pt-80 pb-95">
            <div class="container">  
    <div class="col-lg-6 col-md-6 offset-3">
                        <div class="recept center">
              <?php if(isset($_GET['error']))
{
echo $_GET['error'];
}
			?>
				
        <?php if(isset($_GET)&&isset($_GET['osuccess']))
{ extract($_GET);
                            
                            ?> 
				<div class="border-all">
                          
                            <div class="order_table table-responsive p-4 m-0">
                                <table class="border-all">
                                    <thead>
                                        <tr class="mb-20">
                                            <th  class="pt-20 pb-20" width="50%" colspan="2"><h2><i class="fa fa-check-circle" style="color: green" aria-hidden="true"></i></h2><h6 class="h5">Thank you <?php echo $name; ?> for your order! </br>Order Details has been sent to your email.</h6></th>
                                             
                                            
                                        </tr>
                                    </thead>
                           
                                    <tfoot>
                                        <tr>
                                            <td class="pt-20"><strong>Order ID:</strong></td>
                                            <td class="pt-20"><?php echo "#SM".$orderid; ?> </td>
                                        </tr>
                                        <tr>
                                            <td><strong>Order Value:</strong></td>
                                            <td>&#x20b9;  <?php echo $total; ?></td>
                                        </tr>
                                         <tr>
                                            <td><strong>Amount paid:</strong></td>
                                            <td>&#x20b9;  <?php echo $value; ?></td>
                                        </tr>
                                       <tr class="cart_item">
                                            <td><strong>Transcation ID:</strong></td>
                                            <td> <?php echo $txnid; ?></td>
                                        </tr>
                                        <tr class="cart_item">
                                            <td><strong>Expected Shipping date:</strong></td>
                                            <td><?php echo date("F jS\, Y",strtotime($exdate)); ?></td>
                                        </tr>
                                    </tfoot>
                                </table>     
                            </div>
                        </div>
			<?php 

                unset($_SESSION['exdate']);
				unset($_SESSION['total']);					 
				unset($_SESSION['ordersuccess']);
				unset($_SESSION['txn_id']);
				unset($_SESSION['name']); 
                    
 
} else { ?>	
				 
                <div class="empty-space marg-lg-b30"></div>
			<div class="simple-text">
                    <h6 class="h2"><i class="fa fa-shopping-cart" style="color: green" aria-hidden="true"></i> Please add some products to place your order.</h6>
                </div>
				
				<?php }       
				?>
				
            </div>
                         
                           
                        </form>         
                    </div>
               
           
        </div>
      
        </div>
        <?php include("sm_footer.php"); ?>
        <!-- Footer Area End -->
        
        <!-- QUICKVIEW PRODUCT -->
        
        <!-- END QUICKVIEW PRODUCT -->
        
        <!-- All js here -->
        <script src="assets/js/popper.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/plugins.js"></script>
        <script src="assets/js/ajax-mail.js"></script>
        <script src="assets/js/main.js"></script>
    </body>
</html>
<?php


include "smadmin/function/config.php";
include "smadmin/db/db_connect.php";
include "smadmin/function/function.php";
require_once 'smadmin/admin/class.user_2.php';
include "smadmin/function/image_resize.php";

function product_detail_query_params($query)
{
    unset($query['product_id'], $query['name'], $query['product_size'], $query['parent_id']);
    return $query;
}

function redirect_to_product_detail_url($con, $url, $product_id, $query = array(), $status_code = 302)
{
    $redirect_url = build_product_url_by_stock_id($con, $url, $product_id, $query);
    if ($redirect_url) {
        header("Location: " . $redirect_url, true, $status_code);
        exit();
    }
}

////////////////////////////////Add review//////////////////////////////////////////////
if (isset($_POST['submit_review']) && isset($_POST['parent_id'])) {

    $cid = $_SESSION['userSession'];

    extract($_POST);

    $r_product_id = secure_input($con, $product_id);
    $rr_parent_id = secure_input($con, $parent_id);
    $title = secure_input($con, $review_title);
    $review = secure_input($con, $review);
    $recommend = secure_input($con, $recommend);
    $rating = secure_input($con, $rating);
    $order_pid = secure_input($con, $order_pid);

    ////////////////////////////Image upload////////////////////////////
    $pimage = array();
    for ($i = 0; $i < 3; $i++) {
        if (($_FILES['pic']['error'][$i] == 0)) {
            if (($_FILES["pic"]["size"][$i] < 5000000)) {
                $file_tmp_name = $_FILES["pic"]["tmp_name"][$i];
                $path = "smadmin/uploads/tempimage/";
                $image_path = "uploads/tempimage/";
                $error_path = build_product_url_by_stock_id($con, $url, $r_product_id);
                if (!$error_path) {
                    $error_path = "product-details.php?product_id=" . $r_product_id;
                }
                $exten = explode(".", $_FILES["pic"]["name"][$i]);
                $old_name = $exten[0];
                $extension = end($exten);
                $new_name = 1;
                $file = upload_image($file_tmp_name, $old_name, $path, $image_path, $error_path, $new_name);
                /////////////////image resize/////////////////////////////    
                $width = 800;
                $height = 500;
                $file = "smadmin/" . $file;
                $exten2 = explode(".", $file);
                $extension2 = end($exten);
                $newfilename1 = uniqid('smreview_', true) . "." . $extension2;
                $resizedFile = "smadmin/uploads/reviews/" . $newfilename1;
                $db_image_path = "uploads/reviews/" . $newfilename1;
                if (!smart_resize_image($file, null, $width, $height, true, $resizedFile, true, false, 60)) {
                    exit("error in resizing" . mysqli_error($con));
                }

                $pimage[] = $db_image_path;
                /////////////////////////////////////////////////////////////////////////////////    


            } else {
                $error = "Invalid file size!";
                redirect_to_product_detail_url($con, $url, $r_product_id, array('w_success' => $w_success));
            }
        } else {
            $pimage[] = NULL;
        }
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////////////


    if (!$w_stmt = $con->prepare("INSERT INTO productrating (parent_id, pid, order_pid, cid, title, review, star, pic1, pic2, pic3, recommend) VALUES (?, ?, ?, ?, ?, ?, ?, ?)")) {
        echo "Prepare failed: (" . $con->errno . ") " . $con->error;
    }

    if (!$w_stmt->bind_param("iiiissssssi", $rr_parent_id, $r_product_id, $order_pid, $cid, $title, $review, $rating, $pimage[0], $pimage[1], $pimage[2], $recommend)) {
        echo "Param pass failed: (" . $con->errno . ") " . $con->error;
    }

    if (!$w_stmt->execute()) {

        echo $error = "review update failed!" . $con->error;
        exit();
    } else {

        /////////////////////////update review status for ordered item//////////////////////////////////////////

        $up_query = "UPDATE bb_order_products SET reviewed = ? WHERE id = ?";

        if (!$up_stmt = $con->prepare($up_query)) {
            echo $error = "preparation failed!" . $con->error;
            exit();
        }

        $reviewed = 1;

        if (!$up_stmt->bind_param("ii", $reviewed, $order_pid)) {
            echo "Param pass failed: (" . $con->errno . ") " . $con->error;
            exit();
        }

        if (!$up_stmt->execute()) {
            echo $error = "review update failed!" . $con->error;
            exit();
        } else {
            $r_success = "<strong>Product review added successfully!</strong>";
            redirect_to_product_detail_url($con, $url, $r_product_id, array('r_success' => $r_success));
        }
        //////////////////////////////////////////////////////////////////////////////////////

    }
}
////////////////////////////////Add to wishlist//////////////////////////////////////////////
if (isset($_GET['action']) && $_GET['action'] == "wishlist") {

    $reg_user = new USER();

    if ($reg_user->is_logged_in()) {

        $cid = $_SESSION['userSession'];

        extract($_GET);

        $w_product_id = secure_input($con, $pid);
        $w_pic = secure_input($con, $image);
        $w_price = secure_input($con, $price);

        if (!$w_stmt = $con->prepare("INSERT INTO wishlist (cid, pid, price, image) VALUES (?, ?, ?, ?)")) {
            echo "Prepare failed: (" . $con->errno . ") " . $con->error;
        }

        if (!$w_stmt->bind_param("iiis", $cid, $w_product_id, $w_price, $w_pic)) {
            echo "Param pass failed: (" . $con->errno . ") " . $con->error;
        }

        if (!$w_stmt->execute()) {

            $error = "wishlist update failed!" . $con->error;
            exit();
        } else {
            $w_success = "<strong>Product added to your wishlist</strong>";
            redirect_to_product_detail_url($con, $url, $w_product_id, array('w_success' => $w_success));
        }
    } elseif (!$reg_user->is_logged_in()) {
        $reg_user->redirect('customer-login-checkout.php');
        exit();
    }
}

//////////////////////////product listing////////////////////////////////////////

///////////////from live search - getting product id////////////////////////// 
if (isset($_POST['product_name']) && $_POST['product_name'] != "" && isset($_POST['live_search']) && $_POST['live_search'] == 1) {
    extract($_POST);
    $product_name = secure_input($con, $product_name);
    $active = 1;

    $lsquery = "SELECT t1.id FROM bb_products_stock as t1 INNER JOIN bb_products as t2 ON t1.parent_id = t2.id WHERE t2.name = ? AND t1.active = ? GROUP BY t1.parent_id";

    if (!$lsstmt = $con->prepare($lsquery)) {
        echo "query failed: (" . $con->errno . ") " . $con->error;
    }

    if (!$lsstmt->bind_param("si", $product_name, $active)) {
        echo "Param pass failed: (" . $con->errno . ") " . $con->error;
    }

    if (!$lsstmt->execute()) {
        echo $error = "child product details execution failed!" . $con->error;
    }
    if (!$lsqresult = $lsstmt->get_result()) {
        echo $error = "child product details listing failed!" . $con->error;
    }

    $lsnum_of_rows = $lsqresult->num_rows;

    if ($lsnum_of_rows == 0) {
        echo $serror = "Product details not found";
        exit();
    }

    if (!$lsdata = $lsqresult->fetch_assoc()) {
        echo $cdata = "error" . $con->error;
        exit();
    } else {
        redirect_to_product_detail_url($con, $url, $lsdata['id']);
    }
}
///////////////////////product details regular///////////////////////////////
if (!isset($_GET['product_id']) || $_GET['product_id'] == "") {
    header("location:" . $url);
    exit();
}

if (isset($_GET['product_id']) && $_GET['product_id'] != "") {
    extract($_GET);
    $product_id = secure_input($con, $product_id);

    if (isset($_GET['order_pid']) && $_GET['order_pid'] != "") {
        $order_pid = secure_input($con, $order_pid);
    }


    $active = 1;

    $fupquery = "SELECT t1.*, t2.id as parent_id, t2.mc_id, t2.sc_id, t2.name as pname, t2.details, t2.description, t2.g_description, t2.disclaimer as disclaimer, t2.seo_title, t2.seo_keyword, t2.seo_meta, t3.name as scname, t4.name as mcname, t6.name as psize FROM bb_products_stock as t1 INNER JOIN bb_products as t2 ON t1.parent_id = t2.id INNER JOIN bb_sub_categories as t3 ON t2.sc_id = t3.id INNER JOIN bb_categories as t4 ON t2.mc_id = t4.id INNER JOIN bb_sizes as t6 ON t1.size = t6.id WHERE t1.id = ? ORDER BY t6.name DESC";

    if (!$fupstmt = $con->prepare($fupquery)) {
        echo "query failed: (" . $con->errno . ") " . $con->error;
    }

    if (!$fupstmt->bind_param("i", $product_id)) {
        echo "Param pass failed: (" . $con->errno . ") " . $con->error;
    }

    if (!$fupstmt->execute()) {
        echo $error = "child product details execution failed!" . $con->error;
    }
    if (!$fupqresult = $fupstmt->get_result()) {
        echo $error = "child product details listing failed!" . $con->error;
    }

    $snum_of_rows = $fupqresult->num_rows;

    if ($snum_of_rows == 0) {
        echo $serror = "Product details not found";
        exit();
    } else {

        if (!$fupdata = $fupqresult->fetch_assoc()) {
            echo $cdata = "error" . $con->error;
            exit();
        }

        $r_parent_id = $fupdata['parent_id'];

        $GM_pname_url = URL_trim($fupdata['pname']);
        $GM_mcname_url = URL_trim($fupdata['mcname']);
        $GM_scname_url = URL_trim($fupdata['scname']);
        $canonical_product_url = build_product_url($url, $fupdata['mcname'], $fupdata['scname'], $fupdata['pname'], $product_id);
        $canonical_product_url_with_cart = build_product_url($url, $fupdata['mcname'], $fupdata['scname'], $fupdata['pname'], $product_id, array('msg' => 'cartview'));
        $wishlist_url = build_product_url($url, $fupdata['mcname'], $fupdata['scname'], $fupdata['pname'], $product_id, array('action' => 'wishlist', 'pid' => $product_id, 'price' => $fupdata['price'], 'image' => $fupdata['pic1']));

        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            $current_request_path = rtrim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), '/');
            $canonical_request_path = rtrim(parse_url($canonical_product_url, PHP_URL_PATH), '/');

            // The SEO rewrite supplies the product name in $_GET['name'].
            // When the SEO URL is internally rewritten, some server configurations
            // can make REQUEST_URI appear different from the canonical URL and
            // trigger a false self-redirect. Do not redirect an already rewritten
            // SEO request; only canonicalize direct/non-SEO requests or explicit
            // legacy variation parameters.
            $is_seo_route = isset($_GET['name']) && $_GET['name'] !== '';

            if ((!$is_seo_route && $current_request_path !== $canonical_request_path) || isset($_GET['product_size']) || isset($_GET['parent_id'])) {
                header("Location: " . build_product_url($url, $fupdata['mcname'], $fupdata['scname'], $fupdata['pname'], $product_id, product_detail_query_params($_GET)), true, 301);
                exit();
            }
        }

        //////////////////////////////google main category 1//////////////////////////   

        switch (strtolower($fupdata['mcname'])) {

            case "essential oils":
                //$g_category = "Health &amp; Beauty &gt; Personal Care";
                $g_category = "Essential Oils";
                break;
            case "synergy blends":
                $g_category = "Home Fragrances &gt; Fragrance Oil";
                break;

            case "diffusers":
                $g_category = "Aroma Diffusers";
                break;

            default:
                $g_category = "Natural Essential Oils";
        }
        /////////////////////////////////////////////////////////////////////////////////////////////////  
        //////////////////////////////google sub category //////////////////////////   

        switch (strtolower($fupdata['scname'])) {

            case "soap making":
                $g_category = "Fragrance Oils &gt; Soap Making";
                break;


            case "agarpathis":
                $g_category = "Fragrance Oils &gt; Incense Making";
                break;

            case "colour candle":
                $g_category = "Fragrance Oils &gt; Candle Making";
                break;
            case "ultrasonic":
                $g_category = "Aroma Diffusers &gt; Ultrasonic";
                break;
        }
        ///////////////////////////////////////////////////////////////////////////////////////////////// 

        ///////////////////////////////////////////////////////////////////////

    }
    ///////////////////////////////related products//////////////////////////////////////////////
    $na_query = "SELECT t1.id, t1.name, t1.description, t2.id, t2.mrp, t2.price, t2.pic1, t2.pic2, t2.featured, t2.cdate FROM bb_products as t1 INNER JOIN bb_products_stock as t2 ON t1.id = t2.parent_id WHERE t1.mc_id = ? AND t1.sc_id = ? AND t1.active = ? AND t1.id <> ? GROUP BY t2.parent_id ORDER BY CASE WHEN t1.id > ? THEN 0 ELSE 1 END, t1.id ASC LIMIT 8";

    $product_active = 1;

    if (!$na_stmt = $con->prepare($na_query)) {
        echo $error = "Product data listing preparation failed 1!" . $con->error;
        exit();
    }
    if (!$na_stmt->bind_param('iiiii', $fupdata['mc_id'], $fupdata['sc_id'], $product_active, $r_parent_id, $r_parent_id)) {
        echo $error = "Product data listing preparation failed!" . $con->error;
        exit();
    }

    if (!$na_stmt->execute()) {
        echo $error = "Product data listing execution failed!" . $con->error;
        exit();
    }
    if (!$na_stmt->store_result()) {
        echo $error = "Product data listing execution failed!" . $con->error;
        exit();
    }

    $na_num_of_rows = $na_stmt->num_rows;

    if ($na_num_of_rows == 0) {
        $na_error = "No products available";
    }

    ////////////////////////////primary item sizes///////////////////////////////////////////////////////

    $si_query = "SELECT t1.id, t2.name FROM bb_products_stock as t1 INNER JOIN bb_sizes as t2 ON t1.size = t2.id WHERE t1.parent_id = ? AND t1.active = ? GROUP BY t1.size ORDER BY t2.id ASC";

    if (!$si_stmt = $con->prepare($si_query)) {
        echo "prepare failed: (" . $con->errno . ") " . $con->error;
        exit();
    }
    if (!$si_stmt->bind_param("ii", $r_parent_id, $active)) {
        echo "Param pass failed: (" . $con->errno . ") " . $con->error;
        exit();
    }

    if (!$si_stmt->execute()) {
        $error = "categories list failed!" . $con->error;
        exit();
    }

    if (!$si_stmt->store_result()) {
        $error = "categories list failed!" . $con->error;
        exit();
    }

    $si_num_of_rows = $si_stmt->num_rows;

    if ($si_num_of_rows == 0) {
        $si_error = "No sizes found";
    }


    /////////////////////////////////////////review star count///////////////////////////    


    $reviews_query = "SELECT COUNT(*) as total_reviews, SUM(t1.star) as total_star_1, SUM(t1.recommend) as total_recommend_1, SUM(t2.star) as total_star_2, SUM(t2.recommend) as total_recommend_2 from productrating as t1 RIGHT JOIN smratings as t2 ON t1.parent_id = t2.parent_id WHERE (t1.parent_id = ? OR t2.parent_id = ?) AND (t1.status = ? OR t2.status = ?)";


    if (!$reviews_stmt = $con->prepare($reviews_query)) {
        echo "prepare failed: (" . $con->errno . ") " . $con->error;
        exit();
    }
    $status = 1;

    if (!$reviews_stmt->bind_param("iiii", $r_parent_id, $r_parent_id, $status, $status)) {
        echo "Param pass failed: (" . $con->errno . ") " . $con->error;
        exit();
    }

    if (!$reviews_stmt->execute()) {
        $error = "categories list failed!" . $con->error;
        exit();
    }

    if (!$review_result = $reviews_stmt->get_result()) {
        echo $error = "review details listing failed!" . $con->error;
        exit();
    }

    $reviews_num_of_rows = $review_result->num_rows;

    if ($reviews_num_of_rows == 0) {
        $serror = "No reviews found";
    } else {

        if (!$review_data = $review_result->fetch_assoc()) {
            echo $cdata = "error" . $con->error;
            exit();
        }
        $sum = $review_data['total_star_1'] + $review_data['total_star_2'];
        $rsum = $review_data['total_recommend_1'] + $review_data['total_recommend_2'];
        $re_sum = $review_data['total_reviews'];
        $rper = 0;

        if ($sum > 0) {
            $rper = round(($rsum / $re_sum) * 100);
        }
    }
    /////////////////////////////////////////list regular review///////////////////////////    


    $reviews_query2 = "SELECT t1.title, t1.review, t1.star, t1.cdate, t1.pic1, t1.pic2, t1.pic3, t1.recommend, CONCAT(t2.fname,' ',t2.lname) as cname from productrating as t1 INNER JOIN bb_users as t2 ON t1.cid = t2.id WHERE t1.parent_id = ? AND t1.status = ? ";

    if (!$reviews_stmt2 = $con->prepare($reviews_query2)) {
        echo "prepare failed: (" . $con->errno . ") " . $con->error;
        exit();
    }
    $status = 1;

    if (!$reviews_stmt2->bind_param("ii", $r_parent_id, $status)) {
        echo "Param pass failed: (" . $con->errno . ") " . $con->error;
        exit();
    }

    if (!$reviews_stmt2->execute()) {
        $error = "categories list failed!" . $con->error;
        exit();
    }



    if (!$reviews_stmt2->store_result()) {
        $error = "categories list failed!" . $con->error;
        exit();
    }

    $reviews_num_of_rows2 = $reviews_stmt2->num_rows;

    if ($reviews_num_of_rows2 == 0) {
        $review_error2 = "No reviews found";
    }

    /////////////////////////////////////////list review 2///////////////////////////    


    $reviews_query3 = "SELECT name, title, review, star, review_date, pic1, pic2, pic3, recommend from smratings WHERE parent_id = ? AND status = ? ";

    if (!$reviews_stmt3 = $con->prepare($reviews_query3)) {
        echo "prepare failed: (" . $con->errno . ") " . $con->error;
        exit();
    }
    $status = 1;

    if (!$reviews_stmt3->bind_param("ii", $r_parent_id, $status)) {
        echo "Param pass failed: (" . $con->errno . ") " . $con->error;
        exit();
    }

    if (!$reviews_stmt3->execute()) {
        echo    $error = "review list failed!" . $con->error;
        exit();
    }

    if (!$reviews_stmt3->store_result()) {
        echo $error = "review list failed!" . $con->error;
        exit();
    }

    $reviews_num_of_rows3 = $reviews_stmt3->num_rows;

    if ($reviews_num_of_rows3 == 0) {
        $review_error3 = "No reviews found";
    }


    /////////////////////////////////////////check inwishlist///////////////////////////    

    $inwishlist = false;

    $reg_user = new USER();

    if ($reg_user->is_logged_in()) {

        $cw_query = "SELECT * from wishlist WHERE cid = ? AND pid = ? LIMIT 1";

        if (!$cw_stmt = $con->prepare($cw_query)) {
            echo "prepare failed: (" . $con->errno . ") " . $con->error;
        }

        $cid = $_SESSION['userSession'];

        if (!$cw_stmt->bind_param("ii", $cid, $product_id)) {
            echo "Param pass failed: (" . $con->errno . ") " . $con->error;
        }

        if (!$cw_stmt->execute()) {
            $error = "categories list failed!" . $con->error;
        }

        if (!$cw_stmt->store_result()) {
            $error = "categories list failed!" . $con->error;
        }

        $cw_num_of_rows = $cw_stmt->num_rows;

        if ($cw_num_of_rows == 0) {
            $inwishlist = false;
        } else {
            $inwishlist = true;
        }
    }
    /////////////////////////////////////////check review///////////////////////////    

    if (isset($_GET['order_pid'])) {
        $inreview = false;

        $reg_user = new USER();

        if ($reg_user->is_logged_in()) {

            $cr_query = "SELECT * from productrating WHERE order_pid = ? AND cid = ? LIMIT 1";

            if (!$cr_stmt = $con->prepare($cr_query)) {
                echo "prepare failed: (" . $con->errno . ") " . $con->error;
            }

            $cid = $_SESSION['userSession'];

            if (!$cr_stmt->bind_param("ii", $order_pid, $cid)) {
                echo "Param pass failed: (" . $con->errno . ") " . $con->error;
            }

            if (!$cr_stmt->execute()) {
                $error = "categories list failed!" . $con->error;
            }

            if (!$cr_stmt->store_result()) {
                $error = "categories list failed!" . $con->error;
            }

            $cr_num_of_rows = $cr_stmt->num_rows;

            if ($cr_num_of_rows == 0) {
                $inreview = false;
            } else {
                $inreview = true;
            }
        }
    } else {
        $inreview = true;
    }
    ///////////////////////////////////////////////////////////////////////////////////////
}

?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <!-- Google Tag Manager -->
    <script>
        (function(w, d, s, l, i) {
            w[l] = w[l] || [];
            w[l].push({
                'gtm.start': new Date().getTime(),
                event: 'gtm.js'
            });
            var f = d.getElementsByTagName(s)[0],
                j = d.createElement(s),
                dl = l != 'dataLayer' ? '&l=' + l : '';
            j.async = true;
            j.src =
                'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
            f.parentNode.insertBefore(j, f);
        })(window, document, 'script', 'dataLayer', 'GTM-WWCJ4NT');
    </script>
    <!-- End Google Tag Manager -->


    <script>
        window.dataLayer = window.dataLayer || [];
        window.dataLayer.push({
            'event': 'view_item',
            'value': <?php echo $fupdata['price']; ?>,
            'items': [{
                'id': <?php echo $product_id; ?>,
                'google_business_vertical': 'retail'
            }]
        });
    </script>


    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title><?php echo nl2br(htmlspecialchars_decode(($fupdata['seo_title'])));  ?></title>
    <meta name="description" content="<?php echo nl2br(htmlspecialchars_decode(($fupdata['seo_meta']))); ?>">
    <meta name="Keywords" content="<?php echo nl2br(htmlspecialchars_decode(($fupdata['seo_keyword']))); ?>">
    <link rel="canonical" href="<?php echo $canonical_product_url; ?>">
    <script type="application/ld+json">
{
  "@context":"https://schema.org/",
  "@type":"Product",
  "name":"<?php echo htmlspecialchars($fupdata['pname'], ENT_QUOTES, 'UTF-8'); ?>",
  "image":[
    "<?php echo $url; ?>smadmin/<?php echo $fupdata['pic3']; ?>"
  ],
  "description":"<?php echo htmlspecialchars(strip_tags($fupdata['description']), ENT_QUOTES, 'UTF-8'); ?>",
  "sku":"<?php echo htmlspecialchars($fupdata['sku'], ENT_QUOTES, 'UTF-8'); ?>",
  "category":"<?php echo htmlspecialchars($fupdata['mcname'].' > '.$fupdata['scname'], ENT_QUOTES, 'UTF-8'); ?>",
  "brand":{
    "@type":"Brand",
    "name":"SenseMe India"
  },
  "offers":{
    "@type":"Offer",
    "url":"<?php echo $canonical_product_url; ?>",
    "priceCurrency":"INR",
    "price":"<?php echo $fupdata['price']; ?>",
    "availability":"https://schema.org/InStock",
    "itemCondition":"https://schema.org/NewCondition"
  }
}
</script>

<script type="application/ld+json">
{
  "@context":"https://schema.org",
  "@type":"BreadcrumbList",
  "itemListElement":[
    {
      "@type":"ListItem",
      "position":1,
      "name":"Home",
      "item":"https://sensemeindia.com/"
    },
    {
      "@type":"ListItem",
      "position":2,
      "name":"<?php echo htmlspecialchars($fupdata['pname'], ENT_QUOTES, 'UTF-8'); ?>",
      "item":"<?php echo $canonical_product_url; ?>"
    }
  ]
}
</script>
    
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo $url; ?>assets/img/favicon.png">
    <!-- All css here -->
    <link rel="stylesheet" href="<?php echo $url; ?>assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $url; ?>assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo $url; ?>assets/css/ie7.css">
    <link rel="stylesheet" href="<?php echo $url; ?>assets/css/plugins.css">
    <link rel="stylesheet" href="<?php echo $url; ?>assets/css/style.css">
    <link rel="stylesheet" href="<?php echo $url; ?>assets/css/lightbox.min.css">
    <link rel="stylesheet" href="<?php echo $url; ?>assets/css/menu/style.css">

    <script src="<?php echo $url; ?>assets/js/vendor/modernizr-3.5.0.min.js"></script>
    <script src="<?php echo $url; ?>assets/js/vendor/jquery-3.2.1.min.js"></script>
    <script src="<?php echo $url; ?>assets/js/lightbox-plus-jquery.min.js"></script>
    <script type="<?php echo $url; ?>text/javascript" async src="https://platform.twitter.com/widgets.js"></script>
    <script async defer src="//assets.pinterest.com/js/pinit.js"></script>
    <script src="<?php echo $url; ?>assets/css/menu/script.js"></script>
    <script type="text/javascript">
        //////////////////////////////////qty buttons//////////////////////////////
        jQuery(document).ready(function() {
            // This button will increment the value
            $('.qtyplus').click(function(e) {
                // Stop acting like a button
                e.preventDefault();
                // Get the field name
                fieldName = $(this).attr('field');
                //$('.custom-btn').html("Buy Ticket");
                //$('#cart-widget').slideUp();
                // Get its current value
                var currentVal = parseInt($('input[name=' + fieldName + ']').val());
                // If is not undefined
                if (!isNaN(currentVal)) {
                    // Increment
                    $('input[name=' + fieldName + ']').val(currentVal + 1);
                } else {
                    // Otherwise put a 0 there
                    $('input[name=' + fieldName + ']').val(0);
                }
            });
            // This button will decrement the value till 0
            $(".qtyminus").click(function(e) {
                // Stop acting like a button
                e.preventDefault();
                // Get the field name
                fieldName = $(this).attr('field');
                //$(".custom-btn").html("Buy Ticket");
                //$('#cart-widget').slideUp();
                // Get its current value
                var currentVal = parseInt($('input[name=' + fieldName + ']').val());
                // If it isn't undefined or its greater than 0
                if (!isNaN(currentVal) && currentVal > 0) {
                    // Decrement one
                    $('input[name=' + fieldName + ']').val(currentVal - 1);
                } else {
                    // Otherwise put a 0 there
                    $('input[name=' + fieldName + ']').val(0);
                }
            });
        });

        /////////////////////////////////////////////////////////////////////////////            
        $(document).ready(function() {
            $('#select_color').on('change', '#color_variation', function() {
                var product_id = $("#color_variation").val();
                $("#product_id_variation_color").val(product_id);
                $("#variation_form").submit();

            });

            ////////////////////////////////////////////////////////////

            // $('#select_size').on('change', '#size_variation', function() {
            //     var product_id = $("#size_variation").val();
            //     $("#product_id_variation_size").val(product_id);
            //     $("#variation_form2").submit();

            // });


            $('.size-item').on('click', function() {

                $('.size-item').removeClass('active');
                $(this).addClass('active');

                var sizeUrl = $(this).data('url');

                if (sizeUrl) {
                    window.location.href = sizeUrl;
                }
            });

        });
    </script>

    <script type="text/javascript">
        $(document).ready(function() {

            $(document).on('click', '#addproduct', function() {
                var url = "<?php echo $url; ?>cartsingle.php";
                $.ajax({
                    type: "POST",
                    url: url,
                    data: {
                        id: <?php echo $product_id; ?>,
                        caction: 'add',
                        qty: $("#qty").val()
                    },
                    beforeSend: function() {
                        $(".overlay").fadeIn();
                        //$(elt).html("adding to cart");
                    },
                    success: function(data) {
                        $('.busket-amount').html(data);
                        //		 $('#notify').slideDown();
                        //window.location.search += '&msg=cartview';         
                        window.location.href = '<?php echo $canonical_product_url_with_cart; ?>';

                        // $('#viewcart').fadeIn(); 

                    }
                });
                return false;
            });

        });
    </script>


    <style type="text/css">
        body {
            font-family: 'Open Sans', sans-serif;
        }

        .gray_star {
            color: #D8D8D8;
        }

        .rating {
            overflow: hidden;
            display: inline-block;
            font-size: 0;
            position: relative;
        }

        .rating-input {
            float: left;
            width: 16px !important;
            height: 16px;
            padding: 0 !important;
            margin: 0 0 0 -16px !important;
            opacity: 0 !important;
        }

        .rating:hover .rating-star:hover,
        .rating:hover .rating-star:hover~.rating-star,
        .rating-input:checked~.rating-star {
            background-position: 0 0;
        }

        .rating-star,
        .rating:hover .rating-star {
            position: relative;
            float: right;
            display: block;
            width: 16px;
            height: 16px;
            cursor: pointer;
            margin-right: 5px;
            background: url('assets/img/star.png') 0 -16px;
        }
    </style>

    <!-- Meta Pixel Code -->
    <script>
        ! function(f, b, e, v, n, t, s) {
            if (f.fbq) return;
            n = f.fbq = function() {
                n.callMethod ?
                    n.callMethod.apply(n, arguments) : n.queue.push(arguments)
            };
            if (!f._fbq) f._fbq = n;
            n.push = n;
            n.loaded = !0;
            n.version = '2.0';
            n.queue = [];
            t = b.createElement(e);
            t.async = !0;
            t.src = v;
            s = b.getElementsByTagName(e)[0];
            s.parentNode.insertBefore(t, s)
        }(window, document, 'script',
            'https://connect.facebook.net/en_US/fbevents.js');
        fbq('init', '6089330044459882');
        fbq('track', 'PageView');
        fbq('track', 'ViewContent');
        fbq('track', 'Search');
        fbq('track', 'AddToCart');
        fbq('track', 'InitiateCheckout');
        fbq('track', 'AddPaymentInfo');
        fbq('track', 'Purchase');
        fbq('track', 'CompleteRegistration');
        fbq('track', 'Contact');
        fbq('track', 'FindLocation');
        fbq('track', 'Lead');
        fbq('track', 'SubmitApplication');
    </script>
    <script>
        $(document).on('click', '.read-more-btn', function() {

            let wrapper = $(this).closest('.description-wrapper');
            let text = wrapper.find('.description-text');
            let btn = $(this);

            text.toggleClass('expanded');

            if (text.hasClass('expanded')) {
                btn.html('Close <i class="fa fa-angle-up"></i>');
                btn.css({
                    position: 'relative',
                    display: 'inline-flex',
                    marginTop: '10px'
                });
            } else {
                btn.html('More Details <i class="fa fa-angle-down"></i>');
                btn.css({
                    position: 'absolute',
                    right: '0',
                    bottom: '0',
                    marginTop: '0'
                });
            }
        });
    </script>
    <noscript><img height="1" width="1" style="display:none"
            src="https://www.facebook.com/tr?id=6089330044459882&ev=PageView&noscript=1" /></noscript>
    <!-- End Meta Pixel Code -->
    <style>
        .size-top-ui {
            display: flex;
            gap: 12px;
            margin-top: 10px;
        }

        .size-item {
            padding: 8px 18px;
            border: 1.5px solid #ccc;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            background: #fff;
            transition: 0.2s ease;
        }

        .size-item:hover {
            border-color: #ff6600;
        }

        .size-item.active {
            border-color: #ff6600;
            background: #fff3ea;
            color: #ff6600;
            font-weight: 600;
        }

        /* ===== New Product Detail UI ===== */
        .product-title-main {
            font-size: 28px;
            color: #1a3c1a;
            font-weight: 700;
            margin-bottom: 4px;
            line-height: 1.3;
        }

        .product-subtitle-tag {
            font-size: 15px;
            color: #555;
            margin-bottom: 12px;
            font-weight: 500;
        }

        /* Price row */
        .pd-price-row {
            display: flex;
            align-items: center;
            gap: 14px;
            margin: 14px 0 18px;
            flex-wrap: wrap;
        }

        .pd-main-price {
            font-size: 38px;
            font-weight: 700;
            color: #1a1a1a;
        }

        .pd-discount-pct {
            color: #e53935;
            font-weight: 600;
            font-size: 18px;
            margin-right: 4px;
        }

        .pd-mrp {
            font-size: 14px;
            color: #888;
            text-decoration: line-through;
        }

        /* Action row */
        .pd-action-row {
            display: flex;
            align-items: center;
            gap: 12px;
            margin: 16px 0 20px;
            flex-wrap: wrap;
        }

        .pd-qty-wrapper {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .pd-qty-label {
            font-size: 14px;
            color: #555;
            white-space: nowrap;
            font-weight: 500;
        }

        .pd-qty-select {
            border: 1.5px solid #ccc;
            border-radius: 8px;
            padding: 10px 12px;
            font-size: 14px;
            background: #fff;
            cursor: pointer;
        }

        /* .btn-add-cart-new {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: #1a3c1a;
            color: #fff !important;
            border: none;
            border-radius: 8px;
            padding: 13px 22px;
            font-size: 14px;
            font-weight: 700;
            cursor: pointer;
            text-decoration: none !important;
            letter-spacing: 0.4px;
            transition: background 0.2s;
        }

        .btn-add-cart-new:hover {
            background: #0f2a0f;
        }

        .btn-add-cart-new i {
            font-size: 17px;
        } */

        /* .btn-whatsapp-new {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            background: #ffffff;
            color: #fff;
            border: none;
            border-radius: 8px;
            padding: 11px 16px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none !important;
            transition: background 0.2s;
        }

        .btn-whatsapp-new:hover {
            color: #fff !important;
            background-color: #1a3c1a !important;
        }

        .btn-whatsapp-new .wa-icon {
            font-size: 22px;
        }

        .btn-whatsapp-new .wa-text {
            text-align: left;
            line-height: 1.3;
            color: #065f14;
            font-size: 17px;
        }

        .btn-whatsapp-new .wa-text small {
            display: block;
            font-size: 17px;
            font-weight: 400;
            opacity: 0.9;
            color: #065f14;
        } */
        .btn-whatsapp-new {
            display: flex;
            align-items: center;
            gap: 12px;
            width: 60%;
            max-width: 550px;
            /* height: 80px; */
            background: #fff;
            border: 2px solid #72b36c;
            border-radius: 14px;
            padding: 8px 16px;
            text-decoration: none !important;
            position: relative;
            overflow: hidden;
            transition: 0.3s ease;
            box-sizing: border-box;
        }

        /* Bottom curve design */
        /* .btn-whatsapp-new::before {
            content: "";
            position: absolute;
            bottom: -18px;
            left: -30px;
            width: 140px;
            height: 40px;
            background: #dbe8c5;
            border-radius: 50%;
        }

        .btn-whatsapp-new::after {
            content: "";
            position: absolute;
            bottom: -22px;
            right: -25px;
            width: 140px;
            height: 55px;
            background: #7bc043;
            border-radius: 50%;
        } */

        /* Hover */
        .btn-whatsapp-new:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.12);
        }

        /* Left WhatsApp Icon */
        .wa-icon-box {
            width: 65px;
            min-width: 65px;
            text-align: center;
            border-right: 2px dashed #9ac88b;
            padding-right: 10px;
            position: relative;
            z-index: 2;
        }

        .wa-icon {
            font-size: 46px;
            color: #25D366;
        }

        /* Right Content */
        .wa-content {
            flex: 1;
            position: relative;
            z-index: 2;
        }

        /* Title */
        .wa-title {
            font-size: 16px;
            font-weight: 700;
            color: #0d5725;
            margin-bottom: 4px;
            line-height: 1.1;
        }

        /* Line */
        .wa-line {
            height: 1px;
            background: #aed69e;
            width: 100%;
            margin-bottom: 4px;
        }

        /* Subtitle */
        .wa-subtitle {
            font-size: 14px;
            color: #0d5725;
            margin-bottom: 6px;
            line-height: 1;
            margin-left: 45px;
        }

        /* Discount Button */
        .discount-btn {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background: #0f6b33;
            color: #fff;
            font-size: 13px;
            font-weight: 700;
            padding: 6px 12px;
            border-radius: 6px;
            line-height: 1;
            margin-left: 12px;
        }

        .discount-btn i {
            background: #ffcc00;
            color: #0f6b33;
            border-radius: 50%;
            padding: 5px;
            font-size: 11px;
        }


        /* Social share */
        .pd-social-row {
            display: flex;
            align-items: center;
            gap: 8px;
            margin-top: 16px;
            flex-wrap: wrap;
        }

        .pd-share-btn {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 7px 14px;
            border-radius: 6px;
            font-size: 13px;
            font-weight: 600;
            text-decoration: none !important;
            color: #fff !important;
            transition: opacity 0.2s;
        }

        .pd-share-btn:hover {
            opacity: 0.85;
        }

        .pd-share-fb {
            background: #1877f2;
        }

        .pd-share-tw {
            background: #1da1f2;
        }

        .pd-share-yt {
            background: #ff0000;
        }

        .product-detials-area .product-details-text .p-rating-review .product-rating i,
        i {
            color: #ffffff;
        }

        .pd-share-pi {
            background: #e60023;
        }

        /* ===== Product Info Table ===== */
        .product-info-sections-wrap {
            background: #f7f7f7;
            padding: 20px 0;
        }

        /* Remove single table box */
        .product-info-table {
            background: transparent;
            border: none;
            margin-top: 20px;
        }

        /* Separate box for every row */
        .pit-row {
            display: flex;
            align-items: flex-start;
            gap: 20px;
            background: #fff;
            border: 1px solid #e5e5e5;
            border-radius: 14px;
            padding: 22px 24px;
            margin-bottom: 14px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
        }

        /* Remove last child rule */
        .pit-row:last-child {
            margin-bottom: 0;
        }

        /* Left Icon */
        .pit-icon {
            flex: 0 0 50px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .pit-icon svg {
            width: 34px;
            height: 34px;
            stroke: #1f4d2f;
            fill: none;
        }

        /* Label */
        .pit-label {
            flex: 0 0 180px;
            font-size: 16px;
            font-weight: 700;
            color: #183b1d;
            line-height: 1.4;
            padding: 15px 0px;
        }

        /* Content */
        .pit-content {
            flex: 1;
            font-size: 14px;
            line-height: 1.8;
            color: #444;
        }

        /* Best For Icons */
        .pit-bestfor {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 0;
            flex-wrap: wrap;
        }

        .pit-bf-item {
            flex: 1;
            min-width: 120px;
            text-align: center;
            position: relative;
        }

        .pit-bf-item:not(:last-child)::after {
            content: "";
            position: absolute;
            right: 0;
            top: 10px;
            width: 1px;
            height: 50px;
            background: #ddd;
        }

        .pit-bf-item svg {
            width: 42px;
            height: 42px;
            stroke: #214d2d;
            margin-bottom: 8px;
        }

        .pit-bf-item span {
            display: block;
            font-size: 14px;
            color: #333;
            font-weight: 500;
        }

        /* Compatible With */
        .pit-compat {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
        }

        .pit-compat-item {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 10px 16px;
            border: 1px solid #ddd;
            border-radius: 30px;
            background: #fafafa;
            font-size: 14px;
        }

        .pit-content {
            flex: 1;
        }

        .benefit-list {
            margin: 0;
            padding: 0;
            list-style: none;
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            column-gap: 80px;
            row-gap: 12px;
        }

        .benefit-list li {
            position: relative;
            padding-left: 22px;
            font-size: 14px;
            line-height: 1.6;
        }

        .benefit-list li::before {
            content: "✓";
            color: #2e7d32;
            font-weight: bold;
            position: absolute;
            left: 0;
            top: 0;
        }

        @media (max-width: 768px) {
            .benefit-list {
                grid-template-columns: 1fr;
            }
        }

        /* Mobile Responsive */
        @media(max-width:768px) {
            .btn-whatsapp-new {
                width: 100%;
            }

            .pit-row {
                flex-direction: column;
                padding: 18px;
                gap: 14px;
            }

            .pit-label {
                flex: auto;
                font-size: 18px;
                margin-left: 50px;
                margin-top: -65px;
            }
        }

        .pit-content {
            font-size: 14px;
        }

        .pit-bestfor {
            justify-content: center;
            gap: 20px;
        }

        .pit-bf-item {
            min-width: 80px;
        }

        .pit-bf-item:not(:last-child)::after {
            display: none;
        }

        /* FAQ accordion */
        .pit-faq {
            width: 100%;
        }

        .faq-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
        }

        .faq-item {
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            overflow: hidden;
        }

        .faq-q {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 16px;
            font-size: 13px;
            font-weight: 500;
            color: #333;
            cursor: pointer;
            background: #fafafa;
        }

        .faq-plus {
            font-size: 18px;
            color: #666;
            transition: transform 0.2s;
            display: inline-block;
        }

        .faq-a {
            padding: 10px 20px 55px 20px;
            font-size: 13px;
            color: #555;
            line-height: 1.5;
            display: none;
            border-top: 1px solid #e0e0e0;
        }

        .faq-item.open .faq-a {
            display: block;
        }

        .faq-item.open .faq-plus {
            transform: rotate(45deg);
        }

        /* ===== WhatsApp CTA ===== */
        .wa-cta-section {
            background: #f0f8f0;
            border-top: 1px solid #cde5cd;
            border-bottom: 1px solid #cde5cd;
            padding: 28px 0;
        }

        .wa-cta-inner {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 20px;
            flex-wrap: wrap;
        }

        .wa-cta-left {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .wa-cta-icon {
            width: 50px;
            height: 50px;
            background: #25d366;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }

        .wa-cta-icon i {
            color: #fff;
            font-size: 26px;
        }

        .wa-cta-text h5 {
            margin: 0 0 4px;
            font-size: 16px;
            font-weight: 700;
            color: #1a3c1a;
        }

        .wa-cta-text p {
            margin: 0;
            font-size: 13px;
            color: #555;
        }

        .btn-wa-cta {
            background: #1a3c1a;
            color: #fff !important;
            border: none;
            border-radius: 8px;
            padding: 14px 28px;
            font-size: 14px;
            font-weight: 700;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 10px;
            text-decoration: none !important;
            transition: background 0.2s;
            white-space: nowrap;
        }

        .btn-wa-cta:hover {
            background: #0f2a0f;
        }

        .btn-wa-cta i {
            font-size: 20px;
        }

        /* ===== Trust Badges Bar ===== */
        .trust-badges-bar {
            background: #fff;
            border-top: 1px solid #e5e5e5;
            border-bottom: 1px solid #e5e5e5;
            padding: 14px 0;
        }

        .trust-badges-inner {
            display: flex;
            justify-content: space-around;
            align-items: center;
            gap: 10px;
            flex-wrap: wrap;
        }

        .trust-badge {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 13px;
            color: #333;
            font-weight: 500;
        }

        .trust-badge svg {
            width: 22px;
            height: 22px;
            stroke: #2d6a2d;
            fill: none;
        }

        .btn-add-cart-new {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            background: #1a3c1a;
            color: #fff !important;
            border-radius: 50px;
            width: 50px;
            height: 50px;
            text-decoration: none !important;
            overflow: hidden;
            white-space: nowrap;
            transition: all 0.3s ease;
        }

        /* Icon */
        .btn-add-cart-new i {
            font-size: 18px;
            min-width: 18px;
        }

        /* Hide text initially */
        .btn-add-cart-new span {
            max-width: 0;
            opacity: 0;
            overflow: hidden;
            transition: all 0.3s ease;
            margin-left: 0;
            font-size: 14px;
            font-weight: 700;
        }

        .btn-add-cart-new:hover span {
            max-width: 120px;
            opacity: 1;
            margin-left: 8px;
        }

        .btn-add-cart-new:hover {
            background: #0f2a0f;
        }

        .description-wrapper {
            position: relative;
            max-width: 100%;
        }

        .description-text {
            font-size: 16px;
            line-height: 1.8;
            color: #333;
            margin: 0;
            display: -webkit-box;
            -webkit-line-clamp: 4;
            /* show only 2 lines */
            -webkit-box-orient: vertical;
            overflow: hidden;
            position: relative;
            padding-right: 130px;
            /* space for button */
        }

        .product-detials-area .product-details-text p {
            padding-top: 30px;
        }

        .description-text.expanded {
            -webkit-line-clamp: unset;
            overflow: visible;
            padding-right: 0;
        }

        .read-more-btn {
            position: absolute;
            right: 0;
            bottom: 0;
            background: #fff;
            color: #0066ff;
            font-size: 15px;
            font-weight: 600;
            text-decoration: none;
            padding-left: 10px;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .read-more-btn i {
            font-size: 14px;
        }

        .read-more-btn:hover {
            color: #004de6;
        }

        /* Mobile only */
        @media (min-width: 769px) {
            .btn-add-cart-new {
                width: auto;
                height: auto;
                padding: 13px 22px;
                border-radius: 8px;
            }

            .btn-add-cart-new span {
                max-width: 120px;
                opacity: 1;
                margin-left: 8px;
            }
        }

        @media (max-width: 768px) {

            .description-text {
                font-size: 14px;
                line-height: 1.6;
                padding-right: 0;
                display: block;
                max-height: 52px;
                overflow: hidden;
            }

            .description-text.expanded {
                max-height: 1000px;
            }

            .read-more-btn {
                position: relative;
                right: auto;
                bottom: auto;
                display: inline-flex;
                margin-top: 4px;
                padding-left: 0;
                font-size: 14px;
                background: transparent;
            }
        }

        .wa-cta-inner {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 20px;
        }

        .wa-google-review {
            flex: 0 0 320px;
            text-align: center;
            padding: 10px 15px;
            background: #fff;
            border: 1px solid #e5e5e5;
            border-radius: 10px;
        }

        .wa-google-link {
            text-decoration: none;
        }

        .wa-google-review h4 {
            margin: 0 0 5px;
            color: #1a73e8;
            font-size: 20px;
            font-weight: 700;
        }

        .wa-google-rating {
            color: #fbbc04;
            font-size: 15px;
            margin-bottom: 5px;
        }

        .wa-google-rating span {
            color: #555;
        }

        .wa-google-review p {
            margin: 0;
            font-size: 13px;
            color: #666;
            line-height: 1.4;
        }

        @media(max-width:991px) {
            .wa-google-review {
                flex: 1 1 100%;
                width: 100%;
                max-width: 450px;
            }
        }

        @media (max-width: 768px) {
            .faq-grid {
                grid-template-columns: 1fr;
                gap: 15px;
            }

            .faq-item {
                width: 100%;
            }
        }
    </style>
</head>


<body>
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-WWCJ4NT"
            height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

    <div id="fb-root"></div>
    <script>
        (function(d, s, id) {
            var js, fjs = d.getElementsByTagName(s)[0];
            if (d.getElementById(id)) return;
            js = d.createElement(s);
            js.id = id;
            js.src = "https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v3.0";
            fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));
    </script>

    <!-- Header Area Start -->
    <?php include("sm_header.php"); ?>
    <div class="breadcrumb-area text-center mhide">
        <div class="container">
            <nav aria-label="breadcrumb">
                <ul class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo htmlspecialchars($url, ENT_QUOTES, 'UTF-8'); ?>">Home</a></li>
                    <li class="breadcrumb-item" aria-current="page"><?php echo htmlspecialchars($fupdata['mcname'], ENT_QUOTES, 'UTF-8'); ?></li>
                    <li class="breadcrumb-item" aria-current="page"><?php echo htmlspecialchars($fupdata['scname'], ENT_QUOTES, 'UTF-8'); ?></li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo htmlspecialchars($fupdata['pname'], ENT_QUOTES, 'UTF-8'); ?></li>
                </ul>
            </nav>
        </div>
    </div>
    <!-- Breadcrumb Area End -->
    <!-- Product DEtails Area Start -->
    <div class="product-detials-area bg-gray pt-150">
        <div class="container">
            <div class="row">
                <div class="col-lg-5 col-md-5">

                    <!-- Product title is provided once as the primary page heading below. -->

                    <!-- <div class="p-rating-review dhide">
                        <div class="product-rating">


                            <?php
                            if ($sum > 0) {
                                $oavg = ($sum / $re_sum);
                                $avg = round($oavg);
                            }
                            if ($sum > 0) {
                                for ($i = 1; $i <= 5; $i++) {
                                    if ($i <= $avg) {
                            ?>
                                        <a href="#product_reviews" class="scroll-down ml-0"> <i class="fa fa-star color"></i></a>
                                    <?php } else { ?>
                                        <i class="fa fa-star-o"></i>
                                <?php }
                                } ?>

                                <a href="#product_reviews" title="View reviews" class="scroll-down">(<?php echo $re_sum; ?> reviews)</a>
                            <?php
                            } elseif ($sum <= 0) {
                                $rrow = 0;
                            } ?>

                            <?php if (isset($_GET['r_success'])) { ?>
                                <?php echo $_GET['r_success']; ?>
                            <?php } elseif (isset($inreview) && !$inreview) { ?>

                                <a href="#addproduct" title="Write a review"> Write a review </a>
                            <?php } ?>


                            <?php if (isset($_GET['w_success'])) { ?>
                                <li class="review"><?php echo $_GET['w_success']; ?></li>
                            <?php } elseif (isset($inwishlist) && !$inwishlist) { ?>

                                <a href="<?php echo $wishlist_url; ?>" title="Add to wishlist"><i class="fa fa-heart-o green" aria-hidden="true"></i> Add to Wish List</a> <?php } elseif (isset($inwishlist) && $inwishlist) { ?>

                                | Already in wishlist

                            <?php }  ?>
                            <br>
                            <?php if ($rper > 79) { ?>
                                <h5 class="mt-10 green_text font13 mob_mt0 mob_mb10"><strong><?php echo $rper; ?>% customers recommended this product</strong></h5> <?php } ?>

                        </div>


                    </div> -->
                    <div class="product-image-slider d-flex flex-column">
                        <!--Product Tab Content Start-->
                        <div class="tab-content product-large-image-list">

                            <!-- <div class="double_base">

                                <?php $price_class = "product_sale top125";
                                if ($fupdata['price'] != 0 && $fupdata['price'] < $fupdata['mrp']) {
                                    $discount = round(($fupdata['mrp'] - $fupdata['price']) / $fupdata['mrp'] * 100); ?>

                                    <?php if ($discount >= 25) { ?>

                                        <div class="label_product top100 left_16 top_55">
                                            <span>Hot Deal</span>
                                        </div>
                                        <div class="<?php echo $price_class; ?> left_16 top_85">
                                            <span>- <?php echo $discount; ?>% Off</span>
                                        </div>
                                    <?php } else { ?>

                                        <div class="<?php echo $price_class; ?> left_16 top_55">
                                            <span>- <?php echo $discount; ?>% Off</span>
                                        </div>

                                <?php }
                                } ?>
                            </div> -->
                            <div class="tab-pane fade show active" id="product-slide2" role="tabpanel" aria-labelledby="product-slide-tab-2">
                                <div class="single-product-img img-full">
                                    <?php if ($fupdata['pic3'] != NULL) { ?> <a href="<?php echo $url; ?>smadmin/<?php echo $fupdata['pic3']; ?>"><img src="<?php echo $url; ?>smadmin/<?php echo $fupdata['pic3']; ?>" class="img-fluid" alt=""></a> <?php } ?>
                                    <center>
                                        <p style="color:red;">Images for reference only. Label may vary.</p>
                                    </center>
                                </div>
                            </div>

                            <?php if ($fupdata['pic2'] != NULL) { ?>
                                <div class="tab-pane fade" id="product-slide3" role="tabpanel" aria-labelledby="product-slide-tab-3">
                                    <div class="single-product-img img-full">
                                        <a href="<?php echo $url; ?>smadmin/<?php echo $fupdata['pic2']; ?>"><img src="<?php echo $url; ?>smadmin/<?php echo $fupdata['pic2']; ?>" class="img-fluid" alt=""></a>
                                    </div>
                                </div>

                            <?php } ?>

                            <div class="tab-pane fade" id="product-slide4" role="tabpanel" aria-labelledby="product-slide-tab-4">
                                <div class="single-product-img img-full">
                                    <?php if ($fupdata['pic4'] != NULL) { ?> <a href="<?php echo $url; ?>smadmin/<?php echo $fupdata['pic4']; ?>"><img src="<?php echo $url; ?>smadmin/<?php echo $fupdata['pic4']; ?>" class="img-fluid" alt=""></a> <?php } else {
                                                                                                                                                                                                                                                        echo "not available";
                                                                                                                                                                                                                                                    } ?>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="product-slide5" role="tabpanel" aria-labelledby="product-slide-tab-5">
                                <div class="single-product-img img-full">
                                    <?php if ($fupdata['pic5'] != NULL) { ?> <a href="<?php echo $url; ?>smadmin/<?php echo $fupdata['pic5']; ?>"><img src="<?php echo $url; ?>smadmin/<?php echo $fupdata['pic5']; ?>" class="img-fluid" alt=""></a> <?php } else {
                                                                                                                                                                                                                                                        echo "not available";
                                                                                                                                                                                                                                                    } ?>
                                </div>
                            </div>

                            <div class="tab-pane fade" id="product-slide6" role="tabpanel" aria-labelledby="product-slide-tab-6">
                                <div class="single-product-img img-full">
                                    <?php if ($fupdata['pic7'] != NULL) { ?> <a href="<?php echo $url; ?>smadmin/<?php echo $fupdata['pic7']; ?>"><img src="<?php echo $url; ?>smadmin/<?php echo $fupdata['pic7']; ?>" class="img-fluid" alt=""></a> <?php } else {
                                                                                                                                                                                                                                                        echo "not available";
                                                                                                                                                                                                                                                    } ?>
                                </div>
                            </div>

                        </div>
                        <!--Product Content End-->
                        <!--Product Tab Menu Start-->
                        <div class="product-small-image-list">
                            <div class="nav small-image-slider-single-product-tabstyle-3" role="tablist">

                                <div class="single-small-image img-full">
                                    <?php if ($fupdata['pic3'] != NULL) { ?> <a data-toggle="tab" id="product-slide-tab-2" href="#product-slide2"><img src="<?php echo $url; ?>smadmin/<?php echo $fupdata['pic3']; ?>" class="img-fluid" alt=""></a><?php } else {
                                                                                                                                                                                                                                                        echo " ";
                                                                                                                                                                                                                                                    } ?>
                                </div>
                                <div class="single-small-image img-full">
                                    <?php if ($fupdata['pic2'] != NULL) { ?> <a data-toggle="tab" id="product-slide-tab-3" href="#product-slide3"><img src="<?php echo $url; ?>smadmin/<?php echo $fupdata['pic2']; ?>" class="img-fluid" alt=""></a><?php } else {
                                                                                                                                                                                                                                                        echo " ";
                                                                                                                                                                                                                                                    } ?>
                                </div>
                                <div class="single-small-image img-full">
                                    <?php if ($fupdata['pic4'] != NULL) { ?> <a data-toggle="tab" id="product-slide-tab-4" href="#product-slide4"><img src="<?php echo $url; ?>smadmin/<?php echo $fupdata['pic4']; ?>" class="img-fluid" alt=""></a><?php } else {
                                                                                                                                                                                                                                                        echo " ";
                                                                                                                                                                                                                                                    } ?>
                                </div>
                                <div class="single-small-image img-full">
                                    <?php if ($fupdata['pic5'] != NULL) { ?> <a data-toggle="tab" id="product-slide-tab-5" href="#product-slide5"><img src="<?php echo $url; ?>smadmin/<?php echo $fupdata['pic5']; ?>" class="img-fluid" alt=""></a><?php } else {
                                                                                                                                                                                                                                                        echo " ";
                                                                                                                                                                                                                                                    } ?>
                                </div>

                                <div class="single-small-image img-full">
                                    <?php if ($fupdata['pic7'] != NULL) { ?> <a data-toggle="tab" id="product-slide-tab-6" href="#product-slide6"><img src="<?php echo $url; ?>smadmin/<?php echo $fupdata['pic7']; ?>" class="img-fluid" alt=""></a><?php } else {
                                                                                                                                                                                                                                                        echo " ";
                                                                                                                                                                                                                                                    } ?>
                                </div>


                            </div>
                        </div>
                        <!--Product Tab Menu End-->
                    </div>
                </div>
                <div class="col-lg-7 col-md-7">
                    <h1 class="product-title-main"><?php echo htmlspecialchars($fupdata['pname'], ENT_QUOTES, 'UTF-8'); ?></h1>


                    <div class="product-details-text mobile_mb0">
                        <?php
                        if ($fupdata['price'] != 0 && $fupdata['price'] < $fupdata['mrp']) {
                            $share_price = $fupdata['price'];
                            $discount = round(($fupdata['mrp'] - $fupdata['price']) / $fupdata['mrp'] * 100);
                        } else {
                            $share_price = $fupdata['price'];
                            $discount = 0;
                        }
                        ?>

                        <!-- Price + Size Row -->
                        <div class="pd-price-row">
                            <span class="pd-main-price">
                                <?php if ($discount > 0) { ?><span class="pd-discount-pct">-<?php echo $discount; ?>%</span><?php } ?>
                                ₹<?php echo $fupdata['price']; ?>
                            </span>
                            <?php if ($discount > 0) { ?>
                                <span class="pd-mrp">MRP ₹<?php echo $fupdata['mrp']; ?></span>
                            <?php } ?>
                            <!-- Size Pills -->

                        </div>

                        <!-- Action Row: Qty + Add to Cart + WhatsApp -->
                        <div class="pd-action-row">
                            <div class="size-top-ui" style="margin-top:0;">
                                <?php
                                $currentSize = $product_id;
                                $firstId = '';
                                $firstName = '';
                                $si_stmt->bind_result($si_id, $si_name);
                                $index = 0;
                                while ($si_stmt->fetch()) {
                                    if ($index === 0) {
                                        $firstId = $si_id;
                                        $firstName = $si_name;
                                    }
                                    $unit = ($fupdata['mc_id'] == 4) ? 'shots' : 'ml';
                                    $sactive = ($currentSize == $si_id || (empty($currentSize) && $index === 0)) ? 'active' : '';
                                ?>
                                    <div class="size-item <?php echo $sactive; ?>"
                                        data-id="<?php echo $si_id; ?>"
                                        data-url="<?php echo build_product_url($url, $fupdata['mcname'], $fupdata['scname'], $fupdata['pname'], $si_id); ?>"
                                        data-name="<?php echo $si_name; ?>">
                                        <?php echo $si_name . $unit; ?>
                                    </div>
                                <?php $index++;
                                }
                                $si_stmt->free_result(); ?>
                            </div>
                            <div class="pd-qty-wrapper">
                                <span class="pd-qty-label">Select Qty:</span>
                                <select id="qty" name="qty" class="pd-qty-select">
                                    <?php for ($qi = 1; $qi <= 10; $qi++) { ?>
                                        <option value="<?php echo $qi; ?>"><?php echo $qi; ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                            <!-- <a href="javascript:;" id="addproduct" class="btn-add-cart-new"
                                onclick="dataLayer.push({'event':'addtoCart_click','productvalue':<?php echo $share_price; ?>});">
                                <i class="fa fa-shopping-cart"></i> ADD TO CART
                            </a> -->
                            <a href="javascript:;" id="addproduct" class="btn-add-cart-new"
                                onclick="dataLayer.push({'event':'addtoCart_click','productvalue':<?php echo $share_price; ?>});">

                                <i class="fa fa-shopping-cart"></i>
                                <span>ADD TO CART</span>
                            </a>
                        </div>
                        <?php
                        if ($fupdata['whats_app_show'] == 'Show') {
                        ?>
                            <div class="pd-action-row">
                                <a href="https://api.whatsapp.com/send?phone=919150870543&text=<?php echo rawurlencode('Hi, I need help with: ' . $fupdata['pname']); ?>"
                                    class="btn-whatsapp-new"
                                    target="_blank"
                                    onclick="dataLayer.push({'event':'whatsapp_product_help'});">

                                    <div class="wa-icon-box">
                                        <!-- <i class="fa fa-whatsapp wa-icon"></i> -->
                                        <img src="/assets/img/whatsapp.png" alt="Contact Us" width="60" height="60">
                                    </div>

                                    <div class="wa-content">
                                        <div class="wa-title">
                                            Need Less than 1000ml?
                                        </div>

                                        <div class="wa-line"></div>

                                        <div class="wa-subtitle">
                                            15ml to 500ml
                                        </div>

                                        <div class="discount-btn">
                                            Get Discount Price
                                            <i class="fa fa-percent"></i>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        <?php
                        }
                        ?>
                        <!-- <p class="mt-0"><?php echo nl2br(htmlspecialchars_decode(($fupdata['description']))); ?></p> -->
                        <div class="description-wrapper">
                            <?php
                            if (!empty($fupdata['g_description'])) { ?>
                                <!-- <p class="product-subtitle-tag mhide"><?php echo htmlspecialchars($fupdata['g_description']); ?></p> -->
                            <?php } ?>
                            <p class="description-text">
                                <?php echo nl2br(htmlspecialchars_decode($fupdata['description'])); ?>
                            </p>
                            <a href="javascript:void(0);" class="read-more-btn">
                                More Details
                                <i class="fa fa-angle-down"></i>
                            </a>
                        </div>
                        <!-- Social Share -->
                        <div class="pd-social-row">
                            <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo urlencode($canonical_product_url); ?>"
                                target="_blank" class="pd-share-btn pd-share-fb">
                                <i class="fa fa-facebook"></i> Share
                            </a>
                            <a href="https://twitter.com/intent/tweet?url=<?php echo urlencode($canonical_product_url); ?>&text=<?php echo urlencode($fupdata['seo_title']); ?>"
                                target="_blank" class="pd-share-btn pd-share-tw">
                                <i class="fa fa-twitter"></i> Tweet
                            </a>
                            <a href="https://www.youtube.com/@sensemeindia1181"
                                target="_blank" class="pd-share-btn pd-share-yt">
                                <i class="fa fa-youtube"></i> YouTube
                            </a>
                            <!-- <a href="https://www.pinterest.com/pin/create/button/?url=<?php echo urlencode($canonical_product_url); ?>&media=<?php echo urlencode('https://' . $_SERVER['HTTP_HOST'] . '/smadmin/' . $fupdata['pic2']); ?>&description=<?php echo urlencode($fupdata['description'] . ' Buy@ Rs. ' . $share_price . '. GST Included | Free Shipping'); ?>"
                               target="_blank" class="pd-share-btn pd-share-pi">
                                <i class="fa fa-pinterest"></i> Pin it
                            </a> -->
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Product DEtails Area End -->
    <!-- Product Info Sections Start -->

    <?php

    $mc_key = strtolower(trim($fupdata['mcname']));


    // ==========================================
    // DYNAMIC DATA
    // ==========================================

    $benefits_dynamic =
        !empty($fupdata['benefits_points'])
        ?
        json_decode($fupdata['benefits_points'], true)
        :
        [];

    $best_for_dynamic =
        !empty($fupdata['best_for'])
        ?
        json_decode($fupdata['best_for'], true)
        :
        [];

    $compatible_dynamic =
        !empty($fupdata['compatible_with'])
        ?
        json_decode($fupdata['compatible_with'], true)
        :
        [];

    $faq_dynamic =
        !empty($fupdata['faq_data'])
        ?
        json_decode($fupdata['faq_data'], true)
        :
        [];


    // ==========================================
    // STATIC FALLBACK DATA
    // ==========================================

    $best_for_map = [

        'essential oils' => [
            ['icon' => 'skin', 'label' => 'Skin Care'],
            ['icon' => 'hair', 'label' => 'Hair Care'],
            ['icon' => 'massage', 'label' => 'Massage'],
            ['icon' => 'spa', 'label' => 'Spa'],
            ['icon' => 'diy', 'label' => 'DIY Beauty']
        ],

        'synergy blends' => [
            ['icon' => 'home', 'label' => 'Home'],
            ['icon' => 'massage', 'label' => 'Massage'],
            ['icon' => 'yoga', 'label' => 'Yoga'],
            ['icon' => 'spa', 'label' => 'Spa'],
            ['icon' => 'relax', 'label' => 'Relaxation']
        ],

        'diffusers' => [
            ['icon' => 'home', 'label' => 'Home'],
            ['icon' => 'office', 'label' => 'Office'],
            ['icon' => 'spa', 'label' => 'Spa'],
            ['icon' => 'yoga', 'label' => 'Yoga Studio'],
            ['icon' => 'gift', 'label' => 'Gift']
        ]

    ];

    $best_for_static =
        $best_for_map[$mc_key]
        ??
        [
            ['icon' => 'skin', 'label' => 'Skin Care'],
            ['icon' => 'hair', 'label' => 'Hair Care'],
            ['icon' => 'massage', 'label' => 'Massage']
        ];



    $compat_map = [

        'essential oils' => [
            'Ultrasonic Diffuser',
            'Water-Based Diffuser',
            'Aroma Diffuser Machine'
        ],

        'synergy blends' => [
            'Ultrasonic Diffuser',
            'Water-Based Diffuser',
            'Aroma Diffuser Machine'
        ],

        'diffusers' => [
            'Essential Oils',
            'Synergy Blends',
            'Fragrance Oils'
        ]

    ];

    $compat_static =
        $compat_map[$mc_key]
        ??
        [
            'Ultrasonic Diffuser',
            'Water-Based Diffuser'
        ];



    $lasting_map = [

        'essential oils' => [
            'text' => 'Lasts 4 – 6 Hours',
            'sub' => 'in diffuser (depending on room size and airflow)'
        ],

        'synergy blends' => [
            'text' => 'Lasts 4 – 8 Hours',
            'sub' => 'in diffuser (depending on blend and room size)'
        ],

        'diffusers' => [
            'text' => 'Continuous 6 – 8 Hours',
            'sub' => 'on a single tank (auto shutoff when empty)'
        ]

    ];

    $lasting_static =
        $lasting_map[$mc_key]
        ??
        [
            'text' => '',
            'sub' => ''
        ];



    $faq_map = [

        'essential oils' => [

            [
                'q' => 'How many drops should I use?',
                'a' => 'Add 3–5 drops per 100ml water.'
            ],

            [
                'q' => 'Can I use this oil on skin?',
                'a' => 'Yes, dilute with carrier oil.'
            ]

        ],

        'synergy blends' => [

            [
                'q' => 'How many drops for diffuser?',
                'a' => 'Add 3–5 drops per 100ml water.'
            ]

        ],

        'diffusers' => [

            [
                'q' => 'How much water do I fill?',
                'a' => 'Fill up to max line.'
            ]

        ]

    ];

    $faq_static =
        $faq_map[$mc_key]
        ??
        [
            [
                'q' => 'How to use this product?',
                'a' => 'Please check usage instructions.'
            ]
        ];



    // ==========================================
    // FINAL SHOW DATA
    // ==========================================

    $show_best_for = !empty($best_for_dynamic) ? $best_for_dynamic : '';

    $show_compat = !empty($compatible_dynamic) ? $compatible_dynamic : '';

    $show_faq = !empty($faq_dynamic) ? $faq_dynamic : '';


    $show_lasting = [

        'text' => !empty($fupdata['fragrance_heading']) ? $fupdata['fragrance_heading'] : '',

        'sub' => !empty($fupdata['fragrance_description']) ? $fupdata['fragrance_description'] : ''

    ];

    ?>

    <div class="product-info-sections-wrap bg-white">
        <div class="container">
            <div class="product-info-table">
                <?php
                if (!empty($benefits_dynamic)) {
                ?>
                    <div class="pit-row">
                        <div class="pit-icon">
                            <img src="<?php echo $url; ?>assets/icons/leaf.svg" alt="faq" style="width: 40px;">
                        </div>
                        <div class="pit-label">Benefits</div>
                        <div class="pit-content">

                            <ul class="benefit-list">
                                <?php foreach ($benefits_dynamic as $item) { ?>
                                    <li>
                                        <?php echo htmlspecialchars($item); ?>
                                    </li>
                                <?php } ?>
                            </ul>

                        </div>
                    </div>
                <?php } ?>
                <?php if (!empty($fupdata['smell_description'])) { ?>
                    <div class="pit-row">
                        <div class="pit-icon">
                            <img src="<?php echo $url; ?>assets/icons/nose.svg" alt="faq" style="width: 40px;">
                        </div>
                        <div class="pit-label">Smell Profile</div>

                        <div class="pit-content"><?php echo nl2br(htmlspecialchars_decode($fupdata['smell_description'])); ?></div>

                    </div>
                <?php } ?>
                <?php if (!empty($show_best_for)) { ?>
                    <div class="pit-row">
                        <div class="pit-icon">
                            <img src="<?php echo $url; ?>assets/icons/human.svg" alt="faq" style="width: 40px;">
                        </div>
                        <div class="pit-label">Best For /<br>Where To Use</div>
                        <div class="pit-content">
                            <div class="pit-bestfor">
                                <?php
                                foreach ($show_best_for as $bf) {
                                    $svg = $bf_svgs[$bf['icon']];
                                ?>
                                    <div class="pit-bf-item">
                                        <img src="<?php echo $url; ?>smadmin/<?php echo $bf['icon']; ?>" alt="" width="40px;">
                                        <span><span>
                                                <?php
                                                echo htmlspecialchars(
                                                    !empty($bf['title'])
                                                        ?
                                                        $bf['title']
                                                        :
                                                        $bf['label']
                                                );
                                                ?>
                                            </span></span>
                                    </div>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                <?php } ?>
                <?php if (!empty($show_lasting['text'])) { ?>
                    <div class="pit-row">
                        <div class="pit-icon">
                            <img src="<?php echo $url; ?>assets/icons/time.svg" alt="faq" style="width: 35px;">
                        </div>
                        <div class="pit-label">Fragrance Lasting</div>
                        <div class="pit-content">
                            <strong><?php echo htmlspecialchars($show_lasting['text']); ?></strong><br>
                            <span style="color:#666;"><?php echo htmlspecialchars($show_lasting['sub']); ?></span>
                        </div>
                    </div>
                <?php } ?>
                <?php if (!empty($show_compat)) { ?>
                    <div class="pit-row">
                        <div class="pit-icon">
                            <img src="<?php echo $url; ?>assets/icons/cake.svg" alt="faq" style="width: 40px;">
                        </div>
                        <div class="pit-label">Compatible With</div>
                        <div class="pit-content">
                            <div class="pit-bestfor">
                                <?php foreach ($show_compat as $ci) { ?>
                                    <div class="pit-bf-item">
                                        <img src="<?php echo $url; ?>smadmin/<?php echo $ci['icon']; ?>" alt="" width="40px;">
                                        <span><span>
                                                <?php
                                                echo htmlspecialchars(
                                                    is_array($ci)
                                                        ?
                                                        $ci['title']
                                                        :
                                                        $ci
                                                );
                                                ?>
                                            </span></span>
                                    </div>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                <?php } ?>
                <?php if (!empty($show_faq)) { ?>
                    <div class="pit-row">
                        <div class="pit-icon">
                            <img src="<?php echo $url; ?>assets/icons/faq.svg" alt="faq" style="width: 35px;">
                        </div>
                        <div class="pit-label">FAQ</div>
                        <div class="pit-content pit-faq">
                            <div class="faq-grid">
                                <?php foreach ($show_faq as $fi) { ?>
                                    <div class="faq-item">
                                        <div class="faq-q" onclick="this.parentElement.classList.toggle('open')">
                                            <?php
                                            echo htmlspecialchars(
                                                !empty($fi['question'])
                                                    ?
                                                    $fi['question']
                                                    :
                                                    $fi['q']
                                            );
                                            ?>
                                            <span class="faq-plus">+</span>
                                        </div>
                                        <div class="faq-a"><?php
                                                            echo htmlspecialchars(
                                                                !empty($fi['answer'])
                                                                    ?
                                                                    $fi['answer']
                                                                    :
                                                                    $fi['a']
                                                            );
                                                            ?></div>
                                    </div>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                <?php } ?>
                <?php if (!empty($fupdata['details'])) { ?>
                    <div class="pit-row">
                        <div class="pit-icon">
                            <img src="<?php echo $url; ?>assets/icons/how_to_use.svg" alt="faq" style="width: 35px;">
                        </div>
                        <div class="pit-label">How To Use</div>
                        <div class="pit-content"><?php echo nl2br(htmlspecialchars_decode($fupdata['details'])); ?></div>
                    </div>
                <?php } ?>
                <?php if (!empty($fupdata['disclaimer'])) { ?>
                    <div class="pit-row">
                        <div class="pit-icon">
                            <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" stroke-width="1.5">
                                <circle cx="12" cy="12" r="10" />
                                <line x1="12" y1="8" x2="12" y2="12" stroke-linecap="round" />
                                <line x1="12" y1="16" x2="12.01" y2="16" stroke-linecap="round" />
                            </svg>
                        </div>
                        <div class="pit-label">Disclaimer</div>
                        <div class="pit-content"><?php echo nl2br(htmlspecialchars_decode($fupdata['disclaimer'])); ?></div>
                    </div>
                <?php } ?>
            </div>
        </div>
    </div>
    <!-- Product Info Sections End -->

    <!-- WhatsApp CTA Section -->
    <div class="wa-cta-section">
        <div class="container">
            <div class="wa-cta-inner">
                <div class="wa-cta-left">
                    <div class="wa-cta-icon">
                        <i class="fa fa-whatsapp"></i>
                    </div>
                    <div class="wa-cta-text">
                        <h5>Need fragrance recommendation or bulk <br> order support?</h5>
                        <p>Chat with us on WhatsApp. We're here to help!</p>
                    </div>
                </div>
                <div class="wa-google-review">
                    <a href="https://www.google.com/search?sca_esv=2580695188120823&rlz=1C1CHBF_enIN1141IN1142&si=AMgyJEtREmoPL4P1I5IDCfuA8gybfVI2d5Uj7QMwYCZHKDZ-EwdQJcFQ53v4o27wNfth1t5Lm5QXWAhWjMiNAnU8XD8ml3gRaoeeZ0ldDsvne4qhel2Vnfkeka7bQr2WLBwmvRG6WvBv&q=Mylal+Exports+Reviews&sa=X&ved=2ahUKEwjeu9nS_o6RAxUTxTgGHf2NHtcQ0bkNegQIOBAE&biw=1366&bih=607&dpr=1" target="_blank" class="wa-google-link">
                        <h4>Mylal Exports</h4>
                        <div class="wa-google-rating">
                            ★★★★★ <span>63 Google Reviews</span>
                        </div>
                        <p>
                            Read our customer reviews and discover why businesses trust us.
                        </p>
                    </a>
                </div>
                <a href="https://api.whatsapp.com/send?phone=919150870543" target="_blank"
                    class="btn-wa-cta" onclick="dataLayer.push({'event':'whatsapp_chat'});">
                    <i class="fa fa-whatsapp"></i> CHAT ON WHATSAPP
                </a>
            </div>
        </div>
    </div>

    <!-- Trust Badges Bar -->
    <div class="trust-badges-bar">
        <div class="container">
            <div class="trust-badges-inner">
                <div class="trust-badge">
                    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" stroke-width="1.5" fill="none">
                        <path d="M12 2l2.4 7.4H22l-6.2 4.5 2.4 7.4L12 17l-6.2 4.3 2.4-7.4L2 9.4h7.6z" stroke-linecap="round" stroke-linejoin="round" />
                    </svg>
                    100% Pure &amp; Natural
                </div>
                <div class="trust-badge">
                    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" stroke-width="1.5" fill="none">
                        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" stroke-linecap="round" stroke-linejoin="round" />
                    </svg>
                    Premium Quality
                </div>
                <div class="trust-badge">
                    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" stroke-width="1.5" fill="none">
                        <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z" stroke-linecap="round" stroke-linejoin="round" />
                        <polyline points="3.27,6.96 12,12.01 20.73,6.96" stroke-linecap="round" />
                        <line x1="12" y1="22.08" x2="12" y2="12" stroke-linecap="round" />
                    </svg>
                    Bulk Supply Available
                </div>
                <div class="trust-badge">
                    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" stroke-width="1.5" fill="none">
                        <polyline points="20,6 9,17 4,12" stroke-linecap="round" stroke-linejoin="round" />
                    </svg>
                    Private Labeling
                </div>
                <div class="trust-badge">
                    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" stroke-width="1.5" fill="none">
                        <circle cx="12" cy="12" r="10" stroke-linecap="round" />
                        <line x1="2" y1="12" x2="22" y2="12" stroke-linecap="round" />
                        <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" stroke-linecap="round" />
                    </svg>
                    Export Worldwide
                </div>
            </div>
        </div>
    </div>

    <!-- Protuct Area Start -->
    <div class="product-area bg-gray pb-50 related-product">
        <div class="container">
            <div class="section-title text-center">
                <div class="section-img d-flex justify-content-center">
                    <img src="<?php echo $url; ?>assets/img/icon/title.png" alt="">
                </div>
                <h2><span>Related </span>products</h2>
            </div>
        </div>
        <div class="container text-center">
            <div class="product-carousel">


                <?php
                if (isset($na_error)) {
                ?>
                    <li><a href="javascript:;"><?php echo $na_error; ?></a> </li>
                    <?php
                } else {
                    $related_mcname_url = URL_trim($fupdata['mcname']);
                    $related_scname_url = URL_trim($fupdata['scname']);

                    $na_stmt->bind_result($parent_id, $name, $description, $product_id, $mrp, $price, $pic1, $pic2, $featured, $cdate);
                    while ($na_stmt->fetch()) {
                        $product_display_url = URL_trim($name);

                    ?>
                        <div class="custom-col">
                            <div class="single-product-item">
                                <div class="product-image">
                                    <a href="<?php echo $url; ?><?php echo $related_mcname_url; ?>/<?php echo $related_scname_url; ?>/<?php echo $product_display_url; ?>/<?php echo $product_id; ?>/" target="_blank">
                                        <img src="<?php echo $url; ?>smadmin/<?php echo $pic1; ?>" alt="">
                                    </a>

                                    <!-- <div class="double_base">

                                        <?php $price_class = "product_sale";
                                        if ($price != 0 && $price < $mrp) {
                                            $discount = round(($mrp - $price) / $mrp * 100); ?>

                                            <?php if ($discount >= 25) { ?>

                                                <div class="label_product">
                                                    <span>Hot Deal</span>
                                                </div>
                                                <div class="<?php echo $price_class; ?> top_55">
                                                    <span>- <?php echo $discount; ?>% Off</span>
                                                </div>
                                            <?php } else { ?>

                                                <div class="<?php echo $price_class; ?>">
                                                    <span>- <?php echo $discount; ?>% Off</span>
                                                </div>

                                        <?php }
                                        } ?>



                                    </div> -->
                                </div>
                                <div class="product-text">

                                    <h5> <a href="<?php echo $url; ?><?php echo $related_mcname_url; ?>/<?php echo $related_scname_url; ?>/<?php echo $product_display_url; ?>/<?php echo $product_id; ?>/" target="_blank"><?php echo $name; ?></a></h5>
                                    <div class="pro-price">

                                        <?php if ($price != 0 && $price < $mrp) { ?>
                                            <span class="new-price">&#x20b9; <?php echo $price; ?></span>
                                            <span class="old-price">MRP &#x20b9;<?php echo $mrp; ?></span>
                                        <?php } else { ?>
                                            <span class="new-price">&#x20b9; <?php echo $price; ?></span>
                                        <?php } ?>



                                    </div>
                                    <?php if ($price != 0 && $price < $mrp) { ?>
                                        <!-- <div class="pro-price save-tag">

                                            You save:<strong> &#x20b9;<?php echo $mrp - $price; ?></strong> (<?php echo $discount; ?>% Off)

                                        </div> -->
                                    <?php } ?>

                                    <a href="<?php echo $url; ?><?php echo $related_mcname_url; ?>/<?php echo $related_scname_url; ?>/<?php echo $product_display_url; ?>/<?php echo $product_id; ?>/" target="_blank" class="mt-10"><button type="submit" class="submit-btn default-btn" name="signup">Buy Now</button> </a>
                                </div>
                            </div>

                        </div>

                <?php }
                }
                $na_stmt->free_result();
                ?>


            </div>
        </div>
    </div>
    <div class="testimonial-area pb-50 bg-white pt-85">
        <div class="container">
            <div class="testimonial-slider-wrapper">
                <div class="text-carousel text-center">
                    <div class="slider-text">
                        <span class="testi-quote">
                            <img src="<?php echo $url; ?>assets/img/icon/quote.png" alt="">
                        </span>
                        <p>Initially, I bought an ultrasonic aroma diffuser from him. Wooow! Quality of diffuser is outstanding. I swear, nowhere else we can get such a product. It so elegant and comes with a REMOTE CONTROL. The main part is its pricing. Highly competitive for such a world class diffuser. Many thanks for additional support for selling me THERAPEUTIC GRADE 👌 ESSENTIAL OILS at a best rate. REALLY EXCEEDING THE MARK 👍👍👍👍👍 iam highly satisfied and this is a highly recommended place for all essential oil requirements. Vazhga vazhamudan 🙏</p>
                    </div>
                    <div class="slider-text">
                        <span class="testi-quote">
                            <img src="<?php echo $url; ?>assets/img/icon/quote.png" alt="">
                        </span>
                        <p>We bought aroma diffuser in 3 different flavors. The quality is good and value for money. We recommend all to buy this product.</p>
                    </div>
                    <div class="slider-text">
                        <span class="testi-quote">
                            <img src="<?php echo $url; ?>assets/img/icon/quote.png" alt="">
                        </span>
                        <p>Genuine and outstanding quality. Good at fulfilling the customer needs (oil blending).The aroma fragrance which i received are awesome...</p>
                    </div>

                    <div class="slider-text">
                        <span class="testi-quote">
                            <img src="<?php echo $url; ?>assets/img/icon/quote.png" alt="">
                        </span>
                        <p>I have purchased diffuser and essential oils from Mylal Exports. It's an amazing product, a must buy for every house. Affordable, it's worth every penny spent on it.
                            Diffuser was provided with replacement and service warranty, which is very convenient. The quality of oils is amazing and pure. You can choose to buy organic or non organic essential oils.</p>
                    </div>
                    <div class="slider-text">
                        <span class="testi-quote">
                            <img src="<?php echo $url; ?>assets/img/icon/quote.png" alt="">
                        </span>
                        <p>Excellent Quality, perfect product delivery timing. Business relationship is good.</p>
                    </div>
                    <div class="slider-text">
                        <span class="testi-quote">
                            <img src="<?php echo $url; ?>assets/img/icon/quote.png" alt="">
                        </span>
                        <p>I ordered 32 Essential oils. Today i got as soon as i opened my courier really i am cloud nine. Bcoz each and every product packed well without any leakage. For lesser quantity products they pack another one box for safety and lowest amount 1ml-5ml they put into a box which fully unmovable and not leakage. And also wrap in cover. And they send In DTDC courier thats also good service. Thank you so much. I am very happy for these products and excellent packing😍😍😍😍.</p>
                    </div>
                </div>
                <div class="image-carousel">
                    <div class="testi-img">
                        <h4>saravana kumar</h4>
                    </div>
                    <div class="testi-img">
                        <h4>Leo Robinson</h4>
                    </div>
                    <div class="testi-img">
                        <h4>focus industries</h4>
                    </div>

                    <div class="testi-img">
                        <h4>Kavya K</h4>
                    </div>
                    <div class="testi-img">

                        <h4>Aruachalam Dhamodaran</h4>
                    </div>
                    <div class="testi-img">

                        <h4>Hasina Shaj</h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include("sm_footer.php"); ?>

    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:site" content="@sensemeindia">
    <meta name="twitter:creator" content="@sensemeindia">
    <meta name="twitter:title" content="<?php echo $fupdata['seo_title']; ?>">
    <meta name="twitter:description" content="<?php echo $fupdata['g_description']; ?> Free shipping within India.">
    <meta name="twitter:image" content="<?php echo "https://" . $_SERVER['HTTP_HOST'] . "/smadmin/" . $fupdata['pic6']; ?>">

    <script src="<?php echo $url; ?>assets/js/popper.min.js"></script>
    <script src="<?php echo $url; ?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo $url; ?>assets/js/plugins.js"></script>

    <script src="<?php echo $url; ?>assets/js/main.js"></script>

</body>

</html>
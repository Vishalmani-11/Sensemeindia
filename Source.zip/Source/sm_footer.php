<footer class="footer-area">
            <!-- Footer Top Area Start -->
            <div class="footer-top bg-4 pt-50 pb-50">
                <!-- Newsletter Area Start -->
                    <!--<div class="newsletter-area">
                        <div class="container text-center">
                           
                            <div class="social-icon">
                                <a href="#"><i class="fa fa-twitter"></i></a>
                                <a href="#"><i class="fa fa-google-plus"></i></a>
                                <a href="#"><i class="fa fa-facebook"></i></a>
                                <a href="#"><i class="fa fa-youtube"></i></a>
                                <a href="#"><i class="fa fa-flickr"></i></a>
                            </div>
                        </div>
                    </div>-->
                <!-- Newsletter Area End -->
                <!-- Service Area Start -->
                <div class="service-area pt-50">
                    <div class="container">
                        <div class="service-container">
                            <div class="service-content">
                                <div class="row">
                                    <div class="col-lg-4 col-md-4">
                                        <div class="single-service">
                                            <div class="service-image">
                                                <img src="<?php echo $url; ?>assets/img/icon/rocket.png" alt="">
                                            </div>
                                            <div class="service-text">
                                                <h3>Free delivery</h3>
                                                <p>Free shipping within India as we have covered it for you. </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-4">
                                        <div class="single-service">
                                            <div class="service-image">
                                                <img src="<?php echo $url; ?>assets/img/icon/title_footer.png" alt="">
                                            </div>
                                            <div class="service-text">
                                                <h3>100% Natural</h3>
                                                <p>100% natural products. No animal testing involved.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 col-md-4">
                                        <div class="single-service">
                                            <div class="service-image">
                                                <img src="<?php echo $url; ?>assets/img/icon/support_footer.png" alt="">
                                            </div>
                                            <div class="service-text">
                                                <h3>Online support</h3>
                                                <p>Chat with us on whatsapp online</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Service Area End -->
                <!-- Footer Widget Area Start -->
                <div class="footer-widget-area">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-4 col-md-6">
                                <div class="single-footer-widget">
                                    <div class="footer-logo">
                                        <a href="#"><img src="<?php echo $url; ?>assets/img/logo/logo.png" alt=""></a>
                                    </div>
                                    <p>Feel free to contact us for wholesale, <br>
rebranding & sales. </p>
                                    <div class="footer-text">
                                        <span><i class="icon icon-Pointer"></i><strong>Address</strong> : Mylal Exports, Coimbatore, <br>
Tamil nadu, India.</span>
                                        <span><i class="icon icon-Phone"></i><strong>Phone</strong> : +(91) 91508 70543</span>
                                        <span><i class="icon icon-Mail"></i><strong>Email</strong> : contact@sensemeindia.com</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-2 col-md-3">
                                <div class="single-footer-widget">
                                    <h3>Contact</h3>
                                    <ul class="footer-widget-list">
                                        <li><a href="<?php echo $url; ?>contact-us/">Bulk Purchase</a></li>
                                        <li><a href="<?php echo $url; ?>contact-us/">Own Labeling</a></li>
                                        <li><a href="<?php echo $url; ?>contact-us/">Signature products</a></li>
                                        <li><a href="<?php echo $url; ?>contact-us/">Contact us</a></li>
                                        
                                    </ul>
                                </div>
                            </div>
                            <div class="col-lg-2 col-md-3">
                                <div class="single-footer-widget">
                                    <h3>Quick Links</h3>
                                    <ul class="footer-widget-list">
                                        <li><a href="<?php echo $url; ?>terms-conditions/">Terms &amp; Conditions</a></li>
                                        <li><a href="<?php echo $url; ?>privacy-policy/">Privacy Policy</a></li>
                                        <li><a href="<?php echo $url; ?>shipping-policy/">Shipping &amp; Delivery</a></li>
                                        <li><a href="<?php echo $url; ?>payment-refunds/">Payment Refund</a></li>
                                     
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer-bottom-area pt-30 pb-30">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6 d-flex col-md-6">
                            <div class="footer-text-bottom">
                                <p>&copy; <?php echo date('Y'); ?>@sensemeindia.com. All Rights Reserved</p> 
                            </div>
                        </div>
                        <!--<div class="col-lg-6 col-md-6">-->
                        <!--    <div class="payment-img d-flex justify-content-end">-->
                        <!--       <a href="https://htsuite.com" target="_blank"><strong>Website Developement by HTS Web Solutions</strong></a>. -->
                        <!--    </div>-->
                        <!--</div>-->
                    </div>
                </div>
            </div>
            <!-- Footer Bottom Area End -->
        </footer>
<a id="whatsapp" href="https://api.whatsapp.com/send?phone=919150870543" target="_blank" onclick="dataLayer.push({'event': 'whatsapp_chat'});"><img src="<?php echo $url; ?>assets/img/whatsapp.png" alt="Contact Us"/></a>
<div class="overlay"></div> 
        <div id="side_menu" class="slide-menu">
            
    <div class="slide-header">
            <div class="slide-close-button">
        <button class="close"><i class="fa fa-close"></i></button>
                
      </div>
    </div>
    <div class="slide-menu-here">
      <ul class="menu">
        <li><a href="<?php echo $url; ?>index.php">Home</a></li>
                                    
                                      <?php      
			if(isset($merror))
			{
				?>
			     <?php echo $merror; ?>
			<?php 
						} 
						else
						{
			?>   
                  <?php 
    $sn = 0;
    $mstmt->data_seek(0);
	$mstmt->bind_result($mcid, $mcname, $mbanner);
	while ($mstmt->fetch()) 
	{
        $sn = $sn + 1;
			
	?>          
                              <li class="title"><div class="dropdownmenu"><span><?php echo $mcname; ?></span></div>
                                        <ul class="sub-menu">
                                                                                             
                  
       <?php
    ////////////////////////////////////////sub category////////////////////////////////////////////
        
    $scquery = "SELECT id, name, banner FROM bb_sub_categories WHERE mc_id = ? ORDER BY id ASC";

if(!$scstmt = $con->prepare($scquery))
{
	echo "prepare failed: (" . $con->errno . ") " . $con->error;	exit();
}
	if(!$scstmt->bind_param("i", $mcid))
{
	echo "Param pass failed: (" . $con->errno . ") " . $con->error;exit();
}

	if(!$scstmt->execute())
	{
		$error = "sub categories list failed!".$con->error;		exit();
		
	}

		if(!$scstmt->store_result())
		{
			$error = "sub categories list failed!".$con->error;	exit();				
		}
	
		$scnum_of_rows = $scstmt->num_rows;

if($scnum_of_rows==0)
{
    ?>
                      
	 <li> <a href="javascript:;">No sub categories found!</a></li> 
                      <?php
} else {
    
	$scstmt->bind_result($scid, $scname, $banner);
	while ($scstmt->fetch()) 
	{
        // Do not expose legacy sub-category records that no longer have live category pages.
        if (in_array((int)$scid, array(5, 9, 11), true)) {
            continue;
        }
         
        
        ?>
                                         
                      <li> <a href="<?php echo build_category_url($url, $mcname, $scname, $mcid, $scid); ?>" title="<?php echo $scname; ?>" ><?php echo $scname; ?></a></li>
                      
<?php
        
        
    }
    ?>     </ul>
                                            </li>
                                    
            
        <?php 
    
}
        
////////////////////////////////////////////////////////////////////////////////////////////////////////        
    } 
                         } 
     	?>            
          
              <li class="title"><div class="dropdownmenu"><span>Contact</span></div>
                                      <ul class="sub-menu">
                                            <li><a href="<?php echo $url; ?>contact-us/">For Bulk Purchase</a></li>
                                            <li><a href="<?php echo $url; ?>contact-us/">For Own Labeling</a></li>
                                            <li><a href="<?php echo $url; ?>contact-us/">For Signature Items</a></li>
                                            
                                        </ul>
                                    </li>
         
      </ul>
    </div>
  </div>

<div id="cart_menu" class="cart-slide-menu">
            
    <div class="slide-header">
            <div class="slide-close-button">
        <button class="close"><i class="fa fa-close"></i></button>
                
      </div>
    </div>
    <div class="slide-menu-here">
        <div class="cart-area table-area">
            <div class="container">
                <?php
                $cartCount = isset($_SESSION['cartsingle']) && is_array($_SESSION['cartsingle'])
                    ? count($_SESSION['cartsingle'])
                    : 0;

                $itemLabel = ($cartCount == 1) ? "item" : "items";
                ?>
                <h4 class="green pb-10"><strong>Shopping Cart</strong>(<?php echo $cartCount . " " . $itemLabel; ?>)</h4>

                <?php
                $sn = 0;
                if (isset($_SESSION['cartsingle']) && count($_SESSION['cartsingle']) != 0) {
                    $sn++;
                ?>


                    <div class="row">

                        <div class="col-lg-1 col-sm-1 cart_title mhide"></div>
                        <div class="col-lg-5 col-sm-5 cart_title">Product</div>
                        <div class="col-lg-2 col-sm-2 cart_title">Qty</div>
                        <div class="col-lg-2 col-sm-2 cart_title">Price</div>
                        <div class="col-lg-2 col-sm-2 cart_title mhide">Total</div>


                        <?php

                        $no = 0;
                        $totalcost = 0;

                        if (isset($_SESSION['cartsingle'])) {
                            if (count($_SESSION['cartsingle']) != 0) {
                                $no = count($_SESSION['cartsingle']);
                                foreach ($_SESSION['cartsingle'] as $id => $value) {

                                    /////////////////////////////////

                                    $scquery = "SELECT t1.*, t2.name, t6.name as psize FROM bb_products_stock as t1 INNER JOIN bb_products as t2 ON t1.parent_id = t2.id INNER JOIN bb_sizes as t6 ON t1.size = t6.id WHERE t1.id = ?";

                                    if (!$scstmt = $con->prepare($scquery)) {
                                        echo $error = "product data listing execution failed!" . $con->error;
                                    }

                                    if (!$scstmt->bind_param('i', $id)) {
                                        echo    $error = "product data listing execution failed!" . $con->error;
                                    }

                                    if (!$scstmt->execute()) {
                                        echo $error = "product data deletion execution failed!" . $con->error;
                                    }

                                    if (!$scresult = $scstmt->get_result()) {
                                        echo $error = "cart data listing execution failed!" . $con->error;
                                    }

                                    if (!$prdata = $scresult->fetch_assoc()) {
                                        echo $error = "cart data listing execution failed!" . $con->error;
                                    }

                        ?>

                                    <div class="col-lg-1 col-sm-1 mhide cart_contents"><span style="cursor:pointer !important" onClick="remove('<?php echo $id; ?>', 'remove')"><i class="fa fa-close black"></i></span></div>
                                    <div class="col-lg-5 col-sm-5 cart_contents text-left"><img src="<?php echo $url; ?>smadmin/<?php echo $prdata['pic1']; ?>" alt="<?php echo $prdata['name']; ?>" width="20%"> <?php echo $prdata['name']; ?> <?php echo "(" . $prdata['psize'] . ")"; ?></div>
                                    <div class="col-lg-2 col-sm-2 cart_contents">
                                        <input type='button' value='-' class='qtyminus' onClick="remvqtys('<?php echo $id; ?>', 'qremove')" />
                                        <input name='quantity<?php echo $id; ?>' value="<?php echo $value; ?>" type="text" id="cqty<?php echo $id; ?>" class="qty">
                                        <input type='button' value='+' class='qtyplus' onClick="addqtys('<?php echo $id; ?>', 'update')" />
                                    </div>
                                    <div class="col-lg-2 col-sm-2 cart_contents">
                                        <p class="m_pt10">&#x20b9; <?php echo $prdata['price']; ?></p>
                                    </div>
                                    <div class="col-lg-2 col-sm-2 mhide cart_contents">
                                        <p class="m_pt10">&#x20b9; <?php echo $total = $value * $prdata['price']; ?></p>
                                    </div>

                        <?php
                                    $totalcost += $total;
                                }
                            }
                        }
                        //$_SESSION['postage'] =  $postage;
                        //$_SESSION['totalvalue'] =  $totalcost + $postage;
                        //$gst = (15*$totalcost)/100; 
                        //$_SESSION['gst'] =  $gst;
                        $_SESSION['total'] =  $totalcost;
                        $_SESSION['totalitems'] = count($_SESSION['cartsingle']);
                        ?>
                    </div>




                    <div class="container">
                        <div class="table-total-wrapper d-flex justify-content-end pt-20">
                            <div class="table-total-content">
                                <h2 class="green">Cart Summary</h2>
                                <div class="table-total-amount">
                                    <div class="single-total-content d-flex justify-content-between">
                                        <span>Cart Subtotal</span>
                                        <span class="c-total-price">&#x20b9; <?php echo $totalcost; ?></span>
                                    </div>
                                    <div class="single-total-content d-flex justify-content-between">
                                        <span>Total</span>
                                        <span class="c-total-price">&#x20b9; <?php echo $totalcost; ?></span>
                                    </div>


                                    <div class="product-tag-cat mt-20">

                                    </div>
                                    <a href="<?php echo $url; ?>checkout_order.php" id="checkout_button" onclick="dataLayer.push({'event': 'proceedToBuy_click', 'ordervalue': <?php echo $totalcost; ?>});">Proceed to Buy</a>
                                    <a href="#" id="continue_shopping" class="mt-1 default-btn bg-orange" onClick="continue_shopping();">Continue Shopping</a>


                                </div>
                            </div>
                        </div>
                    </div>


                <?php } else {
                    echo "<h3>No products in cart. Let's add some to buy.</h3>";
                } ?>
            </div>
        </div>
    </div>
  </div>
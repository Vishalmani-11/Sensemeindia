<?php include "smadmin/function/config.php"; 
include "smadmin/db/db_connect.php"; 
include "smadmin/function/function.php"; 
require_once 'smadmin/admin/class.user_2.php';

$reg_user = new USER();

if($reg_user->is_logged_in())
{
	$reg_user->redirect('index.php');
}

?>
<!doctype html>
<html class="no-js" lang="en">
   <head>
     <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-WWCJ4NT');</script>
<!-- End Google Tag Manager -->
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Contact Us | SenseMe India</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Favicon -->
        <link rel="shortcut icon" type="image/x-icon" href="<?php echo $url; ?>assets/img/favicon.png">

        <!-- All css here -->
        <link rel="stylesheet" href="<?php echo $url; ?>assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo $url; ?>assets/css/font-awesome.min.css">
        <link rel="stylesheet" href="<?php echo $url; ?>assets/css/ie7.css">
        <link rel="stylesheet" href="<?php echo $url; ?>assets/css/plugins.css">
        <link rel="stylesheet" href="<?php echo $url; ?>assets/css/style.css">
	   <link rel="stylesheet" href="<?php echo $url; ?>assets/css/menu/style.css">    
        <script src="<?php echo $url; ?>assets/js/vendor/modernizr-3.5.0.min.js"></script>
		<script src='https://www.google.com/recaptcha/api.js' async></script>

       <!-- Facebook Pixel Code -->
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '327668741988781');
  fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
  src="https://www.facebook.com/tr?id=327668741988781&ev=PageView&noscript=1"
/></noscript>
<!-- End Facebook Pixel Code -->
    </head>
    <body>
    	<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-WWCJ4NT"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
  <div id="loadAjax" class="ui-front loader ui-widget-overlay bg-gray opacity-50" style="display:none">
           <img src="<?php echo $url; ?>assets/img/loader-light.gif" alt="">
        </div>
        
         <?php include("sm_header.php"); ?>
        <div class="breadcrumb-area bg-12 text-center">
            <div class="container">
                <h1>Contact Us</h1>
                <nav aria-label="breadcrumb">
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Contact Us</li>
                    </ul>
                </nav>
            </div>
        </div>
        <!-- Breadcrumb Area End -->
        <!-- Cart Area Start -->
         
        <div class="contact-area fix mb-95">             
            <div class="contact-form pt-110">
                <?php if(isset($_GET['success'])) { ?> <h3><strong>Thanks for your message!</strong> We will get back to you soon!</h3> <?php } ?>  <br>
                <h1 class="contact-title">Write to Us</h1>
                <form id="contact-form" action="<?php echo $url; ?>qmail.php" method="post" onSubmit="return checkc()">
                    <div class="row">
                        <div class="col-md-6">
                            <input type="text" name="name" id="name" placeholder="First Name *" required>
                        </div>
                        <div class="col-md-6">
                            <input type="text" name="l_name" id="l_name" placeholder="Last Name *" required>
                        </div>
                        <div class="col-md-6">
                            <input type="text" name="email" id="email" placeholder="Email *" required>
                        </div>
                         <div class="col-md-6">
                            <input type="text" name="phone" id="phone" placeholder="Phone *" required>
                        </div>
                         <div class="col-md-6">
                            <input type="text" name="city" id="city" placeholder="city *" required>
                        </div>
                        <div class="col-md-6">
                            <input type="text" name="subject" id="subject" placeholder="Subject *" required>
                        </div>
                    </div>
                    <textarea name="message" id="message" placeholder="Message *" required></textarea>
                    <!--<div class="col-md-6">-->
                    <div class="g-recaptcha" data-sitekey="6LcE1zstAAAAAJm-BInDxch3VTX-RU0lBS3TGxEw"></div>
                    <!--</div>    -->
                    <button type="submit" name="qsubmit" class="submit-btn default-btn mt-30">
                        <span>Send Email</span>
                    </button>
                    <p class="form-messege"></p>
                </form>
                
                 <script type="text/javascript">

function checkc()
{
var responsep = grecaptcha.getResponse(0);
if(!responsep)
{
	alert("Please complete google captcha!");
	grecaptcha.reset(0);	    
	return false;
}
else
{
//	alert("form submitted");
	 $("#contact-form").submit();
}


}
</script>
                
            </div>
            <div class="contact-address pt-110 pb-100">
                <h1 class="contact-title">For Bulk Purchases, Own Labeling &amp; Signature <br><br> Products</h1>
                <div class="contact-info">
                    <p>and for any inquiries, questions on your purchase or our products, please feel free to contact us. We will get back to you within 24hrs.</p>
                    <div class="contact-list-wrapper">
                        <div class="contact-list">
                            <i class="fa fa-map-signs"></i>
                            <span>Address : Mylal Exports, #38, Machamapalayam, <br>
Sundarapuram, Coimbatore, Tamil Nadu - 641024</span>
                        </div>
                        <div class="contact-list">
                            <i class="fa fa-phone"></i>
                            <span>sensemeindia@gmail.com</span>
                        </div>
                        <div class="contact-list">
                            <i class="fa fa-envelope-o"></i>
                            <span>+(91) 91508 70543</span>
                        </div>
                    </div>
                </div>
                <!--<div class="working-time">
                    <h2>Working hours</h2>
                    <span><span>Monday – Saturday:</span>  08AM – 22PM</span>
                </div>-->
            </div>
        </div>
        <div class="testimonial-area pt-110 pb-95 bg-white">
            <div class="container">
                <div class="testimonial-slider-wrapper">
                    <div class="text-carousel text-center">
                        <div class="slider-text">
                            <span class="testi-quote">
                                <img src="assets/img/icon/quote.png" alt="">
                            </span>
                            <p>Initially, I bought an ultrasonic aroma diffuser from him. Wooow! Quality of diffuser is outstanding. I swear, nowhere else we can get such a product. It so elegant and comes with a REMOTE CONTROL. The main part is its pricing. Highly competitive for such a world class diffuser. Many thanks for additional support for selling me THERAPEUTIC GRADE 👌 ESSENTIAL OILS at a best rate. REALLY EXCEEDING THE MARK 👍👍👍👍👍 iam highly satisfied and this is a highly recommended place for all essential oil requirements. Vazhga vazhamudan 🙏</p>
                        </div>
                        <div class="slider-text">
                            <span class="testi-quote">
                                <img src="assets/img/icon/quote.png" alt="">
                            </span>
                            <p>We bought aroma diffuser in 3 different flavors. The quality is good and value for money. We recommend all to buy this product.</p>
                        </div>
                        <div class="slider-text">
                            <span class="testi-quote">
                                <img src="assets/img/icon/quote.png" alt="">
                            </span>
                            <p>Genuine and outstanding quality. Good at fulfilling the customer needs (oil blending).The aroma fragrance which i received are awesome...</p>
                        </div>
                        
                        <div class="slider-text">
                            <span class="testi-quote">
                                <img src="assets/img/icon/quote.png" alt="">
                            </span>
                            <p>I have purchased diffuser and essential oils from Mylal Exports. It's an amazing product, a must buy for every house. Affordable, it's worth every penny spent on it.
Diffuser was provided with replacement and service warranty, which is very convenient. The quality of oils is amazing and pure. You can choose to buy organic or non organic essential oils.</p>
                        </div>
                        <div class="slider-text">
                            <span class="testi-quote">
                                <img src="assets/img/icon/quote.png" alt="">
                            </span>
                            <p>Excellent Quality, perfect product delivery timing. Business relationship is good.</p>
                        </div>
                        <div class="slider-text">
                            <span class="testi-quote">
                                <img src="assets/img/icon/quote.png" alt="">
                            </span>
                            <p>I ordered 32 Essential oils. Today i got as soon as i opened my courier really i am cloud nine. Bcoz each and every product packed well without any leakage. For lesser quantity products they pack another one box for safety and lowest amount 1ml-5ml they put into a box which fully unmovable and not leakage. And also wrap in cover. And they send In DTDC courier thats also good service. Thank you so much. I am very happy for these products and excellent packing😍😍😍😍.</p>
                        </div>
                    </div>
                    <div class="image-carousel">
                        <div class="testi-img">
                            <h4>saravana kumar</h4>
                        </div>
                        <div class="testi-img">
                            <h4>Leo Robinson</h4>
                        </div>
                        <div class="testi-img">
                            <h4>focus industries</h4>
                        </div>
                        
                        <div class="testi-img">
                            <h4>Kavya K</h4>
                        </div>
                        <div class="testi-img">
                            
                            <h4>Aruachalam Dhamodaran</h4>
                        </div>
                        <div class="testi-img">
                            
                            <h4>Hasina Shaj</h4>
                        </div>
                    </div>
                </div> 
            </div>
        </div>
        <?php include("sm_footer.php"); ?>
        <!-- Footer Area End -->
        
        <!-- QUICKVIEW PRODUCT -->
        
        <!-- END QUICKVIEW PRODUCT -->
        
        <!-- All js here -->
        <script src="<?php echo $url; ?>assets/js/vendor/jquery-3.2.1.min.js"></script>
        <script src="<?php echo $url; ?>assets/js/popper.min.js"></script>
        <script src="<?php echo $url; ?>assets/js/bootstrap.min.js"></script>
        <script src="<?php echo $url; ?>assets/js/plugins.js"></script>
        <script src="<?php echo $url; ?>assets/js/ajax-mail.js"></script>
        <script src="<?php echo $url; ?>assets/js/main.js"></script>
    </body>
</html>
<header class="header-area header-two header-sticky mobile-sticky">
            <div class="header-container">
                <div class="row">
                   
                    <div class="col-lg-12 col-sm-12 pb-25">
                        <div class="logo text-center">
                            <a href="<?php echo $url; ?>"><img id="dlogo" src="<?php echo $url; ?>assets/img/logo/logo.png" alt="SenseMe India"><img id="mlogo" src="<?php echo $url; ?>assets/img/logo/mlogo.png" alt="SenseMe India"></a>
                        </div>
                        
                    </div>
                </div>
            </div>
        </header>
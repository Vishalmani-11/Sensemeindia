<?php
include "smadmin/function/config.php"; 
include "smadmin/db/db_connect.php"; 
include "smadmin/function/function.php"; 
require_once 'smadmin/admin/class.user_2.php';

$reg_user = new USER();

if($reg_user->is_logged_in())
{
	$reg_user->redirect('index.php');
}

?>
<!doctype html>
<html class="no-js" lang="en">
   <head>
       <meta name="robots" content="noindex, nofollow">
   <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-WWCJ4NT');</script>
<!-- End Google Tag Manager -->
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Customer Login | Registration | SenseMe India</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Favicon -->
        <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.png">

        <!-- All css here -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/css/font-awesome.min.css">
        <link rel="stylesheet" href="assets/css/ie7.css">
        <link rel="stylesheet" href="assets/css/plugins.css">
        <link rel="stylesheet" href="assets/css/style.css">
        <script src="assets/js/vendor/modernizr-3.5.0.min.js"></script>

<!-- Facebook Pixel Code -->
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '327668741988781');
  fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
  src="https://www.facebook.com/tr?id=327668741988781&ev=PageView&noscript=1"
/></noscript>
<!-- End Facebook Pixel Code -->
    </head>
    <body>
     	<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-WWCJ4NT"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
  <div id="loadAjax" class="ui-front loader ui-widget-overlay bg-gray opacity-50" style="display:none">
           <img src="assets/img/loader-light.gif" alt="">
        </div>
        
         <?php include("sm_header.php"); ?>
        <div class="breadcrumb-area bg-12 text-center">
            <div class="container">
                <h1>My Cart</h1>
                <nav aria-label="breadcrumb">
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">View Cart</li>
                    </ul>
                </nav>
            </div>
        </div>
        <!-- Breadcrumb Area End -->
        <!-- Cart Area Start -->
        <div class="wishlist-area table-area pt-80 pb-95">
            <div class="container">  
   <div class="row">
            <div class="col-lg-6 col-md-6 bg-color p-5 mr-4">
                <a href="<?php echo $client->createAuthUrl(); ?>" class="mb-30"><img src="<?php echo $url; ?>assets/img/btn_google_signin_dark_normal_web.png" width="100%" alt="Sign In with Gmail"/></a>
        <div class="form-pop-up-content">             
								<h2 class="pb-30">New Customer? Sign Up</h2>
								<form id="register2" action="<?php echo $url; ?>users/customer-registration-action.php" method="POST" onSubmit="return pacheck2()">
									<div class="form-box">
							 <p>   
                              
                                <input type="text" name="initial" required placeholder="First Name*" class="bg-color2">
                             </p>
                            <p>   
                              
                                <input type="text" name="name" required placeholder="Last Name*" class="bg-color2">
                             </p>
                            <p>   
                              
                                <input type="text" name="phone" required placeholder="Phone No*" class="bg-color2">
                             </p>
                            <p>   
                              
                                <input type="email" name="email1" id="email_21" required placeholder="Email address*" class="bg-color2">
                             </p>
                            <p>   
                              
                                <input type="email" name="email2" id="email_22" required placeholder="Re-type Email address*" class="bg-color2">
                             </p>
                             <p>   
                              
                                <input type="password" id="pass21" name="password1" pattern=".{8,}" title="8 characters minimum required" required placeholder="Password*" class="bg-color2">
                             </p>
                             <p>   
                               
                                <input type="password" id="pass22" name="password2" pattern=".{8,}" title="8 characters minimum required" placeholder="Re-type Password*" class="bg-color2">
                             </p>
                             <p>   
                               
                                <input type="text" name="city" required placeholder="City*" class="bg-color2">
                             </p>
                             <p>   
                               
                                <input type="text" name="country" required placeholder="Country*" class="bg-color2">
                             </p>
									</div>
								    <button type="submit" class="submit-btn default-btn-2" name="signup">Register</button>
								</form>
            <script type="text/javascript">

function pacheck2()
{	
var pa1 = $('#pass21').val();
var pa2 = $('#pass22').val();
var email1 = $('#email_21').val();
var email2 = $('#email_22').val(); 
 
    if(email1!=""&&email2!=""&&email1==email2)
        {
         if(pa1!=""&&pa2!=""&&pa1==pa2)
        {
        return true;
        }
        else
        {
        alert("Passwords not match! please try again!");		
        return false;
        }	
        }
    else
    {
    alert("Email Ids not match! please try again!");		
    return false;
    }	

}
</script>
							</div>
                </div>
                <div class="col-lg-5 col-md-5">
        <div class="form-pop-up-content bg-color p-5">
								<h2 class="pb-30">Existing Customer? Login</h2>
								<form id="registration4" action="<?php echo $url; ?>users/user_login_submit.php" method="POST">
									<div class="form-box">
										<p>   
                                
                                <input type="email" name="email" required="" placeholder="E-mail*" class="bg-color2">
                             </p>
                             <p>   
                               
                                <input type="password" name="password" required="" placeholder="Password*" class="bg-color2">
                             </p> 
									</div>
									<div class="checkobx-link pb-20 pt-10">
									    
									    <div class="right-col"><a href="<?php echo $url; ?>users/reset_password.php"><strong>Forget Password?</strong></a></div>
									</div>
								    <button type="submit" class="submit-btn default-btn-2" name="login-bb">login</button>
								</form>
							</div>
                </div>
               </div>
           
        </div>
        </div>
        <?php include("sm_footer.php"); ?>
        <!-- Footer Area End -->
        
        <!-- QUICKVIEW PRODUCT -->
        
        <!-- END QUICKVIEW PRODUCT -->
        
        <!-- All js here -->
        <script src="assets/js/vendor/jquery-3.2.1.min.js"></script>
        <script src="assets/js/popper.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/plugins.js"></script>
        <script src="assets/js/ajax-mail.js"></script>
        <script src="assets/js/main.js"></script>
    </body>
</html>
<?php
/**
 * AJAX Endpoint: Create Razorpay Order
 * POST: amount, customer_name, customer_email, customer_mobile, address, city, state, pincode, order_notes, csrf_token
 */
session_start();
header('Content-Type: application/json');

include "../smadmin/function/config.php";
include "../smadmin/db/db_connect.php";
include "../smadmin/function/function.php";
include "../razorpay_config.php";

// CSRF validation
if (!isset($_POST['csrf_token']) || !isset($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid session. Please refresh the page.']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method.']);
    exit();
}

// Verify OTP was completed
if (!isset($_SESSION['otp_verified']) || $_SESSION['otp_verified'] !== true) {
    echo json_encode(['status' => 'error', 'message' => 'Mobile verification required. Please verify your OTP first.']);
    exit();
}

// Verify cart exists
if (!isset($_SESSION['cartsingle']) || count($_SESSION['cartsingle']) == 0) {
    echo json_encode(['status' => 'error', 'message' => 'Your cart is empty.']);
    exit();
}

// Sanitize inputs
$amount   = isset($_SESSION['total']) ? (int)$_SESSION['total'] : 0;
$name     = secure_input($con, $_POST['customer_name'] ?? '');
$email    = secure_email($_POST['customer_email'] ?? '');
$mobile   = secure_input($con, $_POST['customer_mobile'] ?? '');
$address  = secure_input($con, $_POST['address'] ?? '');
$city     = secure_input($con, $_POST['city'] ?? '');
$state    = secure_input($con, $_POST['state'] ?? '');
$pincode  = secure_input($con, $_POST['pincode'] ?? '');
$notes    = secure_input($con, $_POST['order_notes'] ?? '');

// Validate
if ($amount <= 0) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid order amount.']);
    exit();
}
if (empty($name) || empty($mobile) || !$email || empty($address)) {
    echo json_encode(['status' => 'error', 'message' => 'Missing required customer details.']);
    exit();
}

// Generate unique internal order ID
$orderId = 'SM' . date('Ymd') . strtoupper(substr(bin2hex(random_bytes(4)), 0, 8));

// Amount in paise for Razorpay (1 INR = 100 paise)
$amountPaise = $amount * 100;

// Create Razorpay Order via API
$razorpayData = json_encode([
    'amount'   => $amountPaise,
    'currency' => 'INR',
    'receipt'  => $orderId,
    'notes'    => [
        'customer_name'   => $name,
        'customer_mobile' => $mobile,
        'internal_order'  => $orderId
    ]
]);

$ch = curl_init('https://api.razorpay.com/v1/orders');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST           => true,
    CURLOPT_POSTFIELDS     => $razorpayData,
    CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
    CURLOPT_USERPWD        => RAZORPAY_KEY_ID . ':' . RAZORPAY_KEY_SECRET,
    CURLOPT_TIMEOUT        => 30,
    CURLOPT_SSL_VERIFYPEER => true,
]);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlError = curl_error($ch);
curl_close($ch);

if ($curlError) {
    error_log("Razorpay cURL Error: " . $curlError);
    echo json_encode(['status' => 'error', 'message' => 'Payment gateway error. Please try again.']);
    exit();
}

$rzpOrder = json_decode($response, true);

if ($httpCode !== 200 || !isset($rzpOrder['id'])) {
    error_log("Razorpay Order Creation Failed: HTTP $httpCode - " . $response);
    echo json_encode(['status' => 'error', 'message' => 'Could not create payment order. Please try again.']);
    exit();
}

$razorpayOrderId = $rzpOrder['id'];

// Get client IP
$ipAddress = '';
if (function_exists('get_client_ip')) {
    $ipAddress = get_client_ip();
} else {
    $ipAddress = $_SERVER['REMOTE_ADDR'] ?? '';
}

$totalItems = isset($_SESSION['totalitems']) ? (int)$_SESSION['totalitems'] : count($_SESSION['cartsingle']);

// Save pending order to database
$insertQuery = "INSERT INTO rzp_orders (order_id, razorpay_order_id, customer_name, customer_email, customer_mobile, address, city, state, pincode, total_amount, total_items, payment_status, order_status, order_notes, ip_address) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'PENDING', 'PENDING', ?, ?)";

if ($stmt = $con->prepare($insertQuery)) {
    $stmt->bind_param("sssssssssidss",
        $orderId, $razorpayOrderId, $name, $email, $mobile,
        $address, $city, $state, $pincode, $amount, $totalItems, $notes, $ipAddress
    );

    if (!$stmt->execute()) {
        error_log("Order Insert Error: " . $con->error);
        echo json_encode(['status' => 'error', 'message' => 'Could not save order. Please try again.']);
        $stmt->close();
        exit();
    }
    $stmt->close();
} else {
    error_log("Order Prepare Error: " . $con->error);
    echo json_encode(['status' => 'error', 'message' => 'Database error. Please try again.']);
    exit();
}

// Store order ID in session
$_SESSION['pending_order_id'] = $orderId;
$_SESSION['pending_rzp_order_id'] = $razorpayOrderId;

echo json_encode([
    'status'            => 'success',
    'order_id'          => $orderId,
    'razorpay_order_id' => $razorpayOrderId,
    'amount_paise'      => $amountPaise,
    'amount'            => $amount,
    'message'           => 'Order created successfully.'
]);
?>

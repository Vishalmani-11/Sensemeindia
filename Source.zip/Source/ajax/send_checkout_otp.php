<?php
/**
 * AJAX Endpoint: Send OTP to Mobile via CrystalPro SMS API
 * POST: mobile_number, csrf_token, [resend]
 */
session_start();
header('Content-Type: application/json');

include "../smadmin/function/config.php";
include "../smadmin/db/db_connect.php";
include "../smadmin/function/function.php";
include "../razorpay_config.php";

// CSRF validation
if (!isset($_POST['csrf_token']) || !isset($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid session. Please refresh the page.']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method.']);
    exit();
}

$mobile = isset($_POST['mobile_number']) ? trim($_POST['mobile_number']) : '';

// Validate mobile number
if (!preg_match('/^[0-9]{10}$/', $mobile)) {
    echo json_encode(['status' => 'error', 'message' => 'Please enter a valid 10-digit mobile number.']);
    exit();
}

// Rate limiting: check last OTP sent time for this mobile
$cooldown = OTP_COOLDOWN_SECONDS;
$checkQuery = "SELECT created_at FROM rzp_otp_log WHERE mobile = ? ORDER BY id DESC LIMIT 1";
if ($checkStmt = $con->prepare($checkQuery)) {
    $checkStmt->bind_param("s", $mobile);
    $checkStmt->execute();
    $checkResult = $checkStmt->get_result();
    if ($lastRow = $checkResult->fetch_assoc()) {
        $lastTime = strtotime($lastRow['created_at']);
        $diff = time() - $lastTime;
        if ($diff < $cooldown && !isset($_POST['resend'])) {
            $wait = $cooldown - $diff;
            echo json_encode(['status' => 'error', 'message' => "Please wait {$wait} seconds before requesting a new OTP."]);
            $checkStmt->close();
            exit();
        }
    }
    $checkStmt->close();
}

// Generate 4-digit OTP
$otp = rand(1000, 9999);

// Store OTP in session and database
$_SESSION['checkout_otp'] = $otp;
$_SESSION['checkout_mobile'] = $mobile;
$_SESSION['checkout_otp_time'] = time();

$insertQuery = "INSERT INTO rzp_otp_log (mobile, otp) VALUES (?, ?)";
if ($insertStmt = $con->prepare($insertQuery)) {
    $otpStr = (string)$otp;
    $insertStmt->bind_param("ss", $mobile, $otpStr);
    $insertStmt->execute();
    $insertStmt->close();
}

// Compose SMS message
$message =  "Dear customer, $otp is your OTP sensemeindia. This OTP will be valid for next 5 mins.Never share OTP with anyone.";

// Send SMS via CrystalPro API
// Add country code (91) for Indian numbers - without + sign
$mobileWithCountryCode = '91' . $mobile; // e.g., 919500583833

$params = [
	'key'        => SMS_API_KEY,
	'route'      => SMS_ROUTE,
	'sender'     => SMS_SENDER_ID,
	'number'     => $mobileWithCountryCode,
	'sms'        => $message,
	'templateid' => SMS_TEMPLATE_ID
];
$baseUrl = 'https://sms.crystalpro.net/api/smsapi';
$smsUrl = $baseUrl . '?' . http_build_query($params);
$smsUrl = str_replace(' ', '', $smsUrl); // Remove all spaces
$smsUrl = preg_replace('/\s+/', '', $smsUrl); // Remove all whitespace (including non-breaking spaces, tabs, etc.)

// Debug logging
error_log("SMS API URL: " . $smsUrl);
error_log("SMS API Params: " . json_encode($params));

$ch = curl_init();
curl_setopt_array($ch, [
    CURLOPT_URL            => $smsUrl,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT        => 30,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION   => CURL_HTTP_VERSION_1_1,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_SSL_VERIFYHOST => false
]);

$smsResponse = curl_exec($ch);
$curlError = curl_error($ch);
$curlErrno = curl_errno($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

// Detailed error logging
error_log("SMS API Response Code: " . $httpCode);
error_log("SMS API Response: " . $smsResponse);
if ($curlError) {
    error_log("SMS API cURL Error [" . $curlErrno . "]: " . $curlError);
}

curl_close($ch);

// CrystalPro API Error Code Mapping
$crystalProErrors = [
    '100' => 'Success',
    '101' => 'Invalid API Key',
    '102' => 'Invalid Route',
    '103' => 'Invalid Sender ID',
    '104' => 'Invalid Mobile Number',
    '105' => 'Invalid Message',
    '106' => 'Invalid Template ID',
    '107' => 'Insufficient Balance',
    '108' => 'Account Suspended',
    '109' => 'Invalid DND Number',
    '110' => 'Invalid Request / Missing Parameters',
    '111' => 'Route not allowed for this sender'
];

$errorMessage = $crystalProErrors[$smsResponse] ?? 'Unknown Error';

// Display errors for debugging
$debugMode = false; // Set to false in production
if ($debugMode) {
    echo json_encode([
        'status'           => 'debug',
        'http_code'        => $httpCode,
        'curl_error'       => $curlError,
        'curl_errno'       => $curlErrno,
        'response_code'    => $smsResponse,
        'response_message' => $errorMessage,
        'url'              => $smsUrl,
        'params'           => $params
    ]);
    exit();
}

if ($curlError || $curlErrno) {
    error_log("SMS API cURL Error [" . $curlErrno . "]: " . $curlError);
    echo json_encode(['status' => 'error', 'message' => 'Unable to send OTP. Please try again.']);
    exit();
}

// Check if response is an error code (CrystalPro returns numeric codes)
if (is_numeric($smsResponse)) {
    $responseInt = intval($smsResponse);
    
    // Error codes are in the 100-111 range
    // Any larger number is a Message ID (success indicator)
    if ($responseInt >= 100 && $responseInt <= 111) {
        // This is an error code
        if ($responseInt != 100) { // 100 = Success
            error_log("SMS API Error Code: " . $smsResponse . " - " . $errorMessage);
            echo json_encode(['status' => 'error', 'message' => 'SMS Error: ' . $errorMessage]);
            exit();
        }
    } else if ($responseInt > 111) {
        // Large number = Message ID = Success!
        error_log("SMS sent successfully. Message ID: " . $smsResponse);
        // Continue to success message
    } else {
        // Unknown response
        error_log("SMS API Unknown Response: " . $smsResponse);
        echo json_encode(['status' => 'error', 'message' => 'Unable to send OTP. Please try again.']);
        exit();
    }
}

// For development/testing: if SMS API is not configured, still allow flow
// In production, validate the SMS API response properly
$smsData = json_decode($smsResponse, true);

// CrystalPro returns different response formats - handle gracefully
// If 'status' key exists and indicates failure, report error
if (is_array($smsData) && isset($smsData['status']) && $smsData['status'] === 'error') {
    error_log("SMS API Error: " . $smsResponse);
    echo json_encode(['status' => 'error', 'message' => 'Unable to send OTP. Please try again later.']);
    exit();
}

echo json_encode([
    'status'  => 'success',
    'message' => 'OTP sent successfully to +91 ' . $mobile
]);
?>

<?php
/**
 * AJAX Endpoint: Verify Razorpay Payment + Save Order + Send Emails
 * POST: razorpay_order_id, razorpay_payment_id, razorpay_signature, order_id, csrf_token
 *
 * IMPORTANT: ob_start() is FIRST to prevent PHP notices/warnings from corrupting JSON.
 */
ob_start();
error_reporting(0);
ini_set('display_errors', 0);

session_start();
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Cache-Control: no-cache, no-store, must-revalidate');

function jsonExit($data) {
    // Clear ALL buffer levels (handles nested ob_start() from included files)
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    echo json_encode($data);
    exit();
}

function paymentLog($message, $level = 'INFO') {
    try {
        $logDir = dirname(__DIR__) . '/logs';
        if (!is_dir($logDir)) { mkdir($logDir, 0755, true); }
        $logFile = $logDir . '/payment_' . date('Y-m-d') . '.log';
        file_put_contents($logFile, '[' . date('Y-m-d H:i:s') . '] [' . $level . '] ' . $message . PHP_EOL, FILE_APPEND | LOCK_EX);
    } catch (Exception $e) {}
}

// ==================== SEND EMAIL FUNCTION (Define BEFORE calling) ====================
function sendOrderEmails($order, $items)
{
    // IMPORTANT: This function should NEVER throw exceptions or output anything
    // Order flow must complete successfully even if email fails
    
    $orderId = isset($order['order_id']) ? $order['order_id'] : 'UNKNOWN';
    
    try {
        // Check if PHPMailer exists
        if (!file_exists(dirname(__DIR__) . '/mailer/class.phpmailer.php')) {
            paymentLog("PHPMailer not found for order $orderId", 'WARN');
            return;
        }
        
        require_once dirname(__DIR__) . '/mailer/class.phpmailer.php';

        // Build items HTML
        $itemsHtml = '';
        foreach ($items as $item) {
            $itemsHtml .= "<tr>
                <td style='padding:8px;border:1px solid #ddd;'>" . htmlspecialchars($item['product_name']) . " (" . htmlspecialchars($item['product_size']) . ")</td>
                <td style='padding:8px;border:1px solid #ddd;text-align:center;'>" . intval($item['quantity']) . "</td>
                <td style='padding:8px;border:1px solid #ddd;text-align:right;'>&#x20b9; " . number_format(floatval($item['price']), 2) . "</td>
                <td style='padding:8px;border:1px solid #ddd;text-align:right;'>&#x20b9; " . number_format(floatval($item['total']), 2) . "</td>
            </tr>";
        }

        $emailBody = "
<!DOCTYPE html>
<html><head><meta charset='utf-8'></head>
<body style='font-family:Arial,sans-serif;color:#333;padding:20px;'>
<div style='max-width:600px;margin:0 auto;border:1px solid #ddd;border-radius:5px;'>
<div style='background:#8caf3d;color:#fff;padding:20px;text-align:center;'>
<h1 style='margin:0;font-size:22px;'>Order Confirmed!</h1>
<p style='margin:5px 0 0;'>Thank you for your purchase from SenseMe India</p>
</div>
<div style='padding:20px;'>
<table style='width:100%;margin-bottom:15px;border-collapse:collapse;'>
<tr><td><strong>Order ID:</strong></td><td>" . htmlspecialchars($order['order_id']) . "</td></tr>
<tr><td><strong>Date:</strong></td><td>" . date('d M Y, h:i A', strtotime($order['created_at'])) . "</td></tr>
<tr><td><strong>Payment ID:</strong></td><td>" . htmlspecialchars($order['razorpay_payment_id']) . "</td></tr>
<tr><td><strong>Status:</strong></td><td style='color:green;font-weight:bold;'>SUCCESS</td></tr>
<tr><td><strong>Amount:</strong></td><td><strong>₹ " . number_format(floatval($order['total_amount']), 2) . "</strong></td></tr>
</table>
<h3 style='border-bottom:2px solid #8caf3d;padding-bottom:8px;'>Items</h3>
<table style='width:100%;border-collapse:collapse;margin-bottom:15px;'>
<thead><tr style='background:#f5f5f5;'>
<th style='padding:8px;border:1px solid #ddd;text-align:left;'>Product</th>
<th style='padding:8px;border:1px solid #ddd;text-align:center;'>Qty</th>
<th style='padding:8px;border:1px solid #ddd;text-align:right;'>Price</th>
<th style='padding:8px;border:1px solid #ddd;text-align:right;'>Total</th>
</tr></thead>
<tbody>$itemsHtml</tbody>
</table>
<p style='margin:15px 0;color:#666;'><strong>Shipping Address:</strong><br>
" . htmlspecialchars($order['customer_name']) . "<br>
<strong>Mobile:</strong> " . htmlspecialchars($order['customer_mobile']) . "<br>
" . htmlspecialchars($order['address']) . "<br>
" . htmlspecialchars($order['city']) . ", " . htmlspecialchars($order['state']) . " - " . htmlspecialchars($order['pincode']) . "</p>
<p style='text-align:center;color:#999;font-size:12px;'>Free delivery within India | GST included</p>
</div>
<div style='background:#f5f5f5;padding:15px;text-align:center;font-size:12px;color:#999;'>&copy; " . date('Y') . " SenseMe India</div>
</div>
</body></html>";

        // Get SMTP config
        $smtpHost = defined('SMTP_HOST') ? SMTP_HOST : 'smtp.hostinger.com';
        $smtpPort = defined('SMTP_PORT') ? SMTP_PORT : 465;
        $smtpSecure = defined('SMTP_SECURE') ? SMTP_SECURE : 'ssl';
        $smtpUser = defined('SMTP_USERNAME') ? SMTP_USERNAME : 'order@sensemeindia.com';
        $smtpPass = defined('SMTP_PASSWORD') ? SMTP_PASSWORD : '';
        $fromEmail = defined('FROM_EMAIL') ? FROM_EMAIL : 'order@sensemeindia.com';
        $fromName = defined('FROM_NAME') ? FROM_NAME : 'SenseMe India';
        $adminEmail = defined('ADMIN_EMAIL') ? ADMIN_EMAIL : 'order@sensemeindia.com';

        $sslOpts = ['ssl' => ['verify_peer' => false, 'verify_peer_name' => false, 'allow_self_signed' => true]];

        // Send to Admin
        if (!empty($adminEmail)) {
            $adminBody = str_replace('Order Confirmed!', 'New Order Received!', $emailBody);
            $adminBody = str_replace('Thank you for your purchase from SenseMe India', 'New order on SenseMe India', $adminBody);
            
            $ma = new PHPMailer();
            $ma->IsSMTP();
            $ma->SMTPAuth = true;
            $ma->SMTPSecure = $smtpSecure;
            $ma->Host = $smtpHost;
            $ma->Port = $smtpPort;
            $ma->Username = $smtpUser;
            $ma->Password = $smtpPass;
            $ma->SMTPOptions = $sslOpts;
            $ma->SetFrom($fromEmail, $fromName);
            $ma->AddAddress($adminEmail, 'SenseMe Admin');
            $ma->Subject = 'Order #' . $order['order_id'] . ' | ₹' . number_format(floatval($order['total_amount']), 2);
            $ma->MsgHTML($adminBody);
            $ma->IsHTML(true);
            if (!$ma->Send()) {
                paymentLog("Admin email FAILED for $orderId: " . $ma->ErrorInfo, 'ERROR');
            } else {
                paymentLog("Admin email sent for $orderId", 'INFO');
            }
        }

        // Send to Customer
        if (!empty($order['customer_email']) && filter_var($order['customer_email'], FILTER_VALIDATE_EMAIL)) {
            $mc = new PHPMailer();
            $mc->IsSMTP();
            $mc->SMTPAuth = true;
            $mc->SMTPSecure = $smtpSecure;
            $mc->Host = $smtpHost;
            $mc->Port = $smtpPort;
            $mc->Username = $smtpUser;
            $mc->Password = $smtpPass;
            $mc->SMTPOptions = $sslOpts;
            $mc->SetFrom($fromEmail, $fromName);
            $mc->AddAddress($order['customer_email'], $order['customer_name']);
            $mc->Subject = 'Order Confirmed #' . $order['order_id'];
            $mc->MsgHTML($emailBody);
            $mc->IsHTML(true);
            if (!$mc->Send()) {
                paymentLog("Customer email FAILED for $orderId: " . $mc->ErrorInfo, 'ERROR');
            } else {
                paymentLog("Customer email sent for $orderId", 'INFO');
            }
        }
        
        paymentLog("Email function complete for order $orderId", 'INFO');
        
    } catch (Exception $e) {
        // Log but never throw - do not break order flow
        paymentLog("Email exception for order $orderId: " . $e->getMessage(), 'ERROR');
    }
}

include "../smadmin/function/config.php";
include "../smadmin/db/db_connect.php";
include "../smadmin/function/function.php";
include "../razorpay_config.php";

// Catch any errors from includes
if (!isset($con) || $con === null) {
    paymentLog('Database connection failed after includes', 'ERROR');
    jsonExit(['status' => 'error', 'message' => 'Database connection error. Please try again.']);
}

if (!defined('RAZORPAY_KEY_SECRET')) {
    paymentLog('RAZORPAY_KEY_SECRET not defined', 'ERROR');
    jsonExit(['status' => 'error', 'message' => 'Configuration error. Please contact support.']);
}

// CSRF validation
if (!isset($_POST['csrf_token']) || !isset($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
    paymentLog('CSRF fail. IP: ' . ($_SERVER['REMOTE_ADDR'] ?? ''), 'WARN');
    jsonExit(['status' => 'error', 'message' => 'Invalid session. Please refresh and try again.']);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonExit(['status' => 'error', 'message' => 'Invalid request method.']);
}

try {

$razorpayOrderId   = isset($_POST['razorpay_order_id'])   ? trim($_POST['razorpay_order_id'])   : '';
$razorpayPaymentId = isset($_POST['razorpay_payment_id']) ? trim($_POST['razorpay_payment_id']) : '';
$razorpaySignature = isset($_POST['razorpay_signature'])  ? trim($_POST['razorpay_signature'])  : '';
$orderId           = isset($_POST['order_id'])            ? trim($_POST['order_id'])            : '';

// Basic validation
if (empty($razorpayOrderId) || empty($razorpayPaymentId) || empty($razorpaySignature) || empty($orderId)) {
    paymentLog("Missing fields. OrderID=$orderId", 'ERROR');
    jsonExit(['status' => 'error', 'message' => 'Missing payment details. Please contact support.']);
}

// ==================== DUPLICATE VERIFICATION GUARD ====================
// If already SUCCESS, return success immediately (prevents false error popup on retry)
$dupCheck = "SELECT payment_status FROM rzp_orders WHERE order_id = ? AND razorpay_order_id = ? LIMIT 1";
if ($dupStmt = $con->prepare($dupCheck)) {
    $dupStmt->bind_param("ss", $orderId, $razorpayOrderId);
    $dupStmt->execute();
    $dupResult = $dupStmt->get_result();
    if ($dupRow = $dupResult->fetch_assoc()) {
        if ($dupRow['payment_status'] === 'SUCCESS') {
            paymentLog("Duplicate verify for $orderId - already SUCCESS", 'WARN');
            unset($_SESSION['cartsingle'], $_SESSION['total'], $_SESSION['totalitems']);
            unset($_SESSION['pending_order_id'], $_SESSION['pending_rzp_order_id']);
            $_SESSION['completed_order_id'] = $orderId;
            jsonExit(['status' => 'success', 'order_id' => $orderId, 'redirect' => 'payment-success.php', 'message' => 'Payment already verified!']);
        }
    } else {
        paymentLog("Order $orderId not found for rzp $razorpayOrderId", 'ERROR');
        jsonExit(['status' => 'error', 'message' => 'Order not found. Contact support. Order ID: ' . htmlspecialchars($orderId)]);
    }
    $dupStmt->close();
} else {
    paymentLog("Dup check prepare failed: " . $con->error, 'ERROR');
    jsonExit(['status' => 'error', 'message' => 'Database error. Please contact support.']);
}

// ==================== VERIFY RAZORPAY SIGNATURE ====================
$generatedSignature = hash_hmac('sha256', $razorpayOrderId . '|' . $razorpayPaymentId, RAZORPAY_KEY_SECRET);

if (!hash_equals($generatedSignature, $razorpaySignature)) {
    paymentLog("Signature mismatch for $orderId. Payment $razorpayPaymentId", 'ERROR');
    $failQuery = "UPDATE rzp_orders SET payment_status = 'FAILED', razorpay_payment_id = ?, razorpay_signature = ?, updated_at = NOW() WHERE order_id = ?";
    if ($failStmt = $con->prepare($failQuery)) {
        $failStmt->bind_param("sss", $razorpayPaymentId, $razorpaySignature, $orderId);
        $failStmt->execute();
        $failStmt->close();
    }
    jsonExit(['status' => 'error', 'message' => 'Payment verification failed. If money was deducted, it will be refunded within 5-7 days. Order ID: ' . $orderId]);
}
paymentLog("Signature OK for $orderId. Payment $razorpayPaymentId", 'INFO');

// ==================== PAYMENT VERIFIED - UPDATE ORDER ====================
$updateQuery = "UPDATE rzp_orders SET razorpay_payment_id = ?, razorpay_signature = ?, payment_status = 'SUCCESS', order_status = 'CONFIRMED', updated_at = NOW() WHERE order_id = ? AND razorpay_order_id = ?";
if ($upStmt = $con->prepare($updateQuery)) {
    $upStmt->bind_param("ssss", $razorpayPaymentId, $razorpaySignature, $orderId, $razorpayOrderId);
    if (!$upStmt->execute()) {
        paymentLog("Order update failed $orderId: " . $con->error, 'ERROR');
        jsonExit(['status' => 'error', 'message' => 'Order update failed. Payment received. Contact support. Order ID: ' . $orderId]);
    }
    $upStmt->close();
} else {
    paymentLog("Update prepare failed: " . $con->error, 'ERROR');
    jsonExit(['status' => 'error', 'message' => 'Database error. Payment received. Contact support. Order ID: ' . $orderId]);
}
paymentLog("Order $orderId updated to SUCCESS", 'INFO');

// ==================== SAVE ORDER ITEMS ====================
// Check for existing items to prevent duplicates
$existingItems = 0;
if ($cStmt = $con->prepare("SELECT COUNT(*) as cnt FROM rzp_order_items WHERE order_id = ?")) {
    $cStmt->bind_param("s", $orderId); $cStmt->execute();
    $cRow = $cStmt->get_result()->fetch_assoc();
    $existingItems = (int)$cRow['cnt'];
    $cStmt->close();
}
if (isset($_SESSION['cartsingle']) && count($_SESSION['cartsingle']) != 0 && $existingItems === 0) {
    foreach ($_SESSION['cartsingle'] as $pid => $qty) {
        // Fetch product details
        $pQuery = "SELECT t1.*, t2.name, t6.name as psize FROM bb_products_stock as t1 INNER JOIN bb_products as t2 ON t1.parent_id = t2.id INNER JOIN bb_sizes as t6 ON t1.size = t6.id WHERE t1.id = ?";
        if ($pStmt = $con->prepare($pQuery)) {
            $pStmt->bind_param('i', $pid);
            $pStmt->execute();
            $pResult = $pStmt->get_result();
            if ($pData = $pResult->fetch_assoc()) {
                $itemPrice = $pData['price'];
                $itemTotal = $qty * $itemPrice;
                $productName = $pData['name'];
                $productSize = $pData['psize'];
                $productSku  = $pData['sku'];

                $itemQuery = "INSERT INTO rzp_order_items (order_id, product_id, product_name, product_size, sku, quantity, price, total) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                if ($iStmt = $con->prepare($itemQuery)) {
                    $iStmt->bind_param("sisssidd", $orderId, $pid, $productName, $productSize, $productSku, $qty, $itemPrice, $itemTotal);
                    $iStmt->execute();
                    $iStmt->close();
                }
            }
            $pStmt->close();
        }
    }
}

// ==================== SEND EMAIL NOTIFICATIONS ====================
// Fetch order details for email
$orderQuery = "SELECT * FROM rzp_orders WHERE order_id = ? LIMIT 1";
$orderData = null;
if ($oStmt = $con->prepare($orderQuery)) {
    $oStmt->bind_param("s", $orderId);
    $oStmt->execute();
    $oResult = $oStmt->get_result();
    $orderData = $oResult->fetch_assoc();
    $oStmt->close();
}

// Fetch order items
$itemsQuery = "SELECT * FROM rzp_order_items WHERE order_id = ?";
$orderItems = [];
if ($iStmt = $con->prepare($itemsQuery)) {
    $iStmt->bind_param("s", $orderId);
    $iStmt->execute();
    $iResult = $iStmt->get_result();
    while ($row = $iResult->fetch_assoc()) {
        $orderItems[] = $row;
    }
    $iStmt->close();
}

if ($orderData) {
    // Try to send emails but do NOT fail the order if email fails
    try {
        sendOrderEmails($orderData, $orderItems);
        paymentLog("Emails sent for $orderId", 'INFO');
    } catch (Exception $e) {
        paymentLog("Email error for $orderId: " . $e->getMessage(), 'ERROR');
    }
}

// ==================== CLEAR CART & SESSION DATA ====================
unset($_SESSION['cartsingle'], $_SESSION['total'], $_SESSION['totalitems']);
unset($_SESSION['pending_order_id'], $_SESSION['pending_rzp_order_id']);
unset($_SESSION['otp_verified']);

$_SESSION['completed_order_id'] = $orderId;

paymentLog("Flow complete for $orderId - returning success", 'INFO');
jsonExit([
    'status'   => 'success',
    'order_id' => $orderId,
    'redirect' => 'payment-success.php',
    'message'  => 'Payment successful! Order confirmed. Check your email for confirmation.'
]);

} catch (Exception $e) {
    paymentLog("Uncaught exception: " . $e->getMessage(), 'ERROR');
    jsonExit(['status' => 'error', 'message' => 'An error occurred. Please contact support.']);
}
?>


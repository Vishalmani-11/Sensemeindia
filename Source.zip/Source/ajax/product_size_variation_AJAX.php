<?php
include "../bbadmin/function/config.php"; 
include "../bbadmin/db/db_connect.php"; 
include "../bbadmin/function/function.php";

if(isset($_POST['product_size'])&&$_POST['product_size']!="")
{
$product_id = secure_input($con,$_POST['product_color']);
    
$active = 1;
    
$fupquery = "SELECT t1.*, t2.name as color FROM bb_products_stock as t1 INNER JOIN bb_colors as t2 ON t1.color = t2.id WHERE t1.id = '".$product_id."' AND t1.active = '".$active."'";
	
      if(!$result = mysqli_query($con, $fupquery))
      {
          echo "query failed: (" . $con->errno . ") " . $con->error; exit();
      }
      if(!$row = mysqli_fetch_array($result))
      {
          echo "query failed: (" . $con->errno . ") " . $con->error; exit();
      }
    
      echo json_encode($row);
    
    
}
else
{
    echo "fail"; exit();
}
?>

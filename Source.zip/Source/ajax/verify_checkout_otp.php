<?php
/**
 * AJAX Endpoint: Verify OTP
 * POST: otp, mobile_number, csrf_token
 */
session_start();
header('Content-Type: application/json');

include "../smadmin/function/config.php";
include "../smadmin/db/db_connect.php";
include "../smadmin/function/function.php";
include "../razorpay_config.php";

// CSRF validation
if (!isset($_POST['csrf_token']) || !isset($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid session. Please refresh the page.']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method.']);
    exit();
}

$otp    = isset($_POST['otp']) ? trim($_POST['otp']) : '';
$mobile = isset($_POST['mobile_number']) ? trim($_POST['mobile_number']) : '';

// Basic validation
if (!preg_match('/^[0-9]{4}$/', $otp)) {
    echo json_encode(['status' => 'error', 'message' => 'Please enter a valid 4-digit OTP.']);
    exit();
}
if (!preg_match('/^[0-9]{10}$/', $mobile)) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid mobile number.']);
    exit();
}

// Check session OTP exists
if (!isset($_SESSION['checkout_otp']) || !isset($_SESSION['checkout_mobile']) || !isset($_SESSION['checkout_otp_time'])) {
    echo json_encode(['status' => 'error', 'message' => 'OTP session expired. Please request a new OTP.']);
    exit();
}

// Verify mobile number matches
if ($_SESSION['checkout_mobile'] !== $mobile) {
    echo json_encode(['status' => 'error', 'message' => 'Mobile number mismatch. Please go back and try again.']);
    exit();
}

// Check OTP expiry
$otpAge = time() - $_SESSION['checkout_otp_time'];
if ($otpAge > (OTP_EXPIRY_MINUTES * 60)) {
    unset($_SESSION['checkout_otp'], $_SESSION['checkout_otp_time']);
    echo json_encode(['status' => 'error', 'message' => 'OTP has expired. Please request a new one.']);
    exit();
}

// Check max attempts from DB
$attemptsQuery = "SELECT id, attempts FROM rzp_otp_log WHERE mobile = ? AND verified = 0 ORDER BY id DESC LIMIT 1";
if ($attStmt = $con->prepare($attemptsQuery)) {
    $attStmt->bind_param("s", $mobile);
    $attStmt->execute();
    $attResult = $attStmt->get_result();
    if ($attRow = $attResult->fetch_assoc()) {
        if ($attRow['attempts'] >= OTP_MAX_ATTEMPTS) {
            echo json_encode(['status' => 'error', 'message' => 'Too many attempts. Please request a new OTP.']);
            $attStmt->close();
            exit();
        }
        // Increment attempt count
        $updateAttempts = "UPDATE rzp_otp_log SET attempts = attempts + 1 WHERE id = ?";
        if ($upStmt = $con->prepare($updateAttempts)) {
            $upStmt->bind_param("i", $attRow['id']);
            $upStmt->execute();
            $upStmt->close();
        }
    }
    $attStmt->close();
}

// Verify OTP
if ((string)$_SESSION['checkout_otp'] === (string)$otp) {
    // OTP verified successfully
    $_SESSION['otp_verified'] = true;
    $_SESSION['mobile_number'] = $mobile;

    // Mark OTP as verified in DB
    $verifyQuery = "UPDATE rzp_otp_log SET verified = 1 WHERE mobile = ? AND otp = ? ORDER BY id DESC LIMIT 1";
    if ($vStmt = $con->prepare($verifyQuery)) {
        $vStmt->bind_param("ss", $mobile, $otp);
        $vStmt->execute();
        $vStmt->close();
    }

    // Clear OTP from session (one-time use)
    unset($_SESSION['checkout_otp'], $_SESSION['checkout_otp_time']);

    echo json_encode([
        'status'  => 'success',
        'message' => 'Mobile number verified successfully!'
    ]);
} else {
    echo json_encode([
        'status'  => 'error',
        'message' => 'Invalid OTP. Please check and try again.'
    ]);
}
?>

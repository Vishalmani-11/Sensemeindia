<?php session_start();
include "smadmin/function/config.php"; 
include "smadmin/db/db_connect.php"; 
include "smadmin/function/function.php"; 
require_once 'smadmin/admin/class.user_2.php';

///////////////////////////////////////////////////////////////////////////////////////////////////////////
if(!isset($_SESSION['cartsingle'])||count($_SESSION['cartsingle'])==0)
	{ 
    header("location:index.php"); exit();
}
/*
$userlogin = new USER();
if($userlogin->is_logged_in())
{
     header("location:checkout_process?vphone=".$_SESSION[ 'mobile_number' ]); exit();
} */
?>
<!doctype html>
<html class="no-js" lang="en">
   <head>
     <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-WWCJ4NT');</script>
<!-- End Google Tag Manager -->
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Checkout Cart | SenseMe India</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Favicon -->
        <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.png">

        <!-- All css here -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/css/font-awesome.min.css">
        <link rel="stylesheet" href="assets/css/ie7.css">
        <link rel="stylesheet" href="assets/css/plugins.css">
        <link rel="stylesheet" href="assets/css/style.css">
       <link rel="stylesheet" href="assets/css/menu/style.css">  
       <link rel="stylesheet" href="otp/style.css">
       <script src="assets/js/vendor/modernizr-3.5.0.min.js"></script>
       <script src="assets/js/vendor/jquery-3.2.1.min.js"></script> 
       <script src="assets/css/menu/script.js"></script>
<!-- Meta Pixel Code -->
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '6089330044459882');
  fbq('track', 'PageView');
  fbq('track', 'ViewContent');
  fbq('track', 'Search');
  fbq('track', 'AddToCart');
  fbq('track', 'InitiateCheckout');
  fbq('track', 'AddPaymentInfo');
  fbq('track', 'Purchase');
  fbq('track', 'CompleteRegistration');
  fbq('track', 'Contact');
  fbq('track', 'FindLocation');
  fbq('track', 'Lead');
  fbq('track', 'SubmitApplication');
</script>
<noscript><img height="1" width="1" style="display:none"
  src="https://www.facebook.com/tr?id=6089330044459882&ev=PageView&noscript=1"
/></noscript>
<!-- End Meta Pixel Code -->
	   
	  <script>
	 
	 
	 $(document).ready(function() {
  $(window).keydown(function(event){
    if(event.keyCode == 13) {
      event.preventDefault();
      return false;
    }
  });
});
       $( document ).ready(function() {
///////////////////////////////////////////
                // Get the input field
var input = document.getElementById("mobile");

// Execute a function when the user releases a key on the keyboard
input.addEventListener("keyup", function(event) {
  // Number 13 is the "Enter" key on the keyboard
  if (event.keyCode === 13) {
    // Cancel the default action, if needed
    //  alert("enter");
    //event.preventDefault();
      //alert("before");
    // Trigger the button element with a click
    sendOTP();
	  return false;
      //document.getElementById("login_otp").click();
  }
});
            
});

            </script>
	   
    </head>

<body>        
	<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-WWCJ4NT"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
         <?php include("sm_header_otp.php"); ?>
        <div class="checkout-area pb-90 pt-110 mt-50">
            <div class="container">
                    <div class="row">
                        <div class="col-lg-6 col-md-12 col-sm-12 offset-3">
                                <div class="OTP_container">
                            <div class="checkbox-form">
                                
                                <div class="error"></div>
               
		<form id="frm-mobile-verification" class="mb-10" action="">
			<div class="form-heading"><h3 class="font20">Please Verify your Mobile No</h3></div>

			<div class="form-row">
				+91<input type="text" pattern="[0-9]{10}" id="mobile" class="form-input"
					placeholder="Enter your 10 digit mobile No (No spaces allowed)" autocomplete="off" required oninvalid="this.setCustomValidity('Enter 10 Digits Numeric only. No spaces allowed.')" oninput="this.setCustomValidity('')">
			</div>

			<a class="btnSubmit font15" onClick="sendOTP();">Send OTP</a><br>

		</form>
                                  
                               
                                </div> </div>
                        </div>	
                    </div>
             
                
            </div>
        </div>
        
        <?php include("sm_footer_otp.php"); ?>        
              <script src="assets/js/popper.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/plugins.js"></script>
        <script src="assets/js/main.js"></script>    
    <script src="otp/verification.js"></script>
    </body>
</html>
<?php  
require_once 'admin/class.user.php';
session_start();
$admin_login = new USER();
$admin_login->logout();
header('Location: index.php?lout');
?>
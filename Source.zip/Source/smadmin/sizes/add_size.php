<?php
include "../function/config.php"; 
include "../db/db_connect.php"; 
include "../db/session.php";  
include "../function/function.php";  

////////////////////////save/////////////////////////
if(isset($_POST['submit']))
{
extract($_POST);	
$size = secure_input($con,$size);
 
////////////////////////////////////parent product///////////////////////////////////	
    

if(!$stmt = $con->prepare("INSERT INTO bb_sizes (name) VALUES (?)"))
{
	echo "Prepare failed: (" . $con->errno . ") " . $con->error;
}

if(!$stmt->bind_param("s", $size))
{
	echo "Param pass failed: (" . $con->errno . ") " . $con->error;
}

if(!$stmt->execute()) {
    
	$error = "New size saving failed!".$con->error; exit();   
    
}
else
{
$success= "New size saved successfully!";
	header("location:add_size.php?success=".$success);
	exit();
    
}

}



//////////////////////////size////////////////////////////////////////

$active = 1;

$squery = "SELECT id, name FROM bb_sizes  WHERE active = ? ORDER BY id";

if(!$sstmt = $con->prepare($squery))
{
	echo "prepare failed: (" . $con->errno . ") " . $con->error;	
}

if(!$sstmt->bind_param("i", $active))
{
	echo "Param pass failed: (" . $con->errno . ") " . $con->error;
}

	if(!$sstmt->execute())
	{
		$error = "size list failed!".$con->error;		
		
	}

		if(!$sstmt->store_result())
		{
			$error = "categories list failed!".$con->error;					
		}
	
		$snum_of_rows = $sstmt->num_rows;

if($snum_of_rows==0)
{
	$serror = "No sizes found";		
}
//////////////////////////colors////////////////////////////////////////

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title><?php echo $_SESSION['cName']; ?> Admin Area</title>
    <?php include("../header.php"); ?>

</head>
<body>
<div id="loading" class="ui-front loader ui-widget-overlay bg-white opacity-100"> <img src="<?php echo $_SESSION['gpath'] ?>assets/images/loader-dark.gif" alt=""> </div>
<div id="page-wrapper" class="demo-example"> 
  <!-- #page-header -->
  
  <?php include("../sidebar.php"); ?>
  <!-- #page-sidebar -->
  <div id="menu-right" class="scrollable-content hidden">
    <div class="toggle-content-open clearfix">
      <div id="g10" class="small-gauge float-left"></div>
      <div id="g11" class="small-gauge float-right"></div>
    </div>
  </div>
  <div id="page-content-wrapper">
            
                <div id="page-title">

<h3>
    <strong>Add new size</strong> 
</h3>

</div><!-- #page-title -->

            
<div id="page-content">
<h3><strong>Details:</strong></h3>
<div class="example-box">
<?php 
			   if(isset($error)){ ?>
             
             <div class="infobox error-bg">
<a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>             
<div class="bg-red large btn info-icon">
                        <i class="glyph-icon icon-remove"></i>
                    </div>
                    <h4 class="infobox-title"><?php echo $error;?></h4>
                    <p>Some error in the database query occured. Please try again!</p>
                </div>
           <?php } ?>
    
    <?php 
			   if(isset($_GET['error'])){ ?>
             
             <div class="infobox error-bg">
<a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>             
<div class="bg-red large btn info-icon">
                        <i class="glyph-icon icon-remove"></i>
                    </div>
                    <h4 class="infobox-title"><?php echo $_GET['error'];?></h4>
                    <p>Some error in the database query occured. Please try again!</p>
                </div>
           <?php } ?>
    
            
<?php 
			   if(isset($success)){ ?>
             
             <div class="infobox success-bg">
<a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>             
                    <h4 class="infobox-title"><?php echo $success;?></h4>
                </div><?php } ?>
    
    <?php 
			   if(isset($_GET['success'])){ ?>
             
             <div class="infobox success-bg">
<a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>             
                    <h4 class="infobox-title"><?php echo $_GET['success'];?></h4>
                </div><?php } ?>
     
    <div class="example-code">
<br>
<br>

        <form id="demo-form-2" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" class="col-md-10 center-margin" method="post">
          
			<div class="form-row">
              <div class="form-label col-md-3">
                <label for="">Already added sizes:</label>
              </div>
              <div class="form-input col-md-9">
                <select data-placeholder="Already added sizes" name="size" id="size" class="chosen-select parsley-validated" data-trigger="change">
      
      <?php      
			if(isset($serror))
			{
				?>
			     <option value=""><?php echo $serror; ?></option>	
			<?php 
						} 
						else
						{
			?>
                 <option value="">Already added sizes</option>	
                 <?php } ?>
                 
                  <?php 
	$sstmt->bind_result($id, $scname);
	while ($sstmt->fetch()) 
	{
			
	?>            
                  <option value="<?php echo $id; ?>"><?php echo $scname; ?></option>
                  
       <?php } 
		?>            
        
                </select>
              </div>
              
            </div>
			
			 <div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                      Add new size:(ex: 250ml)
                         <span class="required">*</span>
                    </label>
                </div>
                <div class="form-input col-md-9">
                    <input  type="text" id="size" name="size" data-trigger="change" parsley-rangelength="[1,15]" pattern="^[A-Za-z0-9 ]*$" data-required="true" class="parsley-validated" > 
                </div>
            </div>
			
       		<div class="divider"></div>
            <div class="form-row">
                <input type="hidden" name="superhidden" id="superhidden">
                <div class="form-input col-md-10 col-md-offset-3">
               <button type="submit" name="submit"  class="btn large primary-bg" onclick="javascript:$(&apos;#demo-form-2&apos;).parsley( &apos;validate&apos; );"><span class="button-content">Save Data</span></button>
&nbsp;
                        <a href="#" class="btn large bg-red" title="" onclick="goBack()">
            <span class="button-content">Cancel</span>
        </a>

                </div>
            </div>

        </form>

    </div>
    
</div>
</div>
<!-- #page-content -->
</div>
<!-- #page-main -->
</div>
<!-- #page-wrapper -->

</body>
</html>

<?php
include "../db/session.php";  
//include "../function/config.php"; 
include "../db/db_connect.php"; 
include "../function/function.php";

////////////////////////update/////////////////////////
if(isset($_POST['submit']))
{
extract($_POST);	

$order_id = secure_input($con,$id);    
$customer_phone = secure_input($con,$contact);
$customer_email = secure_input($con,$email);
$cname = secure_input($con,$cname);	
$sremarks = secure_input($con,$sremarks);	
$ostatus = secure_input($con,$ostatus);
$estatus = secure_input($con,$estatus);	
$courier = secure_input($con,$courier);	
$ccode = secure_input($con,$ccode);	    
	
	if($ostatus=="")
	{
		$ostatus = $estatus;
	}
	
	if($esdate=="")
	{
		$esdate = NULL;
	}
	
	if($sdate=="")
	{
		$sdate = $esdate;
	}
	else
	{
$sdate = secure_input($con,$sdate);
$sdate = date('Y-m-d', strtotime($sdate)); 	
	}
	
	if($eddate=="")
	{
		$eddate = NULL;
	}
	
	if($ddate=="")
	{
		$ddate = $eddate;
	}
	else
	{
$ddate = secure_input($con,$ddate);
$ddate = date('Y-m-d', strtotime($ddate)); 	
	}
	
$query = "UPDATE bb_orders SET orderstatus=?, sremarks=?, courier=?, ccode=?, sdate=?, ddate=? WHERE id = ?";

	
	if(!$ustmt = $con->prepare($query))
{
	echo $error = "order update preparation failed!".$con->error; exit();
}
	if(!$ustmt->bind_param("ssssssi", $ostatus, $sremarks, $courier, $ccode, $sdate, $ddate, $order_id))
{
	echo "Param pass failed: (" . $con->errno . ") " . $con->error;exit();
}
	
	if(!$ustmt->execute())
	{
		echo $error = "order update execution failed!".$con->error;		exit();
		
	}
	else
	{
		
		
//////////////////////////////////////////////mail////////////////////////////////////////////////////////////////////////////////

if($ostatus!=""&&$ostatus!=$estatus)	
{
    
	$mquery = "SELECT id, orderid, pid, name, qty, price, cost FROM bb_order_products WHERE orderid =?";

	
if(!$mrstmt = $con->prepare($mquery))
{
	echo $error = "order details preparation failed!".$con->error;exit();
}
	if(!$mrstmt->bind_param("i", $order_id))
{
	echo "Param pass failed: (" . $con->errno . ") " . $con->error;exit();
}
	
	if(!$mrstmt->execute())
	{
		echo $error = "order details execution failed!".$con->error;	 exit();	
		
	}
	
	if(!$mrstmt->store_result())
		{
			echo $error = "order listing execution failed!".$con->error; exit();					
		}
	
	
	$mrnum_of_rows = $mrstmt->num_rows;

	if($mrnum_of_rows==0)
{
        
	echo $error = "No order products available";	exit();	
}	
	$pmessage = $message = "";
	$GST = 0;
	$totalcost = 0;		
	$sn = 0;
	$mrstmt->bind_result($id, $orderid, $pid, $name, $qty, $price, $cost);
	while ($mrstmt->fetch()) 
	{
                
        $sn = 	$sn + 1;
		$name = ucwords($name);
		
	

		
		$pmessage .= "<tr>
                                      <td align='left'><div class='contentEditableContainer contentTextEditable'>
                                          <div class='contentEditable' align='center'>
                                            <p > <span style='color:#222222;'>".$name."</span> </p>
                                          </div>
                                        </div></td>
                                      <td align='left'><div class='contentEditableContainer contentTextEditable'>
                                          <div class='contentEditable' align='center'>
                                            <p > <span style='color:#222222;'>".$qty."</span> </p>
                                          </div>
                                        </div></td>
                                    </tr>";
	
		$totalcost = $totalcost + $cost; 
		  }
		//$GST = ($totalcost*15)/100;
		//$totalcost = $totalcost + $GST; 
    $totalcost = $totalcost; 
		
  
///////////////////////////////mail/////////////////////////////////////////////////////
	$message = "";
	$message = "<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>
<html xmlns='http://www.w3.org/1999/xhtml'>
<head>
<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
<title>Your order #SM".$order_id." is ".$ostatus."!</title>
<style type='text/css'>
body {
	padding-top: 0 !important;
	padding-bottom: 0 !important;
	padding-top: 0 !important;
	padding-bottom: 0 !important;
	margin: 0 !important;
	width: 100% !important;
	-webkit-text-size-adjust: 100% !important;
	-ms-text-size-adjust: 100% !important;
	-webkit-font-smoothing: antialiased !important;
}
.tableContent img {
	border: 0 !important;
	display: block !important;
	outline: none !important;
}
a {
	color: #382F2E;
}
p, h1 {
	color: #382F2E;
	margin: 0;
}
p {
	text-align: left;
	color: #999999;
	font-size: 14px;
	font-weight: normal;
	line-height: 19px;
}
a.link1 {
	color: #382F2E;
}
a.link2 {
	font-size: 16px;
	text-decoration: none;
	color: #ffffff;
}
h2 {
	text-align: left;
	color: #222222;
	font-size: 19px;
	font-weight: normal;
}
div, p, ul, h1 {
	margin: 0;
}
.bgBody {
	background: #ffffff;
}
.bgItem {
	background: #ffffff;
}

@media only screen and (max-width:480px) {
table[class='MainContainer'], td[class='cell'] {
	width: 100% !important;
	height: auto !important;
}
td[class='specbundle'] {
	width: 100% !important;
	float: left !important;
	font-size: 13px !important;
	line-height: 17px !important;
	display: block !important;
	padding-bottom: 15px !important;
}
td[class='spechide'] {
	display: none !important;
}
img[class='banner'] {
	width: 100% !important;
	height: auto !important;
}
td[class='left_pad'] {
	padding-left: 15px !important;
	padding-right: 15px !important;
}
}

@media only screen and (max-width:540px) {
table[class='MainContainer'], td[class='cell'] {
	width: 100% !important;
	height: auto !important;
}
td[class='specbundle'] {
	width: 100% !important;
	float: left !important;
	font-size: 13px !important;
	line-height: 17px !important;
	display: block !important;
	padding-bottom: 15px !important;
}
td[class='spechide'] {
	display: none !important;
}
img[class='banner'] {
	width: 100% !important;
	height: auto !important;
}
.font {
	font-size: 18px !important;
	line-height: 22px !important;
}
.font1 {
	font-size: 18px !important;
	line-height: 22px !important;
}
}
</style>

</head>
<body paddingwidth='0' paddingheight='0'   style='padding-top: 0; padding-bottom: 0; padding-top: 0; padding-bottom: 0; background-repeat: repeat; width: 100% !important; -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; -webkit-font-smoothing: antialiased;' offset='0' toppadding='0' leftpadding='0'>
<table bgcolor='#ffffff' width='100%' border='0' cellspacing='0' cellpadding='0' class='tableContent' align='center'  style='font-family:Helvetica, Arial,serif;'>
  <tbody>
    <tr>
      <td><table width='600' border='0' cellspacing='0' cellpadding='0' align='center' bgcolor='#ffffff' class='MainContainer'>
          <tbody>
            <tr>
              <td><table width='100%' border='0' cellspacing='0' cellpadding='0'>
                  <tbody>
                    <tr>
                      <td valign='top' width='40'>&nbsp;</td>
                      <td><table width='100%' border='0' cellspacing='0' cellpadding='0'>
                          <tbody>
                            <!-- =============================== Header ====================================== -->
                            <tr>
                              <td height='30' class='spechide'></td>
                              
                              <!-- =============================== Body ====================================== --> 
                            </tr>
                            <tr>
                              <td class='movableContentContainer ' valign='top'><div class='movableContent' style='border: 0px; padding-top: 0px; position: relative;'>
                                  <table width='100%' border='0' cellspacing='0' cellpadding='0'>
                                    <tbody>
                                      <tr>
                                        <td height='35'></td>
                                      </tr>
                                      <tr>
                                        <td><table width='100%' border='0' cellspacing='0' cellpadding='0'>
                                            <tbody>
                                              <tr>
                                                <td valign='top' align='center' style='text-align:center;' class='specbundle'><div class='contentEditableContainer contentTextEditable'>
                                                    <div class='contentEditable'>
                                                      <p><img src='http://sensemeindia.com/assets/img/logo/logo.png' alt='Visit SenseMe India'/> </p>
                                                    </div>
                                                  </div></td>
                                              </tr>
                                              <tr>
                                                <td height='35'></td>
                                              </tr>
                                              <tr>
                                                <td valign='top' class='specbundle'><div class='contentEditableContainer contentTextEditable'>
                                                    <div class='contentEditable'>
                                                      <p style='text-align:left;margin:0;font-family:Georgia,Time,sans-serif;font-size:26px;color:#222222;'><span class='specbundle2'><span class='font1'>Dear ".$cname.", your order #SM".$order_id." is ".$ostatus."!&nbsp;</span></p>
                                                    </div>
                                                  </div></td>
                                              </tr>
                                            </tbody>
                                          </table></td>
                                      </tr>
                                    </tbody>
                                  </table>
                                </div>
                                <div class='movableContent' style='border: 0px; padding-top: 0px; position: relative;'>
                                  <table width='100%' border='0' cellspacing='0' cellpadding='0' align='center'>
                                    <tr>
                                      <td height='25'></td>
                                    </tr>
                                    <tr>
                                      <td align='left'><div class='contentEditableContainer contentTextEditable'>
                                          <div class='contentEditable' align='left'>
                                           <h2>Greetings from SenseMe India!</h2>
                                          </div>
                                        </div></td>
                                    </tr>
                                    <tr>
                                      <td align='left'><div class='contentEditableContainer contentTextEditable'>
                                          <div class='contentEditable' align='left'>
                                            <p >";
	
	if($ostatus=='Shipped')
	{
		$message .= "We would like to inform you that We have shipped your order item(s) to your address! Please find your order items(s) details as below. <br />
                                              <br />";
	}
	elseif($ostatus=='Delivered')
	{
	$message .= "We would like to inform you that We have delivered your order item(s) to your address! Please find your order items(s) details as below. <br />
                                              <br />";
	}
		
	if($sdate!="")
	{
	 	$message .= "<strong>Shipped Date: </strong> ".date('l - dS M, Y', strtotime($sdate))."<br>
";
	}
	elseif($esdate!="")
	{
			$message .= "<strong>Shipped Date: </strong> ".date('l - dS M, Y', strtotime($esdate))."<br>
";
		
	}
	
	if($ostatus=="Delivered"&&$ddate!="")
	   {
	$message .= "<strong>Delivered Date: </strong> ".date('l - dS M, Y', strtotime($ddate))."<br>";	   
	   }
	elseif($ostatus=="Delivered"&&$eddate!="")
	{
		$message .= "<strong>Delivered Date: </strong> ".date('l - dS M, Y', strtotime($eddate))."<br>";	   
	}
	
	
		if($courier!="")
	{
	 	$message .= "<strong>Courier name: </strong> ".$courier."<br>";
	}
	
    if($ccode!="")
	{
	 	$message .= "<strong>Courier Tracking: </strong> <a href='".$ccode."' target='_blank'>Track status</a><br>";
	}
	
    
		$message .= "
											  <br><br>

                                              For any queries kindly e-mail us to: order@sensemeindia.com <br />
                                              <br />
                                              Thank you for your order. </p>
                                          </div>
                                        </div></td>
                                    </tr>
                                    <tr>
                                      <td height='15'></td>
                                    </tr>
                                    <tr>
                                      <td align='left'><div class='contentEditableContainer contentTextEditable'>
                                          <div class='contentEditable' align='left'>
                                            <h2>Order detail</h2>
                                          </div>
                                        </div></td>
                                    </tr>
                                    <tr>
                                      <td  style='border-bottom:1px solid #DDDDDD;'></td>
                                    </tr>
                                    <tr>
                                      <td height='15'></td>
                                    </tr>
                                  </table>
                                  <table width='100%' border='0' cellspacing='0' cellpadding='0' align='center'>
                                    <tr>
                                      <td align='left'><div class='contentEditableContainer contentTextEditable'>
                                          <div class='contentEditable' align='left'>
                                            <h2 >Item(s) detail</h2>
                                          </div>
                                        </div></td>
                                    </tr>
                                    <tr>
                                      <td  style='border-bottom:1px solid #DDDDDD;'></td>
                                      <td  style='border-bottom:1px solid #DDDDDD;'></td>
                                   
                                    </tr>
                                   
								   <tr>
                                      <td align='left'><div class='contentEditableContainer contentTextEditable'>
                                          <div class='contentEditable' align='center'>
                                            <h2 > Product </h2>
                                          </div>
                                        </div></td>
                                      <td align='left'><div class='contentEditableContainer contentTextEditable'>
                                          <div class='contentEditable' align='left'>
                                            <h2 > QTY </h2>
                                          </div>
                                        </div></td>
                                    
                                    </tr>";
									
                               $message .= $pmessage;   

								$message .= "<tr>
                                      <td height='55'></td>
                                    </tr>
                                    <tr>
                                      <td align='left'><div class='contentEditableContainer contentTextEditable'>
                                          <div class='contentEditable' align='center'> </div>
                                        </div></td>
                                      <td align='left'><div class='contentEditableContainer contentTextEditable'>
                                          <div class='contentEditable' align='center'> </div>
                                        </div></td>
                                    </tr>
                                    <tr>
                                      <td height='15'></td>
                                    </tr>
                                    <tr>
                                      <td  style='border-bottom:1px solid #DDDDDD;'></td>
                                      <td  style='border-bottom:1px solid #DDDDDD;'></td>
                            
                                    </tr>
                                    <tr>
                                      <td align='left'><div class='contentEditableContainer contentTextEditable'>
                                          <div class='contentEditable' align='center'> </div>
                                        </div></td>
                                      <td align='left'><div class='contentEditableContainer contentTextEditable'>
                                          <div class='contentEditable' align='center'> </div>
                                        </div></td>
                                    </tr>
                                    <tr>
                                      <td  style='border-bottom:1px solid #DDDDDD;'></td>
                                      <td  style='border-bottom:1px solid #DDDDDD;'></td>
                                    </tr>
                                  </table>
                                </div>
                                <table width='100%' border='0' cellspacing='0' cellpadding='0'>
                                  <tbody>
                                    <tr>
                                      <td height='25'></td>
                                    </tr>
                                    <tr>
                                      <td><table width='100%' border='0' cellspacing='0' cellpadding='0'>
                                          <tbody>
                                            <tr>
                                              <td valign='top' class='specbundle'><div class='contentEditableContainer contentTextEditable'>
                                                  <div class='contentEditable' align='center'>
                                                    <p  style='text-align:left;color:#CCCCCC;font-size:12px;font-weight:normal;line-height:20px;'> <span style='font-weight:bold;'>order@sensemeindia.com</span> <br>
                                                      <a target='_blank' href='https://sensemeindia.com'>www.sensemeindia.com</a><br>
                                                    </p>
                                                  </div>
                                                </div></td>
                                              <td valign='top' width='30' class='specbundle'>&nbsp;</td>
                                              <td valign='top' class='specbundle'><table width='100%' border='0' cellspacing='0' cellpadding='0'>
                                                  <tbody>
                                                    <tr>
                                                      <td valign='top' width='52'><div class='contentEditableContainer contentFacebookEditable'>
                                                          <div class='contentEditable'> </div>
                                                        </div></td>
                                                      <td valign='top' width='16'>&nbsp;</td>
                                                      <td valign='top' width='52'></td>
                                                    </tr>
                                                  </tbody>
                                                </table></td>
                                            </tr>
                                          </tbody>
                                        </table></td>
                                    </tr>
                                    <tr>
                                      <td height='88'></td>
                                    </tr>
                                  </tbody>
                                </table>
                                </div>
                                
                                </td>
                            </tr>
                          </tbody>
                        </table></td>
                      <td valign='top' width='40'>&nbsp;</td>
                    </tr>
                  </tbody>
                </table></td>
            </tr>
          </tbody>
        </table></td>
    </tr>
  </tbody>
</table>
</body>
</html>
";		
$from = "order@sensemeindia.com";
$to = $customer_email;
	$subject = "Your order #SM".$order_id." is ".$ostatus."!";	
    
    
    if(!$mail_update = send_html_mail($from,$to,$message,$subject))
    {
        echo $mail_update."error sending mail"; exit();
    }
    
     ///////////////////////////////SMS notification////////////////////////////////////////////   

$sms_message = "Greetings from SenseMe India! Your order #SM".$order_id." at sensemeindia.com is ".$ostatus."!. Contact 9150870543 for any help. Thank you.";                                    
list($header, $content) = PostRequest($customer_phone, $sms_message);
 	
}
//////////////////////////////////////////////////////////////////////////////
	    $success = "Order details successfully updated."; 
		header("location:update_order.php?success=".$success."&id=".$order_id); exit();
	}
    
}
	
//////////////////////////order details/////////////////////////////

if(isset($_GET['id']))
{ 
extract($_GET); 
$query = "SELECT t1.*, t2.email, t2.phone FROM bb_orders as t1 INNER JOIN bb_users as t2 ON t1.cid = t2.id WHERE t1.id = ? ORDER BY orderdate DESC";

if(!$rstmt = $con->prepare($query))
{
	echo $error = "order details preparation failed!".$con->error;
}
	if(!$rstmt->bind_param("i", $id))
{
	echo "Param pass failed: (" . $con->errno . ") " . $con->error;
}
	
	if(!$rstmt->execute())
	{
		echo $error = "order details execution failed!".$con->error;		
		
	}    
    
    if(!$qresult = $rstmt->get_result())
		{
			$error = "Product data listing failed!".$con->error;					
		}
    else
    {
        $data = $qresult->fetch_assoc();
    }
    
}

/////////////////////////////product details//////////////////////////////////////////

if(isset($_GET['id']))
{ 
extract($_GET); 

$id = secure_input($con,$id);	    
$status = secure_input($con,$status);	        
$oquery = "SELECT id, orderid, pid, sku, name, category, sub_category, product_type, picture, color, size, qty, price, cost FROM bb_order_products WHERE orderid = ?";

	
if(!$orstmt = $con->prepare($oquery))
{
	echo $error = "order details preparation failed!".$con->error;
}
	if(!$orstmt->bind_param("i", $id))
{
	echo "Param pass failed: (" . $con->errno . ") " . $con->error;
}
	
	if(!$orstmt->execute())
	{
		echo $error = "order details execution failed!".$con->error;		
		
	}
	
	if(!$orstmt->store_result())
		{
			echo $error = "order listing execution failed!".$con->error;					
		}
	
	
	$ornum_of_rows = $orstmt->num_rows;

	if($ornum_of_rows==0)
{
	$error = "No products available";		
}
	
}

?>
<!DOCTYPE html>
<html>
<head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title><?php echo $_SESSION['cName']; ?> Admin Area</title>
   <?php include("../header.php"); ?>
        <script type="text/javascript" src="<?php echo $_SESSION['gpath']; ?>assets/js/minified/widgets/charts-justgage.min.js"></script>

<style>

.dataTables_scrollBody
{
	height:500px !important;

}

</style>

    </head>
<body>
<div id="loading" class="ui-front loader ui-widget-overlay bg-white opacity-100"> <img src="../assets/images/loader-dark.gif" alt=""> </div>
<div id="page-wrapper" class="demo-example"> 
  <!-- #page-header -->
  
  <?php include("../sidebar.php"); ?>
  <!-- #page-sidebar -->
  <div id="menu-right" class="scrollable-content hidden">
    <div class="toggle-content-open clearfix">
      <div id="g10" class="small-gauge float-left"></div>
      <div id="g11" class="small-gauge float-right"></div>
    </div>
  </div>
  <div id="page-content-wrapper">
            
                <div id="page-title">

<h3>
    View/Update Order details - #BB<?php echo $id." (<strong> ".$data['orderstatus']."</strong>)"; ?>
</h3>
                    
                    <div id="breadcrumb-right">
   
                        <div class="float-right">
               <a href="<?php echo $_SESSION['gpath']; ?>orders/list_all_orders.php?status=<?php echo $status; ?>" title="Orders" class="btn medium bg-white">
            <span class="button-content">Back to Orders</span>
        </a>  
       
                        </div>
                    </div>
</div><!-- #page-title -->

            
<div id="page-content">
<div class="example-box">
<?php 
			   if(isset($error)){ ?>
             
             <div class="infobox error-bg">
<a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>             
<div class="bg-red large btn info-icon">
                        <i class="glyph-icon icon-remove"></i>
                    </div>
                    <h4 class="infobox-title"><?php echo $error;?></h4>
                    <p>Some error in the database query occured. Please try again!</p>
                </div>
            </div><?php } ?>
            
<?php 
			   if(isset($success)){ ?>
             
             <div class="infobox success-bg">
<a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>             
                    <h4 class="infobox-title"><?php echo $success;?></h4>
                </div>
            </div><?php } ?>
	  
    <div class="example-code">
<br>
<br>

        <form id="demo-form-2" action="" class="col-md-10 center-margin" method="post">
			<div class="content-box mrg25B">
          <h3 class="content-box-header primary-bg"> <span>Ordered Item(s)</span> </h3>
          <div class="content-box-wrapper">
			  <table class="table text-center">
            <thead>
                <tr>
                    <th class="text-center" width="5%"></th>
                    <th width="15%">PRODUCT</th>
					<th width="10%"></th>
                    <th class="text-center" width="10%">SKU</th>
                    <th class="text-center" width="10%">CATEGORY</th>
                    <th class="text-center" width="10%">COLOR</th>
                    <th class="text-center" width="10%">SIZE</th>
                    <th class="text-center" width="10%">QTY</th>
					<th class="text-center" width="10%">PRICE</th>
					<th class="text-center" width="10%">TOTAL</th>
                </tr>
            </thead>
            <tbody>
				 
    <?php 
	$sn = 0;
				$GST = 0;
	$orstmt->bind_result($id, $orderid, $pid, $sku, $name, $category, $sub_category, $product_type, $picture, $color, $size, $qty, $price, $cost);
	while ($orstmt->fetch()) 
	{
			$sn = 	$sn + 1;
		$name = ucwords($name);
	?>
    
				
                <tr>
                    <td><?php echo $sn; ?></td>
                   <td class="font-bold text-left"><?php echo $name; ?></td>
					 <td class="font-bold text-left"><img src="../<?php echo $picture; ?>" width="100%" alt=""/></td>
                    <td><?php echo $sku; ?></td>
                    <td><?php echo $category."=>".$product_type."=>".$sub_category; ?></td>
                    <td><?php echo $color; ?></td>
                    <td><?php echo $size; ?></td>
					<td><?php echo $qty; ?></td>
					<td>&#x20b9; <?php echo $price; ?></td>
                  
				  <td>&#x20b9; <?php echo $total = $qty * $price; ?></td>
                </tr>
                   <?php } ?>
       <tr>
                    <td></td>
                    <td class="font-bold text-left"></td>
                  <td></td>
		   <td></td>
                <td></td>
		   <td></td>
                <td></td>
		   <td colspan="2" align="right" class="h4">Shipping:</td>
                  <td class="h4"><?php if($data['shipping']>0) { echo "&#x20b9; ".$data['shipping']; } else { echo "Free"; } ?></td>
                </tr>
				  <tr>
                    <td></td>
                    <td class="font-bold text-left"></td>
                  <td></td>
		   <td></td>
                           <td></td>
		   <td></td>     <td></td>
		   <td colspan="2" align="right" class="h4">Order Total:</td>
                  <td class="h2">&#x20b9; <?php echo $data['cost']; ?></td>
                </tr>
            </tbody>
        </table>
			  
		  </div></div>
  	 
			<div class="content-box mrg25B">
          <h3 class="content-box-header primary-bg"> <span>Order Details</span> </h3>
          <div class="content-box-wrapper">
			  
			<div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        Order Date:
                         
                    </label>
                </div>
                <div class="form-input col-md-9">
                    <?php echo date('l - dS M, Y - h:i:s A', strtotime($data['orderdate'])); ?>
                </div>
            </div>
			<div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        Expected Shipping Date:
                         
                   </label>
                </div>
                <div class="form-input col-md-9">
                    <?php echo date('l - dS M, Y', strtotime($data['exdate'])); ?>
                </div>
            </div>
			<div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        Date shipped:
                         
                    </label>
                </div>
                <div class="form-input col-md-9">
                    <?php if($data['sdate']==NULL) { echo "Not yet shipped"; } else { echo date('l - dS M, Y', strtotime($data['sdate'])); } ?>
                </div>
            </div>
			<div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        Date delivered:
                         
                    </label>
                </div>
                <div class="form-input col-md-9">
                    <?php if($data['ddate']==NULL) { echo "Not yet delivered"; } else { echo date('l - dS M, Y', strtotime($data['ddate'])); } ?>
                </div>
            </div>
			<div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        Order Cost:
                         
                    </label>
                </div>
                <div class="form-input col-md-9">
                  &#x20b9; <?php echo $data['cost']; ?>
                </div>
            </div>
			<div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        Total Items:
                         
                    </label>
                </div>
                <div class="form-input col-md-9">
                    <?php echo $data['titems']; ?>
                </div>
            </div>
			<div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        Current order status:
                         
                    </label>
                </div>
                <div class="form-input col-md-9">
                    <?php echo $data['orderstatus']; ?>
                </div>
            </div>
			<div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        Name:
                         <span class="required">*</span>
                    </label>
                </div>
                <div class="form-input col-md-9">
                    <?php echo ucwords($data['fname']." ".$data['lname']); ?>
                </div>
            </div>
            
             <div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        Contact:                       
                    </label>
                </div>
                 <div class="form-input col-md-9">
                    <?php echo $data['phone']; ?>
                </div>
            </div>
			
			       <div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        Email:                        
                    </label>
                </div>
                 <div class="form-input col-md-9">
                    <?php echo $data['email']; ?>
                </div>
            </div>
	
            <div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        Shipping address:                     
                    </label>
                </div>
                <div class="form-input col-md-9">
				 <?php echo $data['address']; ?>
                </div>
            </div>
			
            </div>
            </div>
            
            <div class="content-box mrg25B">
          <h3 class="content-box-header primary-bg"> <span>Payment Detail</span> </h3>
          <div class="content-box-wrapper">
			  
			<div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        Payment Date:
                         
                    </label>
                </div>
                <div class="form-input col-md-9">
                    <?php if($data['payment_date']==NULL) { echo "N/A"; } else { echo date('l - dS M, Y - h:i:s A', strtotime($data['payment_date'])); } ?>
                </div>
            </div>
			  <div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        Transcation ID
                         
                   </label>
                </div>
                <div class="form-input col-md-9">
                    <?php echo $data['txn_id']; ?>
                </div>
            </div>
			<div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        Payment Status
                         
                   </label>
                </div>
                <div class="form-input col-md-9">
                    <?php echo $data['payment_status']; if($data['pending_reason']!=NULL) { echo " (".$data['pending_reason'].")"; }  ?>
                </div>
            </div>
			  <div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        Amount Paid
                         
                   </label>
                </div>
                <div class="form-input col-md-9">&#x20b9; <?php echo $data['mc_gross']; ?>
                </div>
            </div>
			  <div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        Currency paid
                         
                   </label>
                </div>
                <div class="form-input col-md-9">
                    <?php echo $data['mc_currency']; ?>
                </div>
            </div>
			  <div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        Payment Type
                         
                   </label>
                </div>
                <div class="form-input col-md-9">
                    <?php echo $data['payment_type']; ?>
                </div>
            </div>
			  </div>
		 </div>
            
            <div class="content-box mrg25B">
          <h3 class="content-box-header primary-bg"> <span>Update Order</span> </h3>
          <div class="content-box-wrapper">
              <div class="form-row">
              <div class="form-label col-md-3">
                <label for=""> Update order status: </label>
              </div>
              <div class="form-input col-md-9">
                <select data-placeholder="Select a status..." name="ostatus" class="chosen-select parsley-validated" data-trigger="change">
       <option value="">Select a Status</option>	
					<option value="Shipped">Shipped</option>	
					<option value="Delivered">Delivered</option>	
					<option value="Cancelled">Cancelled</option>	
     
        
                </select>
              </div>
              
            </div>
			<div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                       Status remarks:
                    </label>
                </div>
                <div class="form-input col-md-9">
                    <input type="text" id="status" name="sremarks" value="<?php if($data['sremarks']!=NULL) { echo $data['sremarks']; } ?>" data-trigger="change" class="parsley-validated">
                </div>
            </div>
			
 <div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                       Courier name:
                    </label>
                </div>
                <div class="form-input col-md-9">
                    <input type="text" id="status" name="courier" value="<?php if($data['courier']!=NULL) { echo $data['courier']; } ?>" data-trigger="change" class="parsley-validated">
                </div>
            </div>
              
               <div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        Courier Tracking Code:                      
                    </label>
                </div>
                <div class="form-input col-md-9">
				<textarea class="parsley-validated" cols="80" name="ccode" rows="3"  data-trigger="change"><?php echo $data['ccode']; ?></textarea>
                </div>
            </div>
			
			<div class="form-row">
          <div class="form-label col-md-3">
            <label for="">Update shipped date:</label>
          </div>
          <div class="form-input col-md-9">
            <input type="text" name="sdate" class="fromDate" data-trigger="change" class="parsley-validated" autocomplete="off">
          </div>
        </div>
			
					<div class="form-row">
          <div class="form-label col-md-3">
            <label for="">Update delivered date:</label>
          </div>
          <div class="form-input col-md-9">
            <input type="text" name="ddate" class="fromDate" data-trigger="change" class="parsley-validated" autocomplete="off">
          </div>
        </div>
              
			  </div>
                </div>
              
             
            <div class="form-row">
                <input type="hidden" name="superhidden" id="superhidden">
				<input type="hidden" name="id" id="id" value="<?php echo $data['id']; ?>">    
                <input type="hidden" name="contact" id="contact" value="<?php echo $data['phone']; ?>">    
                <input type="hidden" name="email" id="email" value="<?php echo $data['email']; ?>">                    
				<input type="hidden" name="cname" id="cname" value="<?php echo ucwords($data['lname']." ".$data['fname']); ?>">    
				<input type="hidden" name="estatus" id="estatus" value="<?php echo $data['orderstatus']; ?>">   
				<input type="hidden" name="esdate" id="esdate" value="<?php echo $data['sdate']; ?>">   
				<input type="hidden" name="eddate" id="eddate" value="<?php echo $data['ddate']; ?>">   
				<div class="form-input col-md-10 col-md-offset-2">
               <span class="button-content"><input type="submit" name="submit" value="Update details" onclick="javascript:$(&apos;#demo-form-2&apos;).parsley( &apos;validate&apos; );">
                        </span>

                </div>
            </div>
            
        </form>

    </div>
    
</div>
</div>
<!-- #page-content -->
</div>
<!-- #page-main -->
</div>
<!-- #page-wrapper -->

</body>
</html>

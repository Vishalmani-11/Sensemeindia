<?php
include "../function/config.php"; 
include "../db/db_connect.php"; 
include "../db/session.php";  
include "../function/function.php";

//////////////////////delete////////////////////////
if(isset($_GET['id'])&&$_GET['id']!=''&&isset($_GET['action'])&&$_GET['action']=='delete')
{
extract($_GET);	
$query = "DELETE FROM bb_users WHERE id ='$id'";
$qresult = mysqli_query($con,$query);
if(!$qresult)
{
	$error = "Record deleting failed!".mysqli_error($con);
}
else
{
$success= "Record deleted successfully!";
header("location:list_all_users.php?success=".$success); exit(); 
}
} 

//////////////////////stats update////////////////////////
if(isset($_GET['id'])&&$_GET['id']!=''&&isset($_GET['action'])&&$_GET['action']=='editstatus')
{
extract($_GET);
    if($status ==1) { $ustatus = 0;  } elseif($status==0)  { $ustatus = 1;  }
    
$query = "UPDATE bb_users SET status=? WHERE id = ?";
  if(!$stmt = $con->prepare($query))
            {
                echo $error = "user data listing preparation failed!".$con->error; exit();
            }

      if(!$stmt->bind_param('ii', $ustatus, $id))
            {
                echo $error = "user data listing preparation failed!".$con->error; exit();
            }
 
 if(!$stmt->execute())
	{
		$error = "User status update failed!".$con->error;	
         header("location:list_all_users.php?error"); exit(); 
		
	}
	else
	
	{
		$success= "user status updated successfully!";
        header("location:list_all_users.php?success=".$success); exit(); 
	}
	
} 


//////////////////////////////list users///////////////////////////////////////////////
    
    $status = secure_input($con,$status);	

        $query = "SELECT * FROM bb_users ORDER BY cdate DESC";
        
        if(!$ostmt = $con->prepare($query))
            {
                echo $error = "user data listing preparation failed!".$con->error; exit();
            }


	if(!$ostmt->execute())
	{
		echo $error = "user data listing execution failed!".$con->error;	exit();	
		
	}
		if(!$result = $ostmt->get_result())
		{
			echo $error = "categories data listing execution failed!".$con->error;	exit();				
		}
	
	$onum_of_rows = $result->num_rows;


	if($onum_of_rows==0)
{
	$error = "No users available";		
}

//////////////////////////////////


?>
<!DOCTYPE html>
    <html>
    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title><?php echo $_SESSION['cName']; ?> Admin Area</title>
   <?php include("../header.php"); ?>
        <script type="text/javascript" src="<?php echo $_SESSION['gpath']; ?>assets/js/minified/widgets/charts-justgage.min.js"></script>

<style>

.dataTables_scrollBody
{
	height:500px !important;

}

</style>

    </head>
    <body>
        

        <div id="loading" class="ui-front loader ui-widget-overlay bg-white opacity-100">
            <img src="../assets/images/loader-dark.gif" alt="">
        </div>

        <div id="page-wrapper" class="demo-example">
          <!-- #page-header -->

            <?php include("../sidebar.php"); ?>
            <!-- #page-sidebar -->
            <div id="menu-right" class="scrollable-content hidden">
                <a href="javascript:;" title="Get Source" class="popover-title button-toggle-open">
                    Cloud status
                    <i class="glyph-icon icon-caret-right icon-caret-down"></i>
                </a>
                <div class="clear"></div>
                <a href="javascript:;" title="Get Source" class="popover-title button-toggle-open">
                    Realtime server load
                    <i class="glyph-icon icon-caret-right icon-caret-down"></i>
                </a>
                <div class="toggle-content-open clearfix">

                    <div id="g10" class="small-gauge float-left"></div>
                    <div id="g11" class="small-gauge float-right"></div>
                </div>
            </div>

            <div id="page-content-wrapper">
                <div id="page-title">
                    

<h3>
  <h3>All Users </h3><br>
    
    <?php 
			   if(isset($success)){ ?>

             
             <div class="infobox success-bg">
<a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>             
                    <h4 class="infobox-title"><?php echo $success;?></h4>
                </div><?php } ?>
    
       <?php 
			   if(isset($_GET['success'])){ ?>

             
             <div class="infobox success-bg">
<a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>             
                    <h4 class="infobox-title"><?php echo $_GET['success'];?></h4>
                </div><?php } ?>
              </div><!-- #page-title -->
<div id="page-content">

<script type="text/javascript">

$(document).ready(function() {

});

</script>

<h4>&nbsp;</h4>

<table class="table" id="example1">
  <thead>
		<tr>
			<th width="5%">S.No</th>
			<th width="6%">User ID</th>
			<th width="10%">Name</th>
			<th width="7%">Mobile</th>        
			<th width="7%">e-mail</th>        
			<th width="8%">Address</th>
			<th width="9%">City</th>
            <th width="9%">Country</th>
            <th width="7%">Source</th>  
            <th width="7%">Status</th>              
            <th width="15%">last login</th>            
			<th width="18%">created</th>            
			<th width="10%">Action</th>
		</tr>
	</thead>
	<tbody>
    
    
    <?php 
	$sn = 0;
	//$ostmt->bind_result($id, $name, $cost, $shipping, $titems, $odate, $ostatus, $contact);
	while ($row = $result->fetch_assoc()) {
    
		$sn = 	$sn + 1;
        $name = ucwords($row['fname']." ".$row['lname']); 
        ?>
    
		<tr>
			<td><?php echo $sn;?></td>
			<td><?php echo $row['id']; ?></td>
			<td><?php echo $name; ?></td>
			<td><?php echo $row['phone']; ?></td>
			<td><?php echo $row['email']; ?></td>			
			<td><?php echo $row['address']." - ".$row['zipcode']; ?> </td>
			<td><?php echo $row['city']; ?></td>
            <td><?php echo $row['country']; ?></td>
            <td><?php if($row['oauth_provider']!=NULL) { echo $row['oauth_provider']; } else { echo "SM";  } ?></td>
            <td><?php if($row['status']) { echo "Active"; } else { echo "In-active"; } ?></td>
            <td><?php echo date('dS M, Y - h:i:s A', strtotime($row['llogin'])); ?></td>       
			<td><?php echo date('dS M, Y - h:i:s A', strtotime($row['cdate'])); ?></td>       
			<td><div class="dropdown">
                                    <a href="javascript:;" title="" class="btn medium bg-blue" data-toggle="dropdown">
                                        <span class="button-content">
                                            <i class="glyph-icon font-size-11 icon-cog"></i>
                                            <i class="glyph-icon font-size-11 icon-chevron-down"></i>
                                        </span>
                                    </a>
                                    <ul class="dropdown-menu float-right">
                                        <?php if($row['status']) { ?>

                                        <li>
                                            <a href="list_all_users.php?id=<?php echo $row['id']; ?>&status=<?php echo $row['status']; ?>&action=editstatus" onclick="return confirm('Are you sure you want to deactivate this user?');"  title="">
                                                <i class="glyph-icon icon-edit mrg5R"></i>
                                                Deactivate
                                            </a>
                                        </li>
                                        
								<?php } else {  ?>
                                         <li>
                                            <a href="list_all_users.php?id=<?php echo $row['id']; ?>&status=<?php echo $row['status']; ?>&action=editstatus" onclick="return confirm('Are you sure you want to activate this user?');"  title="">
                                                <i class="glyph-icon icon-edit mrg5R"></i>
                                                Activate
                                            </a>
                                        </li>
                                        <?php } ?>
                                        <li>
                                             <a href="list_all_users.php?id=<?php echo $row['id']; ?>&action=delete" title="" onclick="return confirm('Are you sure you want to delete this user?');" class="font-red">
                                                <i class="glyph-icon icon-remove mrg5R"></i> 
                                                 Delete
                                            </a>
                                        </li>
                                        
                                    </ul>
                                </div>
                               
                            </td>
		</tr>
        
        <?php } ?>
        
	</tbody>
	<tfoot>
		<tr>
			<th></th>
			<th></th>
			<th></th>
			<th></th>
			<th></th>			
            <th></th>			
			<th></th>
			<th></th>			
			<th></th>
            	<th></th>			
			<th></th>
			<th></th>			
			<th></th>
		</tr>
	</tfoot>
</table>


                	</div><!-- #page-content -->
            </div>




                	</div><!-- #page-content -->
            </div><!-- #page-main -->
        </div><!-- #page-wrapper -->

    </body>
</html>


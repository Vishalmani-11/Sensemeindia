<?php
include "../db/db_connect.php"; 
include "../db/session.php";  
include "../function/function.php";  

extract($_POST);

$qty = secure_integers($qty);
$price = secure_integers($price);
$eid = secure_integers($eid);	
$date = secure_input($con,$date);	

///////////////////////////add new price//////////////////////
if($eid==0)
{

		if(!$stmt = $con->prepare("INSERT INTO rrg_pricing (roomID, bookingDate, price, availableQty) VALUES (?, ?, ?, ?)"))
	{
		//echo json_encode(array("statusCode"=>201,"error"=>"$con->error"));
			echo $con->error;

	}


	if(!$stmt->bind_param("isii", $roomid, $date, $price, $qty))
	{
		//	echo json_encode(array("statusCode"=>201,"error"=>"$con->error"));
		echo $con->error;
	}

	if($stmt->execute()) {
		
		echo json_encode(array("statusCode"=>200));
	}
	else
	{
		//	echo json_encode(array("statusCode"=>201,"error"=>"$con->error"));
		echo $con->error;
	}

}
///////////////////////////udpate price//////////////////////
elseif($eid>0)
{

if(!$stmt = $con->prepare("UPDATE rrg_pricing SET price = ?, availableQty = ? WHERE id = ?"))
{
	echo json_encode(array("statusCode"=>201,"error"=>"$con->error"));
	
	
}

if(!$stmt->bind_param("iii", $price, $qty, $eid))
{
	echo $error = "bind failed: (" . $con->errno . ") " . $con->error;

}

if($stmt->execute()) {
	
	echo json_encode(array("statusCode"=>200));
	
}
else
{
		echo json_encode(array("statusCode"=>201,"error"=>"$con->error"));		
}

	}

?>
 
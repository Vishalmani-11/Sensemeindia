<?php
include "../db/session.php";  
//include "../function/config.php"; 
include "../db/db_connect.php"; 
include "../function/function.php";

////////////////////////update/////////////////////////
if(isset($_POST['submit']))
{
extract($_POST);	

$order_id = secure_input($con,$id);   
$liststatus = secure_input($con,$liststatus);       
$customer_phone = secure_input($con,$contact);
$customer_email = secure_input($con,$email);
$cname = secure_input($con,$cname);	
$sremarks = secure_input($con,$sremarks);	
$ostatus = secure_input($con,$ostatus);
$estatus = secure_input($con,$estatus);	
$courier = secure_input($con,$courier);	
$ccode = secure_input($con,$ccode);	    
	
	if($ostatus=="")
	{
		$ostatus = $estatus;
	}
	
	if($esdate=="")
	{
		$esdate = NULL;
	}
	
	if($sdate=="")
	{
		$sdate = $esdate;
	}
	else
	{
$sdate = secure_input($con,$sdate);
$sdate = date('Y-m-d', strtotime($sdate)); 	
	}
	
	if($eddate=="")
	{
		$eddate = NULL;
	}
	
	if($ddate=="")
	{
		$ddate = $eddate;
	}
	else
	{
$ddate = secure_input($con,$ddate);
$ddate = date('Y-m-d', strtotime($ddate)); 	
	}
	
$query = "UPDATE bb_orders SET orderstatus=?, sremarks=?, courier=?, ccode=?, sdate=?, ddate=? WHERE id = ?";

	
	if(!$ustmt = $con->prepare($query))
{
	echo $error = "order update preparation failed!".$con->error; exit();
}
	if(!$ustmt->bind_param("ssssssi", $ostatus, $sremarks, $courier, $ccode, $sdate, $ddate, $order_id))
{
	echo "Param pass failed: (" . $con->errno . ") " . $con->error;exit();
}
	
	if(!$ustmt->execute())
	{
		echo $error = "order update execution failed!".$con->error;		exit();
		
	}
	else
	{
	    $success = "Order details successfully updated."; 
		header("location:update_order_offline.php?success=".$success."&id=".$order_id."&status=".$liststatus); exit();
	}
    
}
	
//////////////////////////order details///////////////////////////////////////////////////////////

if(isset($_GET['id']))
{ 
extract($_GET); 
$id = secure_input($con,$id);   
$query = "SELECT * FROM bb_orders WHERE id = ? ORDER BY orderdate DESC";

if(!$rstmt = $con->prepare($query))
{
	echo $error = "order details preparation failed!".$con->error; exit();
}
	if(!$rstmt->bind_param("i", $id))
{
	echo "Param pass failed: (" . $con->errno . ") " . $con->error;exit();
}
	
	if(!$rstmt->execute())
	{
		echo $error = "order details execution failed!".$con->error;	exit();	
		
	}    
    
    if(!$qresult = $rstmt->get_result())
		{
echo			$error = "Product data listing failed!".$con->error;	exit();				
		}
    else
    {
        $data = $qresult->fetch_assoc();
    }
    
}

/////////////////////////////product details//////////////////////////////////////////

if(isset($_GET['id']))
{ 
extract($_GET); 

 $id = secure_input($con,$id);	   
$status = secure_input($con,$status);	        
$oquery = "SELECT id, orderid, sku, hsc_code, name, qty, price, cost FROM bb_order_products_offline WHERE orderid = ?";

	
if(!$orstmt = $con->prepare($oquery))
{
	echo $error = "order details preparation failed!".$con->error;exit();
}
	if(!$orstmt->bind_param("i", $id))
{
	echo "Param pass failed: (" . $con->errno . ") " . $con->error;exit();
}
	
	if(!$orstmt->execute())
	{
		echo $error = "order details execution failed!".$con->error;	exit();	
		
	}
	
	if(!$orstmt->store_result())
		{
			echo $error = "order listing execution failed!".$con->error;	exit();				
		}
	
	
	$ornum_of_rows = $orstmt->num_rows;

	if($ornum_of_rows==0)
{
	$error = "No products available";		
}
	
}

?>
<!DOCTYPE html>
<html>
<head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title><?php echo $_SESSION['cName']; ?> Admin Area</title>
   <?php include("../header.php"); ?>
        <script type="text/javascript" src="<?php echo $_SESSION['gpath']; ?>assets/js/minified/widgets/charts-justgage.min.js"></script>

<style>

.dataTables_scrollBody
{
	height:500px !important;

}

</style>

    </head>
<body>
<div id="loading" class="ui-front loader ui-widget-overlay bg-white opacity-100"> <img src="../assets/images/loader-dark.gif" alt=""> </div>
<div id="page-wrapper" class="demo-example"> 
  <!-- #page-header -->
  
  <?php include("../sidebar.php"); ?>
  <!-- #page-sidebar -->
  <div id="menu-right" class="scrollable-content hidden">
    <div class="toggle-content-open clearfix">
      <div id="g10" class="small-gauge float-left"></div>
      <div id="g11" class="small-gauge float-right"></div>
    </div>
  </div>
  <div id="page-content-wrapper">
            
                <div id="page-title">

<h3>
    View/Update Order details - #SM<?php echo $id." (<strong> ".$data['orderstatus']."</strong>)"; ?>
</h3>
                    
                    <div id="breadcrumb-right">
   
                        <div class="float-right">
               <a href="<?php echo $_SESSION['gpath']; ?>orders/list_all_orders_offline.php?status=<?php echo $status; ?>" title="Orders" class="btn medium bg-white">
            <span class="button-content">Back to Orders</span>
        </a>  
       
                        </div>
                    </div>
</div><!-- #page-title -->

            
<div id="page-content">
<div class="example-box">
<?php 
			   if(isset($error)){ ?>
             
             <div class="infobox error-bg">
<a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>             
<div class="bg-red large btn info-icon">
                        <i class="glyph-icon icon-remove"></i>
                    </div>
                    <h4 class="infobox-title"><?php echo $error;?></h4>
                    <p>Some error in the database query occured. Please try again!</p>
                </div>
            </div><?php } ?>
            
<?php 
			   if(isset($success)){ ?>
             
             <div class="infobox success-bg">
<a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>             
                    <h4 class="infobox-title"><?php echo $success;?></h4>
                </div>
            </div><?php } ?>
	  
    <div class="example-code">
<br>
<br>

        <form id="demo-form-2" action="" class="col-md-10 center-margin" method="post">
			<div class="content-box mrg25B">
          <h3 class="content-box-header primary-bg"> <span>Ordered Item(s)</span> </h3>
          <div class="content-box-wrapper">
			  <table class="table text-center">
            <thead>
                <tr>
                    <th class="text-center" width="5%"></th>
                    <th width="15%">PRODUCT</th>
                    <th class="text-center" width="10%">SKU</th>
                    <th class="text-center" width="10%">QTY</th>
					<th class="text-center" width="10%">PRICE</th>
					<th class="text-center" width="10%">TOTAL</th>
                </tr>
            </thead>
            <tbody>
				 
    <?php 
	$sn = 0;
				$GST = 0;
	$orstmt->bind_result($id, $orderid, $sku, $hsc_code, $name, $qty, $price, $cost);
	while ($orstmt->fetch()) 
	{
			$sn = 	$sn + 1;
		$name = ucwords($name);
	?>
    
				
                <tr>
                    <td><?php echo $sn; ?></td>
                   <td class="font-bold text-left"><?php echo $name; ?></td>
                    <td><?php echo $sku; ?></td>
                    <td><?php echo $qty; ?></td>
					<td>&#x20b9; <?php echo $price; ?></td>
                  
				  <td>&#x20b9; <?php echo $total = $qty * $price; ?></td>
                </tr>
                   <?php } ?>
       <tr>

		   <td></td>
                <td></td>
		   <td></td>
                
		   <td colspan="2" align="right" class="h4">Shipping:</td>
                  <td class="h4"><?php if($data['shipping']>0) { echo "&#x20b9; ".$data['shipping']; } else { echo "Free"; } ?></td>
                </tr>
				  <tr>
                  <td></td>  
                  <td></td>
		   <td></td>
        
		   <td colspan="2" align="right" class="h4">Order Total:</td>
                  <td class="h2">&#x20b9; <?php echo $data['cost'] + $data['shipping']; ?></td>
                </tr>
            </tbody>
        </table>
			  
		  </div></div>
  	 
			<div class="content-box mrg25B">
          <h3 class="content-box-header primary-bg"> <span>Order Details</span> </h3>
          <div class="content-box-wrapper">
			  
			<div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        Order Date:
                         
                    </label>
                </div>
                <div class="form-input col-md-9">
                    <?php echo date('l - dS M, Y - h:i:s A', strtotime($data['orderdate'])); ?>
                </div>
            </div>
			<div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        Date shipped:
                         
                    </label>
                </div>
                <div class="form-input col-md-9">
                    <?php if($data['sdate']==NULL) { echo "Not yet shipped"; } else { echo date('l - dS M, Y', strtotime($data['sdate'])); } ?>
                </div>
            </div>
			<div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        Date delivered:
                         
                    </label>
                </div>
                <div class="form-input col-md-9">
                    <?php if($data['ddate']==NULL) { echo "Not yet delivered"; } else { echo date('l - dS M, Y', strtotime($data['ddate'])); } ?>
                </div>
            </div>
			<div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        Order Cost:
                         
                    </label>
                </div>
                <div class="form-input col-md-9">
                  &#x20b9; <?php echo $data['mc_gross']; ?>
                </div>
            </div>
			<div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        Total Items:
                         
                    </label>
                </div>
                <div class="form-input col-md-9">
                    <?php echo $data['titems']; ?>
                </div>
            </div>
			<div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        Current order status:
                         
                    </label>
                </div>
                <div class="form-input col-md-9">
                    <?php echo $data['orderstatus']; ?>
                </div>
            </div>
			<div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        Customer Name:
                        
                    </label>
                </div>
                <div class="form-input col-md-9">
                    <?php echo ucwords($data['fname']." ".$data['lname']); ?>
                </div>
            </div>
              
              <div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        Customer GST:
                        
                    </label>
                </div>
                <div class="form-input col-md-9">
                    <?php echo $data['customer_GST']; ?>
                </div>
            </div>
              
            
             <div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        Phone:                       
                    </label>
                </div>
                 <div class="form-input col-md-9">
                    <?php echo $data['phone_offline']; ?>
                </div>
            </div>
			
			       <div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        Email:                        
                    </label>
                </div>
                 <div class="form-input col-md-9">
                    <?php echo $data['email_offline']; ?>
                </div>
            </div>
	
            <div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        Shipping address:                     
                    </label>
                </div>
                <div class="form-input col-md-9">
				 <?php echo $data['address']; ?>
                </div>
            </div>
			
            </div>
            </div>
            
            <div class="content-box mrg25B">
          <h3 class="content-box-header primary-bg"> <span>Payment Detail</span> </h3>
          <div class="content-box-wrapper">
			  <div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        Amount Paid
                         
                   </label>
                </div>
                <div class="form-input col-md-9">&#x20b9; <?php echo $data['mc_gross']; ?>
                </div>
            </div>
			  <div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        Currency paid
                         
                   </label>
                </div>
                <div class="form-input col-md-9">
                    <?php echo $data['mc_currency']; ?>
                </div>
            </div>
			  </div>
		 </div>
            
            <div class="content-box mrg25B">
          <h3 class="content-box-header primary-bg"> <span>Update Order</span> </h3>
          <div class="content-box-wrapper">
              <div class="form-row">
              <div class="form-label col-md-3">
                <label for=""> Update order status: </label>
              </div>
              <div class="form-input col-md-9">
                <select data-placeholder="Select a status..." name="ostatus" class="chosen-select parsley-validated" data-trigger="change">
       <option value="">Select a Status</option>	
					<option value="Shipped">Shipped</option>	
					<option value="Delivered">Delivered</option>	
                </select>
              </div>
              
            </div>
			<div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                       Status remarks:
                    </label>
                </div>
                <div class="form-input col-md-9">
                    <input type="text" id="status" name="sremarks" value="<?php if($data['sremarks']!=NULL) { echo $data['sremarks']; } ?>" data-trigger="change" class="parsley-validated">
                </div>
            </div>
			
 <div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                       Courier name:
                    </label>
                </div>
                <div class="form-input col-md-9">
                    <input type="text" id="status" name="courier" value="<?php if($data['courier']!=NULL) { echo $data['courier']; } ?>" data-trigger="change" class="parsley-validated">
                </div>
            </div>
              
               <div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        Courier Tracking Code:                      
                    </label>
                </div>
                <div class="form-input col-md-9">
				<textarea class="parsley-validated" cols="80" name="ccode" rows="3"  data-trigger="change"><?php echo $data['ccode']; ?></textarea>
                </div>
            </div>
			
			<div class="form-row">
          <div class="form-label col-md-3">
            <label for="">Update shipped date:</label>
          </div>
          <div class="form-input col-md-9">
            <input type="text" name="sdate" class="fromDate" data-trigger="change" class="parsley-validated" autocomplete="off">
          </div>
        </div>
			
					<div class="form-row">
          <div class="form-label col-md-3">
            <label for="">Update delivered date:</label>
          </div>
          <div class="form-input col-md-9">
            <input type="text" name="ddate" class="fromDate" data-trigger="change" class="parsley-validated" autocomplete="off">
          </div>
        </div>
              
			  </div>
                </div>
              
             
            <div class="form-row">
                <input type="hidden" name="superhidden" id="superhidden">
				<input type="hidden" name="id" id="id" value="<?php echo $data['id']; ?>">    
                <input type="hidden" name="contact" id="contact" value="<?php echo $data['phone_offline']; ?>">    
                <input type="hidden" name="email" id="email" value="<?php echo $data['email_offline']; ?>">                    
				<input type="hidden" name="cname" id="cname" value="<?php echo ucwords($data['lname']." ".$data['fname']); ?>">    
				<input type="hidden" name="estatus" id="estatus" value="<?php echo $data['orderstatus']; ?>">   
				<input type="hidden" name="esdate" id="esdate" value="<?php echo $data['sdate']; ?>">   
				<input type="hidden" name="eddate" id="eddate" value="<?php echo $data['ddate']; ?>"> 
                <input type="hidden" name="liststatus" id="liststatus" value="<?php echo $_GET['status']; ?>"> 
				<div class="form-input col-md-10 col-md-offset-2">
               <span class="button-content"><input type="submit" name="submit" value="Update details" onclick="javascript:$(&apos;#demo-form-2&apos;).parsley( &apos;validate&apos; );">
                        </span>

                </div>
            </div>
            
        </form>

    </div>
    
</div>
</div>
<!-- #page-content -->
</div>
<!-- #page-main -->
</div>
<!-- #page-wrapper -->

</body>
</html>

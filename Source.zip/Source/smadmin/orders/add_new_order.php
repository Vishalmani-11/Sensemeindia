<?php
include "../function/config.php"; 
include "../db/db_connect.php"; 
include "../db/session.php";  
include "../function/function.php";  

////////////////////////save/////////////////////////
if(isset($_POST['submit']))
{
extract($_POST);	
$HSC = secure_input($con,$HSC_code);         
$SKU = secure_input($con,$SKU);        
$fname = secure_input($con,$fname);    
$lname = secure_input($con,$lname);    
$phone = secure_input($con,$phone);    
$email = secure_input($con,$email);    
$address = secure_input($con,$address);
$zipcode = secure_input($con,$pincode);    
$GST = secure_input($con,$GST);    
$order_type = 0;    
$order_placed = 1;        
$shipping = secure_input($con,$shipping);	  
$courier = secure_input($con,$courier);	    
$sdate = secure_input($con,$sdate);
$sdate = date('Y-m-d', strtotime($sdate));	 
$fulladdress = $address." - ".$zipcode;
$mc_currency =  "INR";	
$orderstatus = "Shipped";
$order_notes = NULL;
$verify_sign =  "N/A";	    
$sdays = 3;    
$cid = 0;    
$cost = 0;
$no = 0;
/////////////////////////////////////////////////////////////////    
    foreach($pname as $x => $x_value) {
  echo "Key=" . $x . ", Value=" . $x_value;
  echo "<br>";
        
        if($qty[$x]>0&&$price[$x]>0 )
        {
 $cost += ($qty[$x]*$price[$x]);	
            $no++;
        }
        
    }
$mc_gross = $cost + $shipping;
///////////////////////////////order details///////////////////////////////    
$myquery = "INSERT into bb_orders (cid, fname, lname, phone_offline, email_offline, customer_GST, pincode, cost, shipping, titems, address, sdays, exdate, sdate, orderstatus, order_notes, mc_currency, mc_gross, verify_sign, order_placed, order_type) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    
if(!$ostmt = $con->prepare($myquery))
{
	echo "Prepare failed2: (" . $con->errno . ") " . $con->error; exit();
}

if(!$ostmt->bind_param("issssssiiisisssssisii", $cid, $fname, $lname, $phone, $email, $GST, $zipcode, $cost, $shipping, $no, $fulladdress, $sdays, $sdate, $sdate, $orderstatus, $order_notes, $mc_currency, $mc_gross, $verify_sign, $order_placed, $order_type))
{
	echo "Param pass failed: (" . $con->errno . ") " . $con->error; exit();
}

if(!$ostmt->execute()) {
	echo $error = "order saving failed!".$con->error; exit();
    
}
else
{
    $last_id = $ostmt->insert_id;
////////////////////////////order products//////////////////////////////////////////////////////////    
    $pcost = 0;
     foreach($pname as $x => $x_value) {
        
        if($qty[$x]>0&&$price[$x]>0 )
        {
    
			$pcost = $qty[$x]*$price[$x];
            
$opquery = "INSERT into bb_order_products_offline (orderid, sku, hsc_code, name, qty, price, cost) values (?, ?, ?, ?, ?, ?, ?)";

if(!$ostmt = $con->prepare($opquery))
{
	echo "Prepare failed5: (" . $con->errno . ") " . $con->error; exit();
}

if(!$ostmt->bind_param("isssiii", $last_id, $SKU, $HSC_code[$x], $pname[$x], $qty[$x], $price[$x], $pcost))
{
	echo "Param pass failed: (" . $con->errno . ") " . $con->error; exit();
}

if(!$ostmt->execute()) {
	
    echo $error = "New order products saving failed!".$con->error;    
	header("location:add_new_order.php?error=".$error);
	$ostmt->close();	 exit();
	
}
            

        
        }
        
    }
    
    echo $success= "Order created successfully!"; 
    header("location:list_all_orders_offline.php?success=".$success); 
    exit();
          
////////////////////////////////////////////////////////////////////////////////////////////////

}

}


?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title><?php echo $_SESSION['cName']; ?> Admin Area</title>
    <?php include("../header.php"); ?>
    <script type="text/javascript" src="<?php echo $_SESSION['gpath']; ?>assets/js/minified/widgets/charts-justgage.min.js"></script>
    

</head>
<body>
<div id="loading" class="ui-front loader ui-widget-overlay bg-white opacity-100"> <img src="<?php echo $_SESSION['gpath'] ?>assets/images/loader-dark.gif" alt=""> </div>
<div id="page-wrapper" class="demo-example"> 
  <!-- #page-header -->
  
  <?php include("../sidebar.php"); ?>
  <!-- #page-sidebar -->
  <div id="menu-right" class="scrollable-content hidden">
    <div class="toggle-content-open clearfix">
      <div id="g10" class="small-gauge float-left"></div>
      <div id="g11" class="small-gauge float-right"></div>
    </div>
  </div>
  <div id="page-content-wrapper">
            
                <div id="page-title">

<h3>
    <strong>Add New Order</strong> 
</h3>

</div><!-- #page-title -->

            
<div id="page-content">
<h3><strong>Order details:</strong></h3>
<div class="example-box">
<?php 
			   if(isset($error)){ ?>
             
             <div class="infobox error-bg">
<a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>             
<div class="bg-red large btn info-icon">
                        <i class="glyph-icon icon-remove"></i>
                    </div>
                    <h4 class="infobox-title"><?php echo $error;?></h4>
                    <p>Some error in the database query occured. Please try again!</p>
                </div>
           <?php } ?>
    
    <?php 
			   if(isset($_GET['error'])){ ?>
             
             <div class="infobox error-bg">
<a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>             
<div class="bg-red large btn info-icon">
                        <i class="glyph-icon icon-remove"></i>
                    </div>
                    <h4 class="infobox-title"><?php echo $_GET['error'];?></h4>
                    <p>Some error in the database query occured. Please try again!</p>
                </div>
           <?php } ?>
    
            
<?php 
			   if(isset($success)){ ?>
             
             <div class="infobox success-bg">
<a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>             
                    <h4 class="infobox-title"><?php echo $success;?></h4>
                </div><?php } ?>
    
    <?php 
			   if(isset($_GET['success'])){ ?>
             
             <div class="infobox success-bg">
<a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>             
                    <h4 class="infobox-title"><?php echo $_GET['success'];?></h4>
                </div><?php } ?>
     
    <div class="example-code">
<br>
<br>

        <form id="demo-form-2" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" class="col-md-10 center-margin" method="post" enctype="multipart/form-data">
          
	              
             <div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        First Name: <span class="required">*</span>
                    </label>
                </div>
          <div class="form-input col-md-9">
                    <input  type="text" id="name" name="fname" data-trigger="change" parsley-rangelength="[2,99]" data-required="true" class="parsley-validated">
                </div>
            </div>
            
             <div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        Last Name: <span class="required">*</span>
                    </label>
                </div>
          <div class="form-input col-md-9">
                    <input  type="text" id="name" name="lname" data-trigger="change" parsley-rangelength="[1,25]" data-required="true" class="parsley-validated">
                </div>
            </div>
            
                         <div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        Phone No: <span class="required">*</span>
                    </label>
                </div>
          <div class="form-input col-md-9">
                    <input  type="text" id="name" name="phone" data-trigger="change" parsley-rangelength="[2,99]" data-required="true" class="parsley-validated">
                </div>
            </div>
            <div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        E-mail: 
                    </label>
                </div>
          <div class="form-input col-md-9">
                    <input  type="email" id="name" name="email" data-trigger="change" parsley-rangelength="[2,99]" data-required="true" class="parsley-validated">
                </div>
            </div>
            
            
                         <div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        Customer Address: <span class="required">*</span>
                    </label>
                </div>
           <div class="form-input col-md-9">
                <textarea id="description" name="address" rows="3" data-trigger="change" class="parsley-validated" data-required="true"></textarea>
                
              </div>
            </div>
            <div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        Pincode: <span class="required">*</span>
                    </label>
                </div>
          <div class="form-input col-md-9">
                    <input  type="text" id="name" name="pincode" data-trigger="change" parsley-rangelength="[2,20]" data-required="true" class="parsley-validated">
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        Customer GST No:
                    </label>
                </div>
          <div class="form-input col-md-9">
                    <input  type="text" id="name" name="GST" data-trigger="change" parsley-rangelength="[2,99]" class="parsley-validated">
                </div>
            </div>
            
            				<div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                       Product 1:
                         <span class="required">*</span>
                    </label>
                </div>
                <div class="form-input col-md-4">
                    <input  type="text" id="name" name="pname[]" data-trigger="change" parsley-rangelength="[2,99]" placeholder="product name" data-required="true" class="parsley-validated">
                </div>
                        <div class="form-input col-md-2">
                    <input  type="text" id="name" name="HSC_code[]" data-trigger="change" parsley-rangelength="[2,99]" placeholder="HSC Code" class="parsley-validated">
                </div>
                         <div class="form-input col-md-1">
                    <input  type="text" id="name" name="sku[]" data-trigger="change" parsley-rangelength="[2,99]" placeholder="SKU Code" class="parsley-validated">
                </div>
                         <div class="form-input col-md-1">
                    <input  type="text" id="name" name="qty[]" data-trigger="change" parsley-rangelength="[2,99]" placeholder="Quantity" data-required="true" class="parsley-validated">
                </div>
                         <div class="form-input col-md-1">
                    <input  type="text" id="name" name="price[]" data-trigger="change" parsley-rangelength="[2,99]" placeholder="Unit Price" data-required="true" class="parsley-validated">
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                       Product 2:
                        
                    </label>
                </div>
                <div class="form-input col-md-4">
                    <input  type="text" id="name" name="pname[]" data-trigger="change" parsley-rangelength="[2,99]" placeholder="product name" class="parsley-validated">
                </div>
                        <div class="form-input col-md-2">
                    <input  type="text" id="name" name="HSC_code[]" data-trigger="change" parsley-rangelength="[2,99]" placeholder="HSC Code" class="parsley-validated">
                </div>
                         <div class="form-input col-md-1">
                    <input  type="text" id="name" name="sku[]" data-trigger="change" parsley-rangelength="[2,99]" placeholder="SKU Code" class="parsley-validated">
                </div>
                         <div class="form-input col-md-1">
                    <input  type="text" id="name" name="qty[]" data-trigger="change" parsley-rangelength="[2,99]" placeholder="Quantity" class="parsley-validated">
                </div>
                         <div class="form-input col-md-1">
                    <input  type="text" id="name" name="price[]" data-trigger="change" parsley-rangelength="[2,99]" placeholder="Unit Price" class="parsley-validated">
                </div>
            </div>
            <div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                       Product 3:
                        
                    </label>
                </div>
                              <div class="form-input col-md-4">
                    <input  type="text" id="name" name="pname[]" data-trigger="change" parsley-rangelength="[2,99]" placeholder="product name" class="parsley-validated">
                </div>
                        <div class="form-input col-md-2">
                    <input  type="text" id="name" name="HSC_code[]" data-trigger="change" parsley-rangelength="[2,99]" placeholder="HSC Code" class="parsley-validated">
                </div>
                         <div class="form-input col-md-1">
                    <input  type="text" id="name" name="sku[]" data-trigger="change" parsley-rangelength="[2,99]" placeholder="SKU Code" class="parsley-validated">
                </div>
                         <div class="form-input col-md-1">
                    <input  type="text" id="name" name="qty[]" data-trigger="change" parsley-rangelength="[2,99]" placeholder="Quantity" class="parsley-validated">
                </div>
                         <div class="form-input col-md-1">
                    <input  type="text" id="name" name="price[]" data-trigger="change" parsley-rangelength="[2,99]" placeholder="Unit Price" class="parsley-validated">
                </div>
            </div>
            <div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                       Product 4:
                         
                    </label>
                </div>
                             <div class="form-input col-md-4">
                    <input  type="text" id="name" name="pname[]" data-trigger="change" parsley-rangelength="[2,99]" placeholder="product name" class="parsley-validated">
                </div>
                        <div class="form-input col-md-2">
                    <input  type="text" id="name" name="HSC_code[]" data-trigger="change" parsley-rangelength="[2,99]" placeholder="HSC Code" class="parsley-validated">
                </div>
                         <div class="form-input col-md-1">
                    <input  type="text" id="name" name="sku[]" data-trigger="change" parsley-rangelength="[2,99]" placeholder="SKU Code" class="parsley-validated">
                </div>
                         <div class="form-input col-md-1">
                    <input  type="text" id="name" name="qty[]" data-trigger="change" parsley-rangelength="[2,99]" placeholder="Quantity" class="parsley-validated">
                </div>
                         <div class="form-input col-md-1">
                    <input  type="text" id="name" name="price[]" data-trigger="change" parsley-rangelength="[2,99]" placeholder="Unit Price" class="parsley-validated">
                </div>
            </div>
            <div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                       Product 5:                         
                    </label>
                </div>
                             <div class="form-input col-md-4">
                    <input  type="text" id="name" name="pname[]" data-trigger="change" parsley-rangelength="[2,99]" placeholder="product name" class="parsley-validated">
                </div>
                        <div class="form-input col-md-2">
                    <input  type="text" id="name" name="HSC_code[]" data-trigger="change" parsley-rangelength="[2,99]" placeholder="HSC Code" class="parsley-validated">
                </div>
                         <div class="form-input col-md-1">
                    <input  type="text" id="name" name="sku[]" data-trigger="change" parsley-rangelength="[2,99]" placeholder="SKU Code" class="parsley-validated">
                </div>
                         <div class="form-input col-md-1">
                    <input  type="text" id="name" name="qty[]" data-trigger="change" parsley-rangelength="[2,99]" placeholder="Quantity" class="parsley-validated">
                </div>
                         <div class="form-input col-md-1">
                    <input  type="text" id="name" name="price[]" data-trigger="change" parsley-rangelength="[2,99]" placeholder="Unit Price" class="parsley-validated">
                </div>
            </div>
            
                                
	                 <div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        Shipping Charges: <span class="required">*</span>
                    </label>
                </div>
          <div class="form-input col-md-9">
                    <input  type="text" id="name" name="shipping" data-trigger="change" parsley-rangelength="[2,99]" data-required="true" class="parsley-validated">
                </div>
            </div>
            
             <div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        Courier Name: <span class="required">*</span>
                    </label>
                </div>
          <div class="form-input col-md-9">
                    <input  type="text" id="name" name="courier" data-trigger="change" parsley-rangelength="[2,20]" data-required="true" class="parsley-validated">
                </div>
            </div>
            
            <div class="form-row">
          <div class="form-label col-md-3">
            <label for="">Shipping date: <span class="required">*</span></label>
          </div>
          <div class="form-input col-md-9">
            <input type="text" name="sdate" class="fromDate" data-trigger="change" data-required="true" class="parsley-validated" autocomplete="off">
          </div>
        </div>
          
            <div class="divider"></div>
            <div class="form-row">
                <input type="hidden" name="superhidden" id="superhidden">
                <div class="form-input col-md-10 col-md-offset-3">
               <button type="submit" name="submit"  class="btn large primary-bg" onclick="javascript:$(&apos;#demo-form-2&apos;).parsley( &apos;validate&apos; );"><span class="button-content">Save Data</span></button>
&nbsp;
                        <a href="../admin_dashboard.php" class="btn large bg-red" title="">
            <span class="button-content">Cancel</span>
        </a>

                </div>
            </div>

        </form>

    </div>
    
</div>
</div>
<!-- #page-content -->
</div>
<!-- #page-main -->
</div>
<!-- #page-wrapper -->

</body>
</html>

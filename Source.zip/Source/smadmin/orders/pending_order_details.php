<?php
include "../db/session.php";  
//include "../function/config.php"; 
include "../db/db_connect.php"; 
include "../function/function.php";
	
//////////////////////////order details/////////////////////////////

if(isset($_GET['id']))
{ 
extract($_GET); 
$query = "SELECT t1.*, t2.email, t2.phone FROM pending_orders as t1 INNER JOIN bb_users as t2 ON t1.cid = t2.id WHERE t1.id = ? ORDER BY orderdate DESC";

if(!$rstmt = $con->prepare($query))
{
	echo $error = "order details preparation failed!".$con->error;
}
	if(!$rstmt->bind_param("i", $id))
{
	echo "Param pass failed: (" . $con->errno . ") " . $con->error;
}
	
	if(!$rstmt->execute())
	{
		echo $error = "order details execution failed!".$con->error;		
		
	}    
    
    if(!$qresult = $rstmt->get_result())
		{
			$error = "Product data listing failed!".$con->error;					
		}
    else
    {
        $data = $qresult->fetch_assoc();
        $verify_sign = $data['verify_sign'];
    }
    
}

/////////////////////////////product details//////////////////////////////////////////

if(isset($_GET['id']))
{ 
extract($_GET); 

$id = secure_input($con,$id);	    
$status = secure_input($con,$status);	        
$oquery = "SELECT id, orderid, pid, sku, name, category, sub_category, product_type, picture, color, size, qty, price, cost FROM bb_order_products WHERE verify_sign = ?";

	
if(!$orstmt = $con->prepare($oquery))
{
	echo $error = "order details preparation failed!".$con->error;
}
	if(!$orstmt->bind_param("s", $verify_sign))
{
	echo "Param pass failed: (" . $con->errno . ") " . $con->error;
}
	
	if(!$orstmt->execute())
	{
		echo $error = "order details execution failed!".$con->error;		
		
	}
	
	if(!$orstmt->store_result())
		{
			echo $error = "order listing execution failed!".$con->error;					
		}
	
	
	$ornum_of_rows = $orstmt->num_rows;

	if($ornum_of_rows==0)
{
	$error = "No products available";		
}
	
}

?>
<!DOCTYPE html>
<html>
<head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title><?php echo $_SESSION['cName']; ?> Admin Area</title>
   <?php include("../header.php"); ?>
        <script type="text/javascript" src="<?php echo $_SESSION['gpath']; ?>assets/js/minified/widgets/charts-justgage.min.js"></script>

<style>

.dataTables_scrollBody
{
	height:500px !important;

}

</style>

    </head>
<body>
<div id="loading" class="ui-front loader ui-widget-overlay bg-white opacity-100"> <img src="../assets/images/loader-dark.gif" alt=""> </div>
<div id="page-wrapper" class="demo-example"> 
  <!-- #page-header -->
  
  <?php include("../sidebar.php"); ?>
  <!-- #page-sidebar -->
  <div id="menu-right" class="scrollable-content hidden">
    <div class="toggle-content-open clearfix">
      <div id="g10" class="small-gauge float-left"></div>
      <div id="g11" class="small-gauge float-right"></div>
    </div>
  </div>
  <div id="page-content-wrapper">
            
                <div id="page-title">

<h3>
    View/Update Order details - #SM<?php echo $id." (<strong> ".$data['orderstatus']."</strong>)"; ?>
</h3>
                    
                    <div id="breadcrumb-right">
   
                        <div class="float-right">
               <a href="<?php echo $_SESSION['gpath']; ?>orders/list_pending_orders.php" title="Orders" class="btn medium bg-white">
            <span class="button-content">Back to Orders</span>
        </a>  
       
                        </div>
                    </div>
</div><!-- #page-title -->

            
<div id="page-content">
<div class="example-box">
<?php 
			   if(isset($error)){ ?>
             
             <div class="infobox error-bg">
<a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>             
<div class="bg-red large btn info-icon">
                        <i class="glyph-icon icon-remove"></i>
                    </div>
                    <h4 class="infobox-title"><?php echo $error;?></h4>
                    <p>Some error in the database query occured. Please try again!</p>
                </div>
            </div><?php } ?>
            
<?php 
			   if(isset($success)){ ?>
             
             <div class="infobox success-bg">
<a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>             
                    <h4 class="infobox-title"><?php echo $success;?></h4>
                </div>
            </div><?php } ?>
	  
    <div class="example-code">
<br>
<br>

        <form id="demo-form-2" action="" class="col-md-10 center-margin" method="post">
			<div class="content-box mrg25B">
          <h3 class="content-box-header primary-bg"> <span>Ordered Item(s)</span> </h3>
          <div class="content-box-wrapper">
			  <table class="table text-center">
            <thead>
                <tr>
                    <th class="text-center" width="5%"></th>
                    <th width="15%">PRODUCT</th>
					<th width="10%"></th>
                    <th class="text-center" width="10%">SKU</th>
                    <th class="text-center" width="10%">CATEGORY</th>
                    <th class="text-center" width="10%">COLOR</th>
                    <th class="text-center" width="10%">SIZE</th>
                    <th class="text-center" width="10%">QTY</th>
					<th class="text-center" width="10%">PRICE</th>
					<th class="text-center" width="10%">TOTAL</th>
                </tr>
            </thead>
            <tbody>
				 
    <?php 
	$sn = 0;
				$GST = 0;
	$orstmt->bind_result($id, $orderid, $pid, $sku, $name, $category, $sub_category, $product_type, $picture, $color, $size, $qty, $price, $cost);
	while ($orstmt->fetch()) 
	{
			$sn = 	$sn + 1;
		$name = ucwords($name);
	?>
    
				
                <tr>
                    <td><?php echo $sn; ?></td>
                   <td class="font-bold text-left"><?php echo $name; ?></td>
					 <td class="font-bold text-left"><img src="../<?php echo $picture; ?>" width="100%" alt=""/></td>
                    <td><?php echo $sku; ?></td>
                    <td><?php echo $category."=>".$product_type."=>".$sub_category; ?></td>
                    <td><?php echo $color; ?></td>
                    <td><?php echo $size; ?></td>
					<td><?php echo $qty; ?></td>
					<td>&#x20b9; <?php echo $price; ?></td>
                  
				  <td>&#x20b9; <?php echo $total = $qty * $price; ?></td>
                </tr>
                   <?php } ?>
       <tr>
                    <td></td>
                    <td class="font-bold text-left"></td>
                  <td></td>
		   <td></td>
                <td></td>
		   <td></td>
                <td></td>
		   <td colspan="2" align="right" class="h4">Shipping:</td>
                  <td class="h4"><?php if($data['shipping']>0) { echo "&#x20b9; ".$data['shipping']; } else { echo "Free"; } ?></td>
                </tr>
				  <tr>
                    <td></td>
                    <td class="font-bold text-left"></td>
                  <td></td>
		   <td></td>
                           <td></td>
		   <td></td>     <td></td>
		   <td colspan="2" align="right" class="h4">Order Total:</td>
                  <td class="h2">&#x20b9; <?php echo $data['cost']; ?></td>
                </tr>
            </tbody>
        </table>
			  
		  </div></div>
  	 
			<div class="content-box mrg25B">
          <h3 class="content-box-header primary-bg"> <span>Order Details</span> </h3>
          <div class="content-box-wrapper">
			  
			<div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        Order Date:
                         
                    </label>
                </div>
                <div class="form-input col-md-9">
                    <?php echo date('l - dS M, Y - h:i:s A', strtotime($data['orderdate'])); ?>
                </div>
            </div>

			<div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        Order Cost:
                         
                    </label>
                </div>
                <div class="form-input col-md-9">
                  &#x20b9; <?php echo $data['cost']; ?>
                </div>
            </div>
			<div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        Total Items:
                         
                    </label>
                </div>
                <div class="form-input col-md-9">
                    <?php echo $data['titems']; ?>
                </div>
            </div>
			<div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        Current order status:
                         
                    </label>
                </div>
                <div class="form-input col-md-9">
                    <?php echo $data['orderstatus']; ?>
                </div>
            </div>
			<div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        Name:
                         <span class="required">*</span>
                    </label>
                </div>
                <div class="form-input col-md-9">
                    <?php echo ucwords($data['fname']." ".$data['lname']); ?>
                </div>
            </div>
            
             <div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        Contact:                       
                    </label>
                </div>
                 <div class="form-input col-md-9">
                    <?php echo $data['phone']; ?>
                </div>
            </div>
			
			       <div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        Email:                        
                    </label>
                </div>
                 <div class="form-input col-md-9">
                    <?php echo $data['email']; ?>
                </div>
            </div>
	
            <div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        Shipping address:                     
                    </label>
                </div>
                <div class="form-input col-md-9">
				 <?php echo $data['address']; ?>
                </div>
            </div>
			
            </div>
            </div>
            
            
            
        </form>

    </div>
    
</div>
</div>
<!-- #page-content -->
</div>
<!-- #page-main -->
</div>
<!-- #page-wrapper -->

</body>
</html>

<?php
include "../function/config.php"; 
include "../db/db_connect.php"; 
include "../db/session.php";  
include "../function/function.php";
//////////////////////delete////////////////////////
if(isset($_GET['id'])&&$_GET['id']!=''&&isset($_GET['action'])&&$_GET['action']=='delete')
{
extract($_GET);	
$query = "DELETE FROM pending_orders WHERE id ='$id'";
$qresult = mysqli_query($con,$query);
if(!$qresult)
{
	$error = "Record deleting failed!".mysqli_error($con);
}
else
{
$success= "Record deleted successfully!";	
}
} 

/////////////////////////////////////////////////////////////////////////////////////////
$order_type = 1;
if(isset($_GET['status'])&&$_GET['status']!="All"&&$_GET['status']!="")
{
    extract($_GET);
    
 $status = secure_input($con,$status);

        $query = "SELECT t1.id, CONCAT(t1.fname,' ',t1.lname) as name, t1.cost, t1.mc_gross, t1.shipping, t1.titems, t1.orderdate, t1.orderstatus, t2.phone, t2.email, t2.state FROM pending_orders as t1 INNER JOIN bb_users as t2 ON t1.cid = t2.id WHERE t1.orderstatus = ? AND t1.order_type = ? ORDER BY t1.orderdate DESC";
        
        if(!$ostmt = $con->prepare($query))
            {
                echo $error = "categories data listing preparation failed!".$con->error; exit();	
            }
    
        if (!$ostmt->bind_param( 'si', $status, $order_type)) {
            echo $error = "Product data listing preparation failed!" . $con->error; exit();         
        }

}
else
{
         $query = "SELECT t1.id, CONCAT(t1.fname,' ',t1.lname) as name, t1.cost, t1.mc_gross, t1.shipping, t1.titems, t1.orderdate, t1.orderstatus, t2.phone, t2.email, t2.state FROM pending_orders as t1 INNER JOIN bb_users as t2 ON t1.cid = t2.id AND t1.order_type = ? ORDER BY t1.orderdate DESC";
    
        if(!$ostmt = $con->prepare($query))
            {
                echo $error = "categories data listing preparation failed!".$con->error; exit();	
            }
    
     if (!$ostmt->bind_param( 'i', $order_type)) {
            echo $error = "Product data listing preparation failed!" . $con->error; exit();         
        }
}
	
	if(!$ostmt->execute())
	{
		echo $error = "orders data listing execution failed!".$con->error;	exit();	
		
	}
		if(!$ostmt->store_result())
		{
			echo $error = "orders data listing execution failed!".$con->error;	exit();					
		}
	
	$onum_of_rows = $ostmt->num_rows; 

	if($onum_of_rows==0)
{
	$error = "No orders available";		
}

//////////////////////////////////


?>
<!DOCTYPE html>
    <html>
    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title><?php echo $_SESSION['cName']; ?> Admin Area</title>
   <?php include("../header.php"); ?>
        <script type="text/javascript" src="<?php echo $_SESSION['gpath']; ?>assets/js/minified/widgets/charts-justgage.min.js"></script>

<style>

.dataTables_scrollBody
{
	height:500px !important;

}

</style>

    </head>
    <body>
        

        <div id="loading" class="ui-front loader ui-widget-overlay bg-white opacity-100">
            <img src="../assets/images/loader-dark.gif" alt="">
        </div>

        <div id="page-wrapper" class="demo-example">
          <!-- #page-header -->

            <?php include("../sidebar.php"); ?>
            <!-- #page-sidebar -->
            <div id="menu-right" class="scrollable-content hidden">
                <a href="javascript:;" title="Get Source" class="popover-title button-toggle-open">
                    Cloud status
                    <i class="glyph-icon icon-caret-right icon-caret-down"></i>
                </a>
                <div class="clear"></div>
                <a href="javascript:;" title="Get Source" class="popover-title button-toggle-open">
                    Realtime server load
                    <i class="glyph-icon icon-caret-right icon-caret-down"></i>
                </a>
                <div class="toggle-content-open clearfix">

                    <div id="g10" class="small-gauge float-left"></div>
                    <div id="g11" class="small-gauge float-right"></div>
                </div>
            </div>

            <div id="page-content-wrapper">
                <div id="page-title">
                    

<h3>
  <h3><?php if(isset($_GET['status'])) { echo $_GET['status']." Orders"; } ?> </h3><br>
    
    <?php 
			   if(isset($success)){ ?>

             
             <div class="infobox success-bg">
<a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>             
                    <h4 class="infobox-title"><?php echo $success;?></h4>
                </div><?php } ?>
              </div><!-- #page-title -->
<div id="page-content">

<script type="text/javascript">

$(document).ready(function() {

});

</script>

<h4>&nbsp;</h4>

<table class="table" id="example1">
  <thead>
		<tr>
			<th width="5%">S.No</th>
			<th width="8%">Order ID</th>
			<th width="10%">Name</th>
			<th width="10%">Mobile</th>        
            <th width="8%">E-mail</th>        
			<th width="7%">Cost</th>        
			<th width="8%">Total Items</th>
			<th width="10%">Order Status</th>
			<th width="15%">Order Date</th>            
			<th width="10%">Action</th>
		</tr>
	</thead>
	<tbody>
    
    
    <?php 
	$sn = 0;
	$ostmt->bind_result($id, $name, $cost, $mc_gross, $shipping, $titems, $odate, $ostatus, $contact, $contact_email, $state);
	while ($ostmt->fetch()) 
	{
			$sn = 	$sn + 1;
		$name = ucwords($name);
	?>
    
		<tr>
			<td><?php echo $sn;?></td>
			<td>SM<?php echo $id; ?></td>
			<td><?php echo $name; ?></td>
			<td><?php echo $contact; ?></td>
            <td><?php echo $contact_email; ?></td>
			<td>₹<?php if($mc_gross!=NULL) { echo $mc_gross; } else { echo $cost; } ?></td>			
			<td><?php echo $titems; ?></td>
			<td><?php echo $ostatus; ?></td>
			<td><?php echo date('l - dS M, Y - h:i:s A', strtotime($odate)); ?></td>       
			<td>
                                <div class="dropdown">
                                    <a href="javascript:;" title="" class="btn medium bg-blue" data-toggle="dropdown">
                                        <span class="button-content">
                                            <i class="glyph-icon font-size-11 icon-cog"></i>
                                            <i class="glyph-icon font-size-11 icon-chevron-down"></i>
                                        </span>
                                    </a>
                                    <ul class="dropdown-menu float-right">

                                        <li>
                                            <a href="pending_order_details?id=<?php echo $id; ?>&status=<?php echo $ostatus; ?>" title="">
                                                <i class="glyph-icon icon-edit mrg5R"></i>
                                                View Details
                                            </a>
                                        </li>
                                        <li>
                                            <a href="list_pending_orders.php?id=<?php echo $id; ?>&action=delete" title="" onclick="return confirm('Are you sure you want to delete this order?');" class="font-red">
                                                <i class="glyph-icon icon-remove mrg5R"></i>
                                                Delete
                                            </a>
                                        </li>
                                        
                                    </ul>
                                </div>
                            </td>
		</tr>
        
        <?php } ?>
        
	</tbody>
	<tfoot>
		<tr>
			<th></th>
			<th></th>
			<th></th>
            <th></th>
			<th></th>
			<th></th>			
			<th></th>
			<th></th>			
			<th></th>
		</tr>
	</tfoot>
</table>


                	</div><!-- #page-content -->
            </div>




                	</div><!-- #page-content -->
            </div><!-- #page-main -->
        </div><!-- #page-wrapper -->

    </body>
</html>


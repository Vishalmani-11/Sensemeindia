<?php
 if(isset($_GET["order_id"]))  
  { 
require_once('../../pdf/html2pdf.php');
require_once "../db/db_connect.php"; 
require_once "../function/function.php";

$pdf=new PDF();
$pdf->AliasNbPages();
$pdf->SetTitle("invoice");
////add page page automatically for its true parameter

$pdf->SetAutoPageBreak(true, 15);
$pdf->AddPage();
//add images or logo which you want
$pdf->Image('../../assets/img/logo/logo.png',85,15,50);
//set font style
$pdf->SetFont('Arial','B',14);
//assign the form post value in a variable and pass it.
     
$order_id = secure_input($con,$_GET["order_id"]); 
/////////////////////////////order details/////////////////////////////////////     
$query = "SELECT * from bb_orders WHERE id = ?";

if(!$rstmt = $con->prepare($query))
{
	echo $error = "order details preparation failed!".$con->error; exit();
}
	if(!$rstmt->bind_param("i", $order_id))
{
	echo "Param pass failed: (" . $con->errno . ") " . $con->error;exit();
}
	
	if(!$rstmt->execute())
	{
		echo $error = "order details execution failed!".$con->error;	exit();	
		
	}    
    
    if(!$qresult = $rstmt->get_result())
		{
			$error = "Product data listing failed!".$con->error;	exit();				
		}
    else
    {
        $data = $qresult->fetch_assoc();
    }

/////////////////////////////product details//////////////////////////////////////////
   
	
$oquery = "SELECT id, orderid, sku, hsc_code, name, qty, price, cost FROM bb_order_products_offline WHERE orderid = ?";

	
if(!$orstmt = $con->prepare($oquery))
{
	echo $error = "order details preparation failed!".$con->error;exit();
}
	if(!$orstmt->bind_param("i", $order_id))
{
	echo "Param pass failed: (" . $con->errno . ") " . $con->error;exit();
}
	
	if(!$orstmt->execute())
	{
		echo $error = "order details execution failed!".$con->error;	exit();	
		
	}
	
	if(!$orstmt->store_result())
		{
			echo $error = "order listing execution failed!".$con->error;	exit();				
		}
	
	
	$ornum_of_rows = $orstmt->num_rows;

	if($ornum_of_rows==0)
{
	$ornum_error = "No products available";		
}
	
/////////////////////////////////////////invoice header/////////////////////////////////////////     

$header='INVOICE/CASH MEMO';
$pdf->SetFont('Arial','B',16);
$pdf->SetY(40);     
$pdf->Cell(200,7,$header,0,1,'C');
$pdf->SetFont('Arial','B',10);
$pdf->SetTextColor(0, 0, 0);
$pdf->Ln();
$pdf->Ln();     
$company_address = "MYLAL EXPORTS \nNo. 38, Machampalayam road, \nSundarapuram, Coimbatore, \nTamil Nadu 641607. \nGST Registration No: 33AMDPM8320N1ZW";     
$pdf->MultiCell(95,7,"Sold by",0,'L',false); 
$pdf->SetTextColor(92, 92, 92);     
$pdf->MultiCell(95,7,$company_address,0,'L',false); 
$pdf->SetXY(105,60);     
$order_details = "Invoice date: ".date('D, dS M, Y', strtotime($data['orderdate']))."\n Invoice# :".$order_id;     
$pdf->MultiCell(95,7,$order_details,0,'R',false); 
$pdf->Line(10, 115, 200, 115);     
$pdf->SetXY(10,120);       
$billing = "Billing Address:\n".$data['address']."\nGST: ".$data['customer_GST'];     
$pdf->MultiCell(95,7,$billing,0,'L',false);      
$pdf->SetXY(105,120);              
$delivery = "Delivery Address:\n".$data['address'];     
$pdf->MultiCell(95,7,$delivery,0,'R',false);  
$pdf->Ln();          
$pdf->SetFillColor(0,0,0);
$pdf->SetTextColor(255,255,255);
$pdf->Cell(190,7,"ORDER SUMMARY",1,1,'C', true);  
$pdf->SetTextColor(0, 0, 0);     
   $cdata ='<table border="1"><tr><td width="50" height="60">S.No</td><td width="490" height="60">Description</td><td width="80" height="60">Unit Price</td><td width="50" height="60">Qty</td><td width="90" height="60">Total Price</td></tr>';

     $pdf->WriteHTML("$cdata");  
     
    $pdf->SetTextColor(145, 145, 145);  
	
     $cdata = "";
        $sn = 0;

	$orstmt->bind_result($id, $orderid, $sku, $hsc_code, $name, $qty, $price, $cost);
	while ($orstmt->fetch()) 
	{
			$sn = 	$sn + 1;
		$name = ucwords($name);
	
    
		$cdata .='<tr><td width="50" height="50">'.$sn.'</td><td width="490" height="50">'.$name.'('.$sku.')HSC: '.$hsc_code.'</td>';$cdata .='</td><td width="80" height="50">Rs '.bcdiv($price,1,2).'</td><td width="50" height="50">'.$qty.'</td><td width="90" height="50">Rs '.bcdiv($total = $qty * $price,1,2).'</td></tr>';
                    } 
     
         $pdf->WriteHTML("$cdata");  
     
    $pdf->SetTextColor(0, 0, 0); 
     
     $net_price = $data['mc_gross']*100/118;
     
     $gst = $data['mc_gross'] - $net_price;
     
     $gst2 = $gst/2;
     
    $cdata ='<tr align="center"><td width="670" height="50" colspan="5" align="right">SHIPPING:</td><td width="90" height="50">'; 
     if($data['shipping']>0) { $cdata .='Rs '.bcdiv($data['shipping'],1,2); } else { $cdata .='Free'; }

$cdata .='</td></tr>';     
$cdata .='<tr><td width="670" height="50"><strong>TOTAL:(GST inclusive)</strong></td><td width="90" height="50"><strong>Rs '.bcdiv($data['mc_gross'],1,2).'</strong></td></tr>'; 
     
 $cdata .='<tr><td width="760" height="50" colspan="5" >Total GST: Rs '.bcdiv($gst,1,2).'(CGST 9%: Rs '.bcdiv($gst2,1,2).' | SGST 9%: Rs '.bcdiv($gst2,1,2).'</td></tr>';      
     
$cdata .='</table> ';

//     echo $cdata; exit();
//Write HTML to pdf file and output that file on the web browser.

$pdf->WriteHTML("$cdata");  
$pdf->SetFont('Arial','B',6);
$pdf->Output('D','SM_invoice_copy_offline.pdf');
     
     
 }
?>


<?php
session_start();
include "db/db_connect.php"; 
require_once 'admin/class.user.php';
include "function/function.php";  

// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);

$user_login = new USER();

if($user_login->is_logged_in()!="")
{
	$user_login->redirect('admin_dashboard.php');
}

if(isset($_POST['adminlogin']))
{
	extract($_POST);
	$uname = secure_input($con,$username);
	$uname = strtolower($username);
	$upass = secure_input($con,$userpswd);

	
	if($user_login->login($uname,$upass))
	{
		$user_login->redirect('admin_dashboard.php');
	}
}

if(isset($_POST['recoverpswd']))
{
  
	$email = "";
	
	$email = trim($_POST['remail']);
	$email = mysqli_real_escape_string($con,$email);
	
	$stmt = $user_login->runQuery("SELECT * FROM ecrm_employees WHERE email=:email LIMIT 1");
	$stmt->execute(array(":email"=>$email));
	$row = $stmt->fetch(PDO::FETCH_ASSOC);	
      
	if($stmt->rowCount() == 1)
	{
        $id = base64_encode($row['id']);
		$code = md5(uniqid(rand()));
		$tokenac = 0;
    	$stmt = $user_login->runQuery("UPDATE ecrm_employees SET tokenCode=:token, tokenAc=:tokenac WHERE email=:email");
		$stmt->execute(array(":token"=>$code,":tokenac"=>$tokenac,"email"=>$email));
		
		$message= "
				   Hello , $email
				   <br /><br />
				   We have received a request to reset your password, if you do this then just click the following link to reset your password, if not just ignore this email,
				   <br /><br />
				   Click Following Link To Reset Your Password! 
				   <br /><br />
				   <a href='https://sensemeindia.com/smadmin/resetpass.php?id=$id&code=$code'>click here to reset your password</a>
				   <br /><br />
				   Thank you!
				   ";
		$subject = "Password Reset";
		$from = "admin@sensemeindia.com";
        echo $email;
		$mresult = $user_login->send_mail($from,$email,$message,$subject);
		if($mresult=='success')
		{		
		header("location:index.php?rmsg=$email");		
		}
		else
		{
			exit("error in sending mail".$mresult); 
		}
	}
	else
	{
		header("location:index.php?remsg");				
	}

}
?>

<?php
include "db/db_connect.php"; 
include "db/session.php";  

////////////////////////update/////////////////////////
if(isset($_POST['submit']))
{
extract($_POST);	
$nquery = "SELECT * FROM pgallery WHERE album = '$album'";
$cresult =  mysqli_query($con,$query);
$num_rows = mysqli_num_rows($cresult);
$total = $num_rows;
if($total<25)
{
/////////////////////////////Image upload
$pimage ="";
$allowedExts = array("gif", "jpeg", "jpg", "png");
if(($_FILES['file']['error']==0))
{	
$exten = explode(".", $_FILES["file"]["name"]);
$extension = end($exten);
if ((($_FILES["file"]["type"] == "image/gif")
|| ($_FILES["file"]["type"] == "image/jpeg")
|| ($_FILES["file"]["type"] == "image/jpg")
|| ($_FILES["file"]["type"] == "image/pjpeg")
|| ($_FILES["file"]["type"] == "image/x-png")
|| ($_FILES["file"]["type"] == "image/png"))
&& ($_FILES["file"]["size"] < 5000000)
&& in_array($extension, $allowedExts))
  {
    $filename = $_FILES["file"]["name"];
   	 $newfilename = uniqid('thumb', true) .'.'.$extension;
     move_uploaded_file($_FILES["file"]["tmp_name"],"uploads/gallery/" . $filename);
     $pimage = "uploads/gallery/" .$filename;	  					    
  }
else
  {
  echo "Invalid file selected! please try again!";
  }
}
////////////////////////////////
$query = "INSERT INTO pgallery (name,album,image) values ('$title','$album','$pimage')";
$qresult = mysqli_query($con,$query);
if($qresult)
{
	$success= "Photo uploaded successfully!";
	header('location:photo_gallery.php?album='.$album.'&success='.$success);
}
else
{
	$error = "Photo upload failed!".mysqli_error($con);
	header('location:photo_gallery.php?album='.$album.'&error='.$error);	
}
}
}
//////////////////////////////////////////

?>
<!DOCTYPE html>
    <html>
    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>Brave Hearts Admin Area</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

        <!-- Favicons -->

        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/images/icons/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/images/icons/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/images/icons/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="assets/images/icons/apple-touch-icon-57-precomposed.png">
        <link rel="shortcut icon" href="assets/images/icons/favicon.png">
		<script src="editor/ckeditor/ckeditor.js"></script>
        <!--[if lt IE 9]>
          <script src="assets/js/minified/core/html5shiv.min.js"></script>
          <script src="assets/js/minified/core/respond.min.js"></script>
        <![endif]-->

        <!-- Fides Admin CSS Core -->

        <link rel="stylesheet" type="text/css" href="assets/css/minified/aui-production.min.css">

        <!-- Theme UI -->

        <link id="layout-theme" rel="stylesheet" type="text/css" href="assets/themes/minified/fides/color-schemes/dark-blue.min.css">

        <!-- Fides Admin Responsive -->

        <link rel="stylesheet" type="text/css" href="assets/themes/minified/fides/common.min.css">
        <!-- <link rel="stylesheet" type="text/css" href="../_assets/themes/fides/common.css"> -->

        <link id="theme-animations" rel="stylesheet" type="text/css" href="assets/themes/minified/fides/animations.min.css">

        <link rel="stylesheet" type="text/css" href="assets/themes/minified/fides/responsive.min.css">

        <!-- Fides Admin JS -->

        <script type="text/javascript" src="assets/js/minified/aui-production.min.js"></script>

        <script type="text/javascript" src="assets/js/minified/core/raphael.min.js"></script>
        <script type="text/javascript" src="assets/js/minified/widgets/charts-justgage.min.js"></script>

    </head>
    <body>
        

        <div id="loading" class="ui-front loader ui-widget-overlay bg-white opacity-100">
            <img src="assets/images/loader-dark.gif" alt="">
        </div>

        <div id="page-wrapper" class="demo-example">
          <!-- #page-header -->

                        <?php include("sidebar.php"); ?><!-- #page-sidebar -->
            <div id="menu-right" class="scrollable-content hidden">
                <div class="toggle-content-open clearfix">
                    <div id="g10" class="small-gauge float-left"></div>
                    <div id="g11" class="small-gauge float-right"></div>
                </div>
            </div>

          
            <div id="page-content-wrapper">
            
                <div id="page-title">

<h3>
    Add Photo > Album Name:&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $_GET['album'];?></h3>
</div><!-- #page-title -->
<div id="page-content">
<h3></h3> 
<?php 
			   if(isset($error)){ ?>

<div class="example-box">
             
             <div class="infobox error-bg">
<a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>             
<div class="bg-red large btn info-icon">
                        <i class="glyph-icon icon-remove"></i>
                    </div>
                    <h4 class="infobox-title"><?php echo $error;?></h4>
                    <p>Some error in the database query occured. Please try again!</p>
                </div>
            </div>
            <?php } ?>
            
<?php 
			   if(isset($success)){ ?>
             
             <div class="infobox success-bg">
<a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>             
                    <h4 class="infobox-title"><?php echo $success;?></h4>
                    <p>You can view or edit consignments detals through edit consignment link.</p>                    
                </div>
            <?php } ?>
    <div class="example-code">

        <form id="demo-form-2" action="" class="col-md-10 center-margin" method="post" enctype="multipart/form-data">
            
            <div class="form-row">
                <div class="form-label col-md-2">
                    <label for="">
                        Photo Title:
                        <span class="required">*</span>
                    </label>
                </div>
                <div class="form-input col-md-10">
                    <input type="text" id="title" name="title" data-trigger="change" data-required="true" class="parsley-validated">
                </div>
            </div>
                   <div class="form-row">
          <div class="form-label col-md-2">
            <label for=""> Select Photo:<span class="required">*</span> </label>
          </div>
          <div class="float-left col-md-10"> <span class="btn medium bg-green fileinput-button"> <span class="button-content">Maximum width: 1200px X Height: 800px  -  only (gif, jpeg, jpg, png)
              <input type="file" name="file" multiple required>
            </span> </div>
        </div>
       
            <div class="divider"></div>
            <div class="form-row">
                <input type="hidden" name="superhidden" id="superhidden">
                <input type="hidden" name="album" id="album" value="<?php echo $_GET['album']; ?>">                
                <div class="form-input col-md-10 col-md-offset-2">
                <button class="btn primary-bg medium" type="submit" name="submit" onclick="javascript:$(&apos;#demo-form-2&apos;).parsley( &apos;validate&apos; );">
            <span class="button-content">Add Photo</span>
        </button>
        
               <!--<span class="btn large primary-bg button-content"><input type="submit" name="submit" value="Save Changes" onclick="javascript:$(&apos;#demo-form-2&apos;).parsley( &apos;validate&apos; );">
                        </span>-->

                </div>
            </div>

        </form>

    </div>
    </div>
</div>




                	</div><!-- #page-content -->
            </div><!-- #page-main -->
        </div><!-- #page-wrapper -->

    </body>
</html>


<?php
include "db/session.php"; 
include "db/db_connect.php"; 
include "function/function.php"; 
require_once 'admin/class.user.php';
?>
<!DOCTYPE html>
<html>
<head>

 <?php include("header.php"); ?>
 <script type="text/javascript" src="<?php echo $_SESSION['gpath']; ?>assets/js/minified/widgets/charts-justgage.min.js"></script>
</head>
<body>
<div id="loading" class="ui-front loader ui-widget-overlay bg-white opacity-100"> <img src=" <?php echo $_SESSION['gpath']; ?>assets/images/loader-dark.gif" alt=""> </div>
<div id="page-wrapper" class="demo-example"> 
  
  <!-- #page-header -->
  <?php include("sidebar.php"); ?>
  <!-- #page-sidebar -->
  <div id="menu-right" class="scrollable-content hidden">
    <div class="toggle-content-open clearfix">
      <div id="g10" class="small-gauge float-left"></div>
      <div id="g11" class="small-gauge float-right"></div>
    </div>

  </div>

  <div id="page-content-wrapper">
    <div id="page-title">
      <h3>Welcome to Dashboard!</h3>
    </div>
    <!-- #page-title -->
    <div id="page-content">
		<div class="example-box">
<?php 
			   if(isset($_GET['error'])){ ?>
             
             <div class="infobox error-bg">
<a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>             
<div class="bg-red large btn info-icon">
                        <i class="glyph-icon icon-remove"></i>
                    </div>
                    <h4 class="infobox-title"><?php echo $_GET['error'];?></h4>
                    <p>Some error in the database query occured. Please try again!</p>
                </div>
            </div><?php } ?>
            
<?php 
			   if(isset($_GET['success'])){ ?>
             
             <div class="infobox success-bg">
<a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>             
                    <h4 class="infobox-title"><?php echo $_GET['success'];?></h4>
                </div>
            </div><?php } ?>
           <p class="font-size-16"><strong>Your last login:</strong> <?php if($_SESSION['lastlogintime']!=NULL) { echo date("jS D, M Y h:i:sA",strtotime($_SESSION['lastlogintime'])); } else { echo "N/A"; } ?>  </p>
<p class="font-size-16"><strong>Your Role:</strong>  <?php echo $_SESSION['adminRole']; ?></p>    
<p class="font-size-16"><strong>Your IP:</strong>  <?php echo $cip = get_client_ip(); ?></p>    


  <!-- #page-main --> 
</div>
<!-- #page-wrapper -->

</body>
</html>

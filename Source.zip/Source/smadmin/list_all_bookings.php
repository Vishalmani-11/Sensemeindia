<?php
include "db/db_connect.php"; 
include "db/session.php";  
include "function/function.php";  
require_once 'admin/class.user.php';
//////////////////////delete////////////////////////
if(isset($_GET['id'])&&$_GET['id']!=''&&isset($_GET['cancel']))
{
extract($_GET);	

$cancellation = 2;
$status = "Cancelled";	
$email_notifitcation=0;

$uquery = "UPDATE rrg_booking SET bookingStatus = ?, cancellation = ? WHERE id=?";

if(!$ustmt = $con->prepare($uquery))
{
	echo "prepare failed: (" . $con->errno . ") " . $con->error; exit();
}

if(!$ustmt->bind_param("sii", $status, $cancellation, $id))	
{
	echo "Param pass failed: (" . $con->errno . ") " . $con->error; exit();
}

if($ustmt->execute()) {
	$email_notifitcation==1;
	/////////////////////email/////////////////////////////////////////////////
	if($email_notifitcation==1)
		{
		$message = "					
						Hello,
						<br /><br />
						cancellation request was successful! We have cancelled your booking & you will get your refund amount soon for booking ID: RR$id <br/>
						Call the hotel for any help.
						<br /><br />
						Thank you. We look forward to you again!";
						
			$subject = "RR Home Stays booking cancellation";
			$from = "info@htsuite.net";	
			$email = "samy.hts@gmail.com";	
		
			
			if($mail_result = $reg_user->send_mail($from,$email,$message,$subject))	
			{
			$msg = "
					<div class='room-box background-grey mb-5 text-center'>
			<div class='room-box-in'>
										<h5><span class='green'>Cancellation request was sent Successfully!</span><br>
 We will get back to you within 24 hrs</h5>
									</div></div>
					";	
				
				
			}
			else
			{
				echo $mail_result."sorry! there was a problem in sending mail. Try later!"; exit();
			}
		
		$success = "booking cancelled successfully!".$con->error;
	header("location:list_all_bookings.php?success=".$success);		
				exit();				
			
	}
		/////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	
}
else
{
	$error = "booking details update failed!".$con->error;
	header("location:list_all_bookings.php?error=".$error);
	exit();
}
	
} 


////////////////////////////////////////////////////////

$query = "SELECT id, cid, guestName, phone, city, bookingDate, propertyName, checkIn, checkOut, bookingStatus, cancellation, stayed FROM rrg_booking ORDER BY bookingDate DESC";

	if(!$stmt = $con->prepare($query))
	{
	echo	$error = "Booking data listing execution failed!".$con->error;				
	}

	if(!$stmt->execute())
	{
		$error = "Booking data listing execution failed!".$con->error;		
		
	}
		if(!$stmt->store_result())
		{
			$error = "Booking data listing execution failed!".$con->error;					
		}
	
			$num_of_rows = $stmt->num_rows;

if($num_of_rows==0)
{
	$error = "No Booking records available";		
}


//////////////////////////////////


?>
<!DOCTYPE html>
    <html>
    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>RR Admin Area</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

        <!-- Favicons -->

        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/images/icons/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/images/icons/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/images/icons/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="assets/images/icons/apple-touch-icon-57-precomposed.png">
        <link rel="shortcut icon" href="assets/images/icons/favicon.png">

        <!--[if lt IE 9]>
          <script src="assets/js/minified/core/html5shiv.min.js"></script>
          <script src="assets/js/minified/core/respond.min.js"></script>
        <![endif]-->

        <!-- Fides Admin CSS Core -->

        <link rel="stylesheet" type="text/css" href="assets/css/minified/aui-production.min.css">

        <!-- Theme UI -->

        <link id="layout-theme" rel="stylesheet" type="text/css" href="assets/themes/minified/fides/color-schemes/dark-blue.min.css">

        <!-- Fides Admin Responsive -->

        <link rel="stylesheet" type="text/css" href="assets/themes/minified/fides/common.min.css">
        <!-- <link rel="stylesheet" type="text/css" href="../_assets/themes/fides/common.css"> -->

        <link id="theme-animations" rel="stylesheet" type="text/css" href="assets/themes/minified/fides/animations.min.css">

        <link rel="stylesheet" type="text/css" href="assets/themes/minified/fides/responsive.min.css">

        <!-- Fides Admin JS -->

        <script type="text/javascript" src="assets/js/minified/aui-production.min.js"></script>
        <script type="text/javascript" src="assets/js/minified/core/raphael.min.js"></script>
        <script type="text/javascript" src="assets/js/minified/widgets/charts-justgage.min.js"></script>

<style>

.dataTables_scrollBody
{
	height:500px !important;

}

</style>

    </head>
    <body>
        

        <div id="loading" class="ui-front loader ui-widget-overlay bg-white opacity-100">
            <img src="assets/images/loader-dark.gif" alt="">
        </div>

        <div id="page-wrapper" class="demo-example">
          <!-- #page-header -->

            <?php include("sidebar.php"); ?>
            <!-- #page-sidebar -->
            <div id="menu-right" class="scrollable-content hidden">
                <div class="toggle-content-open clearfix">
                    <div id="g10" class="small-gauge float-left"></div>
                    <div id="g11" class="small-gauge float-right"></div>
                </div>
        
    
            </div>

            <div id="page-content-wrapper">
                <div id="page-title">

<h3>
    List all Bookings
    </h3>

              </div><!-- #page-title -->
<div id="page-content">

<script type="text/javascript">

$(document).ready(function() {

});

</script>

<h4>&nbsp;</h4>
    <?php 
			   if(isset($success)){ ?>
             
             <div class="infobox success-bg">
<a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>             
                    <h4 class="infobox-title"><?php echo $success;?></h4>
                </div><?php } ?>
                <?php 
			   if(isset($_GET['success'])){ ?>
             <div class="infobox success-bg">
<a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>             
                    <h4 class="infobox-title"><?php echo $_GET['success'];?></h4>
                </div><?php } ?>
	
	    <?php 
			   if(isset($error)){ ?>
             
             <div class="infobox error-bg">
<a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>             
                    <h4 class="infobox-title"><?php echo $error;?></h4>
                </div><?php } ?>
                <?php 
			   if(isset($_GET['error'])){ ?>
             <div class="infobox error-bg">
<a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>             
                    <h4 class="infobox-title"><?php echo $_GET['error'];?></h4>
                </div><?php } ?>
	
<table class="table" id="example1">
  <thead>
		<tr>
			<th width="4%">Booking#</th>
			<th width="10%">Property</th>
			<th width="10%">Name</th>
			<th width="10%">Check-In</th>
			<th width="10%">Check-Out</th>
			<th width="10%">Status</th>
			<th width="7%">Phone</th> 
			<th width="7%">City</th>   
			<th width="7%">Booking date</th>   
			<th width="5%">Action</th>
		</tr>
	</thead>
	<tbody>
    
    
    <?php 
		$stmt->bind_result($id, $cid, $name, $phone, $city, $bookingdate, $pname, $checkin, $checkout, $status, $cancellation, $stayed);
	while ($stmt->fetch()) 
	{
			
	?>
    
		<tr>
			<td>RRG<?php echo $id;?></td>
			<td><?php echo $pname; ?></td>
			<td><?php echo $name; ?></td>
			<td><?php echo date("l, M jS\, Y",strtotime($checkin)); ?></td>
			<td><?php echo date("l, M jS\, Y",strtotime($checkout)); ?></td>
			<?php if($status=='Booking Confirmed') { ?>
            <td class="font-green font-bold"><?php echo $status; ?> </td> 
			<?php } else { ?>
		    <td class="font-red"><?php echo $status; ?> </td> <?php } ?>
			<td><?php echo $phone; ?></td>            
			<td><?php echo $city; ?></td>            
			<td><?php echo date("F jS\, Y h:i:s A",strtotime($bookingdate)); ?></td>
			<td>
                                <div class="dropdown">
                                    <a href="javascript:;" title="" class="btn medium bg-blue" data-toggle="dropdown">
                                        <span class="button-content">
                                            <i class="glyph-icon font-size-11 icon-cog"></i>
                                            <i class="glyph-icon font-size-11 icon-chevron-down"></i>
                                        </span>
                                    </a>
                                    <ul class="dropdown-menu float-right">

                                        <li>
                                            <a href="javascript:;" class="black-modal-60" id="<?php echo $id; ?>">
                                                <i class="glyph-icon icon-edit mrg5R"></i>
                                                View
                                            </a>
                                        </li>
                                         <?php if($stayed==1)
										 { ?>
                                                      <li>
                                                       <?php 
											
											$paramStr = "id=".base64url_encode($id)."&name=".base64url_encode($name);
											$hmac = hash_hmac('sha1', $paramStr, 'JS4#$sdUI'); 						
										?>                                            
                                        
                                            <a href="javascript:;?<?php echo $paramStr; ?>&pk=<?php echo $hmac; ?>" title="">
                                                <i class="glyph-icon icon-edit mrg5R"></i>
                                                View Invoice
                                            </a>
                                        </li>
							
										               <li>
                                                       <?php 
											
											$paramStr = "id=".base64url_encode($id)."&name=".base64url_encode($name);
											$hmac = hash_hmac('sha1', $paramStr, 'JS4#$sdUI'); 						
										?>                                            
                                        
                                            <a href="javascript:;?<?php echo $paramStr; ?>&pk=<?php echo $hmac; ?>" title="">
                                                <i class="glyph-icon icon-edit mrg5R"></i>
                                                Email Invoice
                                            </a>
                                        </li>
                             	<?php } ?>
										
										
                                   <?php if($status=='Booking Confirmed')
										 { ?>
                            <li>
                                            <a href="list_all_bookings.php?id=<?php echo $id; ?>&cancel&name=<?php echo $name ?>&sus" title="" onclick="return confirm('Are you sure you want to cancel this booking - <?php echo "RRG".$id; ?>?');" class="font-red">
                                                <i class="glyph-icon icon-remove mrg5R"></i>
                                                Cancel
                                            </a>
                                        </li>
                                        
                                        <?php } ?>
                                      <!--  
                                        <li>
                                            <a href="list_all_employees.php?id=<?php echo $id; ?>&name=<?php echo $name ?>&del" title="" onclick="return confirm('Are you sure you want to delete - <?php echo $name; ?>?');" class="font-red">
                                                <i class="glyph-icon icon-remove mrg5R"></i>
                                                Delete
                                            </a>
                                        </li>-->
                                        
                                    </ul>
                                </div>
                            </td>
		</tr>
        
        <?php } 
		
		$stmt->free_result();
		$con->close();
		?>
        
	</tbody>
	<tfoot>
		<tr>
			<th></th>
			<th></th>
			<th></th>
			<th></th>
			<th></th>
			<th></th>
			<th></th>            
			<th></th>
			<th></th>
			<th></th>            
            
		</tr>
	</tfoot>
</table>
                	</div><!-- #page-content -->
            </div>
                	</div><!-- #page-content -->
            </div><!-- #page-main -->
        </div><!-- #page-wrapper -->

    </body>
</html>


<div id="limage" class="hide"><img src="assets/images/loader-light.gif" alt=""/></div>  

    <div class="hide" id="black-modal-60" title="BOOKING DETAILS">
            <div class="pad10A" id="mdata"></div>
            </div> 
<script type="text/javascript">
 
    $(function() {
		
         $( ".black-modal-60" ).click(function() {
			 
			 var employee_id = $(this).attr("id");  
           $.ajax({  
                url:"booking_data.php",  
                method:"post",  
                data:{employee_id:employee_id},
				beforeSend: function(){
				$('#limage').fadeIn();
			    },
			    complete: function(){
				$('#limage').hide();
				},
				success:function(data){  
				$('#mdata').html(data);
				$( "#black-modal-60" ).dialog({
				 modal: true,
				 minWidth: 900,
				 minHeight: 200, 
				 dialogClass: "modal-dialog",
				 buttons: {
					   "CLOSE": function() {
						   $( this ).dialog( "close" );
					   }
				   }, 
				 show: "fadeIn" 
			   });
			   $('.ui-widget-overlay').addClass('bg-black opacity-60');
				
                }  
           });  
		   
         });
		 
    });
 
 
</script>




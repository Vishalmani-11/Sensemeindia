<?php
include "db/session.php";  
include "function/config.php"; 
include "db/db_connect.php"; 
include "function/function.php";  
//////////////////////status_update/////////////////////////////////////////////////////////////////////
if(isset($_GET['id'])&&$_GET['id']!=''&&isset($_GET['action'])&&$_GET['action']=='status')
{
extract($_GET);	
$sc_id = secure_input($con,$sc_id);	
$sc_name = secure_input($con,$sc_name);     
$id = secure_input($con,$id);	
$active = secure_input($con,$active);	    
$squery = "UPDATE bb_products_stock SET active = ? WHERE id = ?";
    
if(!$sstmt = $con->prepare($squery))
{
		$error = "product data listing execution failed!".$con->error;	
    header("location:list_all_products.php?sc_id=".$sc_id."&sc_name=".$sc_name."&error=".$error);	exit();
}

 if(!$sstmt->bind_param('ii',$active, $id))
     {
		$error = "product status update execution failed!".$con->error;	
     header("location:list_all_products.php?sc_id=".$sc_id."&sc_name=".$sc_name."&error=".$error);	exit();
}
 
 if(!$sstmt->execute())
	{
		$error = "product status update failed!".$con->error;		
		header("location:list_all_products.php?sc_id=".$sc_id."&sc_name=".$sc_name."&error=".$error);	exit();
	}
	else
	{
		$success= "product status updated successfully!";
		header("location:list_all_products.php?sc_id=".$sc_id."&sc_name=".$sc_name."&success=".$success);	exit();
	}
	
} 
//////////////////////delete////////////////////////
if(isset($_GET['id'])&&$_GET['id']!=''&&isset($_GET['action'])&&$_GET['action']=='delete')
{
extract($_GET);	
$sc_id = secure_input($con,$sc_id);	
$sc_name = secure_input($con,$sc_name);     
$id = secure_input($con,$id);	
$query = "DELETE FROM bb_products_stock WHERE id = ?";

if(!$stmt = $con->prepare($query))
{
		$error = "product data listing execution failed!".$con->error;	
    header("location:list_all_products.php?sc_id=".$sc_id."&sc_name=".$sc_name."&error=".$error);	exit();
}

 $stmt->bind_param('i',$id);
 
 if(!$stmt->execute())
	{
		$error = "product data deletion execution failed!".$con->error;		
		header("location:list_all_products.php?sc_id=".$sc_id."&sc_name=".$sc_name."&error=".$error);	exit();
	}
	else
	{
		$success= "product deleted successfully!";
		header("location:list_all_products.php?sc_id=".$sc_id."&sc_name=".$sc_name."&success=".$success);	exit();
	}
	
} 
////////////////////////////////edit_parent////////////////////////
if(isset($_POST['submit_edit']))
{
extract($_POST);
$sc_id = secure_input($con,$sc_id);	
$sc_name = secure_input($con,$sc_name);    
$id = secure_input($con,$parent_id);
$pname = secure_input($con,$pname);
$description = secure_input($con,$description);	
$details = secure_input($con,$details);	
$disclaimer = secure_input($con,$disclaimer);	    
$tags = secure_input($con,$tags);	    
$title = secure_input($con,$seo_title);	    
$meta = secure_input($con,$meta_description);	        
$keywords = secure_input($con,$meta_keywords);	   
    

$edquery = "UPDATE bb_products SET name = ?, details = ?, description = ?, disclaimer = ?, seo_title = ?, seo_keyword = ?, seo_meta = ?, tags = ? WHERE id = ?";

if(!$edstmt = $con->prepare($edquery))
{
	 $error = "Product data update preparation failed!".$con->error; 
    header("location:list_all_products.php?sc_id=".$sc_id."&sc_name=".$sc_name."&error=".$error);	exit();
}
	if(!$edstmt->bind_param('ssssssssi',$pname, $details, $description, $disclaimer, $title, $keywords, $meta, $tags, $id))
        {
	 $error = "Product data update preparation failed!".$con->error; 
        header("location:list_all_products.php?sc_id=".$sc_id."&sc_name=".$sc_name."&error=".$error);	exit();
}
    
	if(!$edstmt->execute())
	{
		$error = "Parent product data update execution failed!".$con->error;
       header("location:list_all_products.php?sc_id=".$sc_id."&sc_name=".$sc_name."&error=".$error);	exit();
		
	}
    else
    {
        $success= "Parent product data updated successfully!";
		header("location:list_all_products.php?sc_id=".$sc_id."&sc_name=".$sc_name."&success=".$success);	exit();
    }
    
	
}
////////////////////////////////edit_child////////////////////////
if(isset($_POST['submit_child_edit']))
{
extract($_POST);
$sc_id = secure_input($con,$sc_id);	
$sc_name = secure_input($con,$sc_name);    
$parent_id = secure_input($con,$parent_id);
$id = secure_input($con,$id);   
$e_size = secure_input($con,$e_size);   
$e_featured = secure_input($con,$e_featured);   
$e_bselling = secure_input($con,$e_bselling);       
$id = secure_input($con,$id);   
$SKU = secure_input($con,$SKU);   
$MRP = secure_input($con,$MRP);   
if(isset($_POST['price'])&&$_POST['price']!=""&&$_POST['price']!=0) 
{
    $price = secure_input($con,$price);	
}
else
{
        $price = $MRP;
}    
$qty = secure_input($con,$stock);    
    
if(isset($_POST['size'])&&$_POST['size']!="") { $size = secure_input($con,$size); } else { 	$size = secure_input($con,$e_size); }
    
if(isset($_POST['ftype'])&&$_POST['ftype']!="") { $featured = secure_input($con,$ftype); } else { 	$featured = secure_input($con,$e_featured); } 

if(isset($_POST['bselling'])&&$_POST['bselling']!="") { $bselling = secure_input($con,$bselling); } else { 	$bselling = secure_input($con,$e_bselling); }     
   

/////////////////////////////Image upload///////////////////////////////////////////////////////////
    $pimage = array();
for($i=0;$i<5;$i++)
{    
if(($_FILES['pic']['error'][$i]==0))
{	
if (($_FILES["pic"]["size"][$i] < 1000000))
  {
	$file_tmp_name = $_FILES["pic"]["tmp_name"][$i];
    $path = "../uploads/products/";
    $image_path = "uploads/products/";
	$error_path = "add_new_product.php";
	$exten = explode(".", $_FILES["pic"]["name"][$i]);
	$old_name = $exten[0];
	$new_name = 1;
	$pimage[] = upload_image($file_tmp_name, $old_name, $path, $image_path, $error_path, $new_name); 
  }
else
  {
	$error = "Invalid file size!";
	header("location:add_new_product.php?error=".$error); exit();
  }
}
else
  {
    $pimage[] = $e_pic[$i];    
  }
}
///////////////////////////////////////////////////////////////////////////////////////////////////////        
    
$edquery = "UPDATE bb_products_stock SET sku = ?, size = ?, mrp = ?, price = ?, qty = ?, pic1 = ?, pic2 = ?, pic3 = ?, pic4 = ?, pic5 = ?, featured = ? WHERE id = ?";

if(!$edstmt = $con->prepare($edquery))
{
	echo $error = "Product data update preparation failed!".$con->error; exit();
}
	if(!$edstmt->bind_param('ssiiissssssi',$SKU, $size, $MRP, $price, $qty, $pimage[0], $pimage[1], $pimage[2], $pimage[3], $pimage[4], $featured, $id))
        {
	echo $error = "Product data update preparation failed!".$con->error; exit();
}
    
	if(!$edstmt->execute())
	{
		$error = "Parent product data update execution failed!".$con->error;
        header("location:list_all_products.php?sc_id=".$sc_id."&sc_name=".$sc_name."&error=".$error);	exit();
		
	}
    else
    {
        $success= "Parent product data updated successfully!";
		header("location:list_all_products.php?sc_id=".$sc_id."&sc_name=".$sc_name."&success=".$success);	exit();
    }
    
	
}
////////////////////////add child product/////////////////////////
if(isset($_POST['submit_add']))
{
extract($_POST);	
$sc_id = secure_input($con,$sc_id);	
$sc_name = secure_input($con,$sc_name); 
$parent_id = secure_input($con,$parent_id);    
$SKU = secure_input($con,$SKU);        
$MRP = secure_input($con,$MRP);	
$price = secure_input($con,$price);	
$stock = secure_input($con,$stock);	    
$ftype = secure_input($con,$ftype);	
$bselling = secure_input($con,$bselling);	    
$size = secure_input($con,$size);		    
    

/////////////////////////////Image upload////////////////////////////
    $pimage = array();
for($i=0;$i<5;$i++)
{    
if(($_FILES['pic']['error'][$i]==0))
{	
if (($_FILES["pic"]["size"][$i] < 1000000))
  {
	$file_tmp_name = $_FILES["pic"]["tmp_name"][$i];
    $path = "../uploads/products/";
    $image_path = "uploads/products/";
	$error_path = "add_new_product.php";
	$exten = explode(".", $_FILES["pic"]["name"][$i]);
	$old_name = $exten[0];
	$new_name = 1;
	$pimage[] = upload_image($file_tmp_name, $old_name, $path, $image_path, $error_path, $new_name); 
  }
else
  {
	$error = "Invalid file size!";
	header("location:add_new_product.php?error=".$error); exit();
  }
}
else
  {
    $pimage[] = NULL;    
  }
}
///////////////////////////////////////////////////////////////////////////////////////////////////////
    
if(!$chstmt = $con->prepare("INSERT INTO bb_products_stock (sku, parent_id, size, mrp, price, qty, pic1, pic2, pic3, pic4, pic5, featured, bestselling) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"))
{
	echo "Prepare failed: (" . $con->errno . ") " . $con->error; exit();
}

if(!$chstmt->bind_param("siiiiisssssii", $SKU, $parent_id, $size, $MRP, $price, $stock, $pimage[0], $pimage[1], $pimage[2], $pimage[3], $pimage[4], $ftype, $bselling))
{
	echo "Param pass failed!: (" . $con->errno . ") " . $chstmt->error; exit();
}

if(!$chstmt->execute()) {
    
	$error = "New child product data saving failed!".$con->error;
    header("location:list_all_products.php?sc_id=".$sc_id."&sc_name=".$sc_name."&error=".$error);	exit();
    
}
else
{
	$success= "New child product saved successfully!";
	header("location:list_all_products.php?sc_id=".$sc_id."&sc_name=".$sc_name."&success=".$success);	
	exit();
    }

}
//////////////////////////size////////////////////////////////////////


$squery = "SELECT id, name FROM bb_sizes ORDER BY name ASC";

if(!$sstmt = $con->prepare($squery))
{
	echo "prepare failed: (" . $con->errno . ") " . $con->error;	exit();
}


	if(!$sstmt->execute())
	{
		$error = "size list failed!".$con->error;		exit();
		
	}

		if(!$sstmt->store_result())
		{
			$error = "categories list failed!".$con->error;		exit();			
		}
	
		$snum_of_rows = $sstmt->num_rows;

if($snum_of_rows==0)
{
	$serror = "No sizes found";	
}

//////////////////////////////product listing//////////////////////////////////
if(isset($_GET['sc_id'])&&$_GET['sc_id']!='')
{
extract($_GET);	
$sc_id = secure_input($con,$sc_id);	
$sc_name = secure_input($con,$sc_name);	     
    
    
    
$query = "SELECT t1.id, t1.mc_id, t1.sc_id, t1.name, t2.name FROM bb_products as t1 INNER JOIN bb_sub_categories as t2 ON t1.sc_id = t2.id WHERE t1.sc_id = ? ORDER BY t1.cdate DESC";

if(!$stmt = $con->prepare($query))
{
	echo $error = "Product data listing preparation failed!".$con->error; exit();
}
	if(!$stmt->bind_param('i', $sc_id))
        {
	echo $error = "Product data listing preparation failed!".$con->error; exit();
}
    
	if(!$stmt->execute())
	{
		echo $error = "Product data listing execution failed!".$con->error;	exit();	 
		
	}
		if(!$stmt->store_result())
		{
			echo $error = "Product data listing execution failed!".$con->error;	exit();				
		}
	
	$num_of_rows = $stmt->num_rows;

	if($num_of_rows==0)
{
	 $error = "No parent products available";
}

	}


//////////////////////////////////////////////////////////////////////////////////////////////////


?>
<!DOCTYPE html>
    <html>
    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title><?php echo $_SESSION['cName']; ?> Admin Area</title>
     <?php include("../header.php"); ?>
        <script type="text/javascript" src="<?php echo $_SESSION['gpath']; ?>assets/js/minified/widgets/charts-justgage.min.js"></script>

<style>

.dataTables_scrollBody
{
	height:500px !important;

}

</style>

    </head>
    <body>
        

        <div id="loading" class="ui-front loader ui-widget-overlay bg-gray opacity-50">
           <img src="<?php echo $_SESSION['gpath']; ?>assets/images/loader-light.gif" alt="">
        </div>

        <div id="page-wrapper" class="demo-example">
          <!-- #page-header -->

            <?php include("../sidebar.php"); ?>
            <!-- #page-sidebar -->
            <div id="menu-right" class="scrollable-content hidden">
                <a href="javascript:;" title="Get Source" class="popover-title button-toggle-open">
                    Cloud status
                    <i class="glyph-icon icon-caret-right icon-caret-down"></i>
                </a>
                <div class="clear"></div>
                <a href="javascript:;" title="Get Source" class="popover-title button-toggle-open">
                    Realtime server load
                    <i class="glyph-icon icon-caret-right icon-caret-down"></i>
                </a>
                <div class="toggle-content-open clearfix">

                    <div id="g10" class="small-gauge float-left"></div>
                    <div id="g11" class="small-gauge float-right"></div>

                </div>
            </div>
            <div id="page-content-wrapper">
                <div id="page-title">

<h3 class="font-black">
    <strong>List all products-></strong><strong><span class="font-blue"> <?php echo $sc_name; ?></span></strong>
    </h3>
              </div><!-- #page-title -->
<div id="page-content">


<h4>&nbsp;</h4>

                <?php 
			   if(isset($_GET['success'])){ ?>
             <div class="infobox success-bg">
<a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>             
                    <h4 class="infobox-title"><?php echo $_GET['success'];?></h4>
                </div><?php } ?>
<table class="table" id="example1">
  <thead>
		<tr>
			<th width="5%">S.No</th>
			<th width="25%">Name </th>
            <th width="10%">Type </th>            
			<th width="10%">Category</th>
            <th width="10%">SKU#</th>
            <th width="10%">MRP</th>
            <th width="10%">Price</th>
            <th width="7%">Size</th>
            <th width="7%">Qty</th>
            <th width="10%">Status</th>
			<th width="10%">Action</th>
		</tr>
	</thead>
	<tbody>
    
    
    <?php 
	$sn = 0;
	$stmt->bind_result($id, $mc_id, $sc_id, $name, $cname);
	while ($stmt->fetch()) 
	{
			$sn = 	$sn + 1;
			$name = ucwords($name);
			$cname = ucwords($cname);
			
	?>
    
		<tr class="parent">
			<td><?php echo $sn;?></td>
			<td><?php echo $name; ?></td>
            <td>Parent</td>
            <td><?php echo $cname;?></td>
			<td> - </td>
            <td> - </td>
			<td> - </td>
            <td> - </td> 
            <td> - </td>    
            <td> - </td> 
			<td>
                                <div class="dropdown">
                                    <a href="javascript:;" title="" class="btn medium bg-blue" data-toggle="dropdown">
                                        <span class="button-content">
                                            <i class="glyph-icon font-size-11 icon-cog"></i>
                                            <i class="glyph-icon font-size-11 icon-chevron-down"></i>
                                        </span>
                                    </a>
                                    <ul class="dropdown-menu float-right">
                                        <li>
											  <a href="javascript:;" class="black-modal-edit" id="<?php echo $id; ?>">
                                                <i class="glyph-icon icon-edit mrg5R"></i>
                                                View/Edit
                                            </a>
                                            
											</li>
                                        
										 <li>
											  <a href="javascript:;" class="black-modal-new" id="<?php echo $id; ?>">
                                                 <i class="glyph-icon icon-plus mrg5R font-green"></i>
                                                Add Child
                                            </a>
                                            
											</li>
                                        
                                       
                                       <!-- <li>
                                            <a href="list_all_products.php?id=<?php echo $id; ?>&name=<?php echo $name ?>" title="" onclick="return confirm('Are you sure you want to delete this product? - <?php echo $name ?>');" class="font-red">
                                                <i class="glyph-icon icon-remove mrg5R"></i>
                                                Delete
                                            </a>
                                        </li>-->
                                        
                                    </ul>
                                </div>
                            </td>
		</tr>
        
       <!-- ////////////////////////child/////////////////////////////////-->
        
        
        <?php 
       
$cquery = "SELECT t1.id, t1.sku, t1.mrp, t1.price, t1.qty, t1.pic1, t1.active, t3.name FROM bb_products_stock as t1 INNER JOIN bb_sizes as t3 ON t1.size = t3.id WHERE t1.parent_id = ? ORDER BY t3.name ASC";

if(!$cstmt = $con->prepare($cquery))
{
	echo $error = "Product data listing preparation failed!".$con->error; exit();
}
	if(!$cstmt->bind_param('i', $id))
        {
	echo $error = "Product data listing preparation failed!".$con->error; exit();
}
        
        
	if(!$cstmt->execute())
	{
		echo $error = "Product data listing execution failed!".$con->error;	exit();	 
		
	}
		if(!$cstmt->store_result())
		{
			echo $error = "Product data listing execution failed!".$con->error;	exit();				
		}
        
        
	
	$cnum_of_rows = $cstmt->num_rows;

	if($cnum_of_rows==0)
{
	echo $error = "No child products available";	exit(); 	
}
	$cstmt->bind_result($id, $sku, $mrp, $price, $qty, $pic1, $status, $size);
	while ($cstmt->fetch()) 
	{
        $sn = 	$sn + 1;
	?>
    
		<tr class="child">
			<td><?php echo $sn; ?></td>
			<td> - </td>
            <td>Child</td>
            <td> <?php echo $cname;?> </td>
			<td> <?php echo $sku; ?> </td>
            <td> <?php echo $mrp; ?> </td>
			<td> <?php echo $price; ?> </td>
            <td> <?php echo $size; ?> </td> 
            <td> <?php echo $qty; ?> </td> 
            <td> <?php if($status == 1){ echo "Active"; } else { echo "Inactive"; }  ?> </td> 
			<td>
                                <div class="dropdown">
                                    <a href="javascript:;" title="" class="btn medium bg-blue" data-toggle="dropdown">
                                        <span class="button-content">
                                            <i class="glyph-icon font-size-11 icon-cog"></i>
                                            <i class="glyph-icon font-size-11 icon-chevron-down"></i>
                                        </span>
                                    </a>
                                    <ul class="dropdown-menu float-right">
                                          <li>
											  <a href="javascript:;" class="black-modal-child-view" id="<?php echo $id; ?>">
                                                <i class="glyph-icon icon-eye mrg5R"></i>
                                                View
                                            </a>
                                            
											</li>
                                        <li>
											  <a href="javascript:;" class="black-modal-child-edit" id="<?php echo $id; ?>">
                                                <i class="glyph-icon icon-edit mrg5R"></i>
                                                Edit
                                            </a>
                                            
											</li>
                                        
                                        <?php if($status == 1){ ?>
                                        
                                        <li>
                                            <a href="list_all_products.php?id=<?php echo $id; ?>&sc_id=<?php echo $sc_id; ?>&sc_name=<?php echo $sc_name; ?>&action=status&active=0" title="click to deactivate" onclick="return confirm('Are you sure you want to deactivate this product? - <?php echo $name ?>');">
                                                <i class="glyph-icon icon-edit mrg5R"></i>
                                                Deactivate
                                            </a>
                                        </li>
                                        
                                        <?php } else { ?>
                                        
                                          <li>
                                           <a href="list_all_products.php?id=<?php echo $id; ?>&sc_id=<?php echo $sc_id; ?>&sc_name=<?php echo $sc_name; ?>&action=status&active=1" title="click to activate" onclick="return confirm('Are you sure you want to activate this product? - <?php echo $name ?>');" class="font-green">
                                                <i class="glyph-icon icon-edit mrg5R"></i>
                                                Activate
                                            </a>
                                        </li>
                                        
                                        <?php  } ?>        
                                        <li>
                                           <a href="list_all_products.php?id=<?php echo $id; ?>&sc_id=<?php echo $sc_id; ?>&sc_name=<?php echo $mc_name; ?>&ptype=<?php echo $ptype;?>&action=delete" title="click to activate" onclick="return confirm('Are you sure you want to delete this product? - <?php echo $name ?>');" class="font-red">
                                                <i class="glyph-icon icon-remove mrg5R"></i>
                                                Delete
                                            </a>
                                        </li>
                                        
                                    </ul>
                                </div>
                            </td>
		</tr>
        <?php } ?>
        
        
        
        
      <!-- ////////////////////////child/////////////////////////////////-->
          
        
        <?php } 

		?>
        
	</tbody>
	<tfoot>
		<tr>
            <th></th>
			<th></th>
			<th></th>
			<th></th>
			<th></th>
			<th></th>
			<th></th>
            <th></th>
			<th></th>
			<th></th>
			<th></th>
		</tr>
	</tfoot>
</table>


                	</div><!-- #page-content -->
            </div>




                	</div><!-- #page-content -->
            </div><!-- #page-main -->
        </div><!-- #page-wrapper -->

    </body>
</html>


<!-----------------------------------------------------add variation------------------------------>
<div class="hide" id="black-modal-new" title="Boys -> Teens">
<div class="example-code">
      <form id="demo-form-child" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" class="col-md-11 center-margin" method="post" enctype="multipart/form-data">
        <div class="content-box mrg25B mrg25T">
          <h3 class="content-box-header primary-bg"> <span>Add Child Product</span> </h3>
          <div class="content-box-wrapper"> 
        
			
            <div class="form-row">
                <div class="form-label col-md-4">
                    <label for="">
                       SKU#:
                         <span class="required">*</span>
                    </label>
                </div>
                <div class="form-input col-md-8">
                    <input  type="text" id="SKU" name="SKU" data-trigger="change" parsley-rangelength="[1,15]" pattern="^[A-Za-z0-9]*$" data-required="true" class="parsley-validated" > 
                </div>
            </div>
            
            <div class="form-row">
              <div class="form-label col-md-4">
                <label for=""> Select a size: <span class="required">*</span></label>
              </div>
              <div class="form-input col-md-8">
                <select data-placeholder="Select a size..." name="size" id="size" class="chosen-select parsley-validated" data-trigger="change" required>
      
      <?php      
			if(isset($serror))
			{
				?>
			     <option value=""><?php echo $serror; ?></option>	
			<?php 
						} 
						else
						{
			?>
                 <option value="">Select a size</option>	
                 <?php } ?>
                 
                  <?php 
	$sstmt->bind_result($id, $scname);
	while ($sstmt->fetch()) 
	{
			
	?>            
                  <option value="<?php echo $id; ?>"><?php echo $scname; ?></option>
                  
       <?php } 
		?>            
        
                </select>
              </div>
              
            </div>
            
            
           <div class="form-row">
                <div class="form-label col-md-4">
                    <label for="">
                       MRP:
                         <span class="required">*</span>
                    </label>
                </div>
                <div class="form-input col-md-8">
                    <input  type="text" id="MRP" name="MRP" data-trigger="change" data-type="number" parsley-rangelength="[1,10]" data-required="true" class="parsley-validated" >
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-label col-md-4">
                    <label for="">
                       Selling Price:
                         <span class="required">*</span>
                    </label>
                </div>
                <div class="form-input col-md-8">
                    <input  type="text" id="price" name="price" data-trigger="change" data-type="number" parsley-rangelength="[1,10]" data-required="true" class="parsley-validated" >
                </div>
            </div>
            
             <div class="form-row">
                <div class="form-label col-md-4">
                    <label for="">
                       Stock QTY:
                         <span class="required">*</span>
                    </label>
                </div>
                <div class="form-input col-md-8">
                    <input  type="text" id="stock" name="stock" data-trigger="change" data-type="number" parsley-rangelength="[1,10]" data-required="true" class="parsley-validated" >
                </div>
            </div>
            
            <div class="form-row">
              <div class="form-label col-md-4">
                <label for=""> Featured Product:</label>
              </div>
              <div class="form-input col-md-8">
                <select data-placeholder="Select a type..." name="ftype" class="chosen-select parsley-validated" data-trigger="change" required>
                     <option value="0" selected>No</option>	
					  <option value="1">Yes</option>	
        
                </select>
              </div>
              
            </div>
              
               <div class="form-row">
              <div class="form-label col-md-4">
                <label for=""> Best Selling Product:</label>
              </div>
              <div class="form-input col-md-8">
                <select data-placeholder="Select a type..." name="bselling" class="chosen-select parsley-validated" data-trigger="change" required>
                     <option value="0" selected>No</option>	
					  <option value="1">Yes</option>	
        
                </select>
              </div>
              
            </div>
            
			<div class="form-row">
          <div class="form-label col-md-4">
            <label for="">Product image 1:<span class="required">*</span></label>
          </div>
          <div class="float-left col-md-8"> <span class="btn medium bg-green fileinput-button"><span class="button-content">Max 500kb. Dimension: 640px x 755px. (gif, jpeg, jpg, png) only</span>
              <input type="file" name="pic[]" required>
           </div>
        </div>
				<div class="form-row">
          <div class="form-label col-md-4">
            <label for="">Product image 2:</label>
          </div>
          <div class="float-left col-md-8"> <span class="btn medium bg-green fileinput-button"> <span class="button-content">Max 500kb. Dimension: 640px x 755px. (gif, jpeg, jpg, png) only</span>
              <input type="file" name="pic[]">
           </div>
        </div>
					<div class="form-row">
          <div class="form-label col-md-4">
            <label for="">Product image 3:</label>
          </div>
          <div class="float-left col-md-8"> <span class="btn medium bg-green fileinput-button"> <span class="button-content">Max 500kb. Dimension: 640px x 755px. (gif, jpeg, jpg, png) only</span>
              <input type="file" name="pic[]">
            </div>
        </div>
                        
                        <div class="form-row">
          <div class="form-label col-md-4">
            <label for="">Product image 4:</label>
          </div>
          <div class="float-left col-md-8"> <span class="btn medium bg-green fileinput-button"> <span class="button-content">Max 500kb. Dimension: 640px x 755px. (gif, jpeg, jpg, png) only</span>
              <input type="file" name="pic[]">
            </div>
        </div>
                            
                            <div class="form-row">
          <div class="form-label col-md-4">
            <label for="">Product image 5:</label>
          </div>
          <div class="float-left col-md-8"> <span class="btn medium bg-green fileinput-button"> <span class="button-content">Max 500kb. Dimension: 640px x 755px. (gif, jpeg, jpg, png) only</span>
              <input type="file" name="pic[]">
             </div>
        </div>

			             
            <div class="divider"></div>
            <div class="form-row">
                <input type="hidden" name="parent_id" id="parent_id_add">
                <input type="hidden" name="sc_id" id="mc_id_add" value="<?php echo $sc_id; ?>">
                <input type="hidden" name="sc_name" id="mc_name_add" value="<?php echo $sc_name; ?>">
                <div class="form-input col-md-8 col-md-offset-4">
               <button type="submit" name="submit_add"  class="btn large primary-bg" onclick="javascript:$(&apos;#demo-form-child&apos;).parsley( &apos;validate&apos; );"><span class="button-content">Save Data</span></button>
&nbsp;
                </div>
            </div>
          
            </div> </div> </form> </div></div>
<!------------------------------------------------------------------------------------------>      
<div id="limage" class="hide"><img src="<?php echo $_SESSION['gpath']; ?>assets/images/loader-light.gif" alt=""/></div> 
              
<!-----------------------------------------------------edit parent------------------------------>
<div class="hide" id="black-modal-edit" title="<?php echo $sc_name; ?>">
<div class="example-code">
      <form id="demo-form-edit" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" class="col-md-11 center-margin" method="post" enctype="multipart/form-data">
        <div class="content-box mrg25B mrg25T">
          <h3 class="content-box-header primary-bg"> <span>Edit/View Parent Item details</span> </h3>
          <div class="content-box-wrapper"> 
              
			<div class="form-row">
                <div class="form-label col-md-4">
                    <label for="">
                       Product Name:
                         <span class="required">*</span>
                    </label>
                </div>
                <div class="form-input col-md-8">
                    <input  type="text" id="name" name="pname" data-trigger="change" parsley-rangelength="[2,99]" data-required="true" class="parsley-validated">
                </div>
            </div>
			
				                 <div class="form-row">
                <div class="form-label col-md-4">
                    <label for="">
                        Description: <span class="required">*</span>
                    </label>
                </div>
           <div class="form-input col-md-8">
                <textarea id="description" name="description" rows="5" data-trigger="change" class="parsley-validated" data-required="true"></textarea>
              </div>
            </div>
                        
                         <div class="form-row">
                <div class="form-label col-md-4">
                    <label for="">
                        How to Use: <span class="required">*</span>
                    </label>
                </div>
           <div class="form-input col-md-8">
                <textarea id="details" name="details" rows="5" data-trigger="change" class="parsley-validated" data-required="true"></textarea>
                
              </div>
            </div>
              
               <div class="form-row">
                <div class="form-label col-md-4">
                    <label for="">
                        Disclaimer: <span class="required">*</span>
                    </label>
                </div>
           <div class="form-input col-md-8">
                <textarea id="disclaimer" name="disclaimer" rows="5" data-trigger="change" class="parsley-validated" data-required="true"></textarea>
                
              </div>
            </div>
     <div class="form-row">
                <div class="form-label col-md-4">
                    <label for="">
                        Search tags: <span class="required">comma separated</span>
                    </label>
                </div>
           <div class="form-input col-md-8">
                <textarea id="tags" name="tags" rows="2" data-trigger="change" class="parsley-validated"></textarea>
              </div>
            </div>
            
              <div class="form-row">
                <div class="form-label col-md-4">
                    <label for="">
                        SEO Title:
                    </label>
                </div>
           <div class="form-input col-md-8">
                <textarea id="title" name="seo_title" rows="2" data-trigger="change" class="parsley-validated" data-maxlength="70"></textarea>
                <div class="character-remaining clear input-description font-gray">70 chars only</div>
              </div>
            </div>
            
            <div class="form-row">
                <div class="form-label col-md-4">
                    <label for="">
                        META description:
                    </label>
                </div>
           <div class="form-input col-md-8">
                <textarea id="meta" name="meta_description" rows="2" data-trigger="change" class="parsley-validated" data-maxlength="180"></textarea>
                <div class="character-remaining clear input-description font-gray">180 chars only</div>
              </div>
            </div>
  
            <div class="form-row">
                <div class="form-label col-md-4">
                    <label for="">
                        META Keywords <span class="required">comma separated</span>:
                    </label>
                </div>
           <div class="form-input col-md-8">
                <textarea id="keywords" name="meta_keywords" rows="2" data-trigger="change" class="parsley-validated" data-maxlength="500"></textarea>
                <div class="character-remaining clear input-description font-gray">500 chars only</div>
              </div>
            </div>
            <div class="divider"></div>
            <div class="form-row">
                <input type="hidden" name="parent_id" id="parent_id_edit">
                <input type="hidden" name="sc_id" id="sc_id_edit" value="<?php echo $sc_id; ?>">
                <input type="hidden" name="sc_name" id="sc_name_edit" value="<?php echo $sc_name; ?>">
                <div class="form-input col-md-8 col-md-offset-4">
               <button type="submit" name="submit_edit"  class="btn large primary-bg" onclick="javascript:$(&apos;#demo-form-2&apos;).parsley( &apos;validate&apos; );"><span class="button-content">Save Data</span></button>
&nbsp;

                </div>
            </div>
            
            
            </div> </div> </form> </div></div>
              
 <!-----------------------------------------------------edit child------------------------------>
<div class="hide" id="black-modal-edit-child" title="Edit child product">
<div class="example-code">
      <form id="demo-form-edit-child" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" class="col-md-11 center-margin" method="post" enctype="multipart/form-data">
        <div class="content-box mrg25B mrg25T">
          <h3 class="content-box-header primary-bg"> <span>Edit child product details</span> </h3>
          <div class="content-box-wrapper"> 
        
			
            <div class="form-row">
                <div class="form-label col-md-4">
                    <label for="">
                       SKU#:
                         <span class="required">*</span>
                    </label>
                </div>
                <div class="form-input col-md-8">
                    <input  type="text" id="SKU_edit_child" name="SKU" data-trigger="change" parsley-rangelength="[1,15]" pattern="^[A-Za-z0-9]*$" data-required="true" class="parsley-validated" > 
                </div>
            </div>

        
            <div class="form-row">
              <div class="form-label col-md-4">
                <label for=""> Select a size:</label>
              </div>
              <div class="form-input col-md-8">
                <select data-placeholder="Select a size..." name="size" id="size_edit" class="chosen-select parsley-validated" data-trigger="change">
      
      <?php      
			if(isset($serror))
			{
				?>
			     <option value=""><?php echo $serror; ?></option>	
			<?php 
						} 
						else
						{
			?>
                 <option value="">Select a size</option>	
                 <?php } ?>
                 
                  <?php 
        $sstmt->data_seek(0);                    
	$sstmt->bind_result($id, $scname);
	while ($sstmt->fetch()) 
	{
			
	?>            
                  <option value="<?php echo $id; ?>"><?php echo $scname; ?></option>
                  
       <?php } 
		?>            
        
                </select>
              </div>
              
            </div>
            
   
            
           <div class="form-row">
                <div class="form-label col-md-4">
                    <label for="">
                       MRP:
                         <span class="required">*</span>
                    </label>
                </div>
                <div class="form-input col-md-8">
                    <input  type="text" id="MRP_edit_child" name="MRP" data-trigger="change" data-type="number" parsley-rangelength="[1,10]" data-required="true" class="parsley-validated" >
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-label col-md-4">
                    <label for="">
                       Selling Price:
                         <span class="required">*</span>
                    </label>
                </div>
                <div class="form-input col-md-8">
                    <input  type="text" id="price_edit_child" name="price" data-trigger="change" data-type="number" parsley-rangelength="[1,10]" data-required="true" class="parsley-validated" >
                </div>
            </div>
            
             <div class="form-row">
                <div class="form-label col-md-4">
                    <label for="">
                       Stock QTY:
                         <span class="required">*</span>
                    </label>
                </div>

                <div class="form-input col-md-8">
                    <input  type="text" id="stock_edit_child" name="stock" data-trigger="change" data-type="number" parsley-rangelength="[1,10]" data-required="true" class="parsley-validated" >
                </div>
            </div>
         
            <div class="form-row">
              <div class="form-label col-md-4">
                <label for=""> Featured Product:</label>
              </div>
              <div class="form-input col-md-8">
                <select data-placeholder="Select a type..." name="ftype" class="chosen-select parsley-validated" data-trigger="change">
                    <option value="">Select</option> 
                    <option value="0">No</option>	
					  <option value="1">Yes</option>	
        
                </select>
              </div>
              
            </div>
              
              <div class="form-row">
              <div class="form-label col-md-4">
                <label for=""> Best Selling Product:</label>
              </div>
              <div class="form-input col-md-8">
                <select data-placeholder="Select a type..." name="bselling" class="chosen-select parsley-validated" data-trigger="change">
                    <option value="">Select</option> 
                    <option value="0">No</option>	
					  <option value="1">Yes</option>	
        
                </select>
              </div>
              
            </div>
            
			<div class="form-row">
          <div class="form-label col-md-4">
            <label for="">Product image 1:</label>
          </div>
          <div class="float-left col-md-8"> <span class="btn medium bg-green fileinput-button"> <span class="button-content">Max 500kb. 555px x 555px. (gif, jpeg, jpg, png) only  </span>
              <input type="file" name="pic[]">
           </div>
        </div>
				<div class="form-row">
          <div class="form-label col-md-4">
            <label for="">Product image 2:</label>
          </div>
          <div class="float-left col-md-8"> <span class="btn medium bg-green fileinput-button"> <span class="button-content">Max 500kb. 555px x 555px.  (gif, jpeg, jpg, png) only  </span>
              <input type="file" name="pic[]">
           </div>
        </div>
					<div class="form-row">
          <div class="form-label col-md-4">
            <label for="">Product image 3:</label>
          </div>
          <div class="float-left col-md-8"> <span class="btn medium bg-green fileinput-button"> <span class="button-content">Max 500kb. 555px x 555px.  (gif, jpeg, jpg, png) only </span>
              <input type="file" name="pic[]">
            </div>
        </div>
                        
                        <div class="form-row">
          <div class="form-label col-md-4">
            <label for="">Product image 4:</label>
          </div>
          <div class="float-left col-md-8"> <span class="btn medium bg-green fileinput-button"> <span class="button-content">Max 500kb. 555px x 555px. (gif, jpeg, jpg, png) only </span>
              <input type="file" name="pic[]">
            </div>
        </div>
                            
                            <div class="form-row">
          <div class="form-label col-md-4">
            <label for="">Product image 5:</label>
          </div>
          <div class="float-left col-md-8"> <span class="btn medium bg-green fileinput-button"> <span class="button-content">Max 500kb. 555px x 555px.  (gif, jpeg, jpg, png) only</span>
              <input type="file" name="pic[]">
             </div>
        </div>

			             
            <div class="divider"></div>
            <div class="form-row">
                <input type="hidden" name="parent_id" id="parent_id_edit_child">
                <input type="hidden" name="id" id="id_child_edit">
                <input type="hidden" name="e_size" id="size_child_edit">
                <input type="hidden" name="e_featured" id="featured_child_edit">
                <input type="hidden" name="e_bselling" id="bselling_child_edit">
                <input type="hidden" name="e_pic[]" id="pic1_child_edit">
                <input type="hidden" name="e_pic[]" id="pic2_child_edit">
                <input type="hidden" name="e_pic[]" id="pic3_child_edit">
                <input type="hidden" name="e_pic[]" id="pic4_child_edit">
                <input type="hidden" name="e_pic[]" id="pic5_child_edit">
                <input type="hidden" name="sc_id" id="sc_id_add_edit" value="<?php echo $sc_id; ?>">
                <input type="hidden" name="sc_name" id="sc_name_add_edit" value="<?php echo $sc_name; ?>">
                <div class="form-input col-md-8 col-md-offset-4">
               <button type="submit" name="submit_child_edit"  class="btn large primary-bg" onclick="javascript:$(&apos;#demo-form-edit-child&apos;).parsley( &apos;validate&apos; );"><span class="button-content">Save Data</span></button>
&nbsp;
                </div>
            </div>
          
            </div> </div> </form> </div></div>
<!-------------------------------------view child-------------------------------------------------->		
			<div class="hide" id="black-modal-child_view" title="CHILD PRODUCT DETAILS">
            <div class="pad10A" id="viewfupdata"></div>
            </div> 
<!------------------------------------------------------------------------------------------------->                
              
<script type="text/javascript">
////////////////////////////view child data///////////////////////	
	 $(function() {
		
         $( ".black-modal-child-view" ).click(function() {
			 
			 var cid = $(this).attr("id");  
           $.ajax({  
                url:"fetch_child_data.php",  
                method:"post",  
                data:{cid:cid},
			 beforeSend: function(){
				$('#loading').fadeIn();
			    },
        complete: function(){
				$('#loading').hide();
				},
				success:function(data){  
				$('#viewfupdata').html(data);
				$( "#black-modal-child_view" ).dialog({
				 modal: true,
				 minWidth: 900,
				 minHeight: 400, 
				 dialogClass: "modal-dialog",
				 buttons: {
					   "CLOSE": function() {
						   $( this ).dialog( "close" );
					   }
				   }, 
				 show: "fadeIn" 
			   });
			   $('.ui-widget-overlay').addClass('bg-black opacity-60');
				
                }  
           });  
		   
         });
		 
    });
    
//////////////////////////////////////////////add child/////////////////////////////////////////

 
         $( ".black-modal-new" ).click(function() {
			var cid = $(this).attr("id"); 
			$("#parent_id_add").val(cid);	
           $( "#black-modal-new" ).dialog({
             modal: true,
             minWidth:900,
             minHeight: 200, 
             dialogClass: "modal-dialog", 
             buttons: {
					   "CLOSE": function() {
						   $( this ).dialog( "close" );
					   }
				   },
			   show: "fadeIn" 
           });
           $('.ui-widget-overlay').addClass('bg-black opacity-60');
         });              
    
//////////////////////////////edit child////////////////////////////////////////
 
	$( ".black-modal-child-edit" ).click(function() { 
           var cid = $(this).attr("id");  
		   $.ajax({  
                url:"fetch_child_edit_data.php",  
                method:"POST",  
                data:{cid:cid},  
                dataType:"json",
                beforeSend: function(){
				$('#loading').fadeIn();
			    },
        complete: function(){
				$('#loading').hide();
				},
               error: function(xhr, error){
        console.debug(xhr); console.debug(error);
 },
                success:function(data){  

$('#parent_id_edit_child').val(data.parent_id);
$('#id_child_edit').val(data.id); 		                    
$('#SKU_edit_child').val(data.sku); 				
$('#size_child_edit').val(data.size);                   
$('#MRP_edit_child').val(data.mrp);       
$('#price_edit_child').val(data.price);
$('#stock_edit_child').val(data.qty);		
$('#featured_child_edit').val(data.featured);		
$('#bselling_child_edit').val(data.bestselling);		                    
$('#pic1_child_edit').val(data.pic1);		
$('#pic2_child_edit').val(data.pic2);		
$('#pic3_child_edit').val(data.pic3);		
$('#pic4_child_edit').val(data.pic4);		
$('#pic5_child_edit').val(data.pic5);		                    

					$( "#black-modal-edit-child" ).dialog({
             modal: true,
             minWidth:900,
             minHeight: 200, 
             dialogClass: "modal-dialog", 
             buttons: {
					   "CLOSE": function() {
						   $( this ).dialog( "close" );
					   }
				   },
			   show: "fadeIn" 
           });
           $('.ui-widget-overlay').addClass('bg-black opacity-60');
                }  
           });  
      });      
//////////////////////////////edit parent////////////////////////////////////////
 
	$( ".black-modal-edit" ).click(function() { 
           var cid = $(this).attr("id");  
		   $.ajax({  
                url:"fetch_parent_details.php",  
                method:"POST",  
                data:{cid:cid},  
                dataType:"json",  
                beforeSend: function(){
				$('#loading').fadeIn();
			    },
        complete: function(){
				$('#loading').hide();
				},
                success:function(data){  

$('#parent_id_edit').val(data.id); 		                    
$('#name').val(data.name); 				
$('#details').val(data.details);
$('#description').val(data.description);  
$('#disclaimer').val(data.disclaimer);                      
$('#title').val(data.seo_title);       
$('#keywords').val(data.seo_keyword);
$('#meta').val(data.seo_meta);					
$('#tags').val(data.tags);   			

					$( "#black-modal-edit" ).dialog({
             modal: true,
             minWidth:900,
             minHeight: 200, 
             dialogClass: "modal-dialog", 
             buttons: {
					   "CLOSE": function() {
						   $( this ).dialog( "close" );
					   }
				   },
			   show: "fadeIn" 
           });
           $('.ui-widget-overlay').addClass('bg-black opacity-60');
                }  
           });  
      });  
    
              </script>
           

<script language="javascript">
    function goBack() {
        window.history.back();
    }

    function pageprint() {
        window.print();
    }
</script>
<?php
$mquery = "SELECT id, name FROM bb_categories ORDER BY id ASC";

if(!$mstmt = $con->prepare($mquery))
{
	echo "prepare failed: (" . $con->errno . ") " . $con->error;	exit();
}

	if(!$mstmt->execute())
	{
		$error = "categories list failed!".$con->error;		exit();
		
	}

		if(!$mstmt->store_result())
		{
			$error = "categories list failed!".$con->error;		exit();			
		}
	
		$mnum_of_rows = $mstmt->num_rows;

if($mnum_of_rows==0)
{
	$terror = "No categories found";		
}

?>
    
<div id="page-header" class="clearfix">

    <div id="header-logo"> <a href="javascript:;" class="tooltip-button" data-placement="bottom" title="Close sidebar" id="close-sidebar"> <i class="glyph-icon icon-caret-left"></i> </a> <a href="javascript:;" class="tooltip-button hidden" data-placement="bottom" title="Open sidebar" id="rm-close-sidebar"> <i class="glyph-icon icon-caret-right"></i> </a> <a href="javascript:;" class="tooltip-button hidden" title="Navigation Menu" id="responsive-open-menu"> <i class="glyph-icon icon-align-justify"></i> </a>
        <?php echo $_SESSION['cName']; ?><i class="opacity-80"></i> CRM</div>


    <!--//////notifications///////////// -->
    <?php 
/*	if($_SESSION['adminRole'] == "Admin")
{
	$notificationlink = "notifications_admin.php";
}
else
{
	$notificationlink = "notifications.php";
}

 include($notificationlink);*/ ?>

    <!-------------------------------------------------------------------->

    <div class="user-profile dropdown"> <a href="javascript:;" title="" class="user-ico clearfix" data-toggle="dropdown"> <img width="57" src="<?php echo $_SESSION['gpath'].$_SESSION['cLogo']; ?>" alt=""> <span><?php echo $_SESSION['adminName']." <strong>(".$_SESSION['adminRole'].")</strong>"; ?></span> <i class="glyph-icon icon-chevron-down"></i> </a>
        <ul class="dropdown-menu float-right">
            <li> <a href="javascript:;" title=""> <i class="glyph-icon icon-user mrg5R"></i> <strong>Role</strong>: <?php echo $_SESSION['adminRole']; ?></a> </li>

            <li> <a href="javascript:;" title=""> <i class="glyph-icon icon-desktop mrg5R"></i> <strong>last Login</strong>: <?php if($_SESSION['lastlogintime']!=NULL) { echo date("jS D, M Y h:i:sA",strtotime($_SESSION['lastlogintime'])); } else { echo "N/A"; } ?></a> </li>

            <li>
                <?php 
											
											$paramStr = "id=".base64url_encode($_SESSION['adminSession'])."&name=".base64url_encode($_SESSION['adminName']);
											$hmac = hash_hmac('sha1', $paramStr, 'JS4#$sdUI'); 						
										?>

                <a href="<?php echo $_SESSION['gpath']; ?>change_employee_password.php?<?php echo $paramStr; ?>&pk=<?php echo $hmac; ?>" title="Loan Status"> <i class="glyph-icon icon-dashboard"></i> Change Password</a> </li>

            <li> <a href="<?php echo $_SESSION['gpath']; ?>logout.php" title=""> <i class="glyph-icon icon-minus-circle font-size-13 mrg5R font-red"></i> <span class="font-bold font-red">Logout</span> </a> </li>
        </ul>

    </div>
    <!-- <a href="#" class="btn x-large primary-bg" title="" onclick="goBack()">
            <span class="button-content">BACK</span>
        </a>-->

</div>

<div id="page-sidebar" class="scrollable-content">
    <div id="sidebar-menu">
        <ul>
            <li> <a href="<?php echo $_SESSION['gpath']; ?>admin_dashboard.php" title="Dashboard"> <i class="glyph-icon icon-laptop"></i> Dashboard</a>
            </li>
            
            <li> <a href="javascript:;" title="Landing Users"> <i class="glyph-icon icon-tags"></i>Landing Users</a>
                <ul>
                    <li> <a href="<?php echo $_SESSION['gpath']; ?>users/list_all_landing_users.php?status=All" title="All Users"> <i class="glyph-icon icon-tags"></i>All Users</a>
                    </li>
                    
                  <!--  <li> <a href="<?php echo $_SESSION['gpath']; ?>reports/csv/exportcsv.php?userreport=1" title="Download report"> <i class="glyph-icon icon-download"></i>Download</a>
                    </li>-->
                    
                    
                </ul>
            </li>
            
            
       <!--     
             <li> <a href="<?php echo $_SESSION['gpath']; ?>users/list_all_otp.php" title="OTP Phones"> <i class="glyph-icon icon-laptop"></i> OTP Phones</a></li>
            <li> <a href="javascript:;" title="Orders"> <i class="glyph-icon icon-tags"></i>Online Orders</a>
                <ul>
                    <li> <a href="<?php echo $_SESSION['gpath']; ?>orders/list_all_orders.php?status=All" title="list all orders"> <i class="glyph-icon icon-tags"></i>All</a>
                    </li>
                    <li> <a href="<?php echo $_SESSION['gpath']; ?>orders/list_all_orders.php?status=Confirmed" title="list all orders"> <i class="glyph-icon icon-tags"></i>Current</a>
                    </li>
                    <li> <a href="<?php echo $_SESSION['gpath']; ?>orders/list_all_orders.php?status=Shipped" title="list all orders"> <i class="glyph-icon icon-tags"></i>Shipped</a>
                    </li>
                    <li> <a href="<?php echo $_SESSION['gpath']; ?>orders/list_all_orders.php?status=Delivered" title="list all orders"> <i class="glyph-icon icon-tags"></i>Delivered</a>
                    </li>
                      <li> <a href="<?php echo $_SESSION['gpath']; ?>orders/list_all_orders.php?status=Cancelled" title="list all orders"> <i class="glyph-icon icon-tags"></i>Cancelled</a></li>
                   
                     <li> <a href="<?php echo $_SESSION['gpath']; ?>orders/list_all_orders.php?status=Cancellation Requested" title="list all orders"> <i class="glyph-icon icon-tags"></i>Cancellation Requested </a></li>
                    <li> <a href="<?php echo $_SESSION['gpath']; ?>orders/list_pending_orders.php" title="list all pending orders"> <i class="glyph-icon icon-tags"></i>Pending </a></li>

                </ul>
            </li>-->
            
      <!--       <li> <a href="javascript:;" title="Orders"> <i class="glyph-icon icon-tags"></i>Offline Orders</a>
                <ul>
                     <li> <a href="<?php echo $_SESSION['gpath']; ?>orders/add_new_order.php" title="Create order"> <i class="glyph-icon icon-tags"></i>Create order </a></li>
                    
                    <li> <a href="<?php echo $_SESSION['gpath']; ?>orders/list_all_orders_offline.php?status=All" title="list all offline orders"> <i class="glyph-icon icon-tags"></i>All</a>
                    </li>
                  
                    <li> <a href="<?php echo $_SESSION['gpath']; ?>orders/list_all_orders_offline.php?status=Shipped" title="list all orders"> <i class="glyph-icon icon-tags"></i>Shipped</a>
                    </li>
                    <li> <a href="<?php echo $_SESSION['gpath']; ?>orders/list_all_orders_offline.php?status=Delivered" title="list all orders"> <i class="glyph-icon icon-tags"></i>Delivered</a>
                    </li>
                            

                </ul>
            </li>-->
            
             <!--<li> <a href="javascript:;" title="Reviews"> <i class="glyph-icon icon-tags"></i>Users</a>
                <ul>
                    <li> <a href="<?php echo $_SESSION['gpath']; ?>users/list_all_users.php?status=All" title="All Users"> <i class="glyph-icon icon-tags"></i>All Users</a>
                    </li>
                    
                    <li> <a href="<?php echo $_SESSION['gpath']; ?>reports/csv/exportcsv.php?userreport=1" title="Download report"> <i class="glyph-icon icon-download"></i>Download</a>
                    </li>
                    
                    
                </ul>
            </li>-->
            
             
            
            <li> <a href="javascript:;" title="Reviews"> <i class="glyph-icon icon-tags"></i>Reviews</a>
                <ul>
                    <li> <a href="<?php echo $_SESSION['gpath']; ?>reviews/list_all_reviews.php?status=All" title="All Reviews"> <i class="glyph-icon icon-tags"></i>All Reviews</a>
                    </li>
                    <li> <a href="<?php echo $_SESSION['gpath']; ?>reviews/list_all_reviews.php?status=1" title="Published"> <i class="glyph-icon icon-tags"></i>Published</a>
                    </li>
                    <li> <a href="<?php echo $_SESSION['gpath']; ?>reviews/list_all_reviews.php?status=0" title="Unpublished"> <i class="glyph-icon icon-tags"></i>Unpublished</a>
                    </li>
                     <li> <a href="<?php echo $_SESSION['gpath']; ?>reviews/list_all_sm_reviews.php" title="SM Reviews"> <i class="glyph-icon icon-tags"></i>SM Reviews</a>
                    </li>
                    
                </ul>
            </li>
            
          <!--   <li> <a href="javascript:;" title="Reports"> <i class="glyph-icon icon-tags"></i>Reports</a>
                <ul>
                    <li> <a href="<?php echo $_SESSION['gpath']; ?>reports/order_reports_summary.php" title="Orders"> <i class="glyph-icon icon-tags"></i>Orders</a>
                    </li>
                    <li> <a href="<?php echo $_SESSION['gpath']; ?>reports/sales_report_summary.php" title="Sales"> <i class="glyph-icon icon-tags"></i>Sales</a>
                    </li>
                    <li> <a href="<?php echo $_SESSION['gpath']; ?>reports/download_order_reports.php" title="Download Reports"> <i class="glyph-icon icon-download"></i>Download</a>
                    </li>
                </ul>
            </li>-->
            
            <li> <a href="<?php echo $_SESSION['gpath']; ?>inventory/add_new_product.php" title="Add Product"> <i class="glyph-icon icon-laptop"></i> Add Product</a>
            </li>
            
             <?php      
			if(isset($merror))
			{
				?>
			     <option value=""><?php echo $merror; ?></option>	
			<?php 
						} 
						else
						{
			?>   
                  <?php 
	$mstmt->bind_result($mcid, $mcname);
	while ($mstmt->fetch()) 
	{
			
	?>            
                  <li> <a href="javascript:;" title="<?php echo $mcname; ?>"> <i class="glyph-icon icon-tags"></i><?php echo $mcname; ?></a> <ul>
                  
       <?php
    ////////////////////////////////////////sub category////////////////////////////////////////////
        
    $scquery = "SELECT id, name FROM bb_sub_categories WHERE mc_id = ? ORDER BY id ASC";

if(!$scstmt = $con->prepare($scquery))
{
	echo "prepare failed: (" . $con->errno . ") " . $con->error;	exit();
}
	if(!$scstmt->bind_param("i", $mcid))
{
	echo "Param pass failed: (" . $con->errno . ") " . $con->error;exit();
}

	if(!$scstmt->execute())
	{
		$error = "sub categories list failed!".$con->error;		exit();
		
	}

		if(!$scstmt->store_result())
		{
			$error = "sub categories list failed!".$con->error;	exit();				
		}
	
		$scnum_of_rows = $scstmt->num_rows;

if($scnum_of_rows==0)
{
    ?>
                      
	 <li> <a href="javascript:;">No sub categories found!</a></li> </ul>
                      <?php
} else {
	$scstmt->bind_result($scid, $scname);
	while ($scstmt->fetch()) 
	{        
        ?>
                      <li> <a href="<?php echo $_SESSION['gpath']; ?>inventory/list_all_products.php?sc_id=<?php echo $scid; ?>&sc_name=<?php echo $scname; ?>" title="<?php echo $scname; ?>"> <i class="glyph-icon icon-laptop"></i><?php echo $scname; ?></a></li>
                      
<?php
        
        
    }
    ?>
            </ul>
        <?php 
    
}
        
////////////////////////////////////////////////////////////////////////////////////////////////////////        
    } 
                         } 
     	?>            

                
            </li>
 
         <li> <a href="javascript:;" title="Reports"> <i class="glyph-icon icon-tags"></i>Banners</a>
                <ul>
                    <li> <a href="<?php echo $_SESSION['gpath']; ?>banner/add_banners.php" title="Sub categories banner"> <i class="glyph-icon icon-tags"></i>Sub Categories</a>
                    </li>
                    <li> <a href="<?php echo $_SESSION['gpath']; ?>banner/header_banners.php" title="Header Banner"> <i class="glyph-icon icon-tags"></i>Header Banner</a>
                    </li>
                </ul>
            </li>
            <li> <a href="javascript:;" title="Settings"> <i class="glyph-icon icon-tags"></i>Settings</a>
                <ul>
                     <li> <a href="<?php echo $_SESSION['gpath']; ?>sizes/add_size.php" title="Add Size"> <i class="glyph-icon icon-tags"></i>Add Size</a>
                    </li>
                    
                    <li>
                        <?php 
											
											$paramStr = "id=".base64url_encode($_SESSION['adminSession'])."&name=".base64url_encode($_SESSION['adminName']);
											$hmac = hash_hmac('sha1', $paramStr, 'JS4#$sdUI'); 						
										?>

                        <a href="<?php echo $_SESSION['gpath']; ?>change_employee_password.php?<?php echo $paramStr; ?>&pk=<?php echo $hmac; ?>" title="Change Password"> <i class="glyph-icon icon-dashboard"></i> Change Password</a> </li>
                </ul>
            </li>

            <li> <a href="<?php echo $_SESSION['gpath']; ?>logout.php" title="Logout"> <i class="glyph-icon icon-laptop"></i> Logout</a>
            </li>

        </ul>
    </div>
</div>
<div id="breadcrumb-right">
    <?php if($periodic)
    
{ ?>
    
      <div class="float-right">
<?php							
    $tname = $table_name;
    
$paramStr = "tname=".base64url_encode($tname)."&from=".base64url_encode($from)."&to=".base64url_encode($to)."&periodic=".base64url_encode($periodic)."&column=".base64url_encode($column)."&filename=".base64url_encode($filename);
											$hmac = hash_hmac('sha1', $paramStr, 'o52SG&sdUI'); ?>
							   
             <a href="csv/exportcsv.php?<?php echo $paramStr; ?>&pk=<?php echo $hmac; ?>" target="_blank" class="btn medium bg-white" title="">
            <span class="button-content"><i class="glyph-icon icon-download"></i> Download</span>
        </a>
                        </div>
<?php }  else {  ?>
    
    
   <div class="float-right">
<?php										$tname = $table_name;
											$paramStr = "tname=".base64url_encode($tname)."&periodic=".base64url_encode($periodic)."&filename=".base64url_encode($filename);
											$hmac = hash_hmac('sha1', $paramStr, 'o52SG&sdUI'); ?>
							   
             <a href="csv/exportcsv.php?<?php echo $paramStr; ?>&pk=<?php echo $hmac; ?>" target="_blank" class="btn medium bg-white" title="">
            <span class="button-content"><i class="glyph-icon icon-download"></i> Download</span>
        </a>
                        </div>
    
    
    <?php } ?>
                         
                    </div>
                    
                    
<?php
include "../db/db_connect.php"; 
include "../db/session.php";  
include "../function/function.php";  
require_once '../admin/class.user.php';

//////////////////reports//////////////////////

 if(isset($_POST['rid'])&&isset($_POST['from']))
{
extract($_POST);
$begin = new DateTime($from);
$end = new DateTime($to);
$end = $end->modify('first day of next month'); 
$interval = DateInterval::createFromDateString('1 month');
$daterange = new DatePeriod($begin, $interval ,$end);
$arrData = array();
$netsales = $netloans = 0;
foreach($daterange as $month){
 if($month->format("Y")!="")
 {
$qmonth = $month->format("F");
$qyear = $month->format("Y");

$oquery = "SELECT SUM(cost) AS totalsales, COUNT(id) AS totalorders FROM bb_orders WHERE UPPER(orderstatus)<> ? AND MONTHNAME(orderdate)= ? AND YEAR(orderdate)= ?";			

		if(!$rstmt = $con->prepare($oquery))
		{
		echo $error = "Loan customers report failed!".$con->error; exit();					
		}
		$cancelled = "CANCELLED";
			
		if(!$rstmt->bind_param("sss", $cancelled, $qmonth, $qyear))
		{
		echo $error = "Sales report failed!".$con->error; exit();							
		}


		if($rstmt->execute()) 
			{
				if($qresult = $rstmt->get_result())
					{
						$data = $qresult->fetch_assoc();
					}
					else
					{
							echo $error = "Sales report failed!".$con->error;	exit();				
					}
			}
			else
			{
						echo $error = "Sales report execution failed!".$con->errno." ".$con->error; exit();
			}
			
if($data['totalsales']>0)
{
$totalsales = $data['totalsales'];
}
else
{
$totalsales = 0;
}
$totalloans = $data['totalorders'];
$time = $month->format("M")." ".$qyear;
array_push($arrData, array(
              	"Month" => $time,
              	"Sales" => $totalsales,
              	"Orders" => $totalloans
              	)
           	);
        
 }
 
$netsales = $netsales + $totalsales;
$netloans = $netloans + $totalloans;
}
 			
}


///////////////////////////////////////////////////////////////

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>Sharpstreak Admin Area</title>
<meta name="description" content="">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

     <link rel="apple-touch-icon-precomposed" sizes="144x144" href="../assets/images/icons/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="../assets/images/icons/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="../assets/images/icons/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="../assets/images/icons/apple-touch-icon-57-precomposed.png">
        <link rel="shortcut icon" href="../assets/images/icons/favicon.png">

        <!--[if lt IE 9]>
          <script src="../assets/js/minified/core/html5shiv.min.js"></script>
          <script src="../assets/js/minified/core/respond.min.js"></script>
        <![endif]-->

        <!-- Fides Admin CSS Core -->

        <link rel="stylesheet" type="text/css" href="../assets/css/minified/aui-production.min.css">

        <!-- Theme UI -->

        <link id="layout-theme" rel="stylesheet" type="text/css" href="../assets/themes/minified/fides/color-schemes/dark-blue.min.css">

        <!-- Fides Admin Responsive -->

        <link rel="stylesheet" type="text/css" href="../assets/themes/minified/fides/common.min.css">
        <!-- <link rel="stylesheet" type="text/css" href="../_assets/themes/fides/common.css"> -->

        <link id="theme-animations" rel="stylesheet" type="text/css" href="../assets/themes/minified/fides/animations.min.css">

        <link rel="stylesheet" type="text/css" href="../assets/themes/minified/fides/responsive.min.css">


        <!-- Fides Admin JS -->

        <script type="text/javascript" src="../assets/js/minified/aui-production.min.js"></script>
        <script type="text/javascript" src="../assets/js/minified/core/raphael.min.js"></script>
        <script type="text/javascript" src="../assets/js/minified/widgets/charts-justgage.min.js"></script>
<script type="text/javascript" src="../assets/js/minified/widgets/charts-morris.min.js"></script>  
    

    <script type="text/javascript">
 
    $(function() {
 

		 $( ".fromDate" ).datepicker({
         changeMonth: true,
        changeYear: true,
        showButtonPanel: false,
	   yearRange:'-30:+00',		
        dateFormat: 'MM yy',
        onClose: function(dateText, inst) { 
            var month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
            var year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
            $(this).datepicker('setDate', new Date(year, month, 1));
        }

         });
		 
		 
		 
		 
         $( ".toDate" ).datepicker({
           changeMonth: true,
        changeYear: true,
        showButtonPanel: false,
	   yearRange:'-30:+00',				
        dateFormat: 'MM yy',
        onClose: function(dateText, inst) { 
            var month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
            var year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
            $(this).datepicker('setDate', new Date(year, month, 1));
        }
         });
    });
 
</script>
    <style>

.dataTables_scrollBody
{
	height:500px !important;

}
.ui-datepicker-calendar {
    display: none;
    }​

.ui-datepicker .ui-datepicker-header {
	padding:10px;
}
	
	
.ui-datepicker .ui-datepicker-title{width:170px !important; padding:0 25px}

</style>
    
</head>
<body>
<div id="loading" class="ui-front loader ui-widget-overlay bg-white opacity-100"> <img src="assets/images/loader-dark.gif" alt=""> </div>
<div id="page-wrapper" class="demo-example"> 
  <!-- #page-header -->
  
  <?php include("../sidebar.php"); ?>
  <!-- #page-sidebar -->
  <div id="menu-right" class="scrollable-content hidden"> <a href="javascript:;" title="Get Source" class="popover-title button-toggle-open"> Cloud status <i class="glyph-icon icon-caret-right icon-caret-down"></i> </a>
    <div class="clear"></div>
    <a href="javascript:;" title="Get Source" class="popover-title button-toggle-open"> Realtime server load <i class="glyph-icon icon-caret-right icon-caret-down"></i> </a>
    <div class="toggle-content-open clearfix">
      <div id="g10" class="small-gauge float-left"></div>
      <div id="g11" class="small-gauge float-right"></div>
    </div>
  </div>
  <div id="page-content-wrapper">
    <div id="page-title">
<h3>
   <strong>Sales Performance Summary</strong>
    </h3>

    </div>
    <!-- #page-title -->
    <div id="page-content"> 
      <script type="text/javascript">

$(document).ready(function() {

});

</script>
      <h4>&nbsp;</h4>
        
 <?php        
 if(isset($_POST['rid'])&&isset($_POST['from']))
{   ?>     
      <div class="example-code">   
  <div class="col-lg-12">
              <div class="profile-box profile-box-alt content-box">
                <div class="content-box-header clearfix primary-bg">
                  <div class="user-details">Sales from: <strong><?php echo date("M Y", strtotime($_POST['from']))." - ".date("M Y", strtotime($_POST['to'])) ?></strong> </div>
                </div>

<div class="col-md-12">
<div class="row">
    <div class="col-md-12">
              <div class="profile-box content-box">
            <div class="content-box-header clearfix bg-gray">
                  <div class="user-details">Total Sales: <strong>&#x20b9; <?php echo currencyIndia($netsales); ?></strong> | Total Orders: <strong><?php echo $netloans; ?></strong></div>
                </div>
              </div>
            </div>
  <div class="col-md-12">
        <div class="content-box"><br>

            <div id="labels-bar"></div>
        </div>
    </div>
            <div class="col-md-12">
        <div class="content-box">
            <div id="decimal-data"></div>
        </div>
    </div>
    </div>
    
    
    
</div>    


<script type="text/javascript">

 $(function() {
 var day_data = <?php echo json_encode($arrData); ?>;
     Morris.Bar({
       element: 'labels-bar',
       data: day_data,
       xkey: 'Month',
       ykeys: ['Sales', 'Orders'],
       labels: ['Sales', 'Orders'],
       xLabelAngle: 60
     });
 });
	
$(function() {
var decimal_data = <?php echo json_encode($arrData); ?>;
    window.m = Morris.Line({
      element: 'decimal-data',
       data: decimal_data,
      xkey: 'Month',
      ykeys: ['Sales', 'Orders'],
      labels: ['Sales', 'Orders'],
      parseTime: false,
      xLabelMargin: 10,
      integerYLabels: true,
       xLabelAngle: 60
     });
 });
 
</script>            
            </div>
            
             </div>
             
             
      </div>
        <?php } ?>
        
        <div class="example-code">                

      <form id="demo-form-2" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" class="col-md-12" method="post">
        <div class="content-box mrg25B">
          <h3 class="content-box-header primary-bg"> <span>Select Date</span> </h3>
          <div class="content-box-wrapper">
          
            <div class="form-input col-md-12">

<div class="example-code clearfix">

        <div class="form-row col-lg-6">
            <div class="form-input">
                <input type="text" size="10" class="fromDate" name="from" placeholder="From" class="parsley-validated" autocomplete="off" data-trigger="change" required>
            </div>
        </div>

        <div class="form-row col-lg-6 pad25L">
            <div class="form-input">
                <input type="text" size="10" class="toDate" name="to" placeholder="To" class="parsley-validated" data-trigger="change" autocomplete="off" required>
            </div>
        </div>

    </div>                
              </div>
          </div>
             <div class="form-row">
          <input type="hidden" name="superhidden" id="superhidden">
                    <input type="hidden" name="rid" id="rid" value="sales">  
          <div class="form-input col-md-10 col-md-offset-2"> <span class="button-content">
            <input type="submit" name="submit" class="bg-green" value="View Report" onclick="javascript:$(&apos;#demo-form-2&apos;).parsley( &apos;validate&apos; );">
            </span> </div>
        </div>
        </div>
      </form>
     
      </div>
            
    </div>
    <!-- #page-content --> 
  </div>
</div>
<!-- #page-content -->
</div>
<!-- #page-main -->
</div>
<!-- #page-wrapper -->

</body>
</html>

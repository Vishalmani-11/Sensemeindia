<?php
include "../db/session.php";  
include "../db/db_connect.php"; 
include "../function/function.php";  
require_once '../admin/class.user.php';

$periodic = 0;
$filename = "orders_report.csv";
$column = NULL;
//////////////////////////////report by date///////////////////////////////////////
if(isset($_POST['submit_date'])&&$_POST['submit_date']!="")
{

 $query = "SELECT orderstatus, COUNT(id) FROM bb_orders WHERE orderdate >= ? AND orderdate < ? GROUP BY orderstatus";

    $table_name = "bb_orders";
    $periodic = 1;
    $column = "orderdate";
    
if(!$rstmt = $con->prepare($query))
{
		echo $error = "data listing execution failed!".$con->error;			
}


				$from = date('Y-m-d', strtotime($_POST['from']));
				$to = date('Y-m-d', strtotime($_POST['to'].'+1 day'));	
	
    $filename = "orders_report_".date('d_M_Y', strtotime($_POST['from']))." - ".date('d_M_Y', strtotime($_POST['to'])).".csv";
    
if(!$rstmt->bind_param("ss",$from, $to))
{
		echo $error = "data listing execution failed!".$con->error;			
}


	if(!$rstmt->execute())
	{
		echo $error = "data listing execution failed!".$con->error;		
		
	}
		if(!$rstmt->store_result())
		{
			echo $error = "data listing execution failed!".$con->error;					
		}
	
		$num_of_rows = $rstmt->num_rows;

if($num_of_rows==0)
{
	$cerror = "No records found";		
}

}
else
{

//////////////////////////////data///////////////////////////////////////

 $query = "SELECT orderstatus, COUNT(id) FROM bb_orders GROUP BY orderstatus";

$table_name = "bb_orders";
    
if(!$rstmt = $con->prepare($query))
{
		echo $error = "data listing execution failed!".$con->error;			
}

	if(!$rstmt->execute())
	{
		echo $error = "data listing execution failed!".$con->error;		
		
	}
		if(!$rstmt->store_result())
		{
			echo $error = "data listing execution failed!".$con->error;					
		}
	
		$num_of_rows = $rstmt->num_rows;

if($num_of_rows==0)
{
	$cerror = "No records found";		
}

}

//////////////////////////////////
?>
<!DOCTYPE html>
    <html>
    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title><?php echo $_SESSION['cName']; ?> Admin Area</title>
   <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

        <!-- Favicons -->

        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="../assets/images/icons/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="../assets/images/icons/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="../assets/images/icons/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="../assets/images/icons/apple-touch-icon-57-precomposed.png">
        <link rel="shortcut icon" href="../assets/images/icons/favicon.png">

        <!--[if lt IE 9]>
          <script src="assets/js/minified/core/html5shiv.min.js"></script>
          <script src="assets/js/minified/core/respond.min.js"></script>
        <![endif]-->

        <!-- Fides Admin CSS Core -->

        <link rel="stylesheet" type="text/css" href="../assets/css/minified/aui-production.min.css">

        <!-- Theme UI -->

        <link id="layout-theme" rel="stylesheet" type="text/css" href="../assets/themes/minified/fides/color-schemes/dark-blue.min.css">

        <!-- Fides Admin Responsive -->

        <link rel="stylesheet" type="text/css" href="../assets/themes/minified/fides/common.min.css">
        <!-- <link rel="stylesheet" type="text/css" href="../_assets/themes/fides/common.css"> -->

        <link id="theme-animations" rel="stylesheet" type="text/css" href="../assets/themes/minified/fides/animations.min.css">

        <link rel="stylesheet" type="text/css" href="../assets/themes/minified/fides/responsive.min.css">

        <!-- Fides Admin JS -->

        <script type="text/javascript" src="../assets/js/minified/aui-production.min.js"></script>
        <script type="text/javascript" src="../assets/js/minified/core/raphael.min.js"></script>
        <script type="text/javascript" src="../assets/js/minified/widgets/charts-justgage.min.js"></script>
<script type="text/javascript" src="../assets/js/minified/widgets/charts-morris.min.js"></script>           

<script type="text/javascript">
 
    $(function() {
 
         $( ".fromDate" ).datepicker({
           defaultDate: "+1w",
           changeMonth: true,
           numberOfMonths: 3,
           onClose: function( selectedDate ) {
             $( ".toDate" ).datepicker( "option", "minDate", selectedDate );
           }
         });
         $( ".toDate" ).datepicker({
           defaultDate: "+1w",
           changeMonth: true,
           numberOfMonths: 3,
           onClose: function( selectedDate ) {
             $( ".fromDate" ).datepicker( "option", "maxDate", selectedDate );
           }
         });
 
    });
 
</script>
<style>

.dataTables_scrollBody
{
	height:500px !important;

}

</style>

    </head>
    <body>
    
        

        <div id="loading" class="ui-front loader ui-widget-overlay bg-white opacity-100">
            <img src="assets/images/loader-dark.gif" alt="">
        </div>

        <div id="page-wrapper" class="demo-example">
          <!-- #page-header -->

            <?php include("../sidebar.php"); ?>
            <!-- #page-sidebar -->
            <div id="menu-right" class="scrollable-content hidden">
                <a href="javascript:;" title="Get Source" class="popover-title button-toggle-open">
                    Cloud status
                    <i class="glyph-icon icon-caret-right icon-caret-down"></i>
                </a>
                <div class="clear"></div>
                <a href="javascript:;" title="Get Source" class="popover-title button-toggle-open">
                    Realtime server load
                    <i class="glyph-icon icon-caret-right icon-caret-down"></i>
                </a>
                <div class="toggle-content-open clearfix">

                    <div id="g10" class="small-gauge float-left"></div>
                    <div id="g11" class="small-gauge float-right"></div>

                </div>
            </div>
            <div id="page-content-wrapper">
                <div id="page-title">

<h3>
   <strong>Orders Report Summary</strong> <?php if(isset($_POST['submit_date'])&&$_POST['submit_date']!="")
{ echo "(".date('dS M, Y', strtotime($_POST['from']))." - ".date('dS M, Y', strtotime($_POST['to'])).")"; }  ?>

    </h3>
        <?php include("download_menu.php"); ?>      
              </div><!-- #page-title -->
<div id="page-content">


<h4>&nbsp;</h4>
    <?php 
			   if(isset($success)){ ?>
             
             <div class="infobox success-bg">
<a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>             
                    <h4 class="infobox-title"><?php echo $success;?></h4>
                </div><?php } ?>
                <?php 
			   if(isset($_GET['success'])){ ?>
             <div class="infobox success-bg">
<a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>             
                    <h4 class="infobox-title"><?php echo $_GET['success'];?></h4>
                </div><?php } ?>
                
 <div class="example-code">   
    <?php 
	if($num_of_rows>0)
	{
	$sn = 0;
	$totalAPPs = $confirmed = $shipped = $delivered = $cancelled = $cancel_req = 0;
	$rstmt->bind_result($status, $total);
	while ($rstmt->fetch()) 
	{
			$sn = 	$sn + 1;
			$totalAPPs = $totalAPPs + $total;		
			
			switch (strtoupper($status)) {

						case "CONFIRMED":
						$confirmed = $total;						
						break;

						case "SHIPPED":
  						 $shipped = $total;						
						break;
                    
                        case "DELIVERED":
						$delivered = $total;						
						break;

						case "CANCELLED":
  						$cancelled = $total;						
						break;
                    
                    	case "CANCELLATION REQUESTED":
  						$cancel_req = $total;						
						break;
                    
                    
                    
					}	
} 
		
		$rstmt->free_result();
		$con->close();
		?>
                              
<?php
		$avg_confirmed = round(($confirmed/$totalAPPs)*100, 2);
		$avg_shipped = round(($shipped/$totalAPPs)*100, 2);
        $avg_delivered = round(($delivered/$totalAPPs)*100, 2);
		$avg_cancelled = round(($cancelled/$totalAPPs)*100, 2);
        $avg_cancel_req = round(($cancel_req/$totalAPPs)*100, 2);
?>
 <script type="text/javascript">

 $(function() {
         Morris.Donut({
           element: 'donut4',
           backgroundColor: '#fff',
           labelColor: '#999',
           colors: [
             '#65a6ff',
             '#41e5c0',
              '#9CD159',
             '#ff0000',
               '#d4d4d4'
           ],
           data: [
             {value: <?php echo $confirmed; ?>, label: 'Confirmed(<?php echo $confirmed; ?>)', formatted: '<?php echo $avg_confirmed; ?>%' },
             {value: <?php echo $shipped; ?>, label: 'Shipped(<?php echo $shipped; ?>)', formatted: '<?php echo $avg_shipped; ?>%' },
               {value: <?php echo $delivered; ?>, label: 'Delievered(<?php echo $delivered; ?>)', formatted: '<?php echo $avg_delivered; ?>%' },
               {value: <?php echo $cancelled; ?>, label: 'Cancelled(<?php echo $cancelled; ?>)', formatted: '<?php echo $avg_cancelled; ?>%' },
               {value: <?php echo $cancel_req; ?>, label: 'Cancellation Requested(<?php echo $cancel_req; ?>)', formatted: '<?php echo $avg_cancel_req; ?>%' }
          ],
           formatter: function (x, data) { return data.formatted; }
         });
     });
	

</script>
          
  <div class="col-lg-12">
              <div class="profile-box profile-box-alt content-box">
                <div class="content-box-header clearfix primary-bg">
                  <div class="user-details">Order Report Summary</div>
                </div>
            

<div class="col-md-12">

            <div id="donut4"></div>
            <div class="content-box-header clearfix bg-primary">
                  <div class="user-details"><strong>Total Orders: </strong><?php echo "<b>".$totalAPPs."<b>"; ?></div>
                </div>
                
</div>                
      
      <div class="col-md-12">
            
                <table class="table">
                  <tbody>
                    <tr>
                      <td class="text-left font-size-16 font-blue-alt"><div class="badge badge-small bg-blue"></div>
                        CONFIRMED </td>
                      <td class="text-center font-size-18"><?php echo $confirmed; ?> </td>
                    </tr>
                    <tr>
                      <td class="font-bold text-left font-size-16 font-azure"><div class="badge badge-small bg-azure"></div>
                       SHIPPED </td>
                       <td class="text-center font-size-18"><?php echo $shipped; ?> </td>
                    </tr>
                         <tr>
                      <td class="font-bold text-left font-size-16 font-green"><div class="badge badge-small  bg-green"></div>
                       DELIVERED </td>
                       <td class="text-center font-size-18"><?php echo $delivered; ?> </td>
                    </tr>
                         <tr>
                      <td class="font-bold text-left font-size-16 font-red"><div class="badge badge-small bg-red"></div>
                       CANCELLED </td>
                       <td class="text-center font-size-18"><?php echo $cancelled; ?> </td>
                    </tr>
                       <tr>
                      <td class="font-bold text-left font-size-16 font-gray"><div class="badge badge-small bg-gray-alt"></div>
                       CANCELLATION REQUESTED </td>
                       <td class="text-center font-size-18"><?php echo $cancel_req; ?> </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
             </div>
             
          
      </div>
      <?php } else { ?>
      
       <div class="infobox error-bg"> <a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>
        <h4 class="infobox-title"><?php echo "No Records found!"; ?></h4>
      </div>
	  
	  <?php 
	   } ?>
          
    <form id="demo-form-8" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" class="col-md-12" method="post">
        <div class="content-box mrg25B">
          <h3 class="content-box-header primary-bg"> <span>Reports Summary by Date</span> </h3>
          <div class="content-box-wrapper">
<div class="form-input col-md-12">

<div class="example-code clearfix">

        <div class="form-row col-lg-6">
            <div class="form-input">
                <input type="text" size="10" class="fromDate" name="from" placeholder="From" class="parsley-validated" autocomplete="off" data-trigger="change" required>
            </div>
        </div>

        <div class="form-row col-lg-6 pad25L">
            <div class="form-input">
                <input type="text" size="10" class="toDate" name="to" placeholder="To" class="parsley-validated" data-trigger="change" autocomplete="off" required>
            </div>
        </div>

    </div>                
              </div>
          </div>
             <div class="form-row">
          <input type="hidden" name="superhidden" id="superhidden">
          <input type="hidden" name="rid" id="rid" value="Date">                      
          <div class="form-input col-md-7 col-md-offset-5"> <span class="button-content">
            <input type="submit" name="submit_date" class="bg-green" value="Show Report" onclick="javascript:$(&apos;#demo-form-8&apos;).parsley( &apos;validate&apos; );">
            </span> </div>
        </div>
        </div>
      </form>

                	</div><!-- #page-content -->
            </div>




                	</div><!-- #page-content -->
            </div><!-- #page-main -->
        </div><!-- #page-wrapper -->

    </body>
</html>


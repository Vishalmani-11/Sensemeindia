<?php
include "../../db/session.php";  
include "../../db/db_connect.php"; 
include "../../function/function.php";  
require_once '../../admin/class.user.php';
////////////////////////////////////////////////////////////////////////////////////
if(isset($_GET['tname'])&&isset($_GET['periodic']))
{ 
extract($_GET); 
  
$periodic_report = base64url_decode($periodic);	 
    
         if($periodic_report)
         {

                $subparamStr = "tname=".$tname."&from=".$from."&to=".$to."&periodic=".$periodic."&column=".$column."&filename=".$filename;
                $hmac = hash_hmac('sha1', $subparamStr, 'o52SG&sdUI');

                if($hmac!=$pk) 
                {
                $admin_login = new USER();
                $admin_login->logout();
                header('Location: ../../index.php?hout');
                }
                else
                {
                $tname = base64url_decode($tname);	
                $from = base64url_decode($from);	
                $to = base64url_decode($to);	
                $column = base64url_decode($column);	
                $filename = base64url_decode($filename);
                exportcsv($tname,$from,$to,$column,$filename,$periodic_report,$con);
                }

        }
        else    
        {

                $subparamStr = "tname=".$tname."&periodic=".$periodic."&filename=".$filename;
                $hmac = hash_hmac('sha1', $subparamStr, 'o52SG&sdUI');

                if($hmac!=$pk) 
                {
                $admin_login = new USER();
                $admin_login->logout();
                header('Location: ../../index.php?hout');
                }
                else
                {
                $tname = base64url_decode($tname);	
                $from = NULL;
                $to = NULL;
                $column = NULL;    
                $filename = base64url_decode($filename);	    
                $periodic_report = 0;    
                exportcsv($tname,$from,$to,$column,$filename,$periodic_report,$con);
                }

        }
    
}
//////////////////////////////order report download by status///////////////////////////////////////////////////////////////////
if(isset($_POST['download_report'])&&$_POST['download_report']!="")
{ 
    extract($_POST); 
    
    if(isset($_POST['from'])&&isset($_POST['to']))
    {        
        
	$from = date('Y-m-d', strtotime($_POST['from']));
	$to = date('Y-m-d', strtotime($_POST['to'].'+1 day'));	
	
    $query = "SELECT * from bb_orders WHERE orderstatus = '$orderstatus' AND orderdate >= '$from' AND orderdate < '$to'"; 
    $filename = "orders_status_report_".$orderstatus."_".date('d_M_Y', strtotime($_POST['from']))."_TO_".date('d_M_Y', strtotime($_POST['to'])).".csv";    
    }
    elseif(isset($_POST['report'])&&$_POST['report']=="packing")
    {        
	$orderstatus = "Confirmed";
    $query = "SELECT t1.id as order_no, CONCAT(t1.fname,' ',t1.lname) as name, t1.address, t2.sku, t2.name as product, t2.size, t2.qty from bb_orders as t1 INNER JOIN bb_order_products as t2 WHERE t1.orderstatus = '$orderstatus' ORDER BY t1.id ASC"; 
    $filename = "order_packing_report.csv";    
    }
    else
    {
    $query = "SELECT * from bb_orders WHERE orderstatus = '$orderstatus'"; 
        $filename = "orders_status_report_".$orderstatus.".csv";
    }
    exportcsv_query($filename,$query,$con);
}
////////////////////////////////////////$_GET users report//////////////////////////////////////////////////////////////////////
if(isset($_GET['userreport'])&&$_GET['userreport'])
{ 

    $query = "SELECT * from bb_users ORDER BY cdate DESC"; 
    $filename = "all_users_report.csv";
    
    exportcsv_query($filename,$query,$con);
}
?>
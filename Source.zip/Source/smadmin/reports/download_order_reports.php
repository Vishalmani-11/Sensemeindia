<?php
require_once "../db/session.php"; 
require_once "../db/db_connect.php";  
require_once "../function/function.php";  
?>
<!DOCTYPE html>
    <html>
    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title><?php echo $_SESSION['cName']; ?> Admin Area</title>
  <meta name="description" content="">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

     <link rel="apple-touch-icon-precomposed" sizes="144x144" href="../assets/images/icons/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="../assets/images/icons/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="../assets/images/icons/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="../assets/images/icons/apple-touch-icon-57-precomposed.png">
        <link rel="shortcut icon" href="../assets/images/icons/favicon.png">

        <!--[if lt IE 9]>
          <script src="../assets/js/minified/core/html5shiv.min.js"></script>
          <script src="../assets/js/minified/core/respond.min.js"></script>
        <![endif]-->

        <!-- Fides Admin CSS Core -->

        <link rel="stylesheet" type="text/css" href="../assets/css/minified/aui-production.min.css">

        <!-- Theme UI -->

        <link id="layout-theme" rel="stylesheet" type="text/css" href="../assets/themes/minified/fides/color-schemes/dark-blue.min.css">

        <!-- Fides Admin Responsive -->

        <link rel="stylesheet" type="text/css" href="../assets/themes/minified/fides/common.min.css">
        <!-- <link rel="stylesheet" type="text/css" href="../_assets/themes/fides/common.css"> -->

        <link id="theme-animations" rel="stylesheet" type="text/css" href="../assets/themes/minified/fides/animations.min.css">

        <link rel="stylesheet" type="text/css" href="../assets/themes/minified/fides/responsive.min.css">


        <!-- Fides Admin JS -->

        <script type="text/javascript" src="../assets/js/minified/aui-production.min.js"></script>
        <script type="text/javascript" src="../assets/js/minified/core/raphael.min.js"></script>
        <script type="text/javascript" src="../assets/js/minified/widgets/charts-justgage.min.js"></script>
<script type="text/javascript" src="../assets/js/minified/widgets/charts-morris.min.js"></script>  
    

<script type="text/javascript">
 
    $(function() {
 
         $( ".fromDate" ).datepicker({
           defaultDate: "+1w",
           changeMonth: true,
           numberOfMonths: 3,
           onClose: function( selectedDate ) {
             $( ".toDate" ).datepicker( "option", "minDate", selectedDate );
           }
         });
         $( ".toDate" ).datepicker({
           defaultDate: "+1w",
           changeMonth: true,
           numberOfMonths: 3,
           onClose: function( selectedDate ) {
             $( ".fromDate" ).datepicker( "option", "maxDate", selectedDate );
           }
         });
 
    });
 
</script>
<style>

.dataTables_scrollBody
{
	height:500px !important;

}

</style>

    </head>
    <body>
        

        <div id="loading" class="ui-front loader ui-widget-overlay bg-white opacity-100">
            <img src="assets/images/loader-dark.gif" alt="">
        </div>

        <div id="page-wrapper" class="demo-example">
          <!-- #page-header -->

            <?php include("../sidebar.php"); ?>
            <!-- #page-sidebar -->
            <div id="menu-right" class="scrollable-content hidden">
                <div class="toggle-content-open clearfix">

                    <div id="g10" class="small-gauge float-left"></div>
                    <div id="g11" class="small-gauge float-right"></div>

                </div>
            </div>

            <div id="page-content-wrapper">
                <div id="page-title">

<h3>
   Download Order Reports
    </h3>
              </div><!-- #page-title -->
<div id="page-content">

<script type="text/javascript">

$(document).ready(function() {

});

</script>

<h4>&nbsp;</h4>
    <?php 
			   if(isset($success)){ ?>
             
             <div class="infobox success-bg">
<a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>             
                    <h4 class="infobox-title"><?php echo $success;?></h4>
                </div><?php } ?>
                <?php 
			   if(isset($_GET['success'])){ ?>
             <div class="infobox success-bg">
<a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>             
                    <h4 class="infobox-title"><?php echo $_GET['success'];?></h4>
                </div><?php } ?>
 <div class="example-code">        
          <form id="demo-form-4" target="_blank" action="csv/exportcsv.php" class="col-md-6" method="post">
        <div class="content-box mrg25B">
          <h3 class="content-box-header primary-bg"> <span>Order Status by Date</span> </h3>
          <div class="content-box-wrapper">
            <div class="form-row">
              <div class="form-input col-md-12">
                <select data-placeholder="Select A Status..." name="orderstatus" class="chosen-select parsley-validated" data-trigger="change" required>
                  <option value="">Select A Status</option>
                  <option value="Confirmed">Confirmed</option>
                  <option value="Shipped">Shipped</option>
                    <option value="Delivered">Delivered</option>
                    <option value="Cancellation Requested">Cancellation Requested</option>
                    <option value="Cancelled">Cancelled</option>
                    <option value="Payment Failed">Payment Failed</option>
                    <option value="Pending">Pending</option>
                </select>
              </div>
              
            </div>
            <div class="form-input col-md-12">

<div class="example-code clearfix">

        <div class="form-row col-lg-6">
            <div class="form-input">
                <input type="text" size="10" class="fromDate" name="from" placeholder="From" class="parsley-validated" autocomplete="off" data-trigger="change" required>
            </div>
        </div>

        <div class="form-row col-lg-6 pad25L">
            <div class="form-input">
                <input type="text" size="10" class="toDate" name="to" placeholder="To" class="parsley-validated" data-trigger="change" autocomplete="off" required>
            </div>
        </div>

    </div>                
              </div>
          </div>
             <div class="form-row">
          <input type="hidden" name="superhidden" id="superhidden">
                    <input type="hidden" name="rid" id="rid" value="Status">  
          <div class="form-input col-md-11 col-md-offset-1"> <span class="button-content">
            <input type="submit" name="download_report" class="bg-green" value="Download Report" onclick="javascript:$(&apos;#demo-form-4&apos;).parsley( &apos;validate&apos; );">
            </span> </div>
        </div>
        </div>
      </form>
      <form id="demo-form-5" target="_blank" action="csv/exportcsv.php" class="col-md-6" method="post">
        <div class="content-box mrg25B">
          <h3 class="content-box-header primary-bg"> <span>Order Status (All time)</span> </h3>
          <div class="content-box-wrapper">
            <div class="form-row">
              <div class="form-input col-md-12">
                <select data-placeholder="Select A Status..." name="orderstatus" class="chosen-select parsley-validated" data-trigger="change" required>
                  <option value="">Select A Status</option>
                  <option value="Confirmed">Confirmed</option>
                  <option value="Shipped">Shipped</option>
                    <option value="Delivered">Delivered</option>
                    <option value="Cancellation Requested">Cancellation Requested</option>
                    <option value="Cancelled">Cancelled</option>
                          <option value="Payment Failed">Payment Failed</option>
                    <option value="Pending">Pending</option>
                </select>
              </div>
              
            </div>
           
          </div>
             <div class="form-row">
          <input type="hidden" name="superhidden" id="superhidden">
                    <input type="hidden" name="rid" id="rid" value="Status">  
          <div class="form-input col-md-11 col-md-offset-1"> <span class="button-content">
            <input type="submit" name="download_report" class="bg-green" value="Download Report" onclick="javascript:$(&apos;#demo-form-5&apos;).parsley( &apos;validate&apos; );">
            </span> </div>
        </div>
        </div>
      </form>
     
     <form id="demo-form-7" target="_blank" action="csv/exportcsv.php" class="col-md-7" method="post">
        <div class="content-box mrg25B">
          <h3 class="content-box-header primary-bg"> <span>Order Packing Report</span> </h3>
    <br>
<br>

             <div class="form-row">
          <input type="hidden" name="superhidden" id="superhidden">
                    <input type="hidden" name="report" id="report" value="packing">  
          <div class="form-input col-md-11 col-md-offset-1"> <span class="button-content">
            <input type="submit" name="download_report" class="bg-green" value="Download Report" onclick="javascript:$(&apos;#demo-form-7&apos;).parsley( &apos;validate&apos; );">
            </span> </div>
        </div>
        </div>
      </form>
      </div>
      <div class="divider"></div>

                	</div><!-- #page-content -->
            </div>




                	</div><!-- #page-content -->
            </div><!-- #page-main -->
        </div><!-- #page-wrapper -->

    </body>
</html>


 <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <title><?php echo $_SESSION['cName']; ?> Admin Area</title>
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo $_SESSION['gpath'].$_SESSION['favicon']; ?>">
  <link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo $_SESSION['gpath'].$_SESSION['favicon']; ?>">
  <link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?php echo $_SESSION['gpath'].$_SESSION['favicon']; ?>">
  <link rel="apple-touch-icon-precomposed" href="<?php echo $_SESSION['gpath'].$_SESSION['favicon']; ?>">
  <link rel="shortcut icon" href="<?php echo $_SESSION['gpath'].$_SESSION['favicon']; ?>">

  <!--[if lt IE 9]>
          <script src="assets/js/minified/core/html5shiv.min.js"></script>
          <script src="assets/js/minified/core/respond.min.js"></script>
        <![endif]-->

<link rel="stylesheet" type="text/css" href="<?php echo $_SESSION['gpath']; ?>assets/css/minified/aui-production.min.css">
<link id="layout-theme" rel="stylesheet" type="text/css" href="<?php echo $_SESSION['gpath']; ?>assets/themes/minified/fides/color-schemes/dark-blue.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo $_SESSION['gpath']; ?>assets/themes/minified/fides/common.min.css">
<link id="theme-animations" rel="stylesheet" type="text/css" href="<?php echo $_SESSION['gpath']; ?>assets/themes/minified/fides/animations.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo $_SESSION['gpath']; ?>assets/themes/minified/fides/responsive.min.css">
<script type="text/javascript" src="<?php echo $_SESSION['gpath']; ?>assets/js/minified/aui-production.min.js"></script>
<script type="text/javascript" src="<?php echo $_SESSION['gpath']; ?>assets/js/minified/core/raphael.min.js"></script>


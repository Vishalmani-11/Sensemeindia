<?php
include "../function/config.php"; 
include "../db/db_connect.php"; 
include "../db/session.php";  
include "../function/function.php";  

////////////////////////save/////////////////////////
if(isset($_POST['submit']))
{
extract($_POST);	
$mc_id = secure_input($con,$cid);
$sc_id = secure_input($con,$scid);  
    
/////////////////////////////Image upload////////////////////////////
if(($_FILES['pic']['error']==0))
{	
if (($_FILES["pic"]["size"] < 1000000))
  {
	$file_tmp_name = $_FILES["pic"]["tmp_name"];
    $path = "../uploads/banners/";
    $image_path = "uploads/banners/";
	$error_path = "add_banners.php";
	$exten = explode(".", $_FILES["pic"]["name"]);
	$old_name = $exten[0];
	$new_name = 1;
	$pimage = upload_image($file_tmp_name, $old_name, $path, $image_path, $error_path, $new_name); 
    
  }
else
  {
	$error = "Invalid file size!";
	header("location:add_banners.php?error=".$error); exit();
  }
}
else
  {
    $pimage = NULL;    
  }

  
////////////////////////////////////parent product///////////////////////////////////	

if(!$stmt = $con->prepare("UPDATE bb_sub_categories SET banner = ? WHERE id = ?"))
{
	echo "Prepare failed: (" . $con->errno . ") " . $con->error;
}

if(!$stmt->bind_param("si", $pimage, $sc_id))
{
	echo "Param pass failed: (" . $con->errno . ") " . $con->error;
}

if(!$stmt->execute()) {
    
	$error = "New banner saving failed!".$con->error; exit();   
    
}
else
{
$success= "New banner data saved successfully!";
	header("location:add_banners.php?success=".$success);
	exit();
    
}
   
$con->close();

}

//////////////////////////category////////////////////////////////////////

$active = 1;

$query = "SELECT id, name FROM bb_categories WHERE active = ? ORDER BY name ASC";

if(!$tstmt = $con->prepare($query))
{
	echo "prepare failed: (" . $con->errno . ") " . $con->error;	
}
	if(!$tstmt->bind_param("i", $active))
{
	echo "Param pass failed: (" . $con->errno . ") " . $con->error;
}

	if(!$tstmt->execute())
	{
		$error = "categories list failed!".$con->error;		
		
	}

		if(!$tstmt->store_result())
		{
			$error = "categories list failed!".$con->error;					
		}
	
		$num_of_rows = $tstmt->num_rows;

if($num_of_rows==0)
{
	$terror = "No categories found";		
}
//////////////////////////size////////////////////////////////////////


$squery = "SELECT id, name FROM bb_sizes ORDER BY name ASC";

if(!$sstmt = $con->prepare($squery))
{
	echo "prepare failed: (" . $con->errno . ") " . $con->error;	
}


	if(!$sstmt->execute())
	{
		$error = "size list failed!".$con->error;		
		
	}

		if(!$sstmt->store_result())
		{
			$error = "categories list failed!".$con->error;					
		}
	
		$snum_of_rows = $sstmt->num_rows;

if($snum_of_rows==0)
{
	$serror = "No sizes found";		
}
//////////////////////////colors////////////////////////////////////////

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title><?php echo $_SESSION['cName']; ?> Admin Area</title>
    <?php include("../header.php"); ?>
    
<script>
     $(document).ready(function() {
         
    $("#category").change(function(){
    var categoryId = $(this).val();

    $.ajax({
        type: "POST",
        url: "../inventory/get_sub_category.php",
        data: {category_id : categoryId },
        beforeSend: function(){
				$('#loading').fadeIn();
			    },
        complete: function(){
				$('#loading').hide();
				},
        success: function (data) {            
          //  alert(data); 
            $("#subcategory").prop("disabled", false);
            $("#subcategory").html(data);
        }
    });
});
         
         });
    </script>
</head>
<body>
<div id="loading" class="ui-front loader ui-widget-overlay bg-white opacity-100"> <img src="<?php echo $_SESSION['gpath'] ?>assets/images/loader-dark.gif" alt=""> </div>
<div id="page-wrapper" class="demo-example"> 
  <!-- #page-header -->
  
  <?php include("../sidebar.php"); ?>
  <!-- #page-sidebar -->
  <div id="menu-right" class="scrollable-content hidden">
    <div class="toggle-content-open clearfix">
      <div id="g10" class="small-gauge float-left"></div>
      <div id="g11" class="small-gauge float-right"></div>
    </div>
  </div>
  <div id="page-content-wrapper">
            
                <div id="page-title">

<h3>
    <strong>Add new product</strong> 
</h3>

</div><!-- #page-title -->

            
<div id="page-content">
<h3><strong>Product details:</strong></h3>
<div class="example-box">
<?php 
			   if(isset($error)){ ?>
             
             <div class="infobox error-bg">
<a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>             
<div class="bg-red large btn info-icon">
                        <i class="glyph-icon icon-remove"></i>
                    </div>
                    <h4 class="infobox-title"><?php echo $error;?></h4>
                    <p>Some error in the database query occured. Please try again!</p>
                </div>
           <?php } ?>
    
    <?php 
			   if(isset($_GET['error'])){ ?>
             
             <div class="infobox error-bg">
<a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>             
<div class="bg-red large btn info-icon">
                        <i class="glyph-icon icon-remove"></i>
                    </div>
                    <h4 class="infobox-title"><?php echo $_GET['error'];?></h4>
                    <p>Some error in the database query occured. Please try again!</p>
                </div>
           <?php } ?>
    
            
<?php 
			   if(isset($success)){ ?>
             
             <div class="infobox success-bg">
<a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>             
                    <h4 class="infobox-title"><?php echo $success;?></h4>
                </div><?php } ?>
    
    <?php 
			   if(isset($_GET['success'])){ ?>
             
             <div class="infobox success-bg">
<a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>             
                    <h4 class="infobox-title"><?php echo $_GET['success'];?></h4>
                </div><?php } ?>
     
    <div class="example-code">
<br>
<br>

        <form id="demo-form-2" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" class="col-md-10 center-margin" method="post" enctype="multipart/form-data">
          
			<div class="form-row">
              <div class="form-label col-md-3">
                <label for=""> Select a category: <span class="required">*</span></label>
              </div>
              <div class="form-input col-md-9">
                <select data-placeholder="Select a category..." name="cid" id="category" class="chosen-select parsley-validated" data-trigger="change" required>
      
      <?php      
			if(isset($terror))
			{
				?>
			     <option value=""><?php echo $terror; ?></option>	
			<?php 
						} 
						else
						{
			?>
                 <option value="">Select a category</option>	
                 <?php } ?>
                 
                  <?php 
	$tstmt->bind_result($id, $scname);
	while ($tstmt->fetch()) 
	{
			
	?>            
                  <option value="<?php echo $id; ?>"><?php echo $scname; ?></option>
                  
       <?php } 
		$tstmt->free_result();
		?>            
        
                </select>
              </div>
              
            </div>
			
			<div class="form-row">
              <div class="form-label col-md-3">
                <label for=""> Select a sub-category: <span class="required">*</span></label>
              </div>
              <div class="form-input col-md-9">
                <select data-placeholder="Select a sub-category..." name="scid" disabled id="subcategory" class="chosen-select parsley-validated" data-trigger="change" required>
        
                </select>
              </div>
              
            </div>
			
       		<div class="form-row">
          <div class="form-label col-md-3">
            <label for=""> Upload Main image:<span class="required">*</span></label>
          </div>
          <div class="float-left col-md-9"> <span class="btn medium bg-green fileinput-button"> <span class="button-content">Max 500kb. (gif, jpeg, jpg, png) only</span>
              <input type="file" name="pic" required>
             </div>
        </div>

            <div class="divider"></div>
            <div class="form-row">
                <input type="hidden" name="superhidden" id="superhidden">
                <div class="form-input col-md-10 col-md-offset-3">
               <button type="submit" name="submit"  class="btn large primary-bg" onclick="javascript:$(&apos;#demo-form-2&apos;).parsley( &apos;validate&apos; );"><span class="button-content">Save Data</span></button>
&nbsp;
                        <a href="#" class="btn large bg-red" title="" onclick="goBack()">
            <span class="button-content">Cancel</span>
        </a>

                </div>
            </div>

        </form>

    </div>
    
</div>
</div>
<!-- #page-content -->
</div>
<!-- #page-main -->
</div>
<!-- #page-wrapper -->

</body>
</html>

<?php
ob_start();
include "../function/config.php"; 
include "../db/db_connect.php"; 
include "../db/session.php";  
include "../function/function.php";   
//////////////////////suspend////////////////////////
if(isset($_GET['id'])&&$_GET['id']!=''&&isset($_GET['action'])&&$_GET['action']=='suspend')
{
extract($_GET);	
$query = "UPDATE banner SET active = '0' WHERE id ='$id'";
$qresult = mysqli_query($con,$query);
if(!$qresult)
{
	$error = "banner suspend failed!".mysqli_error($con);
}
else
{
$success= "Banner suspended successfully!";	
}
} 

//////////////////////publish////////////////////////
if(isset($_GET['id'])&&$_GET['id']!=''&&isset($_GET['action'])&&$_GET['action']=='publish')
{
extract($_GET);	
$query = "UPDATE banner SET active = '1' WHERE id ='$id'";
$qresult = mysqli_query($con,$query);
if(!$qresult)
{
	$error = "Banner publish failed!".mysqli_error($con);
}
else
{
$success= "Banner published successfully!";	
}
} 
////////////////////////////////////

if(isset($_POST['submit']))
{
	extract($_POST);	
    
	/////////////////////////////Image upload
$pimage ="";
if(($_FILES['file']['error']==0))
{	
if (($_FILES["file"]["size"] < 2000000))
  {
    $file_tmp_name = $_FILES["file"]["tmp_name"]; 
    $path = "../uploads/sliders/";
    $image_path = "uploads/sliders/";
	$error_path = "header_banners.php";
	$exten = explode(".", $_FILES["file"]["name"]);
	$old_name = $exten[0];
	$new_name = 0;
	$pimage = upload_image($file_tmp_name, $old_name, $path, $image_path, $error_path, $new_name); 
    
    $query = "UPDATE banner SET img = '$pimage' WHERE id ='$bannerid'";
$qresult = mysqli_query($con,$query);
if(!$qresult)
{
	$error = "banner update failed!".mysqli_error($con);
}
else
{
$success= "Banner uploaded successfully!";	
}
	$page = "header_banners.php?success=".$success;
	header("Refresh:0; url = $page"); exit();
	
  }
else
  {
	$error = "Invalid file size!";
	header("location:header_banners.php?error=".$error); exit();
  }
}
else
  {
	$error = "Invalid file selected! try again!";
	header("location:header_banners.php?error=".$error); exit();	
  }
}
////////////////////////////////////////////////////

$query = "SELECT id, active FROM banner ORDER BY id ASC";
$qresult = mysqli_query($con,$query);
if(!$qresult)
{
	$error = "banner listing failed!".mysqli_error($con);
}
$rows = mysqli_num_rows($qresult);
if($rows==0)
{
	$error = "No Banner found!";		
}

///////////////////////////////////////////////////////////

?>
<!DOCTYPE html>
    <html>
    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
       <title><?php echo $_SESSION['cName']; ?> Admin Area</title>
    <?php include("../header.php"); ?>

<style>
.dataTables_scrollBody
{
	height:500px !important;
}
</style>

    </head>
    <body>
        

        <div id="loading" class="ui-front loader ui-widget-overlay bg-white opacity-100">
            <img src="../assets/images/loader-dark.gif" alt="">
        </div>

        <div id="page-wrapper" class="demo-example">
          <!-- #page-header -->

            <?php include("../sidebar.php"); ?>
            <!-- #page-sidebar -->
            <div id="menu-right" class="scrollable-content hidden">
                <a href="javascript:;" title="Get Source" class="popover-title button-toggle-open">
                    Cloud status
                    <i class="glyph-icon icon-caret-right icon-caret-down"></i>
                </a>
                <div class="clear"></div>
                <a href="javascript:;" title="Get Source" class="popover-title button-toggle-open">
                    Realtime server load
                    <i class="glyph-icon icon-caret-right icon-caret-down"></i>
                </a>
                <div class="toggle-content-open clearfix">

                    <div id="g10" class="small-gauge float-left"></div>
                    <div id="g11" class="small-gauge float-right"></div>

                </div>
                 
            </div>

                  <div id="page-content-wrapper">
                <div id="page-title">

<h3>
    Home Header Banners</h3>      
              </div><!-- #page-title -->
            
               
<div id="page-content">



<div class="example-box">
<?php 
			   if(isset($error)){ ?>
             
             <div class="infobox error-bg">
<a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>             
<div class="bg-red large btn info-icon">
                        <i class="glyph-icon icon-remove"></i>
                    </div>
                    <h4 class="infobox-title"><?php echo $error;?></h4>
                    <p>&nbsp;</p>
                </div>
<?php } ?>

<?php 
			   if(isset($_GET['error'])){ ?>
             
             <div class="infobox error-bg">
<a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>             
<div class="bg-red large btn info-icon">
                        <i class="glyph-icon icon-remove"></i>
                    </div>
                    <h4 class="infobox-title"><?php echo $_GET['error'];?></h4>
                    <p>Some error in the database query occured. Please try again!</p>
                </div>
<?php } ?>

            </div>
            
<?php 
			   if(isset($success)){ ?>
             
             <div class="infobox success-bg">
<a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>             
                    <h4 class="infobox-title"><?php echo $success;?></h4>
             </div>
            <?php } ?>
            
            <?php 
			   if(isset($_GET['success'])){ ?>
             
             <div class="infobox success-bg">
<a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>             
                    <h4 class="infobox-title"><?php echo $_GET['success'];?></h4>
             </div>
            <?php } ?>

<script type="text/javascript">

$(document).ready(function() {

});

</script>

<h4>&nbsp;</h4>

<table class="table">
  <thead>
		<tr>
			<th width="6%">Banner No</th>
			<th width="20%">Existing Banner</th>
			<th width="10%">Status</th>     
			<th width="26%">Description</th>
			<th width="15%">Select New Banner</th>
			<th width="13%">Upload</th>       
			<!--<th width="10%">Action</th>  -->     			
		</tr>
	</thead>
	<tbody>
    
 <?php 
	$sn = 0;
	while(list($id, $active) = mysqli_fetch_array($qresult))
	{
			$sn = 	$sn + 1;
	?>
    
		<tr><form action="" method="post" enctype="multipart/form-data">
			<td><?php echo $id; ?></td>
			<td><a href="../uploads/sliders/<?php echo $id; ?>.jpg" target="_blank" title=""><img src="../uploads/sliders/<?php echo $id; ?>.jpg" width="250"/ title="Click to View"></a></td>
			<td> <?php if($active) { echo "Published"; }  else { echo "Suspended"; } ?>
			</td>	
			<td><span class="font font-red"><strong>Image name :</strong> <?php echo $id; ?>.jpg. <strong>Image size:</strong> width: 1903px X height: 649px</span></td>
   			<td><input name="file" type="file"/> <input type="hidden" name="bannerid" value="<?php echo $id; ?>"/> </td>
			<td><button class="btn primary-bg medium" type="submit" name="submit" onclick="javascript:$(&apos;#demo-form-2&apos;).parsley( &apos;validate&apos; );"> <span class="button-content">Upload Banner</span> </button>                               
                            </td>
	<!--<td> <?php	if($active) { ?> <a href="header_banners.php?id=<?php echo $id; ?>&action=suspend" title="Click to suspend" onclick="return confirm('Are you sure you want to suspend this item?');" class="font-red">
                                                <i class="glyph-icon icon-remove mrg5R"></i>
                                                Suspend
                                            </a> <?php } else { ?>
		
		<a href="header_banners.php?id=<?php echo $id; ?>&action=publish" title="Click to publish" onclick="return confirm('Are you sure you want to publish this item?');">
                                                <i class="glyph-icon icon-remove mrg5R"></i>
                                                Publish
                                            </a> <?php } ?>
			</td>-->			
                            </form>
		</tr>
        
		
			 <?php } ?>
    
       
	</tbody>
	<tfoot>
		<tr>
			<th></th>
			<th></th>
			<th></th>
			<th></th>            
			<th></th>
			<th></th>
			<!--<th></th>-->
		</tr>
	</tfoot>
</table>


                	</div><!-- #page-content -->
            </div>




                	</div><!-- #page-content -->
            </div><!-- #page-main -->
        </div><!-- #page-wrapper -->

    </body>
</html>


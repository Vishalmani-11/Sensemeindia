<?php
include "db/db_connect.php"; 
require_once 'admin/class.user.php';
$user_login = new USER();
if($user_login->is_logged_in())
{
	$user_login->redirect('admin_dashboard.php');
}

   $message = '';
   if(isset($_GET['install']))
   {   
	   $message = "Installation completed successfully!";
   } 
   if(isset($_GET['expired']))
   {   
	   $message = "Your Session Expired! Please login again.";
   } 
  if(isset($_GET['lout']))
   {
	   	   $message = "You have successfully signed out";
   }
     if(isset($_GET['hout']))
   {
	   	   $message = "Hacking tried! your IP will get banned!";
   }
    if(isset($_GET['pwrst']))
   {
	   	   $message = "You have successfully changed your password!";
   }
      if(isset($_GET['codexpired']))
   {
	   	   $message = "Your password reset activation code expired! Please try again.";
   }
   if(isset($_GET['err']))
   {
	   	 $message = "Invalid Username or password!";
   }
  if(isset($_GET['acd']))
   {
	   $message = "Account disabled!";
   }
      if(isset($_GET['nouser']))
   {
	   	 $message = "Admin ac not available!";
   }
   if(isset($_GET['rmsg']))
   {
	   	 $message = "We've sent an email to ".$_GET['rmsg']." Please click on the password reset link in the email to generate new password!";
   }
   if(isset($_GET['remsg']))
   {
	   	 $message = "This email id is not registered and it can't be used for password recovery! ";
   }
   
////////////////////////////////////////

$query = "SELECT * FROM cms_gsett";
$qresult = mysqli_query($con,$query);
if(!$qresult)
{
	die("global settings failed!".mysqli_error($con));
}
else
{
if (session_status() == PHP_SESSION_NONE) 
 {
    session_start();
 }
$data = mysqli_fetch_array($qresult);	

$_SESSION['cName'] = $data['cName'];
$_SESSION['cLogo'] = $data['cLogo'];
$_SESSION['favicon'] = $data['favicon'];
$_SESSION['cInfo'] = $data['cInfo'];
$_SESSION['country'] = $data['country'];
$_SESSION['gpath'] = $data['gpath'];
}
   
?>
<!DOCTYPE html>
<html>
  <head>
 <?php include("header.php"); ?>
  </head>
  <body>
<div id="loading" class="ui-front loader ui-widget-overlay bg-white opacity-100"> <img src="']; ?>assets/images/loader-dark.gif" alt=""> </div>
<div id="page-header" class="clearfix">
    <div id="header-logo"> <?php echo $_SESSION['cName']; ?> Admin Area</div>
  </div>
<!-- #page-header -->
<div class="row">
 <form name="login" action="admin_login_submit.php" method="post" id="login-validation" class="col-md-4 center-margin">
    <div id="login-form" class="content-box form-vertical">
        <h3 class="content-box-header ui-state-default">
        <div class="glyph-icon icon-separator"> <i class="glyph-icon icon-users"></i> </div>
        <span><strong>Admin Login</strong></span> </h3>
        <div class="content-box-wrapper pad20A pad0B">
        <div class="form-row">
            <div class="form-label col-md-2">
            <label for="login_email"> Username: <span class="required">*</span> </label>
          </div>
            <div class="form-input col-md-10">
            <div class="form-input-icon"> <i class="glyph-icon icon-user ui-state-default"></i>
                <input placeholder="User Name" data-trigger="change" data-required="true" type="text" name="username" id="txtusername" required>
              </div>
          </div>
          </div>
        <div class="form-row">
            <div class="form-label col-md-2">
            <label for="login_pass"> Password:<span class="required">*</span> </label>
          </div>
            <div class="form-input col-md-10">
            <div class="form-input-icon"> <i class="glyph-icon icon-unlock-alt ui-state-default"></i>
                <input placeholder="Password" data-trigger="keyup" data-rangelength="[3,25]" type="password" name="userpswd" id="login_pass" required>
              </div>
          </div>
          </div>
          
          <div class="form-row">
                                <div class="form-checkbox-radio text-right col-md-12">
                                  <a href="#" class="toggle-switch forgot" switch-target="#login-forgot" switch-parent="#login-form" title="Recover password">Forgot your password?</a>
                                </div>
                            </div>
          
      </div>
        <div class="button-pane text-center">
        <button type="submit" class="btn large primary-bg text-transform-upr font-size-11" id="demo-form-valid" title="Validate!" name="adminlogin"> <span class="button-content"> Login </span> </button>
      </div>
      </div>
      </form>
<!-- forget password--> 
 <form name="login" action="admin_login_submit.php" method="post" id="login-validation" class="col-md-4 center-margin">
          <div class="ui-dialog mrg90T no-shadow hide" id="login-forgot" style="position: relative !important;">
                        <div class="ui-dialog-titlebar ui-widget-header ui-corner-all ui-helper-clearfix">
                            <span class="ui-dialog-title">Recover password</span>
                        </div>
                        <div class="pad20A ui-dialog-content ui-widget-content">
                            <div class="form-row">
                                <div class="form-label col-md-2">
                                    <label for="">
                                        Email:<span class="required">*</span>
                                    </label>
                                </div>
                                <div class="form-input col-md-10">
                                    <div class="form-input-icon">
                                        <i class="glyph-icon icon-envelope ui-state-default"></i>
                                        <input placeholder="Email address" type="email" name="remail" id="remail" required/>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="ui-dialog-buttonpane">     
          			<button type="submit" class="btn large primary-bg" id="demo-form-valid" name="recoverpswd"><span class="button-content">
                                    Recover Password
                                </span>
                            </button>
	<a href="javascript:;" switch-target="#login-form" switch-parent="#login-forgot" class="btn large transparent no-shadow toggle-switch font-bold font-size-11 radius-all-4" id="login-form-valid">
                                <span class="button-content">
                                    Cancel
                                </span>
                            </a>
                        </div>
                    </div>
                      </form>
<!--end-->                
    
  <div class="divider"></div>                    
  </div>
  <div class="row">
<?php 
			   if(isset($_GET['expired'])||isset($_GET['remsg'])||isset($_GET['hout'])||isset($_GET['err'])||isset($_GET['acd'])||isset($_GET['nouser'])||isset($_GET['codexpired'])){ ?>
               <div class="col-md-12">
                <div class="infobox infobox-close-wrapper error-bg mrg0A">
                    <a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>
                    <h4 class="infobox-title"><?php echo $message;?></h4>
                </div>
                
                
                
            </div><?php } ?>
            
            <?php 
			   if(isset($_GET['install'])||isset($_GET['lout'])||isset($_GET['rmsg'])||isset($_GET['pwrst'])){ ?>
               <div class="col-md-12">
                <div class="infobox infobox-close-wrapper success-bg mrg0A">
                    <a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>
                    <h4 class="infobox-title"><?php echo $message;?></h4>
                </div>
                
                
                
            </div><?php } ?>
            </div>


</body>
</html>

<?php
require("db/db_connect.php");
require_once 'admin/class.user.php';
require("function/function.php");


$user = new USER();

///////////////////////////////////////////////////////////////////////
if(isset($_POST['id'])&&isset($_POST['code']))
{
    
    
    extract($_POST);
    
     if($available) { 
         
        $pass = secure_input($con, $_POST['apswd']);	
		$cpass = secure_input($con, $_POST['rapswd']);				
			
			if($cpass!==$pass)
			{
				exit("passwords are not match!"); 
			}
			else
			{
                    $password = $user->hashed($cpass);
				$toAc = 1;
				if(!$stmt = $user->runQuery("UPDATE ecrm_employees SET upass=:upass, tokenAc=:tAc WHERE id=:uid"))
                {
                    echo $error = "updated failed! (" . $user->conn->errno . ") " . $user->conn->error; exit();
                }
           /*         
                $stmt->bindparam(":upass",$password);
                $stmt->bindparam(":tAc",$code);
			     $stmt->bindparam(":uid",$password); */
                
				if(!$pass_result = $stmt->execute(array(":upass"=>$password,":tAc"=>$toAc,":uid"=>$id)))
                {
                    	echo $error = "updated failed! (" . $user->conn->errno . ") " . $user->conn->error; exit();
                }
                
                            // echo "inside2"; exit();
				header("location:index.php?pwrst"); exit();
			}
         
     }
    else { 
     header("location:index.php?nouser"); exit();
    }
    
}
//////////////////////////////////////////////////////////////////////////////////////////
if(!isset($_POST['change_pass'])) { 
if(isset($_GET['id']) && isset($_GET['code']))
{
	$id = base64_decode($_GET['id']);
	$code = $_GET['code'];
	
	$stmt = $user->runQuery("SELECT * FROM ecrm_employees WHERE id=:uid AND tokenCode=:token");
	$stmt->execute(array(":uid"=>$id,":token"=>$code));
	$rows = $stmt->fetch(PDO::FETCH_ASSOC);
	
	if($stmt->rowCount() == 1)
	{
		if($rows['tokenAc']==0)
		{ 
		 $user_available = 1;
		}
		else
			{
				header("location:index.php?codexpired"); exit();
			} 
			
		
	}
	else
	{
        
        header("location:index.php?nouser"); exit();
        
		$msg = "<div class='alert alert-danger'>
				<button class='close' data-dismiss='alert'>&times;</button>
				No Account Found, Try again
				</div>";
				
	}
	
	
}
else { $user->redirect('index.php'); }
}
/////////////////////////////////////////////////////////////////////////////////////////////////
?>
<!DOCTYPE html>
<html>
  <head>
 <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>SensemeIndia Admin</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

        <!-- Favicons -->

        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/images/icons/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/images/icons/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/images/icons/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="assets/images/icons/apple-touch-icon-57-precomposed.png">
        <link rel="shortcut icon" href="assets/images/icons/favicon.png">

        <!--[if lt IE 9]>
          <script src="assets/js/minified/core/html5shiv.min.js"></script>
          <script src="assets/js/minified/core/respond.min.js"></script>
        <![endif]-->

        <!-- Fides Admin CSS Core -->

        <link rel="stylesheet" type="text/css" href="assets/css/minified/aui-production.min.css">

        <!-- Theme UI -->

        <link id="layout-theme" rel="stylesheet" type="text/css" href="assets/themes/minified/fides/color-schemes/dark-blue.min.css">

        <!-- Fides Admin Responsive -->

        <link rel="stylesheet" type="text/css" href="assets/themes/minified/fides/common.min.css">
        <!-- <link rel="stylesheet" type="text/css" href="../_assets/themes/fides/common.css"> -->

        <link id="theme-animations" rel="stylesheet" type="text/css" href="assets/themes/minified/fides/animations.min.css">

        <link rel="stylesheet" type="text/css" href="assets/themes/minified/fides/responsive.min.css">

        <!-- Fides Admin JS -->

        <script type="text/javascript" src="assets/js/minified/aui-production.min.js"></script>
        <script type="text/javascript" src="assets/js/minified/core/raphael.min.js"></script>
  </head>
  <body>

<div id="page-header" class="clearfix">
    <div id="header-logo">SensemeIndia Admin</div>
  </div>
<!-- #page-header -->
<div class="row">
    
    <?php if($user_available) { ?> 
 <form name="login" action="resetpass.php" method="post" id="login-validation" class="col-md-4 center-margin">
    <div id="login-form" class="content-box form-vertical">
        <h3 class="content-box-header ui-state-default">
        <div class="glyph-icon icon-separator"> <i class="glyph-icon icon-users"></i> </div>
        <span><strong>Reset Password</strong></span> </h3>
        <div class="content-box-wrapper pad20A pad0B">
         <div class="form-row">
          <div class="form-label col-md-2">
            <label for="apswd"> Password:<span class="required">*</span> </label>
          </div>
          <div class="form-input col-md-10">
            <div class="form-input-icon"> <i class="glyph-icon icon-unlock-alt ui-state-default"></i>
              <input id="apswd" placeholder="type your new password" data-trigger="keyup" data-rangelength="[3,25]" type="password" data-required="true" data-equalto="#rapswd" name="apswd" class="parsley-validated">
            </div>
          </div>
        </div>
        
           <div class="form-row">
          <div class="form-label col-md-2">
           <label for="rapswd"> Confirm Password:<span class="required">*</span> </label>
          </div>
          <div class="form-input col-md-10">
            <div class="form-input-icon"> <i class="glyph-icon icon-unlock-alt ui-state-default"></i>
              <input id="rapswd" placeholder="confirm your password" data-trigger="keyup" data-rangelength="[3,25]" type="password" name="rapswd" data-equalto="#apswd" data-required="true" class="parsley-validated">
            </div>
          </div>
        </div>
        
      </div>
        <div class="button-pane text-center">
            <input type="hidden" name="id" value="<?php echo $id; ?>">
            <input type="hidden" name="code" value="<?php echo $code; ?>">
            <input type="hidden" name="available" value="<?php echo $user_available; ?>">
        <button type="submit" class="btn large primary-bg text-transform-upr font-size-11" id="demo-form-valid" title="Validate!" name="change_pass"  onclick="javascript:$(&apos;#login-validation&apos;).parsley( &apos;validate&apos; );"> <span class="button-content"> Change Password </span> </button>
      </div>
      </div>
      </form>
    <?php } ?>
 
  <div class="divider"></div>                    
  </div>
  <div class="row">
<?php 
			   if(isset($_GET['expired'])||isset($_GET['remsg'])||isset($_GET['err'])||isset($_GET['nouser'])){ ?>
               <div class="col-md-12">
                <div class="infobox infobox-close-wrapper error-bg mrg0A">
                    <a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>
                    <h4 class="infobox-title"><?php echo $message;?></h4>
                </div>
                
                
                
            </div><?php } ?>
            
            <?php 
			   if(isset($_GET['install'])||isset($_GET['lout'])||isset($_GET['rmsg'])){ ?>
               <div class="col-md-12">
                <div class="infobox infobox-close-wrapper success-bg mrg0A">
                    <a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>
                    <h4 class="infobox-title"><?php echo $message;?></h4>
                </div>
                
                
                
            </div><?php } ?>
            </div>


</body>
</html>

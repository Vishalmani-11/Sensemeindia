<?php
include "../db/session.php";  
include "../function/config.php"; 
include "../db/db_connect.php"; 
include "../function/function.php";
include "../function/image_resize.php";  
//////////////////////delete////////////////////////////////////////////////////////////////
if(isset($_GET['id'])&&$_GET['id']!=''&&isset($_GET['action'])&&$_GET['action']=='delete')
{
extract($_GET);	
    
$d_query = "DELETE FROM smratings WHERE id = ?";
    
if(!$d_stmt = $con->prepare($d_query))
{
	echo $error = "preparation failed!".$con->error; exit();
}

if(!$d_stmt->bind_param("i", $id))
{
	echo "Param pass failed: (" . $con->errno . ") " . $con->error; exit();
}
	
	if(!$d_stmt->execute())
	{
		echo $error = "review update failed!".$d_stmt->error;		 exit();
		
	}
    else
    {
    $success = "Review deleted successfully!";
    header("location:list_all_sm_reviews.php?success=".$success);
    }
    
    
} 
//////////////////////////////// update review///////////////////////////////////////////////////
if(isset($_POST['submit_edit_review']))
{
    
    extract($_POST);
    
$id = secure_input($con,$id);	   
echo $cname = secure_input($con,$review_name);     
$rr_parent_id = secure_input($con,$parent_id);      
if(isset($review_date)&&!empty($review_date))   
{
 $rdate = date('Y/m/d', strtotime($review_date));        
}
else
{
   $rdate = date('Y/m/d', strtotime($e_date));        
}

    if(isset($rating)&&!empty($rating))   
{
    $rating = secure_input($con,$rating);              
}
else
{
   $rating = secure_input($con,$e_rating);        
}
    
    if(isset($recommend)&&!empty($recommend))   
{
$recommend = secure_input($con,$recommend);	        
}
else
{
    $recommend = date('Y/m/d', strtotime($e_recommend));        
}
    
echo $title = secure_input($con,$review_title);	    
echo $review = secure_input($con,$description_review);	
    
////////////////////////////Image upload////////////////////////////
    $pimage = array();
for($i=0;$i<3;$i++)
{    
if(($_FILES['pic']['error'][$i]==0))
{	
if (($_FILES["pic"]["size"][$i] < 5000000))
  {
	$file_tmp_name = $_FILES["pic"]["tmp_name"][$i];
    $path = "../uploads/tempimage/";
    $image_path = "uploads/tempimage/";
	$error_path = "list_all_products.php";
	$exten = explode(".", $_FILES["pic"]["name"][$i]);
    $old_name = $exten[0];
    $extension = end($exten);
    $new_name = 1;
    $file = upload_image($file_tmp_name, $old_name, $path, $image_path, $error_path, $new_name); 
    /////////////////image resize/////////////////////////////    
    $width = 800;
  $height = 500;
    $file = "../".$file;
    $exten2 = explode(".", $file);
    $extension2 = end($exten);
    $newfilename1 = uniqid('smreview_', true).".".$extension2;
   $resizedFile = "../uploads/reviews/".$newfilename1;
    $db_image_path = "uploads/reviews/".$newfilename1;
   if(!smart_resize_image($file, null, $width, $height, true, $resizedFile, true, false, 60 ))
   {
	   exit("error in resizing".mysqli_error($con));
   }
    
    $pimage[] = $db_image_path;
/////////////////////////////////////////////////////////////////////////////////    
    
	
  }
else
  {
	$error = "Invalid file size!";
	header("location:list_all_sm_reviews.php?error=".$error); exit();
  }
}
else
  {
    $pimage[] = $e_pic[$i];   
  }
}
///////////////////////////////////////////////////////////////////////////////////////////////////////
        
   
  
$up_query = "UPDATE smratings SET name = ?, title = ?, review = ?, star = ?, review_date = ?, pic1 = ?, pic2 = ?, pic3 = ?, recommend = ?  WHERE id = ?";
    
if(!$up_stmt = $con->prepare($up_query))
{
	echo $error = "preparation failed!".$con->error; exit();
}

if(!$up_stmt->bind_param("sssissssii", $cname, $title, $review, $rating, $rdate, $pimage[0], $pimage[1], $pimage[2], $recommend, $id))
{
	echo "Param pass failed: (" . $con->errno . ") " . $con->error; exit();
}
	
	if(!$up_stmt->execute())
	{
		echo $error = "review update failed!".$up_stmt->error;		 exit();
		
	}
    else
    {
        
        if($status!=0||$status!=1) { $status = "All";  }
    $success = "<strong>Review updated successfully!</strong>";
    header("location:list_all_sm_reviews.php?status=".$status."&success=".$success);
    }
}


////////////////////////////////status update review///////////////////////////////////////////////////
if(isset($_GET['id'])&&$_GET['id']!=''&&isset($_GET['action'])&&$_GET['action']=='update'&&isset($_GET['status'])&&$_GET['status']!='')
{
    extract($_GET);
    
  $status = secure_input($con,$status);	
    if($status==0)
    {
        $update_status = 1;
    }
    else
        if($status==1)
        {
            $update_status = 0;
        }
   $id = secure_input($con,$id);	
  
$up_query = "UPDATE smratings SET status = ? WHERE id = ?";
    
if(!$up_stmt = $con->prepare($up_query))
{
	echo $error = "preparation failed!".$con->error; exit();
}

if(!$up_stmt->bind_param("ii", $update_status, $id))
{
	echo "Param pass failed: (" . $con->errno . ") " . $con->error; exit();
}
	
	if(!$up_stmt->execute())
	{
		echo $error = "review update failed!".$up_stmt->error;		 exit();
		
	}
    else
    {
        
        if($status!=0||$status!=1) { $status = "All";  }
    $success = "<strong>Review updated successfully!</strong>";
    header("location:list_all_sm_reviews.php?status=".$status."&success=".$success);
    }
}

////////////////////////////////list reviews///////////////////////////////////////////////////////////////////////////////

     $query = "SELECT t1.id, t1.name, t1.title, t1.review, t1.star, t1.review_date, t1.pic1, t1.pic2, t1.pic3, t1.recommend, t1.status, t2.name as pname FROM smratings as t1 INNER JOIN bb_products as t2 ON t1.parent_id = t2.id ORDER BY t1.cdate DESC";
        
    
        if(!$ostmt = $con->prepare($query))
            {
                echo $error = "review listing preparation failed!".$con->error; exit();
            }

	
	if(!$ostmt->execute())
	{
		echo $error = "review data execution failed!".$ostmt->error;	exit();	
		
	}
		if(!$ostmt->store_result())
		{
			echo $error = "review listing execution failed!".$con->error;	exit();				
		}
	
	$onum_of_rows = $ostmt->num_rows;

	if($onum_of_rows==0)
{
	$error = "No reviews available";		
}

//////////////////////////////////


?>
<!DOCTYPE html>
    <html>
    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title><?php echo $_SESSION['cName']; ?> Admin Area</title>
   <?php include("../header.php"); ?>
        <script type="text/javascript" src="<?php echo $_SESSION['gpath']; ?>assets/js/minified/widgets/charts-justgage.min.js"></script>

<style>

.dataTables_scrollBody
{
	height:500px !important;

}

</style>
        
           <style type="text/css">
        .gray_star
        {
            color: #D8D8D8;
        }
.rating {
	overflow: hidden;
	display: inline-block;
	font-size: 0;
	position: relative;
}
.rating-input {
	float: left;
	width: 16px !important;
	height: 16px;
	padding:0 !important;	  
	margin: 0 0 0 -16px !important;
	opacity: 0 !important;
}
.rating:hover .rating-star:hover, .rating:hover .rating-star:hover ~ .rating-star, .rating-input:checked ~ .rating-star {
	background-position: 0 0;
}
.rating-star, .rating:hover .rating-star {
	position: relative;
	float: right;
	display: block;
	width: 16px;
	height: 16px;
    cursor: pointer;
	margin-right:5px;
	background: url('../assets/images/star.png') 0 -16px;
}
</style>
<script type="text/javascript">
    $(function() {
         $( "#FUPdatepicker" ).datepicker({
            numberOfMonths: 2,
            showButtonPanel: true
          });
 
    });
	
	
</script>

    </head>
    <body>
        

        <div id="loading" class="ui-front loader ui-widget-overlay bg-white opacity-100">
            <img src="../assets/images/loader-dark.gif" alt="">
        </div>

        <div id="page-wrapper" class="demo-example">
          <!-- #page-header -->

            <?php include("../sidebar.php"); ?>
            <!-- #page-sidebar -->
            <div id="menu-right" class="scrollable-content hidden">
                <a href="javascript:;" title="Get Source" class="popover-title button-toggle-open">
                    Cloud status
                    <i class="glyph-icon icon-caret-right icon-caret-down"></i>
                </a>
                <div class="clear"></div>
                <a href="javascript:;" title="Get Source" class="popover-title button-toggle-open">
                    Realtime server load
                    <i class="glyph-icon icon-caret-right icon-caret-down"></i>
                </a>
                <div class="toggle-content-open clearfix">

                    <div id="g10" class="small-gauge float-left"></div>
                    <div id="g11" class="small-gauge float-right"></div>
                </div>
            </div>

            <div id="page-content-wrapper">
                <div id="page-title">

  <h3><?php if(isset($_GET['status']))

        { 
        if($_GET['status']===0)
            
        { echo "Unpublished Reviews"; } 
    
          elseif($_GET['status']===1) 

          { echo "Published Reviews"; } 
    
         else  { echo "All Reviews"; } 
    
        }
      
      else { echo "All Reviews"; }?> </h3><br>
    
                    
    <?php 
			   if(isset($success)){ ?>

             
             <div class="infobox success-bg">
<a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>             
                    <h4 class="infobox-title"><?php echo $success;?></h4>
                </div><?php } ?>
                    
                        <?php 
			   if(isset($_GET['success'])){ ?>

             
             <div class="infobox success-bg">
<a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>             
                    <h4 class="infobox-title"><?php echo $_GET['success'];?></h4>
                </div><?php } ?>
                    
              </div><!-- #page-title -->
<div id="page-content">


<h4>&nbsp;</h4>

<table class="table" id="example1">
  <thead>
		<tr>
			<th width="5%">S.No</th>
			<th width="9%">Product</th>
            <th width="8%">Customer</th>
			<th width="28%">Review</th>
			<th width="4%">Star</th>        
            <th width="5%">Recommend</th> 
			<th width="7%">Review Date</th>        
			<th width="5%">Status</th>			
			<th width="5%">Action</th>
		</tr>
	</thead>
	<tbody>
    
    
    <?php 
	$sn = 0;
	$ostmt->bind_result($id, $name, $title, $review, $star, $cdate, $pic1, $pic2, $pic3, $recommend, $status, $pname);
	while ($ostmt->fetch()) 
	{
        $sn = $sn + 1;
		$name = ucwords($name);
	?>
    
		<tr>
			<td><?php echo $sn;?></td>
			<td><?php echo $pname; ?></a>
</td>
    <td><?php echo $name; ?></td>
    
			<td><strong><?php echo $title; ?></strong><br><?php echo $review; ?>
                
                <?php if(!empty($pic1)) { ?>
                <br><br>

                
<a href="<?php echo $pic1; ?>" title="View product" target="_blank"><img src="../<?php echo $pic1; ?>" width="15%"> <?php } ?>
    
     <?php if(!empty($pic2)) { ?>
               
                
<a href="<?php echo $pic2; ?>" title="View product" target="_blank"><img src="../<?php echo $pic2; ?>" width="15%"> <?php } ?>
    
     <?php if(!empty($pic3)) { ?>
                               
<a href="<?php echo $pic3; ?>" title="View product" target="_blank"><img src="../<?php echo $pic3; ?>" width="15%"> <?php } ?>
</td>
			<td><?php echo $star; ?></td>
        <td><?php if($recommend==0) { echo "No"; } else { echo "Yes"; } ?></td>
			<td><?php echo date('d-m-Y', strtotime($cdate)); ?></td>       
			<td><?php if($status>0) { echo "Published"; } else { echo "Unpublished"; } ?></td>			
			<td>
                                <div class="dropdown">
                                    <a href="javascript:;" title="" class="btn medium bg-blue" data-toggle="dropdown">
                                        <span class="button-content">
                                            <i class="glyph-icon font-size-11 icon-cog"></i>
                                            <i class="glyph-icon font-size-11 icon-chevron-down"></i>
                                        </span>
                                    </a>
                                    <ul class="dropdown-menu float-right">
                                        
                                          <li>
											  <a href="javascript:;" class="black-modal-review-edit" id="<?php echo $id; ?>">
                                                <i class="glyph-icon icon-edit mrg5R"></i>
                                                Edit
                                            </a>
                                            
											</li>
                                        
                                        
                                    <?php if($status==0)
    { ?>
        
    
                                 <li>
                                            <a href="list_all_sm_reviews.php?id=<?php echo $id; ?>&action=update&status=<?php echo $status; ?>" title="" onclick="return confirm('Are you sure you want to publish this review?');" class="font-green">
                                                <i class="glyph-icon icon-plus mrg5R"></i>
                                                Publish
                                            </a>
                                        </li>
                                        
                                        <?php } else if($status==1) { ?>
                                        
                                            <li>
                                            <a href="list_all_sm_reviews.php?id=<?php echo $id; ?>&action=update&status=<?php echo $status; ?>" title="" onclick="return confirm('Are you sure you want to unpublish this review?');" class="font-red">
                                                <i class="glyph-icon icon-remove mrg5R"></i>
                                                Unpublish
                                            </a>
                                        </li>
                                        <?php } ?>
								
                                        <li>
                                            <a href="list_all_sm_reviews.php?id=<?php echo $id; ?>&action=delete" title="" onclick="return confirm('Are you sure you want to delete this review?');" class="font-red">
                                                <i class="glyph-icon icon-remove mrg5R"></i>
                                                Delete
                                            </a>
                                        </li>
                                        
                                    </ul>
                                </div>
                            </td>
		</tr>
        
        <?php } ?>
        
	</tbody>
	<tfoot>
		<tr>
			<th></th>
			<th></th>
			<th></th>
			<th></th>
			<th></th>			
			<th></th>
			<th></th>			
			<th></th>
		</tr>
	</tfoot>
</table>


                	</div><!-- #page-content -->
            </div>




                	</div><!-- #page-content -->
            </div><!-- #page-main -->
        </div><!-- #page-wrapper -->

<!-----------------------------------------------------edit child------------------------------>
<div class="hide" id="black-modal-review-child" title="Edit review">
<div class="example-code">
      <form id="demo-form-review-child" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" class="col-md-11 center-margin" method="post" enctype="multipart/form-data">
        <div class="content-box mrg25B mrg25T">
          <h3 class="content-box-header primary-bg"> <span>Edit review details</span> </h3>
          <div class="content-box-wrapper"> 
        
              
                <div class="form-row">
              <div class="form-label col-md-4">
                <label for=""> Review Date:</label>
              </div>
              <div class="form-input col-md-8">
                <input type="text" class="col-md-12" class="datepicker" id="FUPdatepicker" name="review_date">
              </div>
            </div>
              
               <div class="form-row">
                     <div class="form-label col-md-4">
                    <label for="">
                       Rating:                      
                    </label>
                </div>
                 <div class="form-input col-md-8">
              <div class="submit-rating">
                                        <span class="rating">
            <input type="radio" class="rating-input" id="rating-input-1-5" value="5" name="rating"/>
            <label for="rating-input-1-5" class="rating-star"></label>
            <input type="radio" class="rating-input" id="rating-input-1-4" value="4" name="rating"/>
            <label for="rating-input-1-4" class="rating-star"></label>
            <input type="radio" class="rating-input" id="rating-input-1-3" value="3" name="rating"/>
            <label for="rating-input-1-3" class="rating-star"></label>
            <input type="radio" class="rating-input" id="rating-input-1-2" value="2" name="rating"/>
            <label for="rating-input-1-2" class="rating-star"></label>
            <input type="radio" class="rating-input" id="rating-input-1-1" value="1" name="rating"/>
            <label for="rating-input-1-1" class="rating-star"></label>
            </span>
                                    </div>
                     </div>
                </div>
              
              
              
            <div class="form-row">
                <div class="form-label col-md-4">
                    <label for="">
                      Name:
                         <span class="required">*</span>
                    </label>
                </div>
                <div class="form-input col-md-8">
                    <input  type="text" id="review_name" name="review_name" data-trigger="change" data-required="true" class="parsley-validated" >
                </div>
            </div>
            
           <div class="form-row">
                <div class="form-label col-md-4">
                    <label for="">
                      Title:
                         <span class="required">*</span>
                    </label>
                </div>
                <div class="form-input col-md-8">
                    <input  type="text" id="review_title" name="review_title" data-trigger="change" data-required="true" class="parsley-validated" >
                </div>
            </div>
              
                <div class="form-row">
                <div class="form-label col-md-4">
                    <label for="">
                        Review: <span class="required">*</span>
                    </label>
                </div>
           <div class="form-input col-md-8">
                <textarea id="description_review" name="description_review" rows="10" data-trigger="change" class="parsley-validated" data-required="true"></textarea>
              </div>
            </div>
         
             <div class="form-row">
              <div class="form-label col-md-4">
                <label for=""> Would you recommend this product?:</label>
              </div>
              <div class="form-input col-md-8">
                <select data-placeholder="Select a value..." name="recommend" class="chosen-select parsley-validated" data-trigger="change" required>
					  <option value="1" selected>Yes</option>	
                    <option value="0">No</option>	
        
                </select>
              </div>
              
            </div>
              
                
			<div class="form-row">
          <div class="form-label col-md-4">
            <label for="">Product image 1:</label>
          </div>
          <div class="float-left col-md-8"> <span class="btn medium bg-green fileinput-button"><span class="button-content">Max 500kb. (gif, jpg, png) only</span>
              <input type="file" name="pic[]">
           </div>
        </div>
				<div class="form-row">
          <div class="form-label col-md-4">
            <label for="">Product image 2:</label>
          </div>
          <div class="float-left col-md-8"> <span class="btn medium bg-green fileinput-button"> <span class="button-content">Max 500kb. (gif, jpg, png) only</span>
              <input type="file" name="pic[]">
           </div>
        </div>
					<div class="form-row">
          <div class="form-label col-md-4">
            <label for="">Product image 3:</label>
          </div>
          <div class="float-left col-md-8"> <span class="btn medium bg-green fileinput-button"> <span class="button-content">Max 500kb. (gif, jpg, png) only</span>
              <input type="file" name="pic[]">
            </div>
        </div>
                        
			             
            <div class="divider"></div>
            <div class="form-row">
                <input type="hidden" name="parent_id" id="parent_id_review_edit">
                <input type="hidden" name="id" id="id_review_edit">
                <input type="hidden" name="e_recommend" id="recommend_review">                
                <input type="hidden" name="e_date" id="date_review"> 
                <input type="hidden" name="e_rating" id="star_review">                
                <input type="hidden" name="e_pic[]" id="pic1_review">
                <input type="hidden" name="e_pic[]" id="pic1_review">
                <input type="hidden" name="e_pic[]" id="pic1_review">
                <div class="form-input col-md-8 col-md-offset-4">
               <button type="submit" name="submit_edit_review"  class="btn large primary-bg" onclick="javascript:$(&apos;#demo-form-edit-review&apos;).parsley( &apos;validate&apos; );"><span class="button-content">Save Data</span></button>
&nbsp;
                </div>
            </div>
          
            </div> </div> </form> </div></div>
              
<!----------------------------------------------------------------------->
<script type="text/javascript">              
              //////////////////////////////edit child////////////////////////////////////////
 
	$( ".black-modal-review-edit" ).click(function() { 
           var cid = $(this).attr("id");  
		   $.ajax({  
                url:"fetch_review_data.php",  
                method:"POST",  
                data:{cid:cid},  
                dataType:"json",
                beforeSend: function(){
				$('#loading').fadeIn();
			    },
        complete: function(){
				$('#loading').hide();
				},
               error: function(xhr, error){
        console.debug(xhr); console.debug(error);
 },
                success:function(data){  

$('#parent_id_review_edit').val(data.parent_id);                    
$('#id_review_edit').val(data.id);
$('#review_title').val(data.title);
$('#review_name').val(data.name);
$('#description_review').val(data.review);   
$('#date_review').val(data.review_date);                       
$('#star_review').val(data.star);                       
$('#pic1_review').val(data.pic1);                       
$('#pic2_review').val(data.pic2);                       
$('#pic3_review').val(data.pic3);    
$('#recommend_review').val(data.recommend);                        

					$( "#black-modal-review-child" ).dialog({
             modal: true,
             minWidth:900,
             minHeight: 200, 
             dialogClass: "modal-dialog", 
             buttons: {
					   "CLOSE": function() {
						   $( this ).dialog( "close" );
					   }
				   },
			   show: "fadeIn" 
           });
           $('.ui-widget-overlay').addClass('bg-black opacity-60');
                }  
           });  
      });      
              
              </script>

    </body>
</html>


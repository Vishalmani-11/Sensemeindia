<?php
include "../db/session.php";  
include "../function/config.php"; 
include "../db/db_connect.php"; 
include "../function/function.php";
//////////////////////delete////////////////////////
if(isset($_GET['id'])&&$_GET['id']!=''&&isset($_GET['action'])&&$_GET['action']=='delete')
{
extract($_GET);	
    
$d_query = "DELETE FROM productrating WHERE id = ?";
    
if(!$d_stmt = $con->prepare($d_query))
{
	echo $error = "preparation failed!".$con->error; exit();
}

if(!$d_stmt->bind_param("i", $id))
{
	echo "Param pass failed: (" . $con->errno . ") " . $con->error; exit();
}
	
	if(!$d_stmt->execute())
	{
		echo $error = "review update failed!".$d_stmt->error;		 exit();
		
	}
    else
    {
    $success = "Review deleted successfully!";
    header("location:list_all_reviews.php?success=".$success);
    }
    
    
} 
////////////////////////////////update review///////////////////////////////////////////////////
if(isset($_GET['id'])&&$_GET['id']!=''&&isset($_GET['action'])&&$_GET['action']=='update'&&isset($_GET['status'])&&$_GET['status']!='')
{
    extract($_GET);
    
  $status = secure_input($con,$status);	
    if($status==0)
    {
        $update_status = 1;
    }
    else
        if($status==1)
        {
            $update_status = 0;
        }
   $id = secure_input($con,$id);	
  
$up_query = "UPDATE productrating SET status = ? WHERE id = ?";
    
if(!$up_stmt = $con->prepare($up_query))
{
	echo $error = "preparation failed!".$con->error; exit();
}

if(!$up_stmt->bind_param("ii", $update_status, $id))
{
	echo "Param pass failed: (" . $con->errno . ") " . $con->error; exit();
}
	
	if(!$up_stmt->execute())
	{
		echo $error = "review update failed!".$up_stmt->error;		 exit();
		
	}
    else
    {
        
        if($status!=0||$status!=1) { $status = "All";  }
    $success = "<strong>Review updated successfully!</strong>";
    header("location:list_all_reviews.php?status=".$status."&success=".$success);
    }
}

////////////////////////////////list reviews///////////////////////////////////////////////////////////////////////////////

if(isset($_GET['status'])&&$_GET['status']!="All"&&$_GET['status']!="")
{
    extract($_GET);
    
    $status = secure_input($con,$status);	

        $query = "SELECT t1.id, t1.title, t1.review, t1.star, t1.cdate, t1.status, CONCAT(t2.fname,' ',t2.lname) as cname, t2.phone, t3.orderid, t3.name as pname, t3.picture FROM productrating as t1 INNER JOIN bb_users as t2 ON t1.cid = t2.id INNER JOIN bb_order_products as t3 ON t1.order_pid = t3.id WHERE t1.status = ? ORDER BY t1.cdate DESC";
        
        if(!$ostmt = $con->prepare($query))
            {
                echo $error = "review data listing preparation failed!".$con->error;exit();
            }
    
        if ( !$ostmt->bind_param( 's', $status ) ) {
            echo $error = "review data listing preparation failed!" . $con->error; exit();
            exit();
        }

}
else
{
        $query = "SELECT t1.id, t1.title, t1.review, t1.star, t1.cdate, t1.status, CONCAT(t2.fname,' ',t2.lname) as cname, t2.phone, t3.orderid, t3.name as pname, t3.picture FROM productrating as t1 INNER JOIN bb_users as t2 ON t1.cid = t2.id INNER JOIN bb_order_products as t3 ON t1.order_pid = t3.id ORDER BY t1.cdate DESC";
        
    
        if(!$ostmt = $con->prepare($query))
            {
                echo $error = "categories data listing preparation failed!".$con->error; exit();
            }
}
	
	if(!$ostmt->execute())
	{
		echo $error = "review data execution failed!".$ostmt->error;	exit();	
		
	}
		if(!$ostmt->store_result())
		{
			echo $error = "review listing execution failed!".$con->error;	exit();				
		}
	
	$onum_of_rows = $ostmt->num_rows;

	if($onum_of_rows==0)
{
	$error = "No categories available";		
}

//////////////////////////////////


?>
<!DOCTYPE html>
    <html>
    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title><?php echo $_SESSION['cName']; ?> Admin Area</title>
   <?php include("../header.php"); ?>
        <script type="text/javascript" src="<?php echo $_SESSION['gpath']; ?>assets/js/minified/widgets/charts-justgage.min.js"></script>

<style>

.dataTables_scrollBody
{
	height:500px !important;

}

</style>

    </head>
    <body>
        

        <div id="loading" class="ui-front loader ui-widget-overlay bg-white opacity-100">
            <img src="../assets/images/loader-dark.gif" alt="">
        </div>

        <div id="page-wrapper" class="demo-example">
          <!-- #page-header -->

            <?php include("../sidebar.php"); ?>
            <!-- #page-sidebar -->
            <div id="menu-right" class="scrollable-content hidden">
                <a href="javascript:;" title="Get Source" class="popover-title button-toggle-open">
                    Cloud status
                    <i class="glyph-icon icon-caret-right icon-caret-down"></i>
                </a>
                <div class="clear"></div>
                <a href="javascript:;" title="Get Source" class="popover-title button-toggle-open">
                    Realtime server load
                    <i class="glyph-icon icon-caret-right icon-caret-down"></i>
                </a>
                <div class="toggle-content-open clearfix">

                    <div id="g10" class="small-gauge float-left"></div>
                    <div id="g11" class="small-gauge float-right"></div>
                </div>
            </div>

            <div id="page-content-wrapper">
                <div id="page-title">

  <h3><?php if(isset($_GET['status']))

        { 
        if($_GET['status']===0)
            
        { echo "Unpublished Reviews"; } 
    
          elseif($_GET['status']===1) 

          { echo "Published Reviews"; } 
    
         else  { echo "All Reviews"; } 
    
        }
      
      else { echo "All Reviews"; }?> </h3><br>
    
                    
    <?php 
			   if(isset($success)){ ?>

             
             <div class="infobox success-bg">
<a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>             
                    <h4 class="infobox-title"><?php echo $success;?></h4>
                </div><?php } ?>
                    
                        <?php 
			   if(isset($_GET['success'])){ ?>

             
             <div class="infobox success-bg">
<a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>             
                    <h4 class="infobox-title"><?php echo $_GET['success'];?></h4>
                </div><?php } ?>
                    
              </div><!-- #page-title -->
<div id="page-content">

<script type="text/javascript">

$(document).ready(function() {

});

</script>

<h4>&nbsp;</h4>

<table class="table" id="example1">
  <thead>
		<tr>
			<th width="5%">Order ID</th>
			<th width="10%">Product</th>
			<th width="28%">Review</th>
			<th width="4%">Star</th>        
			<th width="7%">Date</th>        
			<th width="5%">Status</th>
			<th width="10%">Customer</th>
			<th width="7%">Action</th>
		</tr>
	</thead>
	<tbody>
    
    
    <?php 
	$sn = 0;
	$ostmt->bind_result($id, $title, $review, $star, $cdate, $status, $cname, $phone, $orderid, $pname, $picture);
	while ($ostmt->fetch()) 
	{
		$name = ucwords($name);
	?>
    
		<tr>
			<td>BB<?php echo $id;?></td>
			<td><a href="../<?php echo $picture; ?>" title="View product" target="_blank"><img src="../<?php echo $picture; ?>" width="25%"><br><?php echo $pname; ?></a>
</td>
			<td><?php echo $title; ?><br><?php echo $review; ?>
</td>
			<td><?php echo $star; ?></td>
			<td><?php echo date('l - dS M, Y - h:i:s A', strtotime($cdate)); ?></td>       
			<td><?php if($status>0) { echo "Published"; } else { echo "Unpublished"; } ?></td>
			<td><?php echo $cname."<br>(".$phone.")"; ?></td>
			<td>
                                <div class="dropdown">
                                    <a href="javascript:;" title="" class="btn medium bg-blue" data-toggle="dropdown">
                                        <span class="button-content">
                                            <i class="glyph-icon font-size-11 icon-cog"></i>
                                            <i class="glyph-icon font-size-11 icon-chevron-down"></i>
                                        </span>
                                    </a>
                                    <ul class="dropdown-menu float-right">
                                        
                                    <?php if($status==0)
    { ?>
        
    
                                 <li>
                                            <a href="list_all_reviews.php?id=<?php echo $id; ?>&action=update&status=<?php echo $status; ?>" title="" onclick="return confirm('Are you sure you want to publish this review?');" class="font-green">
                                                <i class="glyph-icon icon-plus mrg5R"></i>
                                                Publish
                                            </a>
                                        </li>
                                        
                                        <?php } else if($status==1) { ?>
                                        
                                            <li>
                                            <a href="list_all_reviews.php?id=<?php echo $id; ?>&action=update&status=<?php echo $status; ?>" title="" onclick="return confirm('Are you sure you want to unpublish this review?');" class="font-red">
                                                <i class="glyph-icon icon-remove mrg5R"></i>
                                                Unpublish
                                            </a>
                                        </li>
                                        <?php } ?>
								
                                        <li>
                                            <a href="list_all_reviews.php?id=<?php echo $id; ?>&action=delete" title="" onclick="return confirm('Are you sure you want to delete this review?');" class="font-red">
                                                <i class="glyph-icon icon-remove mrg5R"></i>
                                                Delete
                                            </a>
                                        </li>
                                        
                                    </ul>
                                </div>
                            </td>
		</tr>
        
        <?php } ?>
        
	</tbody>
	<tfoot>
		<tr>
			<th></th>
			<th></th>
			<th></th>
			<th></th>
			<th></th>			
			<th></th>
			<th></th>			
			<th></th>
		</tr>
	</tfoot>
</table>


                	</div><!-- #page-content -->
            </div>




                	</div><!-- #page-content -->
            </div><!-- #page-main -->
        </div><!-- #page-wrapper -->

    </body>
</html>


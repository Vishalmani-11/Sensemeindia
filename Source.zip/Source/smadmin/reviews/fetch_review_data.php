 <?php  
include "../function/config.php"; 
include "../db/db_connect.php"; 
include "../function/function.php";  

if(isset($_POST["cid"]))  
 {  
	 //$query = "SELECT t1.*, t2.name FROM bb_products as t1 INNER JOIN bb_sub_categories as t2 ON t1.sc_id = t2.id WHERE t1.id = '".$_POST["cid"]."'";
	 $query = "SELECT * FROM smratings WHERE id = '".$_POST["cid"]."'";  
      if(!$result = mysqli_query($con, $query))
      {
          echo "error".$con->error; exit();
      }
      $row = mysqli_fetch_array($result);  
      echo json_encode($row);
	 	
 }  
 ?>




                    
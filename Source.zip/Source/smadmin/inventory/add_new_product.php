<?php
include "../function/config.php"; 
include "../db/db_connect.php"; 
include "../db/session.php";  
include "../function/function.php";  

////////////////////////save/////////////////////////
if(isset($_POST['submit']))
{
extract($_POST);	
$mc_id = secure_input($con,$cid);
$sc_id = secure_input($con,$scid);  
$HSC = secure_input($con,$HSC_code);         
$SKU = secure_input($con,$SKU);        
$pname = secure_input($con,$pname);
$MRP = secure_input($con,$MRP);	
if(isset($_POST['price'])&&$_POST['price']!=""&&$_POST['price']!=0) 
{
    $price = secure_input($con,$price);	
}
else
{
        $price = $MRP;
}
    
$stock = secure_input($con,$stock);	    
$bselling = secure_input($con,$bselling);		    
$ftype = secure_input($con,$ftype);		
$size = secure_input($con,$size);		    
$disclaimer = secure_input($con,$disclaimer);		    
$description = secure_input($con,$description);
$google_description = secure_input($con,$google_description);    
$details = secure_input($con,$details);	  
$tags = secure_input($con,$tags);	    
$title = secure_input($con,$seo_title);	    
$meta = secure_input($con,$meta_description);	        
$keywords = secure_input($con,$meta_keywords);	      
    
/////////////////////////////Image upload////////////////////////////
    $pimage = array();
for($i=0;$i<7;$i++)
{    
if(($_FILES['pic']['error'][$i]==0))
{	
if (($_FILES["pic"]["size"][$i] < 1000000))
  {
	$file_tmp_name = $_FILES["pic"]["tmp_name"][$i];
    $path = "../uploads/products/";
    $image_path = "uploads/products/";
	$error_path = "add_new_product.php";
	$exten = explode(".", $_FILES["pic"]["name"][$i]);
	$old_name = $exten[0];
	$new_name = 1;
	$pimage[] = upload_image($file_tmp_name, $old_name, $path, $image_path, $error_path, $new_name); 
    
  }
else
  {
	$error = "Invalid file size!";
	header("location:add_new_product.php?error=".$error); exit();
  }
}
else
  {
    $pimage[] = NULL;    
  }
}
  
////////////////////////////////////parent product///////////////////////////////////	
    

if(!$stmt = $con->prepare("INSERT INTO bb_products (mc_id, sc_id, name, hsc_code, details, description, g_description, disclaimer, seo_title, seo_keyword, seo_meta, tags) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"))
{
	echo "Prepare failed: (" . $con->errno . ") " . $con->error; exit();   
}

if(!$stmt->bind_param("iissssssssss", $mc_id, $sc_id, $pname, $HSC, $details, $description, $google_description, $disclaimer, $title, $keywords, $meta, $tags))
{
	echo "Param pass failed: (" . $con->errno . ") " . $con->error; exit();   
}

if(!$stmt->execute()) {
    
echo	$error = "New parent product data saving failed!".$con->error; exit();   

}
else
{

$parent_id = $stmt->insert_id;  
////////////////////////////////////child product///////////////////////////////////	

if(!$chstmt = $con->prepare("INSERT INTO bb_products_stock (sku, parent_id, size, mrp, price, qty, pic1, pic2, pic3, pic4, pic5, pic6, pic7, featured, bestselling) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"))
{
	echo "Prepare failed: (" . $con->errno . ") " . $con->error; exit();
}

if(!$chstmt->bind_param("siiiiisssssssii", $SKU, $parent_id, $size, $MRP, $price, $stock, $pimage[0], $pimage[1], $pimage[2], $pimage[3], $pimage[4], $pimage[5], $pimage[6], $ftype, $bselling))
{
	echo "Param pass failed: (" . $con->errno . ") " . $con->error; exit();
}

if(!$chstmt->execute()) {
    
	$error = "New child product data saving failed!".$con->error;
    header("location:add_new_product.php?error=".$error); exit();   
    
}
else
{
	$success= "New Product data saved successfully!";
	header("location:add_new_product.php?success=".$success);
	exit();
    }
//////////////////////////////////////////////////////////////////////////////////      
    
}
   


}

//////////////////////////category////////////////////////////////////////

$active = 1;

$query = "SELECT id, name FROM bb_categories WHERE active = ? ORDER BY name ASC";

if(!$tstmt = $con->prepare($query))
{
	echo "prepare failed: (" . $con->errno . ") " . $con->error;	exit();   
}
	if(!$tstmt->bind_param("i", $active))
{
	echo "Param pass failed: (" . $con->errno . ") " . $con->error;exit();   
}

	if(!$tstmt->execute())
	{
		$error = "categories list failed!".$con->error;		exit();   
		
	}

		if(!$tstmt->store_result())
		{
			$error = "categories list failed!".$con->error;		exit();   			
		}
	
		$num_of_rows = $tstmt->num_rows;

if($num_of_rows==0)
{
	$terror = "No categories found";		
}
//////////////////////////size////////////////////////////////////////


$squery = "SELECT id, name FROM bb_sizes ORDER BY name ASC";

if(!$sstmt = $con->prepare($squery))
{
	echo "prepare failed: (" . $con->errno . ") " . $con->error;	exit();   
}


	if(!$sstmt->execute())
	{
		$error = "size list failed!".$con->error;		exit();   
		
	}

		if(!$sstmt->store_result())
		{
			$error = "categories list failed!".$con->error;	exit();   				
		}
	
		$snum_of_rows = $sstmt->num_rows;

if($snum_of_rows==0)
{
	$serror = "No sizes found";		
}
//////////////////////////colors////////////////////////////////////////

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title><?php echo $_SESSION['cName']; ?> Admin Area</title>
    <?php include("../header.php"); ?>
    
<script>
     $(document).ready(function() {
         
    $("#category").change(function(){
    var categoryId = $(this).val();

    $.ajax({
        type: "POST",
        url: "get_sub_category.php",
        data: {category_id : categoryId },
        beforeSend: function(){
				$('#loading').fadeIn();
			    },
        complete: function(){
				$('#loading').hide();
				},
        success: function (data) {            
          //  alert(data); 
            $("#subcategory").prop("disabled", false);
            $("#subcategory").html(data);
        }
    });
});
         
         });
    </script>
</head>
<body>
<div id="loading" class="ui-front loader ui-widget-overlay bg-white opacity-100"> <img src="<?php echo $_SESSION['gpath'] ?>assets/images/loader-dark.gif" alt=""> </div>
<div id="page-wrapper" class="demo-example"> 
  <!-- #page-header -->
  
  <?php include("../sidebar.php"); ?>
  <!-- #page-sidebar -->
  <div id="menu-right" class="scrollable-content hidden">
    <div class="toggle-content-open clearfix">
      <div id="g10" class="small-gauge float-left"></div>
      <div id="g11" class="small-gauge float-right"></div>
    </div>
  </div>
  <div id="page-content-wrapper">
            
                <div id="page-title">

<h3>
    <strong>Add new product</strong> 
</h3>

</div><!-- #page-title -->

            
<div id="page-content">
<h3><strong>Product details:</strong></h3>
<div class="example-box">
<?php 
			   if(isset($error)){ ?>
             
             <div class="infobox error-bg">
<a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>             
<div class="bg-red large btn info-icon">
                        <i class="glyph-icon icon-remove"></i>
                    </div>
                    <h4 class="infobox-title"><?php echo $error;?></h4>
                    <p>Some error in the database query occured. Please try again!</p>
                </div>
           <?php } ?>
    
    <?php 
			   if(isset($_GET['error'])){ ?>
             
             <div class="infobox error-bg">
<a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>             
<div class="bg-red large btn info-icon">
                        <i class="glyph-icon icon-remove"></i>
                    </div>
                    <h4 class="infobox-title"><?php echo $_GET['error'];?></h4>
                    <p>Some error in the database query occured. Please try again!</p>
                </div>
           <?php } ?>
    
            
<?php 
			   if(isset($success)){ ?>
             
             <div class="infobox success-bg">
<a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>             
                    <h4 class="infobox-title"><?php echo $success;?></h4>
                </div><?php } ?>
    
    <?php 
			   if(isset($_GET['success'])){ ?>
             
             <div class="infobox success-bg">
<a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>             
                    <h4 class="infobox-title"><?php echo $_GET['success'];?></h4>
                </div><?php } ?>
     
    <div class="example-code">
<br>
<br>

        <form id="demo-form-2" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" class="col-md-10 center-margin" method="post" enctype="multipart/form-data">
          
			<div class="form-row">
              <div class="form-label col-md-3">
                <label for=""> Select a category: <span class="required">*</span></label>
              </div>
              <div class="form-input col-md-9">
                <select data-placeholder="Select a category..." name="cid" id="category" class="chosen-select parsley-validated" data-trigger="change" required>
      
      <?php      
			if(isset($terror))
			{
				?>
			     <option value=""><?php echo $terror; ?></option>	
			<?php 
						} 
						else
						{
			?>
                 <option value="">Select a category</option>	
                 <?php } ?>
                 
                  <?php 
	$tstmt->bind_result($id, $scname);
	while ($tstmt->fetch()) 
	{
			
	?>            
                  <option value="<?php echo $id; ?>"><?php echo $scname; ?></option>
                  
       <?php } 
		$tstmt->free_result();
		?>            
        
                </select>
              </div>
              
            </div>
			
			<div class="form-row">
              <div class="form-label col-md-3">
                <label for=""> Select a sub-category: <span class="required">*</span></label>
              </div>
              <div class="form-input col-md-9">
                <select data-placeholder="Select a sub-category..." name="scid" disabled id="subcategory" class="chosen-select parsley-validated" data-trigger="change" required>
        
                </select>
              </div>
              
            </div>
			<div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                       Product Name:
                         <span class="required">*</span>
                    </label>
                </div>
                <div class="form-input col-md-9">
                    <input  type="text" id="name" name="pname" data-trigger="change" parsley-rangelength="[2,99]" data-required="true" class="parsley-validated">
                </div>
            </div>
            
             <div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                      HSC Code:                       
                    </label>
                </div>
                <div class="form-input col-md-9">
                    <input  type="text" id="HSC" name="HSC_code" data-trigger="change" parsley-rangelength="[1,99]" pattern="^[A-Za-z0-9]*$" class="parsley-validated" > 
                </div>
            </div>
			
            <div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                       SKU#:
                         <span class="required">*</span>
                    </label>
                </div>
                <div class="form-input col-md-9">
                    <input  type="text" id="SKU" name="SKU" data-trigger="change" parsley-rangelength="[1,15]" pattern="^[A-Za-z0-9]*$" data-required="true" class="parsley-validated" > 
                </div>
            </div>
            
            <div class="form-row">
              <div class="form-label col-md-3">
                <label for=""> Select a size: <span class="required">*</span></label>
              </div>
              <div class="form-input col-md-9">
                <select data-placeholder="Select a size..." name="size" id="size" class="chosen-select parsley-validated" data-trigger="change" required>
      
      <?php      
			if(isset($serror))
			{
				?>
			     <option value=""><?php echo $serror; ?></option>	
			<?php 
						} 
						else
						{
			?>
                 <option value="">Select a size</option>	
                 <?php } ?>
                 
                  <?php 
	$sstmt->bind_result($id, $scname);
	while ($sstmt->fetch()) 
	{
			
	?>            
                  <option value="<?php echo $id; ?>"><?php echo $scname; ?></option>
                  
       <?php } 
		$tstmt->free_result();
		?>            
        
                </select>
              </div>
              
            </div>
            
            
            
           <div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                       MRP:
                         <span class="required">*</span>
                    </label>
                </div>
                <div class="form-input col-md-9">
                    <input  type="text" id="name" name="MRP" data-trigger="change" data-type="number" parsley-rangelength="[1,10]" data-required="true" class="parsley-validated" >
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                       Selling Price:
                         <span class="required">*</span>
                    </label>
                </div>
                <div class="form-input col-md-9">
                    <input  type="text" id="name" name="price" data-trigger="change" data-type="number" parsley-rangelength="[1,10]" data-required="true" class="parsley-validated" >
                </div>
            </div>
            
             <div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                       Stock QTY:
                         <span class="required">*</span>
                    </label>
                </div>
                <div class="form-input col-md-9">
                    <input  type="text" id="stock" name="stock" data-trigger="change" data-type="number" parsley-rangelength="[1,10]" data-required="true" class="parsley-validated" >
                </div>
            </div>
            
            <div class="form-row">
              <div class="form-label col-md-3">
                <label for=""> Featured Product:</label>
              </div>
              <div class="form-input col-md-9">
                <select data-placeholder="Select a type..." name="ftype" class="chosen-select parsley-validated" data-trigger="change" required>
                     <option value="0" selected>No</option>	
					  <option value="1">Yes</option>	
        
                </select>
              </div>
              
            </div>
            
                 <div class="form-row">
              <div class="form-label col-md-3">
                <label for=""> Best Selling Product:</label>
              </div>
              <div class="form-input col-md-9">
                <select data-placeholder="Select a type..." name="bselling" class="chosen-select parsley-validated" data-trigger="change" required>
                     <option value="0" selected>No</option>	
					  <option value="1">Yes</option>	
        
                </select>
              </div>
              
            </div>
            
            
            
			<div class="form-row">
          <div class="form-label col-md-3">
            <label for=""> Upload Main image:<span class="required">*</span></label>
          </div>
          <div class="float-left col-md-9"> <span class="btn medium bg-green fileinput-button"> <span class="button-content">Max 500kb. Dimension: 268px x 268px. (gif, jpeg, jpg, png) only</span>
              <input type="file" name="pic[]" required>
             </div>
        </div>
				<div class="form-row">
          <div class="form-label col-md-3">
            <label for=""> Upload image 1:<span class="required">*</span></label>
          </div>
          <div class="float-left col-md-9"> <span class="btn medium bg-green fileinput-button"> <span class="button-content">Max 500kb. Dimension: 800px x 800px. (gif, jpeg, jpg, png) only</span>
              <input type="file" name="pic[]" required>
            </div>
        </div>
					<div class="form-row">
          <div class="form-label col-md-3">
            <label for=""> Upload image 2:</label>
          </div>
          <div class="float-left col-md-9"> <span class="btn medium bg-green fileinput-button"> <span class="button-content">Max 500kb. Dimension: 800px x 800px. (gif, jpeg, jpg, png) only</span>
              <input type="file" name="pic[]"> 
            </div>
        </div>
                        
                        <div class="form-row">
          <div class="form-label col-md-3">
            <label for=""> Upload image 3:</label>
          </div>
          <div class="float-left col-md-9"> <span class="btn medium bg-green fileinput-button"> <span class="button-content">Max 500kb. Dimension: 800px x 800px. (gif, jpeg, jpg, png) only</span>
              <input type="file" name="pic[]">
             </div>
        </div>
                            
                            <div class="form-row">
          <div class="form-label col-md-3">
            <label for=""> Upload image 4:</label>
          </div>
          <div class="float-left col-md-9"> <span class="btn medium bg-green fileinput-button"> <span class="button-content">Max 500kb. Dimension: 800px x 800px. (gif, jpeg, jpg, png) only</span>
              <input type="file" name="pic[]"> 
            </div>
        </div>
                                
                                  <div class="form-row">
          <div class="form-label col-md-3">
            <label for=""> Upload social media image:<span class="required">*</span></label>
          </div>
          <div class="float-left col-md-9"> <span class="btn medium bg-green fileinput-button"> <span class="button-content">Max 500kb. Dimension: 1200px x 550px. (gif, jpeg, jpg, png) only</span>
              <input type="file" name="pic[]">
             </div>
        </div>
									  
									  <div class="form-row">
          <div class="form-label col-md-3">
            <label for=""> Packing image:<span class="required">*</span></label>
          </div>
          <div class="float-left col-md-9"> <span class="btn medium bg-green fileinput-button"> <span class="button-content">Max 500kb. Dimension: 1200px x 550px. (gif, jpeg, jpg, png) only</span>
              <input type="file" name="pic[]">
             </div>
        </div>
									  
									  
                                      
	                 <div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        Description: <span class="required">*</span>
                    </label>
                </div>
           <div class="form-input col-md-9">
                <textarea id="description" name="description" rows="10" data-trigger="change" class="parsley-validated" data-required="true"></textarea>
              </div>
            </div>
                                             <div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        Google Description: <span class="required">*</span>
                    </label>
                </div>
           <div class="form-input col-md-9">
                <textarea id="google_description" name="google_description" rows="10" data-trigger="change" class="parsley-validated" data-required="true"></textarea>
              </div>
            </div>
                                          
                        
                         <div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        How to Use: <span class="required">*</span>
                    </label>
                </div>
           <div class="form-input col-md-9">
                <textarea id="description" name="details" rows="10" data-trigger="change" class="parsley-validated" data-required="true"></textarea>
                
              </div>
            </div>
                                
                                 <div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        Disclaimer: <span class="required">*</span>
                    </label>
                </div>
           <div class="form-input col-md-9">
                <textarea id="description" name="disclaimer" rows="10" data-trigger="change" class="parsley-validated" data-required="true"></textarea>
                
              </div>
            </div>
     <div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        Search tags: <span class="required">comma separated</span>
                    </label>
                </div>
           <div class="form-input col-md-9">
                <textarea id="tags" name="tags" rows="2" data-trigger="change" class="parsley-validated"></textarea>
              </div>
            </div>
            
              <div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        SEO Title:
                    </label>
                </div>
           <div class="form-input col-md-9">
                <textarea id="description" name="seo_title" rows="1" data-trigger="change" class="parsley-validated" data-maxlength="70"></textarea>
                <div class="character-remaining clear input-description font-gray">70 chars only</div>
              </div>
            </div>
            
            <div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        META description:
                    </label>
                </div>
           <div class="form-input col-md-9">
                <textarea id="description" name="meta_description" rows="2" data-trigger="change" class="parsley-validated" data-maxlength="180"></textarea>
                <div class="character-remaining clear input-description font-red">180 chars only</div>
              </div>
            </div>
  
            <div class="form-row">
                <div class="form-label col-md-3">
                    <label for="">
                        META Keywords <span class="required">comma separated</span>:
                    </label>
                </div>
           <div class="form-input col-md-9">
                <textarea id="description" name="meta_keywords" rows="2" data-trigger="change" class="parsley-validated" data-maxlength="500"></textarea>
                <div class="character-remaining clear input-description font-red">500 chars only</div>
              </div>
            </div>
            <div class="divider"></div>
            <div class="form-row">
                <input type="hidden" name="superhidden" id="superhidden">
                <div class="form-input col-md-10 col-md-offset-3">
               <button type="submit" name="submit"  class="btn large primary-bg" onclick="javascript:$(&apos;#demo-form-2&apos;).parsley( &apos;validate&apos; );"><span class="button-content">Save Data</span></button>
&nbsp;
                        <a href="#" class="btn large bg-red" title="" onclick="goBack()">
            <span class="button-content">Cancel</span>
        </a>

                </div>
            </div>

        </form>

    </div>
    
</div>
</div>
<!-- #page-content -->
</div>
<!-- #page-main -->
</div>
<!-- #page-wrapper -->

</body>
</html>

<?php
include "db/db_connect.php"; 
include "db/session.php";  
include "function/function.php";  

////////////////////////update/////////////////////////
if(isset($_POST['submit']))
{
extract($_POST);	
$id = secure_input($con,$id);
$pname = secure_input($con,$pname);
$cname = secure_input($con,$cname);
$ebanner1 = secure_input($con,$ebanner1);	
$ebanner2 = secure_input($con,$ebanner2);	
$ebanner3 = secure_input($con,$ebanner3);		
	if(isset($_POST['ftype'])&&$_POST['ftype']!="")
	{
		$ftype = secure_input($con,$ftype);
	}
	else
	{
		$ftype = secure_input($con,$eftype);
	}
$price = secure_input($con,$price);	
$description = secure_input($con,$description);	
	
///////////////////////////////primage//////////////////////////
$allowedExts = array("gif", "jpeg", "jpg", "png"); 
if(empty($_FILES['pic1']['name'])) 
{	

	$pic1 = $ebanner1;
}
elseif(($_FILES['pic1']['error']==0))
{	
$exten = explode(".", $_FILES["pic1"]["name"]);
$extension = end($exten);
if ((($_FILES["pic1"]["type"] == "image/gif") 
|| ($_FILES["pic1"]["type"] == "image/jpeg") 
|| ($_FILES["pic1"]["type"] == "image/jpg") 
|| ($_FILES["pic1"]["type"] == "image/pjpeg") 
|| ($_FILES["pic1"]["type"] == "image/x-png")  
|| ($_FILES["pic1"]["type"] == "image/png")) 
&& in_array($extension, $allowedExts))
{
	if($_FILES["pic1"]["size"] < 1000000)
	  {
		$filename = $_FILES["pic1"]["name"];
		 //$newfilename = uniqid('vgp', true) .'.'.$extension;
		$newfilename = 'VGP-'.$filename;
		 if(!move_uploaded_file($_FILES["pic1"]["tmp_name"],"../products/" . $newfilename))
		 {
			echo 'Your file was not uploaded please try again!'.print_r($_FILES); 
		 }
		$pic1 = "products/" .$newfilename;	  					    
	  }
	  else
		  {
		  echo "File size must be less than 2MB. please try again!".print_r($_FILES);
		  }

}
else
  {
  echo "Invalid file selected! please try again!".print_r($_FILES);
  }
  
}


///////////////////////////////MSDS//////////////////////////
$allowedExts = array("gif", "jpeg", "jpg", "png", "pdf"); 
if(empty($_FILES['pic2']['name'])) 
{	
$pic2 = $ebanner2;
}
elseif(($_FILES['pic2']['error']==0))
{	
$exten = explode(".", $_FILES["pic2"]["name"]);
$extension = end($exten);
if ((($_FILES["pic2"]["type"] == "image/gif")
|| ($_FILES["pic2"]["type"] == "image/jpeg")
|| ($_FILES["pic2"]["type"] == "image/jpg")
|| ($_FILES["pic2"]["type"] == "image/pjpeg")
|| ($_FILES["pic2"]["type"] == "image/x-png")
|| ($_FILES["pic2"]["type"] == "application/pdf")
|| ($_FILES["pic2"]["type"] == "image/png"))              
&& in_array($extension, $allowedExts))
  {
	if($_FILES["pic2"]["size"] < 1000000)
	  {
		$filename = $_FILES["pic2"]["name"];
   		 $newfilename = 'VGP-'.$filename;
			if(!move_uploaded_file($_FILES["pic2"]["tmp_name"],"../products/" . $newfilename))
			{
				echo 'Your file was not uploaded please try again!'.print_r($_FILES); 
			}
   		  $pic2 = "products/" .$newfilename;	  					      					    
	  }
	  else
		  {
		  echo "File size must be less than 3MB. please try again!";
		  }  
	  
  }
  
else
  {
  echo "Invalid file selected! please try again!".print_r($_FILES);
  }
}


///////////////////////////////tech//////////////////////////
$allowedExts = array("gif", "jpeg", "jpg", "png", "pdf"); 
if(empty($_FILES['pic3']['name'])) 
{	

$pic3 = $ebanner3;
}
elseif(($_FILES['pic3']['error']==0))
{	
$exten = explode(".", $_FILES["pic3"]["name"]);
$extension = end($exten);
if ((($_FILES["pic3"]["type"] == "image/gif")
|| ($_FILES["pic3"]["type"] == "image/jpeg")
|| ($_FILES["pic3"]["type"] == "image/jpg")
|| ($_FILES["pic3"]["type"] == "image/pjpeg")
|| ($_FILES["pic3"]["type"] == "image/x-png")
|| ($_FILES["pic3"]["type"] == "application/pdf")
|| ($_FILES["pic3"]["type"] == "image/png"))              
&& in_array($extension, $allowedExts))
  {

	if($_FILES["pic3"]["size"] < 1000000)
	  {
		$filename = $_FILES["pic3"]["name"];
   	 $newfilename = 'VGP-'.$filename;
		 if(!move_uploaded_file($_FILES["pic3"]["tmp_name"],"../products/" . $newfilename))
		 {
			 echo 'Your file was not uploaded please try again!'.print_r($_FILES); 
		 }
     $pic3 = "products/" .$newfilename;	 			      					    
	  }
	  else
	  {
	  echo "File size must be less than 3MB. please try again!";
	  }  

  }
else
  {
  echo "Invalid file selected! please try again!".print_r($_FILES);
  }
}

///////////////////////////////////////////////////////////////////////////////	


$uquery = "UPDATE vgp_products SET name=?, price = ?, description=?, ftype=?, pic1 = ?, pic2 = ?, pic3 = ? WHERE id=?";

if(!$ustmt = $con->prepare($uquery))
{
	echo "prepare failed: (" . $con->errno . ") " . $con->error;
}

if(!$ustmt->bind_param("sisssssi", $pname, $price, $description, $ftype, $pic1, $pic2, $pic3, $id))
{
	echo "Param pass failed: (" . $con->errno . ") " . $con->error;
}

if($ustmt->execute()) {
	$success= "product data updated successfully!";
	$_GET['id'] = $id;
	$_GET['cname'] = $cname;
}
else
{
	$error = "product data update failed!".$stmt->error;
}
 $ustmt->close();
}

///////////////////////////////////////////////////////////////////////////////
if(isset($_GET['id'])&&$_GET['id']!="")
{ 
extract($_GET); 
$id = secure_input($con,$id);
$cname = secure_input($con,$cname);	
	
$query = "SELECT * FROM vgp_products WHERE id =?";

if($stmt = $con->prepare($query))
{

	if(!$stmt->bind_param('i',$id))
	{
		$error = "Product data listing execution failed!".$con->error;		
	}
	
	
	if(!$stmt->execute())
	{
		$error = "Product data listing execution failed!".$con->error;		
		
	}
		if(!$qresult = $stmt->get_result())
		{
			$error = "Product data listing failed!".$con->error;					
		}
	
}
else
{
	$error = "Product data listing preparation failed!".$con->error;
}

	$data = $qresult->fetch_assoc();

}

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title><?php echo $_SESSION['cName']; ?> Admin Area</title>
<meta name="description" content="">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

<!-- Favicons -->

<link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/images/icons/apple-touch-icon-144-precomposed.png">
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/images/icons/apple-touch-icon-114-precomposed.png">
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/images/icons/apple-touch-icon-72-precomposed.png">
<link rel="apple-touch-icon-precomposed" href="assets/images/icons/apple-touch-icon-57-precomposed.png">
<link rel="shortcut icon" href="assets/images/icons/favicon.png">
<script src="editor/ckeditor/ckeditor.js"></script>
<!--[if lt IE 9]>
          <script src="assets/js/minified/core/html5shiv.min.js"></script>
          <script src="assets/js/minified/core/respond.min.js"></script>
        <![endif]-->

<!-- Fides Admin CSS Core -->

<link rel="stylesheet" type="text/css" href="assets/css/minified/aui-production.min.css">

<!-- Theme UI -->

<link id="layout-theme" rel="stylesheet" type="text/css" href="assets/themes/minified/fides/color-schemes/dark-blue.min.css">

<!-- Fides Admin Responsive -->

<link rel="stylesheet" type="text/css" href="assets/themes/minified/fides/common.min.css">
<!-- <link rel="stylesheet" type="text/css" href="../_assets/themes/fides/common.css"> -->

<link id="theme-animations" rel="stylesheet" type="text/css" href="assets/themes/minified/fides/animations.min.css">
<link rel="stylesheet" type="text/css" href="assets/themes/minified/fides/responsive.min.css">

<!-- Fides Admin JS -->

<script type="text/javascript" src="assets/js/minified/aui-production.min.js"></script>
<script type="text/javascript" src="assets/js/minified/core/raphael.min.js"></script>
<script type="text/javascript" src="assets/js/minified/widgets/charts-justgage.min.js"></script>
</head>
<body>
<div id="loading" class="ui-front loader ui-widget-overlay bg-white opacity-100"> <img src="assets/images/loader-dark.gif" alt=""> </div>
<div id="page-wrapper" class="demo-example"> 
  <!-- #page-header -->
  
  <?php include("sidebar.php"); ?>
  <!-- #page-sidebar -->
  <div id="menu-right" class="scrollable-content hidden">
    <div class="toggle-content-open clearfix">
      <div id="g10" class="small-gauge float-left"></div>
      <div id="g11" class="small-gauge float-right"></div>
    </div>
  </div>
  <div id="page-content-wrapper">
            
                <div id="page-title">

<h3>
  Edit/View product: <?php echo "<strong>".$data['name']."</strong>"; ?>
</h3>
</div><!-- #page-title -->

            
<div id="page-content">
<h3><strong>Product details:</strong></h3>
<div class="example-box">
<?php 
			   if(isset($error)){ ?>
             
             <div class="infobox error-bg">
<a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>             
<div class="bg-red large btn info-icon">
                        <i class="glyph-icon icon-remove"></i>
                    </div>
                    <h4 class="infobox-title"><?php echo $error;?></h4>
                    <p>Some error in the database query occured. Please try again!</p>
                </div>
            </div><?php } ?>
            
<?php 
			   if(isset($success)){ ?>
             
             <div class="infobox success-bg">
<a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>             
                    <h4 class="infobox-title"><?php echo $success;?></h4>
                </div>
            </div><?php } ?>
    <div class="example-code">
<br>
<br>

        <form id="demo-form-2" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" class="col-md-10 center-margin" method="post" enctype="multipart/form-data">
            <div class="form-row">
                <div class="form-label col-md-2">
                    <label for="">
                        Data created on:                        
                    </label>
                </div>
                <div class="form-input col-md-10">
                    <?php 
if($data['cdate']!=NULL)
{
	echo date("F jS\, Y h:i:s A",strtotime($data['cdate']));
}
?>
</p>
                </div>
            </div>
                        <div class="form-row">
                <div class="form-label col-md-2">
                    <label for="">
                        Data last updated on:                        
                    </label>
                </div>
                <div class="form-input col-md-10">
                    <?php 
if($data['udate']!=NULL)
{
	echo date("F jS\, Y h:i:s A",strtotime($data['udate']));
}
else
{
	echo "-";
}
?>
</p>
                </div>
            </div>
	
	 <div class="form-row">
                <div class="form-label col-md-2">
                    <label for="">
                        Category:                        
                    </label>
                </div>
                <div class="form-input col-md-10">
                <?php echo $cname; ?>
</p>
                </div>
            </div>
           
           	<div class="form-row">
                <div class="form-label col-md-2">
                    <label for="">
                       Product Name:
                         <span class="required">*</span>
                    </label>
                </div>
                <div class="form-input col-md-10">
                    <input  type="text" id="name" name="pname" value="<?php echo $data['name']; ?>" data-trigger="change" parsley-rangelength="[2,99]" data-required="true" data-pattern="^[A-Za-z ]*$" class="parsley-validated">
                </div>
            </div>
	
	  	<div class="form-row">
                <div class="form-label col-md-2">
                    <label for="">
                       Current Frame Type:
                         <span class="required">*</span>
                    </label>
                </div>
                <div class="form-input col-md-10">
                   <?php echo $data['ftype']; ?>
                </div>
            </div>
	
	<div class="form-row">
              <div class="form-label col-md-2">
                <label for=""> Frame type:</label>
              </div>
              <div class="form-input col-md-10">
                <select data-placeholder="Select a category..." name="ftype" class="chosen-select parsley-validated" data-trigger="change">
      
     
                 <option value="">Select a type</option>	
                     <option value="Framed">Framed</option>	
					  <option value="Unframed">Unframed</option>	
        
                </select>
              </div>
              
            </div>
	
			<div class="form-row">
          <div class="form-label col-md-2">
            <label for=""> Existing image 1:</label>
          </div>
          <div class="float-left col-md-10"><?php if($data['pic1']!=NULL||$data['pic1']!="") { ?><a href="../<?php echo $data['pic1']; ?>" target="_blank"><img src="../<?php echo $data['pic1']; ?>" width="30%"></a><?php } else echo "Not available"; ?></div>
        </div>
	<div class="form-row">
          <div class="form-label col-md-2">
            <label for=""> Upload New Product image 1:</label>
          </div>
          <div class="float-left col-md-10"> <span class="btn medium bg-green fileinput-button"> <span class="button-content">Max 1MB. Dimension: 1170px x 517px. (gif, jpeg, jpg, png) only
              <input type="file" name="pic1">
            </span> </div>
        </div>
			
   
					<div class="form-row">
          <div class="form-label col-md-2">
            <label for=""> Existing image 2:</label>
          </div>
          <div class="float-left col-md-10"><?php if($data['pic2']!=NULL||$data['pic2']!="") { ?><a href="../<?php echo $data['pic2']; ?>" target="_blank"><img src="../<?php echo $data['pic2']; ?>" width="30%"></a><?php } else echo "Not available"; ?></div>
        </div>
	<div class="form-row">
          <div class="form-label col-md-2">
            <label for=""> Upload New Product image 2:</label>
          </div>
          <div class="float-left col-md-10"> <span class="btn medium bg-green fileinput-button"> <span class="button-content">Max 1MB. Dimension: 1170px x 517px. (gif, jpeg, jpg, png) only
              <input type="file" name="pic2">
            </span> </div>
        </div>
			
   
					<div class="form-row">
          <div class="form-label col-md-2">
            <label for=""> Existing image 3:</label>
          </div>
          <div class="float-left col-md-10"><?php if($data['pic3']!=NULL||$data['pic3']!="") { ?><a href="../<?php echo $data['pic3']; ?>" target="_blank"><img src="../<?php echo $data['pic3']; ?>" width="30%"></a><?php } else echo "Not available"; ?></div>
        </div>
	<div class="form-row">
          <div class="form-label col-md-2">
            <label for=""> Upload New Product image 3:</label>
          </div>
          <div class="float-left col-md-10"> <span class="btn medium bg-green fileinput-button"> <span class="button-content">Max 1MB. Dimension: 1170px x 517px. (gif, jpeg, jpg, png) only
              <input type="file" name="pic3">
            </span> </div>
        </div>
	
			<div class="form-row">
                <div class="form-label col-md-2">
                    <label for="">
                       Price:(NZD)
                         <span class="required">*</span>
                    </label>
                </div>
                <div class="form-input col-md-10">
                    <input  type="text" id="name" name="price" data-type="number" data-trigger="change" value="<?php echo $data['price']; ?>" parsley-rangelength="[1,25]" data-required="true" class="parsley-validated">
                </div>
            </div>
                 <div class="form-row">
                <div class="form-label col-md-2">
                    <label for="">
                        Description: <span class="required">*</span>
                    </label>
                </div>
           <div class="form-input col-md-10">
                <textarea id="description" name="description" rows="10" data-trigger="change" class="parsley-validated" data-required="true" data-maxlength="3000"><?php echo $data['description']; ?></textarea>
                <div class="character-remaining clear input-description font-red">3000 chars only</div>
              </div>
            </div>
            <div class="divider"></div>
            <div class="form-row">
                <input type="hidden" name="superhidden" id="superhidden">
				<input type="hidden" name="id" id="id" value="<?php echo $data['id']; ?>"> 
				<input type="hidden" name="eftype" id="eftype" value="<?php echo $data['ftype']; ?>">
				<input type="hidden" name="cname" id="id" value="<?php echo $cname; ?>">
				
				<input type="hidden" name="ebanner1" id="id" value="<?php echo $data['pic1']; ?>"> 
				<input type="hidden" name="ebanner2" id="id" value="<?php echo $data['pic2']; ?>"> 
				<input type="hidden" name="ebanner3" id="id" value="<?php echo $data['pic3']; ?>"> 
				<div class="form-input col-md-10 col-md-offset-2">
            <button type="submit" name="submit"  class="btn large primary-bg" onclick="javascript:$(&apos;#demo-form-2&apos;).parsley( &apos;validate&apos; );"><span class="button-content">Save Data</span></button>
&nbsp;
                        <a href="#" class="btn large bg-red" title="" onclick="goBack()">
            <span class="button-content">Cancel</span>
        </a>
                </div>
            </div>

        </form>

    </div>
    
</div>
</div>
<!-- #page-content -->
</div>
<!-- #page-main -->
</div>
<!-- #page-wrapper -->

</body>
</html>

<?php
include "../db/session.php";
include "../function/config.php";
include "../db/db_connect.php";
include "../function/function.php";
include "../function/image_resize.php";
//////////////////////status_update/////////////////////////////////////////////////////////////////////
if (isset($_GET['id']) && $_GET['id'] != '' && isset($_GET['action']) && $_GET['action'] == 'status') {
  extract($_GET);
  $sc_id = secure_input($con, $sc_id);
  $sc_name = secure_input($con, $sc_name);
  $id = secure_input($con, $id);
  $active = secure_input($con, $active);
  $squery = "UPDATE bb_products_stock SET active = ? WHERE id = ?";

  if (!$sstmt = $con->prepare($squery)) {
    $error = "product data listing execution failed!" . $con->error;
    header("location:list_all_products.php?sc_id=" . $sc_id . "&sc_name=" . $sc_name . "&error=" . $error);
    exit();
  }

  if (!$sstmt->bind_param('ii', $active, $id)) {
    $error = "product status update execution failed!" . $con->error;
    header("location:list_all_products.php?sc_id=" . $sc_id . "&sc_name=" . $sc_name . "&error=" . $error);
    exit();
  }

  if (!$sstmt->execute()) {
    $error = "product status update failed!" . $con->error;
    header("location:list_all_products.php?sc_id=" . $sc_id . "&sc_name=" . $sc_name . "&error=" . $error);
    exit();
  } else {
    $success = "product status updated successfully!";
    header("location:list_all_products.php?sc_id=" . $sc_id . "&sc_name=" . $sc_name . "&success=" . $success);
    exit();
  }
}
//////////////////////delete////////////////////////
if (isset($_GET['id']) && $_GET['id'] != '' && isset($_GET['action']) && $_GET['action'] == 'delete') {
  extract($_GET);
  $sc_id = secure_input($con, $sc_id);
  $sc_name = secure_input($con, $sc_name);
  $id = secure_input($con, $id);
  $query = "DELETE FROM bb_products_stock WHERE id = ?";

  if (!$stmt = $con->prepare($query)) {
    $error = "product data listing execution failed!" . $con->error;
    header("location:list_all_products.php?sc_id=" . $sc_id . "&sc_name=" . $sc_name . "&error=" . $error);
    exit();
  }

  $stmt->bind_param('i', $id);

  if (!$stmt->execute()) {
    $error = "product data deletion execution failed!" . $con->error;
    header("location:list_all_products.php?sc_id=" . $sc_id . "&sc_name=" . $sc_name . "&error=" . $error);
    exit();
  } else {
    $success = "product deleted successfully!";
    header("location:list_all_products.php?sc_id=" . $sc_id . "&sc_name=" . $sc_name . "&success=" . $success);
    exit();
  }
}
////////////////////////////////edit_parent////////////////////////
if (isset($_POST['submit_edit'])) {
  extract($_POST);
  $sc_id = secure_input($con, $sc_id);
  $sc_name = secure_input($con, $sc_name);
  $id = secure_input($con, $parent_id);
  $pname = secure_input($con, $pname);
  $HSC = secure_input($con, $HSC_code);
  $description = secure_input($con, $description);
  $google_description = secure_input($con, $google_description);
  $details = secure_input($con, $details);
  $disclaimer = secure_input($con, $disclaimer);
  $tags = secure_input($con, $tags);
  $title = secure_input($con, $seo_title);
  $meta = secure_input($con, $meta_description);
  $keywords = secure_input($con, $meta_keywords);


  $edquery = "UPDATE bb_products SET name = ?, hsc_code = ?, details = ?, description = ?, g_description = ?, disclaimer = ?, seo_title = ?, seo_keyword = ?, seo_meta = ?, tags = ? WHERE id = ?";

  if (!$edstmt = $con->prepare($edquery)) {
    $error = "Product data update preparation failed!" . $con->error;
    header("location:list_all_products.php?sc_id=" . $sc_id . "&sc_name=" . $sc_name . "&error=" . $error);
    exit();
  }
  if (!$edstmt->bind_param('ssssssssssi', $pname, $HSC, $details, $description, $google_description, $disclaimer, $title, $keywords, $meta, $tags, $id)) {
    $error = "Product data update preparation failed!" . $con->error;
    header("location:list_all_products.php?sc_id=" . $sc_id . "&sc_name=" . $sc_name . "&error=" . $error);
    exit();
  }

  if (!$edstmt->execute()) {
    $error = "Parent product data update execution failed!" . $con->error;
    header("location:list_all_products.php?sc_id=" . $sc_id . "&sc_name=" . $sc_name . "&error=" . $error);
    exit();
  } else {
    $success = "Parent product data updated successfully!";
    header("location:list_all_products.php?sc_id=" . $sc_id . "&sc_name=" . $sc_name . "&success=" . $success);
    exit();
  }
}
////////////////////////////////edit_child////////////////////////
if (isset($_POST['submit_child_edit'])) {
  extract($_POST);

  $sc_id = secure_input($con, $sc_id);
  $sc_name = secure_input($con, $sc_name);
  $parent_id = secure_input($con, $parent_id);
  $id = secure_input($con, $id);
  $e_size = secure_input($con, $e_size);
  $e_featured = secure_input($con, $e_featured);
  $e_bselling = secure_input($con, $e_bselling);

  $id = secure_input($con, $id);
  $SKU = secure_input($con, $SKU);
  $MRP = secure_input($con, $MRP);
  if (isset($_POST['price']) && $_POST['price'] != "" && $_POST['price'] != 0) {
    $price = secure_input($con, $price);
  } else {
    $price = $MRP;
  }
  $qty = secure_input($con, $stock);

  if (isset($_POST['size']) && $_POST['size'] != "") {
    $size = secure_input($con, $size);
  } else {
    $size = secure_input($con, $e_size);
  }

  if (isset($_POST['ftype']) && $_POST['ftype'] != "") {
    $featured = secure_input($con, $_POST['ftype']);
  } else {
    $featured = secure_input($con, $e_featured);
  }

  if (isset($_POST['bselling']) && $_POST['bselling'] != "") {
    $bselling = secure_input($con, $_POST['bselling']);
  } else {
    $bselling = secure_input($con, $e_bselling);
  }


  /////////////////////////////Image upload///////////////////////////////////////////////////////////
  $pimage = array();
  for ($i = 0; $i < 7; $i++) {
    if (($_FILES['pic']['error'][$i] == 0)) {
      if (($_FILES["pic"]["size"][$i] < 1000000)) {
        $file_tmp_name = $_FILES["pic"]["tmp_name"][$i];
        $path = "../uploads/products/";
        $image_path = "uploads/products/";
        $error_path = "add_new_product.php";
        $exten = explode(".", $_FILES["pic"]["name"][$i]);
        $old_name = $exten[0];
        $new_name = 1;
        echo "<br> " . $pimage[] = upload_image($file_tmp_name, $old_name, $path, $image_path, $error_path, $new_name);
      } else {
        $error = "Invalid file size!";
        header("location:add_new_product.php?error=" . $error);
        exit();
      }
    } else {
      $pimage[] = $e_pic[$i];
    }
  }
  if ($pimage[6] == '') {
    $pimage[6] = 'uploads/products/senseme_packing.jpg';
  }
  ///////////////////////////////////////////////////////////////////////////////////////////////////////        

  //////////////// PRODUCT INFORMATION ////////////////////

  $whats_app_show = secure_input($con, $_POST['whats_app_show']);
  $benefits_title = secure_input($con, $_POST['benefits_title']);
  $smell_title = secure_input($con, $_POST['smell_title']);
  $smell_description = secure_input($con, $_POST['smell_description']);

  $fragrance_title = secure_input($con, $_POST['fragrance_title']);
  $fragrance_heading = secure_input($con, $_POST['fragrance_heading']);
  $fragrance_description = secure_input($con, $_POST['fragrance_description']);


  // ==========================
  // ICON UPLOAD FUNCTION
  // ==========================
  function uploadSingleImage($fileName, $existing = '')
  {
    global $con;

    $path = "../uploads/product_icons/";
    $image_path = "uploads/product_icons/";

    if (!file_exists($path)) {
      mkdir($path, 0777, true);
    }

    if (
      isset($_FILES[$fileName]) &&
      $_FILES[$fileName]['error'] == 0
    ) {

      $file_tmp =
        $_FILES[$fileName]['tmp_name'];

      $ext =
        pathinfo(
          $_FILES[$fileName]['name'],
          PATHINFO_EXTENSION
        );

      $new_name =
        time() .
        rand(1111, 9999) .
        "." . $ext;

      move_uploaded_file(
        $file_tmp,
        $path . $new_name
      );

      return $image_path . $new_name;
    }

    return $existing;
  }



  // ==========================
  // TOP ICONS
  // ==========================
  $benefits_icon =
    uploadSingleImage(
      'benefits_icon'
    );

  $smell_icon =
    uploadSingleImage(
      'smell_icon'
    );

  $fragrance_icon =
    uploadSingleImage(
      'fragrance_icon'
    );



  // ==========================
  // BENEFITS ARRAY
  // ==========================
  $benefits = [];

  if (
    isset($_POST['benefits'])
  ) {

    foreach (
      $_POST['benefits']
      as $value
    ) {

      if (
        trim($value) != ''
      ) {

        $benefits[] =
          secure_input(
            $con,
            $value
          );
      }
    }
  }

  $benefits_json =
    json_encode($benefits);



  // ==========================
  // BEST FOR
  // ==========================
  // $best_for = [];

  // if (isset($_POST['best_for_title'])) {
  //   foreach ($_POST['best_for_title'] as $key => $title) {
  //     if (trim($title) == '') continue;
  //     $icon = '';
  //     if (isset($_FILES['best_for_icon']['name'][$key]) && $_FILES['best_for_icon']['error'][$key] == 0) {
  //       $tmp = $_FILES['best_for_icon']['tmp_name'][$key];
  //       $ext = pathinfo($_FILES['best_for_icon']['name'][$key], PATHINFO_EXTENSION);
  //       $name = time() . rand(1111, 9999) . "." . $ext;
  //       move_uploaded_file($tmp, "../uploads/product_icons/" . $name);
  //       $icon = "uploads/product_icons/" . $name;
  //     }
  //     $best_for[] = [
  //       'title' => secure_input($con, $title),
  //       'icon' => $icon
  //     ];
  //   }
  // }
  $best_for = [];

  if (isset($_POST['best_for_title'])) {

    foreach ($_POST['best_for_title'] as $key => $title) {

      if (trim($title) == '') continue;

      // Keep old image by default
      $icon = $_POST['old_best_for_icon'][$key] ?? '';

      // Replace with new image if uploaded
      if (
        isset($_FILES['best_for_icon']['name'][$key]) &&
        $_FILES['best_for_icon']['error'][$key] == 0
      ) {
        $tmp = $_FILES['best_for_icon']['tmp_name'][$key];
        $ext = pathinfo($_FILES['best_for_icon']['name'][$key], PATHINFO_EXTENSION);
        $name = time() . rand(1111, 9999) . "." . $ext;

        move_uploaded_file($tmp, "../uploads/product_icons/" . $name);

        $icon = "uploads/product_icons/" . $name;
      }

      $best_for[] = [
        'title' => secure_input($con, $title),
        'icon'  => $icon
      ];
    }
  }

  $best_for_json = json_encode($best_for);
  // ==========================
  // COMPATIBLE
  // ==========================
  // $compatible = [];

  // if (
  //   isset(
  //     $_POST['compatible_title']
  //   )
  // ) {

  //   foreach (
  //     $_POST['compatible_title']
  //     as $key => $title
  //   ) {

  //     if (
  //       trim($title) == ''
  //     ) continue;

  //     $icon = '';

  //     if (
  //       isset(
  //         $_FILES['compatible_icon']['name'][$key]
  //       )
  //       &&
  //       $_FILES['compatible_icon']['error'][$key] == 0
  //     ) {

  //       $tmp =
  //         $_FILES['compatible_icon']['tmp_name'][$key];

  //       $ext =
  //         pathinfo(
  //           $_FILES['compatible_icon']['name'][$key],
  //           PATHINFO_EXTENSION
  //         );

  //       $name =
  //         time() .
  //         rand(1111, 9999)
  //         . "." . $ext;

  //       move_uploaded_file(
  //         $tmp,
  //         "../uploads/product_icons/"
  //           . $name
  //       );

  //       $icon =
  //         "uploads/product_icons/"
  //         . $name;
  //     }

  //     $compatible[] = [

  //       'title' =>
  //       secure_input(
  //         $con,
  //         $title
  //       ),

  //       'icon' =>
  //       $icon
  //     ];
  //   }
  // }

  // $compatible_json =
  //   json_encode(
  //     $compatible
  //   );


$compatible = [];

if (isset($_POST['compatible_title'])) {

    foreach ($_POST['compatible_title'] as $key => $title) {

        if (trim($title) == '') {
            continue;
        }

        // Keep old image if available
        $icon = $_POST['old_compatible_icon'][$key] ?? '';

        // Upload new image if selected
        if (
            isset($_FILES['compatible_icon']['name'][$key]) &&
            $_FILES['compatible_icon']['error'][$key] == 0
        ) {

            $tmp = $_FILES['compatible_icon']['tmp_name'][$key];

            $ext = pathinfo(
                $_FILES['compatible_icon']['name'][$key],
                PATHINFO_EXTENSION
            );

            $name = time() . rand(1111, 9999) . '.' . $ext;

            move_uploaded_file(
                $tmp,
                "../uploads/product_icons/" . $name
            );

            $icon = "uploads/product_icons/" . $name;
        }

        $compatible[] = [
            'title' => secure_input($con, $title),
            'icon'  => $icon
        ];
    }
}

$compatible_json = json_encode($compatible);

  // ==========================
  // FAQ
  // ==========================
  $faq = [];

  if (
    isset(
      $_POST['faq_question']
    )
  ) {

    foreach (
      $_POST['faq_question']
      as $key => $question
    ) {

      if (
        trim(
          $question
        ) == ''
      ) continue;

      $faq[] = [

        'question' =>
        secure_input(
          $con,
          $question
        ),

        'answer' =>
        secure_input(
          $con,
          $_POST['faq_answer'][$key]
        )
      ];
    }
  }

  $faq_json =
    json_encode(
      $faq
    );

  // $edquery = "UPDATE bb_products_stock SET sku = ?, size = ?, mrp = ?, price = ?, qty = ?, pic1 = ?, pic2 = ?, pic3 = ?, pic4 = ?, pic5 = ?, pic6 = ?, pic7 = ?, featured = ?, bestselling = ? WHERE id = ?";
  $edquery = "UPDATE bb_products_stock SET

sku = ?,
size = ?,
mrp = ?,
price = ?,
qty = ?,
pic1 = ?,
pic2 = ?,
pic3 = ?,
pic4 = ?,
pic5 = ?,
pic6 = ?,
pic7 = ?,

featured = ?,
bestselling = ?,
whats_app_show = ?,
benefits_title = ?,
benefits_icon = ?,
benefits_points = ?,

smell_title = ?,
smell_icon = ?,
smell_description = ?,

best_for = ?,

fragrance_title = ?,
fragrance_icon = ?,
fragrance_heading = ?,
fragrance_description = ?,

compatible_with = ?,
faq_data = ?

WHERE id = ?";
  if (!$edstmt = $con->prepare($edquery)) {
    echo $error = "Product data update preparation failed!" . $con->error;
    exit();
  }
  // if (!$edstmt->bind_param('ssiiisssssssssi', $SKU, $size, $MRP, $price, $qty, $pimage[0], $pimage[1], $pimage[2], $pimage[3], $pimage[4], $pimage[5], $pimage[6], $featured, $bselling, $id)) {
  //   echo $error = "Product data update preparation failed!" . $con->error;
  //   exit();
  // }
  $edstmt->bind_param(

    "ssiiissssssssissssssssssssssi",

    $SKU,
    $size,
    $MRP,
    $price,
    $qty,

    $pimage[0],
    $pimage[1],
    $pimage[2],
    $pimage[3],
    $pimage[4],
    $pimage[5],
    $pimage[6],

    $featured,
    $bselling,
    $whats_app_show,
    $benefits_title,
    $benefits_icon,
    $benefits_json,

    $smell_title,
    $smell_icon,
    $smell_description,

    $best_for_json,

    $fragrance_title,
    $fragrance_icon,
    $fragrance_heading,
    $fragrance_description,

    $compatible_json,
    $faq_json,

    $id
  );
  if (!$edstmt->execute()) {
    $error = "Parent product data update execution failed!" . $con->error;
    header("location:list_all_products.php?sc_id=" . $sc_id . "&sc_name=" . $sc_name . "&error=" . $error);
    exit();
  } else {
    $success = "Parent product data updated successfully!";
    header("location:list_all_products.php?sc_id=" . $sc_id . "&sc_name=" . $sc_name . "&success=" . $success);
    exit();
  }
}

////////////////////////////////Add review//////////////////////////////////////////////
if (isset($_POST['submit_review'])) {
  extract($_POST);

  $sc_id = secure_input($con, $sc_id);
  $sc_name = secure_input($con, $sc_name);
  $cname = secure_input($con, $cname);
  $rr_parent_id = secure_input($con, $parent_id);
  $rdate = date('Y/m/d', strtotime($review_date));
  $title = secure_input($con, $review_title);
  $review = secure_input($con, $review);
  $recommend = secure_input($con, $recommend);
  $rating = secure_input($con, $rating);

  ////////////////////////////Image upload////////////////////////////
  $pimage = array();
  for ($i = 0; $i < 3; $i++) {
    if (($_FILES['pic']['error'][$i] == 0)) {
      if (($_FILES["pic"]["size"][$i] < 5000000)) {
        $file_tmp_name = $_FILES["pic"]["tmp_name"][$i];
        $path = "../uploads/tempimage/";
        $image_path = "uploads/tempimage/";
        $error_path = "list_all_products.php";
        $exten = explode(".", $_FILES["pic"]["name"][$i]);
        $old_name = $exten[0];
        $extension = end($exten);
        $new_name = 1;
        $file = upload_image($file_tmp_name, $old_name, $path, $image_path, $error_path, $new_name);
        /////////////////image resize/////////////////////////////    
        $width = 800;
        $height = 500;
        $file = "../" . $file;
        $exten2 = explode(".", $file);
        $extension2 = end($exten);
        $newfilename1 = uniqid('smreview_', true) . "." . $extension2;
        $resizedFile = "../uploads/reviews/" . $newfilename1;
        $db_image_path = "uploads/reviews/" . $newfilename1;
        if (!smart_resize_image($file, null, $width, $height, true, $resizedFile, true, false, 60)) {
          exit("error in resizing" . mysqli_error($con));
        }

        $pimage[] = $db_image_path;
        /////////////////////////////////////////////////////////////////////////////////    


      } else {
        $error = "Invalid file size!";
        header("location:list_all_products.php?error=" . $error);
        exit();
      }
    } else {
      $pimage[] = NULL;
    }
  }
  ///////////////////////////////////////////////////////////////////////////////////////////////////////


  if (!$w_stmt = $con->prepare("INSERT INTO smratings (parent_id, name, title, review, star, review_date, pic1, pic2, pic3, recommend) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")) {
    echo "Prepare failed: (" . $con->errno . ") " . $con->error;
  }

  if (!$w_stmt->bind_param("isssssssss", $rr_parent_id, $cname, $title, $review, $rating, $rdate, $pimage[0], $pimage[1], $pimage[2], $recommend)) {
    echo "Param pass failed: (" . $con->errno . ") " . $con->error;
  }

  if (!$w_stmt->execute()) {

    echo $error = "review update failed!" . $con->error;
    exit();
  } else {
    $r_success = "<strong>Product review added successfully!</strong>";
    header("location:list_all_products.php?sc_id=" . $sc_id . "&sc_name=" . $sc_name . "&success=" . $r_success);
  }
}
////////////////////////add child product/////////////////////////
if (isset($_POST['submit_add'])) {
  extract($_POST);
  $sc_id = secure_input($con, $sc_id);
  $sc_name = secure_input($con, $sc_name);
  $parent_id = secure_input($con, $parent_id);
  $SKU = secure_input($con, $SKU);
  $MRP = secure_input($con, $MRP);
  $price = secure_input($con, $price);
  $stock = secure_input($con, $stock);
  $ftype = secure_input($con, $ftype);
  $bselling = secure_input($con, $bselling);
  $size = secure_input($con, $size);


  /////////////////////////////Image upload////////////////////////////
  $pimage = array();
  for ($i = 0; $i < 6; $i++) {
    if (($_FILES['pic']['error'][$i] == 0)) {
      if (($_FILES["pic"]["size"][$i] < 1000000)) {
        $file_tmp_name = $_FILES["pic"]["tmp_name"][$i];
        $path = "../uploads/products/";
        $image_path = "uploads/products/";
        $error_path = "add_new_product.php";
        $exten = explode(".", $_FILES["pic"]["name"][$i]);
        $old_name = $exten[0];
        $new_name = 1;
        $pimage[] = upload_image($file_tmp_name, $old_name, $path, $image_path, $error_path, $new_name);
      } else {
        $error = "Invalid file size!";
        header("location:add_new_product.php?error=" . $error);
        exit();
      }
    } else {
      $pimage[] = NULL;
    }
  }
  ///////////////////////////////////////////////////////////////////////////////////////////////////////

  if (!$chstmt = $con->prepare("INSERT INTO bb_products_stock (sku, parent_id, size, mrp, price, qty, pic1, pic2, pic3, pic4, pic5, pic6, pic7, featured, bestselling) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")) {
    echo "Prepare failed: (" . $con->errno . ") " . $con->error;
    exit();
  }

  if (!$chstmt->bind_param("siiiiisssssssii", $SKU, $parent_id, $size, $MRP, $price, $stock, $pimage[0], $pimage[1], $pimage[2], $pimage[3], $pimage[4], $pimage[5], $pimage[6], $ftype, $bselling)) {
    echo "Param pass failed!: (" . $con->errno . ") " . $chstmt->error;
    exit();
  }

  if (!$chstmt->execute()) {

    $error = "New child product data saving failed!" . $con->error;
    header("location:list_all_products.php?sc_id=" . $sc_id . "&sc_name=" . $sc_name . "&error=" . $error);
    exit();
  } else {
    $success = "New child product saved successfully!";
    header("location:list_all_products.php?sc_id=" . $sc_id . "&sc_name=" . $sc_name . "&success=" . $success);
    exit();
  }
}
//////////////////////////size////////////////////////////////////////


$squery = "SELECT id, name FROM bb_sizes ORDER BY name ASC";

if (!$sstmt = $con->prepare($squery)) {
  echo "prepare failed: (" . $con->errno . ") " . $con->error;
  exit();
}


if (!$sstmt->execute()) {
  $error = "size list failed!" . $con->error;
  exit();
}

if (!$sstmt->store_result()) {
  $error = "categories list failed!" . $con->error;
  exit();
}

$snum_of_rows = $sstmt->num_rows;

if ($snum_of_rows == 0) {
  $serror = "No sizes found";
}

//////////////////////////////product listing//////////////////////////////////
if (isset($_GET['sc_id']) && $_GET['sc_id'] != '') {
  extract($_GET);
  $sc_id = secure_input($con, $sc_id);
  $sc_name = secure_input($con, $sc_name);



  $query = "SELECT t1.id, t1.mc_id, t1.sc_id, t1.name, t2.name FROM bb_products as t1 INNER JOIN bb_sub_categories as t2 ON t1.sc_id = t2.id WHERE t1.sc_id = ? ORDER BY t1.cdate DESC";

  if (!$stmt = $con->prepare($query)) {
    echo $error = "Product data listing preparation failed!" . $con->error;
    exit();
  }
  if (!$stmt->bind_param('i', $sc_id)) {
    echo $error = "Product data listing preparation failed!" . $con->error;
    exit();
  }

  if (!$stmt->execute()) {
    echo $error = "Product data listing execution failed!" . $con->error;
    exit();
  }
  if (!$stmt->store_result()) {
    echo $error = "Product data listing execution failed!" . $con->error;
    exit();
  }

  $num_of_rows = $stmt->num_rows;

  if ($num_of_rows == 0) {
    $error = "No parent products available";
  }
}


//////////////////////////////////////////////////////////////////////////////////////////////////


?>
<!DOCTYPE html>
<html>

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <title><?php echo $_SESSION['cName']; ?> Admin Area</title>
  <?php include("../header.php"); ?>
  <script type="text/javascript" src="<?php echo $_SESSION['gpath']; ?>assets/js/minified/widgets/charts-justgage.min.js"></script>

  <style>
    .dataTables_scrollBody {
      height: 500px !important;

    }
  </style>


  <style type="text/css">
    .gray_star {
      color: #D8D8D8;
    }

    .rating {
      overflow: hidden;
      display: inline-block;
      font-size: 0;
      position: relative;
    }

    .rating-input {
      float: left;
      width: 16px !important;
      height: 16px;
      padding: 0 !important;
      margin: 0 0 0 -16px !important;
      opacity: 0 !important;
    }

    .rating:hover .rating-star:hover,
    .rating:hover .rating-star:hover~.rating-star,
    .rating-input:checked~.rating-star {
      background-position: 0 0;
    }

    .rating-star,
    .rating:hover .rating-star {
      position: relative;
      float: right;
      display: block;
      width: 16px;
      height: 16px;
      cursor: pointer;
      margin-right: 5px;
      background: url('../assets/images/star.png') 0 -16px;
    }
  </style>
  <script type="text/javascript">
    $(function() {
      $("#FUPdatepicker").datepicker({
        numberOfMonths: 2,
        showButtonPanel: true
      });

    });
  </script>
</head>

<body>


  <div id="loading" class="ui-front loader ui-widget-overlay bg-gray opacity-50">
    <img src="<?php echo $_SESSION['gpath']; ?>assets/images/loader-light.gif" alt="">
  </div>

  <div id="page-wrapper" class="demo-example">
    <!-- #page-header -->

    <?php include("../sidebar.php"); ?>
    <!-- #page-sidebar -->
    <div id="menu-right" class="scrollable-content hidden">
      <a href="javascript:;" title="Get Source" class="popover-title button-toggle-open">
        Cloud status
        <i class="glyph-icon icon-caret-right icon-caret-down"></i>
      </a>
      <div class="clear"></div>
      <a href="javascript:;" title="Get Source" class="popover-title button-toggle-open">
        Realtime server load
        <i class="glyph-icon icon-caret-right icon-caret-down"></i>
      </a>
      <div class="toggle-content-open clearfix">

        <div id="g10" class="small-gauge float-left"></div>
        <div id="g11" class="small-gauge float-right"></div>

      </div>
    </div>
    <div id="page-content-wrapper">
      <div id="page-title">

        <h3 class="font-black">
          <strong>List all products-></strong><strong><span class="font-blue"> <?php echo $sc_name; ?></span></strong>
        </h3>
      </div><!-- #page-title -->
      <div id="page-content">


        <h4>&nbsp;</h4>

        <?php
        if (isset($_GET['success'])) { ?>
          <div class="infobox success-bg">
            <a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>
            <h4 class="infobox-title"><?php echo $_GET['success']; ?></h4>
          </div><?php } ?>
        <table class="table" id="example1">
          <thead>
            <tr>
              <th width="5%">S.No</th>
              <th width="25%">Name </th>
              <th width="10%">Type </th>
              <th width="10%">Category</th>
              <th width="10%">SKU#</th>
              <th width="10%">MRP</th>
              <th width="10%">Price</th>
              <th width="7%">Size</th>
              <th width="7%">Qty</th>
              <th width="10%">Status</th>
              <th width="10%">Action</th>
            </tr>
          </thead>
          <tbody>


            <?php
            $sn = 0;
            $stmt->bind_result($id, $mc_id, $sc_id, $name, $cname);
            while ($stmt->fetch()) {
              $sn =   $sn + 1;
              $name = ucwords($name);
              $cname = ucwords($cname);

            ?>

              <tr class="parent">
                <td><?php echo $sn; ?></td>
                <td><?php echo $name; ?></td>
                <td>Parent</td>
                <td><?php echo $cname; ?></td>
                <td> - </td>
                <td> - </td>
                <td> - </td>
                <td> - </td>
                <td> - </td>
                <td> - </td>
                <td>
                  <div class="dropdown">
                    <a href="javascript:;" title="" class="btn medium bg-blue" data-toggle="dropdown">
                      <span class="button-content">
                        <i class="glyph-icon font-size-11 icon-cog"></i>
                        <i class="glyph-icon font-size-11 icon-chevron-down"></i>
                      </span>
                    </a>
                    <ul class="dropdown-menu float-right">
                      <li>
                        <a href="javascript:;" class="black-modal-edit" id="<?php echo $id; ?>">
                          <i class="glyph-icon icon-edit mrg5R"></i>
                          View/Edit
                        </a>

                      </li>

                      <li>
                        <a href="javascript:;" class="black-modal-new" id="<?php echo $id; ?>">
                          <i class="glyph-icon icon-plus mrg5R font-green"></i>
                          Add Child
                        </a>

                      </li>

                      <li>
                        <a href="javascript:;" class="black-modal-new-review" id="<?php echo $id; ?>">
                          <i class="glyph-icon icon-plus mrg5R font-green"></i>
                          Add Review
                        </a>

                      </li>


                      <!-- <li>
                                            <a href="list_all_products.php?id=<?php echo $id; ?>&name=<?php echo $name ?>" title="" onclick="return confirm('Are you sure you want to delete this product? - <?php echo $name ?>');" class="font-red">
                                                <i class="glyph-icon icon-remove mrg5R"></i>
                                                Delete
                                            </a>
                                        </li>-->

                    </ul>
                  </div>
                </td>
              </tr>

              <!-- ////////////////////////child/////////////////////////////////-->


              <?php

              $cquery = "SELECT t1.id, t1.sku, t1.mrp, t1.price, t1.qty, t1.pic1, t1.active, t3.name FROM bb_products_stock as t1 INNER JOIN bb_sizes as t3 ON t1.size = t3.id WHERE t1.parent_id = ? ORDER BY t3.name ASC";

              if (!$cstmt = $con->prepare($cquery)) {
                echo $error = "Product data listing preparation failed!" . $con->error;
                exit();
              }
              if (!$cstmt->bind_param('i', $id)) {
                echo $error = "Product data listing preparation failed!" . $con->error;
                exit();
              }


              if (!$cstmt->execute()) {
                echo $error = "Product data listing execution failed!" . $con->error;
                exit();
              }
              if (!$cstmt->store_result()) {
                echo $error = "Product data listing execution failed!" . $con->error;
                exit();
              }



              $cnum_of_rows = $cstmt->num_rows;

              if ($cnum_of_rows == 0) {
                continue;
              }
              $cstmt->bind_result($id, $sku, $mrp, $price, $qty, $pic1, $status, $size);
              while ($cstmt->fetch()) {
                $sn =   $sn + 1;
              ?>

                <tr class="child">
                  <td><?php echo $sn; ?></td>
                  <td> <?php echo $name; ?> </td>
                  <td>Child</td>
                  <td> <?php echo $cname; ?> </td>
                  <td> <?php echo $sku; ?> </td>
                  <td> <?php echo $mrp; ?> </td>
                  <td> <?php echo $price; ?> </td>
                  <td> <?php echo $size; ?> </td>
                  <td> <?php echo $qty; ?> </td>
                  <td> <?php if ($status == 1) {
                          echo "Active";
                        } else {
                          echo "Inactive";
                        }  ?> </td>
                  <td>
                    <div class="dropdown">
                      <a href="javascript:;" title="" class="btn medium bg-blue" data-toggle="dropdown">
                        <span class="button-content">
                          <i class="glyph-icon font-size-11 icon-cog"></i>
                          <i class="glyph-icon font-size-11 icon-chevron-down"></i>
                        </span>
                      </a>
                      <ul class="dropdown-menu float-right">
                        <li>
                          <a href="javascript:;" class="black-modal-child-view" id="<?php echo $id; ?>">
                            <i class="glyph-icon icon-eye mrg5R"></i>
                            View
                          </a>

                        </li>
                        <li>
                          <a href="javascript:;" class="black-modal-child-edit" id="<?php echo $id; ?>">
                            <i class="glyph-icon icon-edit mrg5R"></i>
                            Edit
                          </a>

                        </li>

                        <?php if ($status == 1) { ?>

                          <li>
                            <a href="list_all_products.php?id=<?php echo $id; ?>&sc_id=<?php echo $sc_id; ?>&sc_name=<?php echo $sc_name; ?>&action=status&active=0" title="click to deactivate" onclick="return confirm('Are you sure you want to deactivate this product? - <?php echo $name ?>');">
                              <i class="glyph-icon icon-edit mrg5R"></i>
                              Deactivate
                            </a>
                          </li>

                        <?php } else { ?>

                          <li>
                            <a href="list_all_products.php?id=<?php echo $id; ?>&sc_id=<?php echo $sc_id; ?>&sc_name=<?php echo $sc_name; ?>&action=status&active=1" title="click to activate" onclick="return confirm('Are you sure you want to activate this product? - <?php echo $name ?>');" class="font-green">
                              <i class="glyph-icon icon-edit mrg5R"></i>
                              Activate
                            </a>
                          </li>

                        <?php  } ?>
                        <li>
                          <a href="list_all_products.php?id=<?php echo $id; ?>&sc_id=<?php echo $sc_id; ?>&sc_name=<?php echo $mc_name; ?>&ptype=<?php echo $ptype; ?>&action=delete" title="click to activate" onclick="return confirm('Are you sure you want to delete this product? - <?php echo $name ?>');" class="font-red">
                            <i class="glyph-icon icon-remove mrg5R"></i>
                            Delete
                          </a>
                        </li>

                      </ul>
                    </div>
                  </td>
                </tr>
              <?php } ?>




              <!-- ////////////////////////child/////////////////////////////////-->


            <?php }

            ?>

          </tbody>
          <tfoot>
            <tr>
              <th></th>
              <th></th>
              <th></th>
              <th></th>
              <th></th>
              <th></th>
              <th></th>
              <th></th>
              <th></th>
              <th></th>
              <th></th>
            </tr>
          </tfoot>
        </table>


      </div><!-- #page-content -->
    </div>




  </div><!-- #page-content -->
  </div><!-- #page-main -->
  </div><!-- #page-wrapper -->

</body>

</html>


<!-----------------------------------------------------add child------------------------------>
<div class="hide" id="black-modal-new" title="Add child product for <?php echo $name; ?>">
  <div class="example-code">
    <form id="demo-form-child" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="col-md-11 center-margin" method="post" enctype="multipart/form-data">
      <div class="content-box mrg25B mrg25T">
        <h3 class="content-box-header primary-bg"> <span>Add Child Product</span> </h3>
        <div class="content-box-wrapper">


          <div class="form-row">
            <div class="form-label col-md-4">
              <label for="">
                SKU#:
                <span class="required">*</span>
              </label>
            </div>
            <div class="form-input col-md-8">
              <input type="text" id="SKU" name="SKU" data-trigger="change" parsley-rangelength="[1,15]" pattern="^[A-Za-z0-9]*$" data-required="true" class="parsley-validated">
            </div>
          </div>

          <div class="form-row">
            <div class="form-label col-md-4">
              <label for=""> Select a size: <span class="required">*</span></label>
            </div>
            <div class="form-input col-md-8">
              <select data-placeholder="Select a size..." name="size" id="size" class="chosen-select parsley-validated" data-trigger="change" required>

                <?php
                if (isset($serror)) {
                ?>
                  <option value=""><?php echo $serror; ?></option>
                <?php
                } else {
                ?>
                  <option value="">Select a size</option>
                <?php } ?>

                <?php
                $sstmt->bind_result($id, $scname);
                while ($sstmt->fetch()) {

                ?>
                  <option value="<?php echo $id; ?>"><?php echo $scname; ?></option>

                <?php }
                ?>

              </select>
            </div>

          </div>


          <div class="form-row">
            <div class="form-label col-md-4">
              <label for="">
                MRP:
                <span class="required">*</span>
              </label>
            </div>
            <div class="form-input col-md-8">
              <input type="text" id="MRP" name="MRP" data-trigger="change" data-type="number" parsley-rangelength="[1,10]" class="parsley-validated">
            </div>
          </div>

          <div class="form-row">
            <div class="form-label col-md-4">
              <label for="">
                Selling Price:
                <span class="required">*</span>
              </label>
            </div>
            <div class="form-input col-md-8">
              <input type="text" id="price" name="price" data-trigger="change" data-type="number" parsley-rangelength="[1,10]" class="parsley-validated">
            </div>
          </div>

          <div class="form-row">
            <div class="form-label col-md-4">
              <label for="">
                Stock QTY:
                <span class="required">*</span>
              </label>
            </div>
            <div class="form-input col-md-8">
              <input type="text" id="stock" name="stock" data-trigger="change" data-type="number" parsley-rangelength="[1,10]" data-required="true" class="parsley-validated">
            </div>
          </div>

          <div class="form-row">
            <div class="form-label col-md-4">
              <label for=""> Featured Product:</label>
            </div>
            <div class="form-input col-md-8">
              <select data-placeholder="Select a type..." name="ftype" class="chosen-select parsley-validated" data-trigger="change" required>
                <option value="0" selected>No</option>
                <option value="1">Yes</option>

              </select>
            </div>

          </div>

          <div class="form-row">
            <div class="form-label col-md-4">
              <label for=""> Best Selling Product:</label>
            </div>
            <div class="form-input col-md-8">
              <select data-placeholder="Select a type..." name="bselling" class="chosen-select parsley-validated" data-trigger="change" required>
                <option value="0" selected>No</option>
                <option value="1">Yes</option>

              </select>
            </div>

          </div>

          <div class="form-row">
            <div class="form-label col-md-4">
              <label for=""> Upload Main image:<span class="required">*</span></label>
            </div>
            <div class="float-left col-md-8"> <span class="btn medium bg-green fileinput-button"> <span class="button-content">Max 500kb. Dimension: 268px x 268px. (gif, jpeg, jpg, png) only</span>
                <input type="file" name="pic[]" required>
            </div>
          </div>

          <div class="form-row">
            <div class="form-label col-md-4">
              <label for="">Product image 1:<span class="required">*</span></label>
            </div>
            <div class="float-left col-md-8"> <span class="btn medium bg-green fileinput-button"><span class="button-content">Max 500kb. Dimension: 640px x 755px. (gif, jpeg, jpg, png) only</span>
                <input type="file" name="pic[]" required>
            </div>
          </div>
          <div class="form-row">
            <div class="form-label col-md-4">
              <label for="">Product image 2:</label>
            </div>
            <div class="float-left col-md-8"> <span class="btn medium bg-green fileinput-button"> <span class="button-content">Max 500kb. Dimension: 640px x 755px. (gif, jpeg, jpg, png) only</span>
                <input type="file" name="pic[]">
            </div>
          </div>
          <div class="form-row">
            <div class="form-label col-md-4">
              <label for="">Product image 3:</label>
            </div>
            <div class="float-left col-md-8"> <span class="btn medium bg-green fileinput-button"> <span class="button-content">Max 500kb. Dimension: 640px x 755px. (gif, jpeg, jpg, png) only</span>
                <input type="file" name="pic[]">
            </div>
          </div>

          <div class="form-row">
            <div class="form-label col-md-4">
              <label for="">Product image 4:</label>
            </div>
            <div class="float-left col-md-8"> <span class="btn medium bg-green fileinput-button"> <span class="button-content">Max 500kb. Dimension: 640px x 755px. (gif, jpeg, jpg, png) only</span>
                <input type="file" name="pic[]">
            </div>
          </div>

          <div class="form-row">
            <div class="form-label col-md-4">
              <label for=""> Upload social media image:<span class="required">*</span></label>
            </div>
            <div class="float-left col-md-8"> <span class="btn medium bg-green fileinput-button"> <span class="button-content">Max 500kb.(1200px x 550px) (gif, jpeg, jpg, png) only</span>
                <input type="file" name="pic[]">
            </div>
          </div>

          <div class="form-row">
            <div class="form-label col-md-4">
              <label for="">Packing image:</label>
            </div>
            <div class="float-left col-md-8"> <span class="btn medium bg-green fileinput-button"> <span class="button-content">Max 500kb. Dimension: 640px x 755px. (gif, jpeg, jpg, png) only</span>
                <input type="file" name="pic[]">
            </div>
          </div>

          <div class="divider"></div>
          <div class="form-row">
            <input type="hidden" name="parent_id" id="parent_id_add">
            <input type="hidden" name="sc_id" id="mc_id_add" value="<?php echo $sc_id; ?>">
            <input type="hidden" name="sc_name" id="mc_name_add" value="<?php echo $sc_name; ?>">
            <div class="form-input col-md-8 col-md-offset-4">
              <button type="submit" name="submit_add" class="btn large primary-bg" onclick="javascript:$(&apos;#demo-form-child&apos;).parsley( &apos;validate&apos; );"><span class="button-content">Save Data</span></button>
              &nbsp;
            </div>
          </div>

        </div>
      </div>
    </form>
  </div>
</div>

<!-----------------------------------------------------add review------------------------------>
<div class="hide" id="black-modal-new-review" title="Add review">
  <div class="example-code">
    <form id="demo-form-child" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="col-md-11 center-margin" method="post" enctype="multipart/form-data">
      <div class="content-box mrg25B mrg25T">
        <h3 class="content-box-header primary-bg"> <span>Add Review</span> </h3>
        <div class="content-box-wrapper">

          <div class="form-row">
            <div class="form-label col-md-4">
              <label for=""> Review Date: <span class="required">*</span></label>
            </div>
            <div class="form-input col-md-8">
              <input type="text" class="col-md-12" class="datepicker" id="FUPdatepicker" name="review_date" required>
            </div>
          </div>

          <div class="form-row">
            <div class="form-label col-md-4">
              <label for="">
                Rating:
                <span class="required">*</span>
              </label>
            </div>
            <div class="form-input col-md-8">
              <div class="submit-rating">
                <span class="rating">
                  <input type="radio" class="rating-input" id="rating-input-1-5" value="5" required name="rating" />
                  <label for="rating-input-1-5" class="rating-star"></label>
                  <input type="radio" class="rating-input" id="rating-input-1-4" value="4" name="rating" />
                  <label for="rating-input-1-4" class="rating-star"></label>
                  <input type="radio" class="rating-input" id="rating-input-1-3" value="3" name="rating" />
                  <label for="rating-input-1-3" class="rating-star"></label>
                  <input type="radio" class="rating-input" id="rating-input-1-2" value="2" name="rating" />
                  <label for="rating-input-1-2" class="rating-star"></label>
                  <input type="radio" class="rating-input" id="rating-input-1-1" value="1" name="rating" />
                  <label for="rating-input-1-1" class="rating-star"></label>
                </span>
              </div>
            </div>
          </div>
          <div class="form-row">
            <div class="form-label col-md-4">
              <label for="">
                Customer Name:
                <span class="required">*</span>
              </label>
            </div>
            <div class="form-input col-md-8">
              <input type="text" id="name" name="cname" data-trigger="change" data-required="true" class="parsley-validated">
            </div>
          </div>
          <div class="form-row">
            <div class="form-label col-md-4">
              <label for="">
                Title:
                <span class="required">*</span>
              </label>
            </div>
            <div class="form-input col-md-8">
              <input type="text" id="review_title" name="review_title" data-trigger="change" data-required="true" class="parsley-validated">
            </div>
          </div>

          <div class="form-row">
            <div class="form-label col-md-4">
              <label for="">
                Description: <span class="required">*</span>
              </label>
            </div>
            <div class="form-input col-md-8">
              <textarea id="review" name="review" rows="10" data-trigger="change" class="parsley-validated" data-required="true"></textarea>
            </div>
          </div>

          <div class="form-row">
            <div class="form-label col-md-4">
              <label for=""> Would you recommend this product?:</label>
            </div>
            <div class="form-input col-md-8">
              <select data-placeholder="Select a value..." name="recommend" class="chosen-select parsley-validated" data-trigger="change" required>
                <option value="1" selected>Yes</option>
                <option value="0">No</option>

              </select>
            </div>

          </div>


          <div class="form-row">
            <div class="form-label col-md-4">
              <label for="">Product image 1:</label>
            </div>
            <div class="float-left col-md-8"> <span class="btn medium bg-green fileinput-button"><span class="button-content">Max 500kb. (gif, jpg, png) only</span>
                <input type="file" name="pic[]">
            </div>
          </div>
          <div class="form-row">
            <div class="form-label col-md-4">
              <label for="">Product image 2:</label>
            </div>
            <div class="float-left col-md-8"> <span class="btn medium bg-green fileinput-button"> <span class="button-content">Max 500kb. (gif, jpg, png) only</span>
                <input type="file" name="pic[]">
            </div>
          </div>
          <div class="form-row">
            <div class="form-label col-md-4">
              <label for="">Product image 3:</label>
            </div>
            <div class="float-left col-md-8"> <span class="btn medium bg-green fileinput-button"> <span class="button-content">Max 500kb. (gif, jpg, png) only</span>
                <input type="file" name="pic[]">
            </div>
          </div>

          <div class="divider"></div>
          <div class="form-row">
            <input type="hidden" name="parent_id" id="parent_id_review">
            <input type="hidden" name="sc_id" id="mc_id_add" value="<?php echo $sc_id; ?>">
            <input type="hidden" name="sc_name" id="mc_name_add" value="<?php echo $sc_name; ?>">
            <div class="form-input col-md-8 col-md-offset-4">
              <button type="submit" name="submit_review" class="btn large primary-bg" onclick="javascript:$(&apos;#demo-form-child&apos;).parsley( &apos;validate&apos; );"><span class="button-content">Save Data</span></button>
              &nbsp;
            </div>
          </div>

        </div>
      </div>
    </form>
  </div>
</div>
<!------------------------------------------------------------------------------------------>
<div id="limage" class="hide"><img src="<?php echo $_SESSION['gpath']; ?>assets/images/loader-light.gif" alt="" /></div>

<!-----------------------------------------------------edit parent------------------------------>
<div class="hide" id="black-modal-edit" title="<?php echo $sc_name; ?>">
  <div class="example-code">
    <form id="demo-form-edit" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="col-md-11 center-margin" method="post" enctype="multipart/form-data">
      <div class="content-box mrg25B mrg25T">
        <h3 class="content-box-header primary-bg"> <span>Edit/View Parent Item details</span> </h3>
        <div class="content-box-wrapper">

          <div class="form-row">
            <div class="form-label col-md-4">
              <label for="">
                Product Name:
                <span class="required">*</span>
              </label>
            </div>
            <div class="form-input col-md-8">
              <input type="text" id="parent_name" name="pname" data-trigger="change" parsley-rangelength="[2,99]" data-required="true" class="parsley-validated">
            </div>
          </div>

          <div class="form-row">
            <div class="form-label col-md-4">
              <label for="">
                HSC Code:
              </label>
            </div>
            <div class="form-input col-md-8">
              <input type="text" id="HSC_code" name="HSC_code" data-trigger="change" parsley-rangelength="[1,99]" pattern="^[A-Za-z0-9]*$" class="parsley-validated">
            </div>
          </div>

          <div class="form-row">
            <div class="form-label col-md-4">
              <label for="">
                Description: <span class="required">*</span>
              </label>
            </div>
            <div class="form-input col-md-8">
              <textarea id="description" name="description" rows="5" data-trigger="change" class="parsley-validated" data-required="true"></textarea>
            </div>
          </div>


          <div class="form-row">
            <div class="form-label col-md-4">
              <label for="">
                Google Description: <span class="required">*</span>
              </label>
            </div>
            <div class="form-input col-md-8">
              <textarea id="google_description" name="google_description" rows="5" data-trigger="change" class="parsley-validated" data-required="true"></textarea>
            </div>
          </div>


          <div class="form-row">
            <div class="form-label col-md-4">
              <label for="">
                How to Use: <span class="required">*</span>
              </label>
            </div>
            <div class="form-input col-md-8">
              <textarea id="details" name="details" rows="5" data-trigger="change" class="parsley-validated" data-required="true"></textarea>

            </div>
          </div>

          <div class="form-row">
            <div class="form-label col-md-4">
              <label for="">
                Disclaimer: <span class="required">*</span>
              </label>
            </div>
            <div class="form-input col-md-8">
              <textarea id="disclaimer" name="disclaimer" rows="5" data-trigger="change" class="parsley-validated" data-required="true"></textarea>

            </div>
          </div>
          <div class="form-row">
            <div class="form-label col-md-4">
              <label for="">
                Search tags: <span class="required">comma separated</span>
              </label>
            </div>
            <div class="form-input col-md-8">
              <textarea id="tags" name="tags" rows="2" data-trigger="change" class="parsley-validated"></textarea>
            </div>
          </div>

          <div class="form-row">
            <div class="form-label col-md-4">
              <label for="">
                SEO Title:
              </label>
            </div>
            <div class="form-input col-md-8">
              <textarea id="title" name="seo_title" rows="2" data-trigger="change" class="parsley-validated" data-maxlength="70"></textarea>
              <div class="character-remaining clear input-description font-gray">70 chars only</div>
            </div>
          </div>

          <div class="form-row">
            <div class="form-label col-md-4">
              <label for="">
                META description:
              </label>
            </div>
            <div class="form-input col-md-8">
              <textarea id="meta" name="meta_description" rows="2" data-trigger="change" class="parsley-validated" data-maxlength="180"></textarea>
              <div class="character-remaining clear input-description font-gray">180 chars only</div>
            </div>
          </div>

          <div class="form-row">
            <div class="form-label col-md-4">
              <label for="">
                META Keywords <span class="required">comma separated</span>:
              </label>
            </div>
            <div class="form-input col-md-8">
              <textarea id="keywords" name="meta_keywords" rows="2" data-trigger="change" class="parsley-validated" data-maxlength="500"></textarea>
              <div class="character-remaining clear input-description font-gray">500 chars only</div>
            </div>
          </div>
          <div class="divider"></div>
          <div class="form-row">
            <input type="hidden" name="parent_id" id="parent_id_edit">
            <input type="hidden" name="sc_id" id="sc_id_edit" value="<?php echo $sc_id; ?>">
            <input type="hidden" name="sc_name" id="sc_name_edit" value="<?php echo $sc_name; ?>">
            <div class="form-input col-md-8 col-md-offset-4">
              <button type="submit" name="submit_edit" class="btn large primary-bg" onclick="javascript:$(&apos;#demo-form-2&apos;).parsley( &apos;validate&apos; );"><span class="button-content">Save Data</span></button>
              &nbsp;

            </div>
          </div>


        </div>
      </div>
    </form>
  </div>
</div>

<!-----------------------------------------------------edit child------------------------------>
<div class="hide" id="black-modal-edit-child" title="Edit child product">
  <div class="example-code">
    <form id="demo-form-edit-child" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="col-md-11 center-margin" method="post" enctype="multipart/form-data">
      <div class="content-box mrg25B mrg25T">
        <h3 class="content-box-header primary-bg"> <span>Edit child product details</span> </h3>
        <div class="content-box-wrapper">


          <div class="form-row">
            <div class="form-label col-md-4">
              <label for="">
                SKU#:
                <span class="required">*</span>
              </label>
            </div>
            <div class="form-input col-md-8">
              <input type="text" id="SKU_edit_child" name="SKU" data-trigger="change" parsley-rangelength="[1,15]" pattern="^[A-Za-z0-9]*$" data-required="true" class="parsley-validated">
            </div>
          </div>


          <div class="form-row">
            <div class="form-label col-md-4">
              <label for=""> Select a size:</label>
            </div>
            <div class="form-input col-md-8">
              <select data-placeholder="Select a size..." name="size" id="size_edit" class="chosen-select parsley-validated" data-trigger="change">

                <?php
                if (isset($serror)) {
                ?>
                  <option value=""><?php echo $serror; ?></option>
                <?php
                } else {
                ?>
                  <option value="">Select a size</option>
                <?php } ?>

                <?php
                $sstmt->data_seek(0);
                $sstmt->bind_result($id, $scname);
                while ($sstmt->fetch()) {

                ?>
                  <option value="<?php echo $id; ?>"><?php echo $scname; ?></option>

                <?php }
                ?>

              </select>
            </div>

          </div>



          <div class="form-row">
            <div class="form-label col-md-4">
              <label for="">
                MRP:
                <span class="required">*</span>
              </label>
            </div>
            <div class="form-input col-md-8">
              <input type="text" id="MRP_edit_child" name="MRP" data-trigger="change" data-type="number" parsley-rangelength="[1,10]" class="parsley-validated">
            </div>
          </div>

          <div class="form-row">
            <div class="form-label col-md-4">
              <label for="">
                Selling Price:
                <span class="required">*</span>
              </label>
            </div>
            <div class="form-input col-md-8">
              <input type="text" id="price_edit_child" name="price" data-trigger="change" data-type="number" parsley-rangelength="[1,10]" class="parsley-validated">
            </div>
          </div>

          <div class="form-row">
            <div class="form-label col-md-4">
              <label for="">
                Stock QTY:
                <span class="required">*</span>
              </label>
            </div>

            <div class="form-input col-md-8">
              <input type="text" id="stock_edit_child" name="stock" data-trigger="change" data-type="number" parsley-rangelength="[1,10]" data-required="true" class="parsley-validated">
            </div>
          </div>

          <div class="form-row">
            <div class="form-label col-md-4">
              <label for=""> Featured Product:</label>
            </div>
            <div class="form-input col-md-8">
              <select data-placeholder="Select a type..." name="ftype" class="chosen-select parsley-validated" data-trigger="change">
                <option value="">Select</option>
                <option value="0">No</option>
                <option value="1">Yes</option>

              </select>
            </div>

          </div>

          <div class="form-row">
            <div class="form-label col-md-4">
              <label for=""> Most Selling Product:</label>
            </div>
            <div class="form-input col-md-8">
              <select data-placeholder="Select a type..." name="bselling" class="chosen-select parsley-validated" data-trigger="change">
                <option value="">Select</option>
                <option value="0">No</option>
                <option value="1">Yes</option>

              </select>
            </div>

          </div>

          <div class="form-row">
            <div class="form-label col-md-4">
              <label for=""> Upload Main image:</label>
            </div>
            <div class="float-left col-md-8"> <span class="btn medium bg-green fileinput-button"> <span class="button-content">Max 500kb.(268px x 268px)(gif, jpeg, jpg, png) only </span>
                <input type="file" name="pic[]">
            </div>
          </div>
          <div class="form-row">
            <div class="form-label col-md-4">
              <label for="">Product image 1:</label>
            </div>
            <div class="float-left col-md-8"> <span class="btn medium bg-green fileinput-button"> <span class="button-content">Max 500kb. 555px x 555px. (gif, jpeg, jpg, png) only </span>
                <input type="file" name="pic[]">
            </div>
          </div>
          <div class="form-row">
            <div class="form-label col-md-4">
              <label for="">Product image 2:</label>
            </div>
            <div class="float-left col-md-8"> <span class="btn medium bg-green fileinput-button"> <span class="button-content">Max 500kb. 555px x 555px. (gif, jpeg, jpg, png) only </span>
                <input type="file" name="pic[]">
            </div>
          </div>

          <div class="form-row">
            <div class="form-label col-md-4">
              <label for="">Product image 3:</label>
            </div>
            <div class="float-left col-md-8"> <span class="btn medium bg-green fileinput-button"> <span class="button-content">Max 500kb. 555px x 555px. (gif, jpeg, jpg, png) only </span>
                <input type="file" name="pic[]">
            </div>
          </div>

          <div class="form-row">
            <div class="form-label col-md-4">
              <label for="">Product image 4:</label>
            </div>
            <div class="float-left col-md-8"> <span class="btn medium bg-green fileinput-button"> <span class="button-content">Max 500kb. 555px x 555px. (gif, jpeg, jpg, png) only</span>
                <input type="file" name="pic[]">
            </div>
          </div>

          <div class="form-row">
            <div class="form-label col-md-4">
              <label for=""> Upload social media image:</label>
            </div>
            <div class="float-left col-md-8"> <span class="btn medium bg-green fileinput-button"> <span class="button-content">Max 500kb.(1200px x 550px) (gif, jpeg, jpg, png) only</span>
                <input type="file" name="pic[]">
            </div>
          </div>

          <div class="form-row">
            <div class="form-label col-md-4">
              <label for="">Packing Image:</label>
            </div>
            <div class="float-left col-md-8"> <span class="btn medium bg-green fileinput-button"> <span class="button-content">Max 500kb. 555px x 555px. (gif, jpeg, jpg, png) only</span>
                <input type="file" name="pic[]">
            </div>
          </div>

          <style>
            .dynamic-box {
              border: 1px solid #ddd;
              padding: 15px;
              margin-bottom: 15px;
              background: #fafafa;
              border-radius: 6px;
            }

            .text-right {
              text-align: right;
            }

            .mb-2 {
              margin-bottom: 10px;
            }
          </style>
          <!-- PRODUCT INFORMATION SECTION -->

          <div class="content-box-wrapper">

            <h3 class="content-box-header bg-default">
              Product Information Section
            </h3>
            <div class="content-box">
              <div class="form-row">
                <div class="form-label col-md-4">
                  <label>Whats app</label>
                </div>
                <div class="form-input col-md-8">
                  <select name="whats_app_show" id="whats_app_show" class="chosen-select parsley-validated">
                    <option value="Show">Show</option>
                    <option value="Hide">Hide</option>
                  </select>
                </div>
              </div>
              <!-- BENEFITS -->
              <!-- <div class="form-row">
                <div class="form-label col-md-4">
                  <label>Benefits Title</label>
                </div>

                <div class="form-input col-md-8">
                  <input type="text"
                    id="benefits_title"
                    name="benefits_title"
                    class="parsley-validated"
                    value="Benefits">
                </div>
              </div> -->


              <!-- <div class="form-row">
                <div class="form-label col-md-4">
                  <label>Benefits Icon</label>
                </div>

                <div class="form-input col-md-8">
                  <input type="file"
                    id="benefits_icon"
                    name="benefits_icon">

                  <img id="benefits_icon_img"
                    style="max-height:40px;
                    margin-top:10px;
                    display:none;">
                </div>
              </div> -->


              <div class="form-row">
                <div class="form-label col-md-4">
                  <label>Benefits Points</label>
                </div>

                <div class="form-input col-md-8">

                  <div id="benefits_container"></div>

                  <button type="button"
                    id="add_benefit_btn"
                    class="btn medium bg-green">
                    Add Benefit
                  </button>

                </div>
              </div>


              <!-- SMELL PROFILE -->
              <!-- <div class="form-row">
                <div class="form-label col-md-4">
                  <label>Smell Profile Title</label>
                </div>

                <div class="form-input col-md-8">
                  <input type="text"
                    id="smell_title"
                    name="smell_title"
                    class="parsley-validated"
                    value="Smell Profile">
                </div>
              </div> -->


              <!-- <div class="form-row">
                <div class="form-label col-md-4">
                  <label>Smell Icon</label>
                </div>

                <div class="form-input col-md-8">
                  <input type="file"
                    id="smell_icon"
                    name="smell_icon">

                  <img id="smell_icon_img"
                    style="max-height:40px;
                    margin-top:10px;
                    display:none;">
                </div>
              </div> -->


              <div class="form-row">
                <div class="form-label col-md-4">
                  <label>Smell Description</label>
                </div>

                <div class="form-input col-md-8">
                  <textarea
                    id="smell_description"
                    name="smell_description"
                    class="parsley-validated"
                    rows="4"></textarea>
                </div>
              </div>


              <!-- BEST FOR -->
              <div class="form-row">
                <div class="form-label col-md-4">
                  <label>Best For / Where To Use</label>
                </div>

                <div class="form-input col-md-8">

                  <div id="best_for_container"></div>

                  <button type="button"
                    id="add_best_for_btn"
                    class="btn medium bg-green">
                    Add Item
                  </button>

                </div>
              </div>


              <!-- FRAGRANCE -->
              <!-- <div class="form-row">
                <div class="form-label col-md-4">
                  <label>Fragrance Title</label>
                </div>

                <div class="form-input col-md-8">
                  <input type="text"
                    id="fragrance_title"
                    name="fragrance_title"
                    class="parsley-validated"
                    value="Fragrance Lasting">
                </div>
              </div> -->

              <!-- 
              <div class="form-row">
                <div class="form-label col-md-4">
                  <label>Fragrance Icon</label>
                </div>

                <div class="form-input col-md-8">
                  <input type="file"
                    id="fragrance_icon"
                    name="fragrance_icon">

                  <img id="fragrance_icon_img"
                    style="max-height:40px;
                    display:none;">
                </div>
              </div> -->


              <div class="form-row">
                <div class="form-label col-md-4">
                  <label> Fragrance Main Heading</label>
                </div>

                <div class="form-input col-md-8">
                  <input type="text"
                    id="fragrance_heading"
                    name="fragrance_heading"
                    class="parsley-validated">
                </div>
              </div>


              <div class="form-row">
                <div class="form-label col-md-4">
                  <label>Fragrance Description</label>
                </div>

                <div class="form-input col-md-8">
                  <textarea
                    id="fragrance_description"
                    name="fragrance_description"
                    class="parsley-validated"
                    rows="3"></textarea>
                </div>
              </div>


              <!-- COMPATIBLE -->
              <div class="form-row">
                <div class="form-label col-md-4">
                  <label>Compatible With</label>
                </div>

                <div class="form-input col-md-8">

                  <div id="compatible_container"></div>

                  <button type="button"
                    id="add_compatible_btn"
                    class="btn medium bg-green">
                    Add Compatible
                  </button>

                </div>
              </div>


              <!-- FAQ -->
              <div class="form-row">
                <div class="form-label col-md-4">
                  <label>FAQ</label>
                </div>

                <div class="form-input col-md-8">

                  <div id="faq_container"></div>

                  <button type="button"
                    id="add_faq_btn"
                    class="btn medium bg-green">
                    Add FAQ
                  </button>

                </div>
              </div>

            </div>

          </div>

          <div class="divider"></div>
          <div class="form-row">
            <input type="hidden" name="parent_id" id="parent_id_edit_child">
            <input type="hidden" name="id" id="id_child_edit">
            <input type="hidden" name="e_size" id="size_child_edit">
            <input type="hidden" name="e_featured" id="featured_child_edit">
            <input type="hidden" name="e_bselling" id="bselling_child_edit">
            <input type="hidden" name="e_pic[]" id="pic1_child_edit">
            <input type="hidden" name="e_pic[]" id="pic2_child_edit">
            <input type="hidden" name="e_pic[]" id="pic3_child_edit">
            <input type="hidden" name="e_pic[]" id="pic4_child_edit">
            <input type="hidden" name="e_pic[]" id="pic5_child_edit">
            <input type="hidden" name="e_pic[]" id="pic6_child_edit">
            <input type="hidden" name="e_pic[]" id="pic7_child_edit">
            <input type="hidden" name="sc_id" id="sc_id_add_edit" value="<?php echo $sc_id; ?>">
            <input type="hidden" name="sc_name" id="sc_name_add_edit" value="<?php echo $sc_name; ?>">
            <div class="form-input col-md-8 col-md-offset-4">
              <button type="submit" name="submit_child_edit" class="btn large primary-bg" onclick="javascript:$(&apos;#demo-form-edit-child&apos;).parsley( &apos;validate&apos; );"><span class="button-content">Save Data</span></button>
              &nbsp;
            </div>
          </div>
        </div>
      </div>
    </form>
  </div>
</div>
<!-------------------------------------view child-------------------------------------------------->
<div class="hide" id="black-modal-child_view" title="CHILD PRODUCT DETAILS">
  <div class="pad10A" id="viewfupdata"></div>
</div>
<!------------------------------------------------------------------------------------------------->

<script type="text/javascript">
  ////////////////////////////view child data///////////////////////	
  $(function() {

    $(".black-modal-child-view").click(function() {

      var cid = $(this).attr("id");
      $.ajax({
        url: "fetch_child_data.php",
        method: "post",
        data: {
          cid: cid
        },
        beforeSend: function() {
          $('#loading').fadeIn();
        },
        complete: function() {
          $('#loading').hide();
        },
        success: function(data) {
          $('#viewfupdata').html(data);
          $("#black-modal-child_view").dialog({
            modal: true,
            minWidth: 900,
            minHeight: 400,
            dialogClass: "modal-dialog",
            buttons: {
              "CLOSE": function() {
                $(this).dialog("close");
              }
            },
            show: "fadeIn"
          });
          $('.ui-widget-overlay').addClass('bg-black opacity-60');

        }
      });

    });

  });

  //////////////////////////////////////////////add child/////////////////////////////////////////


  $(".black-modal-new").click(function() {
    var cid = $(this).attr("id");
    $("#parent_id_add").val(cid);
    $("#black-modal-new").dialog({
      modal: true,
      minWidth: 900,
      minHeight: 200,
      dialogClass: "modal-dialog",
      buttons: {
        "CLOSE": function() {
          $(this).dialog("close");
        }
      },
      show: "fadeIn"
    });
    $('.ui-widget-overlay').addClass('bg-black opacity-60');
  });

  //////////////////////////////////////////////add review/////////////////////////////////////////


  $(".black-modal-new-review").click(function() {
    var cid = $(this).attr("id");
    $("#parent_id_review").val(cid);
    $("#black-modal-new-review").dialog({
      modal: true,
      minWidth: 900,
      minHeight: 200,
      dialogClass: "modal-dialog",
      buttons: {
        "CLOSE": function() {
          $(this).dialog("close");
        }
      },
      show: "fadeIn"
    });
    $('.ui-widget-overlay').addClass('bg-black opacity-60');
  });
  //////////////////////////////edit child////////////////////////////////////////

  $(".black-modal-child-edit").click(function() {
    var cid = $(this).attr("id");
    $.ajax({
      url: "fetch_child_edit_data.php",
      method: "POST",
      data: {
        cid: cid
      },
      dataType: "json",
      beforeSend: function() {
        $('#loading').fadeIn();
      },
      complete: function() {
        $('#loading').hide();
      },
      error: function(xhr, error) {
        console.debug(xhr);
        console.debug(error);
      },
      success: function(data) {

        $('#parent_id_edit_child').val(data.parent_id);
        $('#id_child_edit').val(data.id);
        $('#SKU_edit_child').val(data.sku);
        $('#size_child_edit').val(data.size);
        $('#MRP_edit_child').val(data.mrp);
        $('#price_edit_child').val(data.price);
        $('#stock_edit_child').val(data.qty);
        $('#featured_child_edit').val(data.featured);
        $('#bselling_child_edit').val(data.bestselling);
        $('#pic1_child_edit').val(data.pic1);
        $('#pic2_child_edit').val(data.pic2);
        $('#pic3_child_edit').val(data.pic3);
        $('#pic4_child_edit').val(data.pic4);
        $('#pic5_child_edit').val(data.pic5);
        $('#pic6_child_edit').val(data.pic6);
        $('#pic7_child_edit').val(data.pic7);
        // =========================
        // PRODUCT INFO DATA LOAD
        // =========================
        $('#whats_app_show').val(data.whats_app_show).trigger('chosen:updated');
        $('#benefits_title')
          .val(data.benefits_title);

        $('#smell_title')
          .val(data.smell_title);

        $('#smell_description')
          .val(data.smell_description);

        $('#fragrance_title')
          .val(data.fragrance_title);

        $('#fragrance_heading')
          .val(data.fragrance_heading);

        $('#fragrance_description')
          .val(data.fragrance_description);


        // ICON PREVIEW
        if (data.benefits_icon != '') {
          $("#benefits_icon_img")
            .attr('src',
              '../' + data.benefits_icon)
            .show();
        }

        if (data.smell_icon != '') {
          $("#smell_icon_img")
            .attr('src',
              '../' + data.smell_icon)
            .show();
        }

        if (data.fragrance_icon != '') {
          $("#fragrance_icon_img")
            .attr('src',
              '../' + data.fragrance_icon)
            .show();
        }


        // CLEAR OLD DATA
        $("#benefits_container").html('');
        $("#best_for_container").html('');
        $("#compatible_container").html('');
        $("#faq_container").html('');



        // =========================
        // BENEFITS
        // =========================
        if (data.benefits_points) {

          $.each(
            data.benefits_points,
            function(index, item) {

              $("#benefits_container")
                .append(`
        <div class="dynamic-box">

            <div class="text-right mb-2">
                <a href="javascript:;"
                class="btn small bg-red remove-item">
                Remove
                </a>
            </div>

            <div class="form-row">
                <div class="form-label col-md-4">
                    <label>Benefit</label>
                </div>

                <div class="form-input col-md-8">
                    <input type="text"
                    name="benefits[]"
                    class="parsley-validated"
                    value="${item}">
                </div>
            </div>

        </div>
        `);
            });
        }



        // =========================
        // BEST FOR
        // =========================
        if (data.best_for) {

          $.each(
            data.best_for,
            function(index, item) {

              $("#best_for_container")
                .append(`

        <div class="dynamic-box">

            <div class="text-right mb-2">
                <a href="javascript:;"
                class="btn small bg-red remove-item">
                Remove
                </a>
            </div>

            <div class="form-row">
                <div class="form-label col-md-4">
                    <label>Title</label>
                </div>

                <div class="form-input col-md-8">
                    <input type="text"
                    name="best_for_title[]"
                    class="parsley-validated"
                    value="${item.title}">
                </div>
            </div>
            <div class="form-row">
                <div class="form-label col-md-4">
                    <label>Image</label>
                </div>

                <div class="form-input col-md-8">
                   <input type="file" name="best_for_icon[]" class="parsley-validated" accept="image/*">
                   <input type="hidden" name="old_best_for_icon[]" value="${item.icon}">
                </div>
            </div>
            ${
            item.icon
            ?
            `<img src="../${item.icon}"
            style="height:50px;">`
            :
            ''
            }

        </div>
        `);
            });
        }



        // =========================
        // COMPATIBLE
        // =========================
        if (data.compatible_with) {

          $.each(
            data.compatible_with,
            function(index, item) {

              $("#compatible_container")
                .append(`

        <div class="dynamic-box">

            <div class="text-right mb-2">
                <a href="javascript:;"
                class="btn small bg-red remove-item">
                Remove
                </a>
            </div>

            <input type="text"
            name="compatible_title[]"
            class="parsley-validated"
            value="${item.title}">
            <br><br><br>
            <div class="form-row">
                <div class="form-input col-md-8">
                   <input type="file" name="compatible_icon[]" class="parsley-validated" accept="image/*">
                   <input type="hidden" name="old_compatible_icon[]" value="${item.icon}">
                </div>
            </div>
            ${
            item.icon
            ?
            `<img src="../${item.icon}"
            style="height:50px;">`
            :
            ''
            }

        </div>
        `);
            });
        }



        // =========================
        // FAQ
        // =========================
        if (data.faq_data) {

          $.each(
            data.faq_data,
            function(index, item) {

              $("#faq_container")
                .append(`

        <div class="dynamic-box">

            <div class="text-right mb-2">
                <a href="javascript:;"
                class="btn small bg-red remove-item">
                Remove
                </a>
            </div>

            <div class="form-row">
                <div class="form-label col-md-4">
                    <label>Question</label>
                </div>

                <div class="form-input col-md-8">
                    <input type="text"
                    name="faq_question[]"
                    class="parsley-validated"
                    value="${item.question}">
                </div>
            </div>

            <div class="form-row">
                <div class="form-label col-md-4">
                    <label>Answer</label>
                </div>

                <div class="form-input col-md-8">
                    <textarea
                    name="faq_answer[]"
                    class="parsley-validated">${item.answer}</textarea>
                </div>
            </div>

        </div>
        `);
            });
        }
        $("#black-modal-edit-child").dialog({
          modal: true,
          minWidth: 900,
          minHeight: 200,
          dialogClass: "modal-dialog",
          buttons: {
            "CLOSE": function() {
              $(this).dialog("close");
            }
          },
          show: "fadeIn"
        });
        $('.ui-widget-overlay').addClass('bg-black opacity-60');
      }
    });
  });
  //////////////////////////////edit parent////////////////////////////////////////

  $(".black-modal-edit").click(function() {
    var cid = $(this).attr("id");
    $.ajax({
      url: "fetch_parent_details.php",
      method: "POST",
      data: {
        cid: cid
      },
      dataType: "json",
      beforeSend: function() {
        $('#loading').fadeIn();
      },
      complete: function() {
        $('#loading').hide();
      },
      success: function(data) {

        $('#parent_id_edit').val(data.id);
        $('#parent_name').val(data.name);
        $('#HSC_code').val(data.hsc_code);
        $('#details').val(data.details);
        $('#description').val(data.description);
        $('#google_description').val(data.g_description);
        $('#disclaimer').val(data.disclaimer);
        $('#title').val(data.seo_title);
        $('#keywords').val(data.seo_keyword);
        $('#meta').val(data.seo_meta);
        $('#tags').val(data.tags);

        $("#black-modal-edit").dialog({
          modal: true,
          minWidth: 900,
          minHeight: 200,
          dialogClass: "modal-dialog",
          buttons: {
            "CLOSE": function() {
              $(this).dialog("close");
            }
          },
          show: "fadeIn"
        });
        $('.ui-widget-overlay').addClass('bg-black opacity-60');
      }
    });
  });
</script>
<script>
  $(document).ready(function() {

    // ==========================
    // BENEFITS
    // ==========================
    $("#add_benefit_btn").click(function() {

      let html = `
        <div class="benefit-item dynamic-box">

            <div class="text-right mb-2">
                <a href="javascript:;"
                    class="btn small bg-red remove-item">
                    Remove
                </a>
            </div>

            <div class="form-row">
                <div class="form-label col-md-4">
                    <label>Benefit Point</label>
                </div>

                <div class="form-input col-md-8">
                    <input type="text"
                        name="benefits[]"
                        class="parsley-validated"
                        placeholder="Enter benefit point">
                </div>
            </div>

        </div>`;

      $("#benefits_container").append(html);
    });



    // ==========================
    // BEST FOR
    // ==========================
    $("#add_best_for_btn").click(function() {

      let html = `
    <div class="best-for-item dynamic-box">

        <div class="text-right mb-2">
            <a href="javascript:;" class="btn small bg-red remove-item">
                Remove
            </a>
        </div>

        <div class="form-row">
            <div class="form-label col-md-4">
                <label>Title</label>
            </div>

            <div class="form-input col-md-8">
                <input type="text"
                    name="best_for_title[]"
                    class="parsley-validated"
                    placeholder="Example: Skin Care">
            </div>
        </div>

        <div class="form-row mt-2">
            <div class="form-label col-md-4">
                <label>Image</label>
            </div>

            <div class="form-input col-md-8">
                <input type="file"
                    name="best_for_icon[]"
                    class="parsley-validated"
                    accept="image/*">
            </div>
        </div>

    </div>`;

      $("#best_for_container").append(html);
    });



    // ==========================
    // COMPATIBLE
    // ==========================
    $("#add_compatible_btn").click(function() {

      let html = `
        <div class="compatible-item dynamic-box">

            <div class="text-right mb-2">
                <a href="javascript:;"
                    class="btn small bg-red remove-item">
                    Remove
                </a>
            </div>

            <div class="form-row">
                <div class="form-label col-md-4">
                    <label>Title</label>
                </div>

                <div class="form-input col-md-8">
                    <input type="text"
                        name="compatible_title[]"
                        class="parsley-validated"
                        placeholder="Example: Ultrasonic Diffuser">
                </div>
            </div>

            <div class="form-row">
                <div class="form-label col-md-4">
                    <label>Icon / Image</label>
                </div>

                <div class="form-input col-md-8">

                    <input type="file"
                        name="compatible_icon[]"
                        class="image-preview-input"
                        accept="image/*">

                    <img class="preview-img"
                        style="max-height:50px;
                        display:none;
                        margin-top:10px;">

                </div>
            </div>

        </div>`;

      $("#compatible_container").append(html);
    });



    // ==========================
    // FAQ
    // ==========================
    $("#add_faq_btn").click(function() {

      let html = `
        <div class="faq-item dynamic-box">

            <div class="text-right mb-2">
                <a href="javascript:;"
                    class="btn small bg-red remove-item">
                    Remove
                </a>
            </div>

            <div class="form-row">
                <div class="form-label col-md-4">
                    <label>Question</label>
                </div>

                <div class="form-input col-md-8">
                    <input type="text"
                        name="faq_question[]"
                        class="parsley-validated"
                        placeholder="Enter Question">
                </div>
            </div>

            <div class="form-row">
                <div class="form-label col-md-4">
                    <label>Answer</label>
                </div>

                <div class="form-input col-md-8">
                    <textarea
                        name="faq_answer[]"
                        class="parsley-validated"
                        rows="3"
                        placeholder="Enter Answer"></textarea>
                </div>
            </div>

        </div>`;

      $("#faq_container").append(html);
    });



    // ==========================
    // REMOVE ITEM
    // ==========================
    $(document).on("click", ".remove-item", function() {
      $(this).closest(".dynamic-box").remove();
    });



    // ==========================
    // IMAGE PREVIEW
    // ==========================
    $(document).on("change", ".image-preview-input", function() {

      let input = this;

      if (input.files && input.files[0]) {

        let reader = new FileReader();

        reader.onload = function(e) {

          $(input)
            .siblings(".preview-img")
            .attr("src", e.target.result)
            .show();
        };

        reader.readAsDataURL(input.files[0]);
      }
    });

  });
</script>
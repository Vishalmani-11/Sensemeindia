 <?php  
include "../db/db_connect.php"; 
include "../function/function.php";  
require_once '../admin/class.user.php';

if(isset($_POST["category_id"]))  
 {  
	 
	 $query = "SELECT id, name FROM bb_sub_categories WHERE active = 1 AND mc_id = '".$_POST["category_id"]."'";  
      if(!$result = mysqli_query($con, $query))       
    {
        echo "error".mysql_error(); 
    }
        
     $row = mysqli_num_rows($result); 
		if($row==0)
		{
die(mysqli_error($con));
die("No records found!");
		}
else{ 
          
            while ($row2 = mysqli_fetch_array($result)) 
        {
           echo '<option value="'.$row2['id'].'">'.$row2['name'].'</option>';
        }
      
}
        
	 
	 
	 /*
	 $query = "SELECT * FROM ecrm_pros_customers WHERE id = ? ";

	 if(!$stmt = $con->prepare($query))
		{
	echo "failed: (" . $con->errno . ") " . $con->error;		
		}

	 if(!$stmt->bind_param("i", $id))
{
	echo "Param pass failed: (" . $con->errno . ") " . $con->error;
}
	 
	if(!$stmt->execute())
	{
		echo $error = "Prospective customer data listing execution failed!".$con->error;		
	}
		
	 $stmt->bind_result($col1,$col2,$col3,$col4);


while ($stmt->fetch()) {
    
	$output[]=array($col1,$col2,$col3,$col4);
}
	 
	 
	 
	 if(!$qresult = $stmt->get_result())
		{
			echo $error = "Prospective customer data listing failed!".$con->error;					
		}
		$data = $qresult->fetch_assoc();
	 	
	 	echo json_encode($data); 
*/	 	
 }  
 ?>




                    
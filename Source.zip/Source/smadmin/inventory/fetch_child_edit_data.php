 <?php  
// include "../function/config.php"; 
// include "../db/db_connect.php"; 
// include "../function/function.php";  

// if(isset($_POST["cid"]))  
//  {  
// 	 //$query = "SELECT t1.*, t2.name FROM bb_products as t1 INNER JOIN bb_sub_categories as t2 ON t1.sc_id = t2.id WHERE t1.id = '".$_POST["cid"]."'";
// 	 $query = "SELECT * FROM bb_products_stock WHERE id = '".$_POST["cid"]."'";  
//       if(!$result = mysqli_query($con, $query))
//       {
//           echo "error".$con->error; exit();
//       }
//       $row = mysqli_fetch_array($result);  
//       echo json_encode($row);
	 	
//  }  


include "../function/config.php";
include "../db/db_connect.php";
include "../function/function.php";

if (isset($_POST["cid"])) {

    $cid = secure_input(
        $con,
        $_POST["cid"]
    );

    $query = "
    SELECT *
    FROM bb_products_stock
    WHERE id = ?
    ";

    $stmt =
    mysqli_prepare(
    $con,
    $query
    );

    mysqli_stmt_bind_param(
    $stmt,
    "i",
    $cid
    );

    mysqli_stmt_execute(
    $stmt
    );

    $result =
    mysqli_stmt_get_result(
    $stmt
    );

    $row =
    mysqli_fetch_assoc(
    $result
    );

    if (!$row) {

        echo json_encode([
            "status" => 0,
            "message" => "No data found"
        ]);

        exit;
    }


    // JSON decode fields
    $row['benefits_points'] =
    !empty(
    $row['benefits_points']
    )
    ?
    json_decode(
    $row['benefits_points'],
    true
    )
    :
    [];



    $row['best_for'] =
    !empty(
    $row['best_for']
    )
    ?
    json_decode(
    $row['best_for'],
    true
    )
    :
    [];



    $row['compatible_with'] =
    !empty(
    $row['compatible_with']
    )
    ?
    json_decode(
    $row['compatible_with'],
    true
    )
    :
    [];



    $row['faq_data'] =
    !empty(
    $row['faq_data']
    )
    ?
    json_decode(
    $row['faq_data'],
    true
    )
    :
    [];


    echo json_encode($row);
    exit;
}

 ?>




                    
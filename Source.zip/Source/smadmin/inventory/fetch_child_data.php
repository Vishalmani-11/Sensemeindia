<?php  
 if(isset($_POST["cid"]))  
  {  
include "../function/config.php"; 
include "../db/db_connect.php"; 
include "../function/function.php";  

$id = secure_input($con,$_POST["cid"]);  	 
     
$fupquery = "SELECT t1.*, t2.name as pname, t3.name as scname, t4.name as mcname, t6.name as psize FROM bb_products_stock as t1 INNER JOIN bb_products as t2 ON t1.parent_id = t2.id INNER JOIN bb_sub_categories as t3 ON t2.sc_id = t3.id INNER JOIN bb_categories as t4 ON t2.mc_id = t4.id INNER JOIN bb_sizes as t6 ON t1.size = t6.id WHERE t1.id = ?";
	
if(!$fupstmt = $con->prepare($fupquery))
{
	echo "query failed: (" . $con->errno . ") " . $con->error;
}

if(!$fupstmt->bind_param("i", $id))
{
	echo "Param pass failed: (" . $con->errno . ") " . $con->error;
}

	if(!$fupstmt->execute())
	{
		echo $error = "child product details execution failed!".$con->error;		
	}
		if(!$fupqresult = $fupstmt->get_result())
		{
			echo $error = "child product details listing failed!".$con->error;					
		}
	 
	 $fupqresult->num_rows;
	 
		if(!$data = $fupqresult->fetch_assoc())
		{
			echo $cdata = "error".$con->error;
		}
	 

$cdata ="";
$cdata = '<div class="content-box mrg25B">
          <h3 class="content-box-header primary-bg"> <span><strong>'.$data['pname'].'</strong></span> </h3>
          <div class="content-box-wrapper">
                   <div class="content-box">
                    <table class="table">
                        <tbody>
               
                           <tr>
                                <td width="20%" class="font-bold text-left"> Product Status:  </td>
                                <td>';
                                  
                                  if($data['active']==1) { 	$cdata .= 'Active'; } else { $cdata .="Inactive"; } 
                                  
                            $cdata .= '</td>
                            </tr>
                            
                             
                                <td width="20%" class="font-bold text-left">Date created:     </td>
                                <td>'; 
								
if($data['cdate']!=NULL) { 	$cdata .= date("l, jS\ F Y - h:i:s A",strtotime($data['cdate'])); }

			$cdata .='	</td>
                            </tr>
                 
                            <tr>
                                <td width="20%" class="font-bold text-left">Last updated: </td>
                                <td>';
								
if($data['udate']!=NULL) { 	$cdata .= date("l, jS\ F Y h:i:s A",strtotime($data['udate'])); } else { $cdata .="-"; } 
							
			$cdata .='</td> 
                            </tr>
                            
                            <tr>
                                <td width="20%" class="font-bold text-left">Main Category:  </td>
                                <td>'.$data["mcname"].'</td>
                            </tr>
                             <tr>
                                <td width="20%" class="font-bold text-left">Sub Category:  </td>
                                <td>'.$data["scname"].'</td>
                            </tr>
                     
                             <tr>
                                <td width="20%" class="font-bold text-left">MRP:  </td>
                                <td>'.$data["mrp"].'</td>
                            </tr>
                            
                             <tr>
                                <td width="20%" class="font-bold text-left">Selling Price:  </td>
                                <td>'.$data["price"].'</td>
                            </tr>
                             <tr>
                                <td width="20%" class="font-bold text-left">Size:  </td>
                                <td>'.$data["psize"].'</td>
                            </tr>
                            
                             <tr>
                                <td width="20%" class="font-bold text-left">Stock Qty:  </td>
                                <td>'.$data["qty"].'</td>
                            </tr>
                            
                            <tr>
                                <td width="20%" class="font-bold text-left">Featured Product:  </td>
                                <td>';
                                  
                                  if($data['featured']==1) { 	$cdata .= 'Yes'; } else { $cdata .="No"; } 
                                  
                            $cdata .= '</td>
                            </tr> 
                            
                                 <tr>
                                <td width="20%" class="font-bold text-left">Most Selling Product:  </td>
                                <td>';
                                  
                                  if($data['bestselling']==1) { 	$cdata .= 'Yes'; } else { $cdata .="No"; } 
                                  
                            $cdata .= '</td>
                            </tr> 
                            
                            <tr>
                                <td width="20%" class="font-bold text-left">Image 1:  </td>
                                <td>';
    
    if($data['pic1']!=NULL) { 	$cdata .= '<a href="../'.$data["pic1"].'" target="_blank"><img src="../'.$data["pic1"].'" width="10%" alt="click to view"></a>'; } else { $cdata .="-"; } 
                                
                              $cdata .=  '</td>
                            </tr>
                            
                             <tr>
                                <td width="20%" class="font-bold text-left">Image 2:  </td>
                                <td>';
    
    if($data['pic2']!=NULL) { 	$cdata .= '<a href="../'.$data["pic2"].'" target="_blank"><img src="../'.$data["pic2"].'" width="10%"  alt="click to view"></a>'; } else { $cdata .="-"; } 
                                
                              $cdata .=  '</td>
                            </tr>
                             <tr>
                                <td width="20%" class="font-bold text-left">Image 3:  </td>
                                <td>';
    
    if($data['pic3']!=NULL) { 	$cdata .= '<a href="../'.$data["pic3"].'" target="_blank"><img src="../'.$data["pic3"].'" width="10%"  alt="click to view"></a>'; } else { $cdata .="-"; } 
                                
                              $cdata .=  '</td>
                            </tr>
                             <tr>
                                <td width="20%" class="font-bold text-left">Image 4:  </td>
                                <td>';
    
    if($data['pic4']!=NULL) { 	$cdata .= '<a href="../'.$data["pic4"].'" target="_blank"><img src="../'.$data["pic4"].'" width="10%"  alt="click to view"></a>'; } else { $cdata .="-"; } 
                                
                              $cdata .=  '</td>
                            </tr>
                             <tr>
                                <td width="20%" class="font-bold text-left">Image 5:  </td>
                                <td>';
    
    if($data['pic5']!=NULL) { 	$cdata .= '<a href="../'.$data["pic5"].'" target="_blank"><img src="../'.$data["pic5"].'" width="10%"  alt="click to view"></a>'; } else { $cdata .="-"; } 
                                
                              $cdata .=  '</td>
                            </tr>
							
							 <tr>
                                <td width="20%" class="font-bold text-left">Packing Image:  </td>
                                <td>';
    
    if($data['pic7']!=NULL) { 	$cdata .= '<a href="../'.$data["pic7"].'" target="_blank"><img src="../'.$data["pic7"].'" width="10%"  alt="click to view"></a>'; } else { $cdata .="-"; } 
                                
                              $cdata .=  '</td>
                            </tr>
                            
                            <tr>
                                <td width="20%" class="font-bold text-left">Social Media banner:  </td>
                                <td>';
    
    if($data['pic6']!=NULL) { 	$cdata .= '<a href="../'.$data["pic6"].'" target="_blank"><img src="../'.$data["pic6"].'" width="10%"  alt="click to view"></a>'; } else { $cdata .="-"; } 
                                
                              $cdata .=  '</td>
                            </tr>';
     
     
                            
							$cdata .= '</tbody></table></div></div></div>';					
	echo $cdata;
 }
 
?>
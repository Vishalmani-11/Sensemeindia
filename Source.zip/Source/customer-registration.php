<?php
include "bbadmin/function/config.php"; 
?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-WWCJ4NT');</script>
<!-- End Google Tag Manager -->
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Customer Registration</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-png" href="assets/img/favicon.png">
    
    <!-- CSS 
    ========================= -->


    <!-- Plugins CSS -->
    <link rel="stylesheet" href="assets/css/plugins.css">
    
    <!-- Main Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">

    <script src="assets/js/plugins.js"></script>

<!-- Facebook Pixel Code -->
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '327668741988781');
  fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
  src="https://www.facebook.com/tr?id=327668741988781&ev=PageView&noscript=1"
/></noscript>
<!-- End Facebook Pixel Code -->
    
    
</head>

<body>
	<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-WWCJ4NT"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
  <div id="loadAjax" class="ui-front loader ui-widget-overlay bg-gray opacity-50" style="display:none">
           <img src="assets/img/loader-light.gif" alt="">
        </div>
    
<?php include("sm_header.php"); ?>
    <!--breadcrumbs area start-->
    <div class="breadcrumbs_area">
        <div class="container">   
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb_content">
                        <ul>
                            <li><a href="index.php">home</a></li>
                            <li>/</li><li>New User Registration</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>         
    </div>
    <div class="customer_login text-center">
        <div class="container">
            <?php if(isset($_GET['msg'])) echo $_GET['msg'];  ?><br>
<br>

            <div class="row">
               <!--login area start-->
                <div class="col-lg-6 col-md-6 offset-3">
                    <div class="account_form register">
                        <h2>Sign up now!</h2>
                        <form id="register" action="users/customer-registration-action.php" method="POST" onSubmit="return pacheck()">
                            <p>   
                                <label>First Name  <span>*</span></label>
                                <input type="text" name="initial" required>
                             </p>
                            <p>   
                                <label>Last Name  <span>*</span></label>
                                <input type="text" name="name" required>
                             </p>
                            <p>   
                                <label>Phone No  <span>*</span></label>
                                <input type="text" name="phone" required>
                             </p>
                            <p>   
                                <label>Email address  <span>*</span></label>
                                <input type="email" name="email1" id="email_1" required autocomplete="off">
                             </p>
                            <p>   
                                <label>Re-type Email address  <span>*</span></label>
                                <input type="email" name="email2" id="email_2" required autocomplete="off">
                             </p>
                             <p>   
                                <label>Password <span>*</span></label>
                                <input type="password" id="pass1" name="password1" pattern=".{8,}" title="8 characters minimum required" required>
                             </p>
                             <p>   
                                <label>Re-type Password <span>*</span></label>
                                <input type="password" id="pass2" name="password2" pattern=".{8,}" title="8 characters minimum required">
                             </p>
                             <p>   
                                <label>City  <span>*</span></label>
                                <input type="text" name="city" required>
                             </p>
                             <p>   
                                <label>Country  <span>*</span></label>
                                <input type="text" name="country" required>
                             </p>
                            <div class="login_submit text-center">
                                <button type="submit" name="signup">Register</button>
                            </div>
                        </form>
                        <script type="text/javascript">

function pacheck()
{	
var pa1 = $('#pass1').val();
var pa2 = $('#pass2').val();
var email1 = $('#email_1').val();
var email2 = $('#email_2').val(); 
 
    if(email1!=""&&email2!=""&&email1==email2)
        {
         if(pa1!=""&&pa2!=""&&pa1==pa2)
        {
        return true;
        }
        else
        {
        alert("Passwords not match! please try again!");		
        return false;
        }	
        }
    else
    {
    alert("Email Ids not match! please try again!");		
    return false;
    }	

}
</script>
                    </div>    
                </div>
            </div>
        </div>    
    </div>
   <?php include("bb_footer.php"); ?>

</body>

</html>
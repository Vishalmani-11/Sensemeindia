<?php
session_start();
include "smadmin/db/db_connect.php"; 
include "smadmin/function/function.php"; 
if(isset($_POST['id']))
{
	$product_id = secure_input($con,$_POST['id']);
	$action = secure_input($con,$_POST['caction']); //the action from the URL 
	$q = secure_input($con,$_POST['qty']);
}

if(isset($_POST['rid']))
{
	$product_id = secure_input($con,$_POST['rid']);
	$action = secure_input($con,$_POST['caction']); //the action from the URL 
}

if(isset($_GET['id']))
{
	$product_id = secure_input($con,$_POST['id']);
	$action = secure_input($con,$_POST['caction']); //the action from the URL 		
}

//function to check if a product exists
function productExists($product_id,$con) {
	$pquery = "SELECT * FROM bb_products_stock WHERE id = ?";
	
	if(!$pstmt = $con->prepare($pquery))
{
	echo $error = "product data listing execution failed!".$con->error;			
}

 if(!$pstmt->bind_param('i',$product_id))
 {
 	echo	$error = "product data listing execution failed!".$con->error;			
 }
 
 if(!$pstmt->execute())
	{
	echo $error = "product data deletion execution failed!".$con->error;		
	}
	
	if(!$result = $pstmt->get_result())
		{
			echo $error = "categories data listing execution failed!".$con->error;					
		}

	$prnum_of_rows = $result->num_rows;
	
		if(!$vdata = $result->fetch_assoc())
		{
			echo $error = "categories data listing execution failed!".$con->error;					
		}
	
    return $prnum_of_rows > 0;
}

//if there is an product_id and that product_id doesn't exist display an error message
if($product_id && !productExists($product_id,$con)) {
    die("Error. Product Doesn't Exist");
}

switch($action) { //decide what to do 

   case "add":
   if(ISSET($_SESSION['cartsingle'][$product_id]))
   {
	$_SESSION['cartsingle'][$product_id] = $_SESSION['cartsingle'][$product_id]+$q; //add one to the quantity of the product with id $product_id    
   }
   else
   {$_SESSION['cartsingle'][$product_id] = $q; //add one to the quantity of the product with id $product_id 
   }
    	   
	echo count($_SESSION['cartsingle'])." item";
    break;

   case "update":
   if(ISSET($_SESSION['cartsingle'][$product_id])&&$q!=0)
   {
	$_SESSION['cartsingle'][$product_id] = $q; //add one to the quantity of the product with id $product_id    
   }   
   elseif($q==0)
   {
	   unset($_SESSION['cartsingle'][$product_id]);
   }
    break;

    case "qremove":
   if(ISSET($_SESSION['cartsingle'][$product_id]))
   {
        $_SESSION['cartsingle'][$product_id]--; //remove one from the quantity of the product with id $product_id 
        if($_SESSION['cartsingle'][$product_id] == 0) unset($_SESSION['cartsingle'][$product_id]); //if the quantity is zero, remove it completely (using the 'unset' function) - otherwise is will show zero, then -1, -2 etc when the user keeps removing items. 
   }
    break;

    case "remove":
   if(ISSET($_SESSION['cartsingle'][$product_id]))
   {
	unset($_SESSION['cartsingle'][$product_id]); //delete the selected product    
   }
   if(count($_SESSION['cartsingle'])==0)
   {
	unset($_SESSION['cartsingle']); //delete the selected product    
   }
   header("location:{$_SESSION['page']}?cont=yes");
   break;

    case "empty":
        unset($_SESSION['cartsingle']); //unset the whole cart, i.e. empty the cart. 
    break;


}

?>
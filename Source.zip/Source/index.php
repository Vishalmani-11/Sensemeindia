<?php
include "smadmin//function/config.php";
include "smadmin/db/db_connect.php";
include "smadmin/function/function.php";

///////////////////////////////most selling//////////////////////////////////////////////
$na_query = "SELECT t1.id, t1.name, t1.description, t2.id, t2.mrp, t2.price, t2.pic1, t2.pic2, t2.bestselling, t2.cdate, t3.name, t4.name FROM bb_products as t1 INNER JOIN bb_products_stock as t2 ON t1.id = t2.parent_id INNER JOIN bb_categories as t3 ON t1.mc_id = t3.id INNER JOIN bb_sub_categories as t4 ON t1.sc_id = t4.id WHERE t1.active = ? AND t2.bestselling = ? GROUP BY t2.parent_id ORDER BY RAND() LIMIT 24";

$product_active = 1;
$bestselling = 1;

if (!$na_stmt = $con->prepare($na_query)) {
    echo $error = "Product data listing preparation failed 1!" . $con->error;
    exit();
}
if (!$na_stmt->bind_param('ii', $product_active, $bestselling)) {
    echo $error = "Product data listing preparation failed!" . $con->error;
    exit();
}

if (!$na_stmt->execute()) {
    echo $error = "Product data listing execution failed!" . $con->error;
    exit();
}
if (!$na_stmt->store_result()) {
    echo $error = "Product data listing execution failed!" . $con->error;
    exit();
}

$na_num_of_rows = $na_stmt->num_rows;

if ($na_num_of_rows == 0) {
    $na_error = "No parent products available";
}
///////////////////////////////featured//////////////////////////////////////////////
$query = "SELECT t1.id, t1.name, t1.description, t2.id, t2.mrp, t2.price, t2.pic1, t2.pic2, t2.featured, t2.cdate, t3.name, t4.name FROM bb_products as t1 INNER JOIN bb_products_stock as t2 ON t1.id = t2.parent_id INNER JOIN bb_categories as t3 ON t1.mc_id = t3.id INNER JOIN bb_sub_categories as t4 ON t1.sc_id = t4.id WHERE t1.active = ? AND t2.featured = ? GROUP BY t2.parent_id ORDER BY RAND() LIMIT 12";

$product_active = 1;
$featured = 1;

if (!$stmt = $con->prepare($query)) {
    echo $error = "Product data listing preparation failed 3!" . $con->error;
    exit();
}
if (!$stmt->bind_param('ii', $product_active, $featured)) {
    echo $error = "Product data listing preparation failed!" . $con->error;
    exit();
}

if (!$stmt->execute()) {
    echo $error = "Product data listing execution failed!" . $con->error;
    exit();
}
if (!$stmt->store_result()) {
    echo $error = "Product data listing execution failed!" . $con->error;
    exit();
}

$num_of_rows = $stmt->num_rows;

if ($num_of_rows == 0) {
    $error = "No parent products available";
}
///////////////////////////////essential//////////////////////////////////////////////
$es_query = "SELECT t1.id, t1.name, t1.description, t2.id, t2.mrp, t2.price, t2.pic1, t2.pic2, t2.cdate, t3.name, t4.name FROM bb_products as t1 INNER JOIN bb_products_stock as t2 ON t1.id = t2.parent_id INNER JOIN bb_categories as t3 ON t1.mc_id = t3.id INNER JOIN bb_sub_categories as t4 ON t1.sc_id = t4.id WHERE t1.active = ? AND t1.mc_id = ? GROUP BY t2.parent_id ORDER BY RAND() LIMIT 8";

$product_active = 1;
$es_mc_id = 2;

if (!$es_stmt = $con->prepare($es_query)) {
    echo $error = "Product data listing preparation failed 3!" . $con->error;
    exit();
}
if (!$es_stmt->bind_param('ii', $product_active, $es_mc_id)) {
    echo $error = "Product data listing preparation failed!" . $con->error;
    exit();
}

if (!$es_stmt->execute()) {
    echo $error = "Product data listing execution failed!" . $con->error;
    exit();
}
if (!$es_stmt->store_result()) {
    echo $error = "Product data listing execution failed!" . $con->error;
    exit();
}

$es_num_of_rows = $es_stmt->num_rows;

if ($es_num_of_rows == 0) {
    $es_error = "No parent products available";
}
?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <!-- Google Tag Manager -->
    <!--<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-PJDLLCD');</script>-->
    <!-- End Google Tag Manager -->

    <!-- Google Tag Manager -->
    <script>
        (function(w, d, s, l, i) {
            w[l] = w[l] || [];
            w[l].push({
                'gtm.start': new Date().getTime(),
                event: 'gtm.js'
            });
            var f = d.getElementsByTagName(s)[0],
                j = d.createElement(s),
                dl = l != 'dataLayer' ? '&l=' + l : '';
            j.async = true;
            j.src =
                'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
            f.parentNode.insertBefore(j, f);
        })(window, document, 'script', 'dataLayer', 'GTM-WWCJ4NT');
    </script>
    <!-- End Google Tag Manager -->
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <!--<title>Essential oil Manufacturer | High-Quality Products | Buy online-Sense Me</title>-->
   <title>Essential Oil Manufacturer & Supplier in India | SenseMe India</title>
   <meta name="description" content="SenseMe India is an essential oil manufacturer and supplier in India offering customized manufacturing, bulk supply, fragrance oils and diffuser oils for B2B industries.">
   <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="preload" as="image" href="https://sensemeindia.com/smadmin/uploads/sliders/1.jpg" fetchpriority="high">
<link rel="canonical" href="https://sensemeindia.com/" />
  <meta property="og:title" content="Essential Oil Manufacturer & Supplier in India | SenseMe India">
<meta property="og:url" content="https://sensemeindia.com/">
<meta property="og:description" content="Essential oil manufacturer and supplier in India offering customized manufacturing, fragrance oils, diffuser oils and bulk supply for B2B industries.">
<meta property="og:image" content="https://sensemeindia.com/assets/img/logo.png">

<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="Essential Oil Manufacturer & Supplier in India | SenseMe India">
<meta name="twitter:description" content="Essential oil manufacturer and supplier in India offering customized manufacturing, fragrance oils, diffuser oils and bulk supply for B2B industries.">
<meta name="twitter:image" content="https://sensemeindia.com/assets/img/logo.png">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo $url; ?>assets/img/favicon.png">

    <!-- All css here -->
    <link rel="stylesheet" href="<?php echo $url; ?>assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $url; ?>assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo $url; ?>assets/css/ie7.css">
    <link rel="stylesheet" href="<?php echo $url; ?>assets/css/plugins.css">
    <link rel="stylesheet" href="<?php echo $url; ?>assets/css/style.css">
    <link rel="stylesheet" href="<?php echo $url; ?>assets/css/menu/style.css">

    </style>
    <script src="<?php echo $url; ?>assets/js/vendor/modernizr-3.5.0.min.js"></script>
    <script src="<?php echo $url; ?>assets/js/vendor/jquery-3.2.1.min.js"></script>
    <script src="<?php echo $url; ?>assets/css/menu/script.js"></script>

    <!-- Meta Pixel Code -->
    <script>
        ! function(f, b, e, v, n, t, s) {
            if (f.fbq) return;
            n = f.fbq = function() {
                n.callMethod ?
                    n.callMethod.apply(n, arguments) : n.queue.push(arguments)
            };
            if (!f._fbq) f._fbq = n;
            n.push = n;
            n.loaded = !0;
            n.version = '2.0';
            n.queue = [];
            t = b.createElement(e);
            t.async = !0;
            t.src = v;
            s = b.getElementsByTagName(e)[0];
            s.parentNode.insertBefore(t, s)
        }(window, document, 'script',
            'https://connect.facebook.net/en_US/fbevents.js');
        fbq('init', '6089330044459882');
        fbq('track', 'PageView');
        fbq('track', 'ViewContent');
        fbq('track', 'Search');
        fbq('track', 'AddToCart');
        fbq('track', 'InitiateCheckout');
        fbq('track', 'AddPaymentInfo');
        fbq('track', 'Purchase');
        fbq('track', 'CompleteRegistration');
        fbq('track', 'Contact');
        fbq('track', 'FindLocation');
        fbq('track', 'Lead');
        fbq('track', 'SubmitApplication');
    </script>
    <noscript><img height="1" width="1" style="display:none"
            src="https://www.facebook.com/tr?id=6089330044459882&ev=PageView&noscript=1" /></noscript>
    <!-- End Meta Pixel Code -->
    <script type="application/ld+json">
{
  "@context":"https://schema.org",
  "@type":"Organization",
  "name":"SenseMe India",
  "url":"https://sensemeindia.com/",
  "logo":"https://sensemeindia.com/assets/img/logo.png",
  "description":"Manufacturer and supplier of Premium Essential Oils, Fragrance Oils, Carrier Oils and Diffuser Oils in India.",
  "sameAs":[
    "https://www.facebook.com/sensemeindia",
    "https://www.instagram.com/sensemeindia",
    "https://www.linkedin.com/company/sensemeindia"
  ]
}
</script>

<script type="application/ld+json">
{
  "@context":"https://schema.org",
  "@type":"WebSite",
  "url":"https://sensemeindia.com/",
  "name":"SenseMe India",
  "potentialAction":{
    "@type":"SearchAction",
    "target":"https://sensemeindia.com/search.php?search={search_term_string}",
    "query-input":"required name=search_term_string"
  }
}
</script>
</head>


<body>

    <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-W82ZW9Q7"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
    <?php include("sm_header.php"); ?>

    <!-- Order Success Message -->
    <?php if (isset($_GET['order_success']) && $_GET['order_success'] == 1): ?>
        <div style="background: #d1e7dd; border: 1px solid #badbcc; color: #0f5132; padding: 15px 20px; margin: 0; text-align: center; font-size: 16px; font-weight: 500;">
            ✓ Your order has been placed successfully! You will receive an order confirmation email shortly.
        </div>
    <?php endif; ?>

    <div class="ht-hero-section fix ht-hero-two">
        <div class="ht-hero-slider">

            <div class="ht-single-slide" style="background-image: url(smadmin/uploads/sliders/1.jpg)">
            </div>
        </div>
    </div>


    <div class="product-area bg-1 pt-110 pb-80 product-two-area">
        <div class="container">
            <div class="section-title text-center">
                <div class="section-img d-flex justify-content-center mhide">
                    <img src="assets/img/icon/title.png" alt="">
                </div>
                <h2><span>Most </span>selling products</h2>
            </div>
        </div>
        <div class="container pt-50">
            <div class="tab-content text-center">
                <div class="tab-pane active show fade" id="tab1" role="tabpanel">
                    <div class="product-carousel">

                        <?php
                        if (isset($na_error)) {
                        ?>
                            <a href="javascript:;"><?php echo $na_error; ?></a>
                            <?php
                        } else {
                            $sn = 0;
                            $na_stmt->bind_result($parent_id, $name, $description, $product_id, $mrp, $price, $pic1, $pic2, $featured, $cdate, $mc_name, $sc_name);
                            while ($na_stmt->fetch()) {
                                $product_display_url = URL_trim($name);
                                $home_mcname_url = URL_trim($mc_name);
                                $home_scname_url = URL_trim($sc_name);
                                $sn += 1;
                                if (!$even = ($sn % 2 == 0)) {
                            ?>
                                    <div class="custom-col">

                                    <?php } ?>

                                    <div class="single-product-item">
                                        <div class="product-image">

                                            <a href="<?php echo $url; ?><?php echo $home_mcname_url; ?>/<?php echo $home_scname_url; ?>/<?php echo $product_display_url; ?>/<?php echo $product_id; ?>/" target="_blank"> <img src="<?php echo $url; ?>smadmin/<?php echo $pic1; ?>" alt="">
                                            </a>
                                            <div class="double_base">
                                                <?php $price_class = "product_sale";
                                                if ($price != 0 && $price < $mrp) {
                                                    $discount = round(($mrp - $price) / $mrp * 100); ?>

                                                    <?php if ($discount >= 25) { ?>
                                                        <!-- Ganesan -->
                                                        <!-- <div class="label_product">
                                                                <span>Hot Deal</span>
                                                            </div> -->
                                                        <!-- <div class="<?php echo $price_class; ?> top_55">
                                                            <span>- <?php echo $discount; ?>% Off</span>
                                                        </div> -->
                                                    <?php } else { ?>

                                                        <!-- <div class="<?php echo $price_class; ?>">
                                                            <span>- <?php echo $discount; ?>% Off</span>
                                                        </div> -->
                                                        <!-- Ganesan -->
                                                <?php }
                                                } ?>

                                            </div>
                                        </div>
                                        <div class="product-text">
                                            <h5><a href="<?php echo $url; ?><?php echo $home_mcname_url; ?>/<?php echo $home_scname_url; ?>/<?php echo $product_display_url; ?>/<?php echo $product_id; ?>/" target="_blank"> <?php echo $name; ?></a></h5>
                                            <div class="pro-price">

                                                <?php if ($price != 0 && $price < $mrp) { ?>
                                                    <span class="new-price">&#x20b9; <?php echo $price; ?></span>
                                                    <span class="old-price">MRP &#x20b9;<?php echo $mrp; ?></span>
                                                <?php } else { ?>
                                                    <span class="new-price">&#x20b9;<?php echo $price; ?></span>
                                                <?php } ?>


                                            </div>

                                            <?php if ($price != 0 && $price < $mrp) { ?>
                                                <div class="pro-price save-tag">
                                                    <!-- Ganesan -->
                                                    <!-- You save:<strong> &#x20b9;<?php echo $mrp - $price; ?></strong> (<?php echo $discount; ?>% Off) -->
                                                    <!-- Ganesan -->
                                                </div> <?php } ?>

                                            <a href="<?php echo $url; ?><?php echo $home_mcname_url; ?>/<?php echo $home_scname_url; ?>/<?php echo $product_display_url; ?>/<?php echo $product_id; ?>/" target="_blank" class="mt-10"><button type="submit" class="submit-btn default-btn" name="signup">Buy Now</button> </a>

                                        </div>
                                    </div>

                                    <?php
                                    if ($even = ($sn % 2 == 0)) {
                                    ?>
                                    </div>

                                <?php } ?>


                        <?php }
                        } ?>


                    </div>
                </div>



            </div>
        </div>

    </div>
    <div class="shop-banner-area pt-60 pb-60">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="shop-banner-img">
                        <a href="<?php echo $url; ?>Diffuser-Oil/Spiritual-Diffuser-Oil/2/7/" target="_blank"><img src="assets/img/banner/2.jpg" alt=""></a>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="shop-banner-img">

                        <a href="<?php echo $url; ?>Diffuser-Oil/Relaxation-Stress-Relief-Diffuser-Oil/2/3/" target="_blank"><img src="assets/img/banner/3.jpg" alt=""></a>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="shop-banner-img">
                        <a href="<?php echo $url; ?>Diffuser-Oil/Sleep-Diffuser-Oil/2/4/" target="_blank"><img src="assets/img/banner/4.jpg" alt=""></a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="product-area bg-1 pt-110 pb-80 product-two-area">
        <div class="container">
            <div class="section-title text-center">
                <div class="section-img d-flex justify-content-center mhide">
                    <img src="assets/img/icon/title.png" alt="">
                </div>
                <h2><span>Most </span>Featured Products</h2>
            </div>
        </div>
        <div class="container pt-50">
            <div class="tab-content text-center">
                <div class="tab-pane active show fade" id="tab1" role="tabpanel">
                    <div class="product-carousel">
                        <?php
                        if (isset($error)) {
                        ?>
                            <a href="javascript:;"><?php echo $error; ?></a>
                            <?php
                        } else {
                            $sn = 0;
                            $product_display_url = $home_mcname_url = $home_scname_url = '';
                            $stmt->bind_result($parent_id, $name, $description, $product_id, $mrp, $price, $pic1, $pic2, $featured, $cdate, $mc_name, $sc_name);
                            while ($stmt->fetch()) {
                                $product_display_url = URL_trim($name);
                                $home_mcname_url = URL_trim($mc_name);
                                $home_scname_url = URL_trim($sc_name);
                                $sn += 1;
                                if (!$even = ($sn % 2 == 0)) {
                            ?>
                                    <div class="custom-col">
                                    <?php } ?>
                                    <div class="single-product-item">
                                        <div class="product-image">
                                            <a href="<?php echo $url; ?><?php echo $home_mcname_url; ?>/<?php echo $home_scname_url; ?>/<?php echo $product_display_url; ?>/<?php echo $product_id; ?>/" target="_blank"> <img src="<?php echo $url; ?>smadmin/<?php echo $pic1; ?>" alt="">
                                            </a>
                                            <div class="double_base">
                                                <?php $price_class = "product_sale";
                                                if ($price != 0 && $price < $mrp) {
                                                    $discount = round(($mrp - $price) / $mrp * 100); ?>

                                                    <?php if ($discount >= 25) { ?>
                                                        <!-- Ganesan -->
                                                        <!-- <div class="label_product">
                                                            <span>Hot Deal</span>
                                                        </div>
                                                        <div class="<?php echo $price_class; ?> top_55">
                                                            <span>- <?php echo $discount; ?>% Off</span>
                                                        </div> -->
                                                    <?php } else { ?>

                                                        <!-- <div class="<?php echo $price_class; ?>">
                                                            <span>- <?php echo $discount; ?>% Off</span>
                                                        </div> -->
                                                        <!-- Ganesan -->
                                                <?php }
                                                } ?>
                                            </div>
                                        </div>
                                        <div class="product-text">
                                            <h5> <a href="<?php echo $url; ?><?php echo $home_mcname_url; ?>/<?php echo $home_scname_url; ?>/<?php echo $product_display_url; ?>/<?php echo $product_id; ?>/" target="_blank"><?php echo $name; ?></a></h5>
                                            <div class="pro-price">
                                                <?php if ($price != 0 && $price < $mrp) { ?>
                                                    <span class="new-price">&#x20b9; <?php echo $price; ?></span>
                                                    <span class="old-price">MRP &#x20b9;<?php echo $mrp; ?></span>
                                                <?php } else { ?>
                                                    <span class="new-price">&#x20b9;<?php echo $price; ?></span>
                                                <?php } ?>
                                            </div>
                                            <?php if ($price != 0 && $price < $mrp) { ?>
                                                <div class="pro-price save-tag">
                                                    <!-- Ganesan -->
                                                    <!-- You save: <strong>&#x20b9;<?php echo $mrp - $price; ?> </strong>(<?php echo $discount; ?>% Off) -->
                                                    <!-- Ganesan -->
                                                </div> <?php } ?>
                                            <a href="<?php echo $url; ?><?php echo $home_mcname_url; ?>/<?php echo $home_scname_url; ?>/<?php echo $product_display_url; ?>/<?php echo $product_id; ?>/" target="_blank" class="mt-10"><button type="submit" class="submit-btn default-btn" name="signup">Buy Now</button> </a>
                                        </div>
                                    </div>
                                    <?php
                                    if ($even = ($sn % 2 == 0)) {
                                    ?>
                                    </div>
                                <?php } ?>
                        <?php }
                        } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="shop-banner-area pt-60 pb-60 bg_white">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <div class="shop-banner-img">
                        <a href="<?php echo $url; ?>Fragrance-Oils/Fragrance-Oils-for-Soap-Making/3/14/" target="_blank"><img src="assets/img/banner/5.jpg" alt=""></a>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="shop-banner-img">
                        <a href="<?php echo $url; ?>Fragrance-Oils/Fragrance-Oils-for-Agarbatti-Making/3/15/" target="_blank"><img src="assets/img/banner/6.jpg" alt=""></a>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="shop-banner-img">
                        <a href="<?php echo $url; ?>Fragrance-Oils/Fragrance-Oils-for-Candle-Making/3/16/" target="_blank"><img src="assets/img/banner/candle-fragrance-oils.jpg" alt="candle fragrance oils"></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="banner-area banner-one-area fix pt-60 pb-80 bg_white">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 d-flex align-items-center">
                    <div class="banner-text pt-15">
                        <h3>Premium Essential Oils for Manufacturers & Bulk Buyers</h3>
                      <h1>Essential Oils <span class="green">Manufacturer &amp; Supplier in India</span></h1>
                        <h2>
                           <span>Natural Essential Oils, Fragrance Oils & Carrier Oils</span>
                        </h2>
                     <p>SenseMe India manufactures and supplies premium essential oils, fragrance oils, carrier oils and diffuser oils for soap making, candle making, cosmetics, aromatherapy, incense and personal care industries across India.</p>
                     <a href="<?php echo $url; ?>Diffuser-Machines/Ultrasonic-Diffuser-Machines/5/21/" target="_blank" class="default-btn">Shop Now</a>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="banner-image-wrapper">
                        <div class="banner-image">
                            <img src="assets/img/banner/1.jpg" alt="">
                        </div>
                        <div class="banner-image-text">
                            <h4>Premium Essential Oils for Industrial Applications</h4>
                           <p>Our essential oils are widely used in soap making, candle making, cosmetics, aromatherapy, incense manufacturing, personal care products and wellness applications.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="product-area pt-100 product-four-area bg-color pb-60">
        <div class="container">
            <div class="section-title section-title-four text-center mb-40">
                <h4>To be Calm &amp; Stress free</h4>
                <h2><span>Most </span>Essential products</h2>
            </div>
        </div>
        <div class="container-fluid">
            <div class="product-carousel-two text-center">

                <?php
                if (isset($es_error)) {
                ?>
                    <a href="javascript:;"><?php echo $es_error; ?></a>
                    <?php
                } else {
                    $sn = 0;
                    $product_display_url = $home_mcname_url = $home_scname_url = '';

                    $es_stmt->bind_result($parent_id, $name, $description, $product_id, $mrp, $price, $pic1, $pic2, $cdate, $mc_name, $sc_name);
                    while ($es_stmt->fetch()) {
                        $product_display_url = URL_trim($name);
                        $home_mcname_url = URL_trim($mc_name);
                        $home_scname_url = URL_trim($sc_name);
                    ?>
                        <div class="custom-col">
                            <div class="single-product-item">
                                <div class="product-image">
                                    <a href="<?php echo $url; ?><?php echo $home_mcname_url; ?>/<?php echo $home_scname_url; ?>/<?php echo $product_display_url; ?>/<?php echo $product_id; ?>/" target="_blank"> <img src="<?php echo $url; ?>smadmin/<?php echo $pic1; ?>" alt="">
                                    </a>

                                    <div class="double_base">


                                        <?php $price_class = "product_sale";
                                        if ($price != 0 && $price < $mrp) {
                                            $discount = round(($mrp - $price) / $mrp * 100); ?>

                                            <?php if ($discount >= 25) { ?>
                                                <!-- Ganesan -->
                                                <!-- <div class="label_product">
                                                    <span>Hot Deal</span>
                                                </div>
                                                <div class="<?php echo $price_class; ?> top_55">
                                                    <span>- <?php echo $discount; ?>% Off</span>
                                                </div> -->
                                            <?php } else { ?>

                                                <!-- <div class="<?php echo $price_class; ?>">
                                                    <span>- <?php echo $discount; ?>% Off</span>
                                                </div> -->
                                                <!-- Ganesan -->
                                        <?php }
                                        } ?>


                                    </div>

                                </div>
                                <div class="product-text">
                                    <h5> <a href="<?php echo $url; ?><?php echo $home_mcname_url; ?>/<?php echo $home_scname_url; ?>/<?php echo $product_display_url; ?>/<?php echo $product_id; ?>/" target="_blank"><?php echo $name; ?></a></h5>
                                    <div class="pro-price">

                                        <?php if ($price != 0 && $price < $mrp) { ?>
                                            <span class="new-price">&#x20b9; <?php echo $price; ?></span>
                                            <span class="old-price clear">MRP &#x20b9;<?php echo $mrp; ?>
                                            <?php } else { ?>
                                                <span class="new-price">&#x20b9;<?php echo $price; ?></span>
                                            <?php } ?>

                                    </div>
                                    <?php if ($price != 0 && $price < $mrp) { ?>
                                        <div class="pro-price save-tag">
                                            <!-- Ganesan -->
                                            <!-- You save: <strong>&#x20b9;<?php echo $mrp - $price; ?></strong> (<?php echo $discount; ?>% Off) -->
                                            <!-- Ganesan -->
                                        </div> <?php } ?>

                                    <a href="<?php echo $url; ?><?php echo $home_mcname_url; ?>/<?php echo $home_scname_url; ?>/<?php echo $product_display_url; ?>/<?php echo $product_id; ?>/" target="_blank" class="mt-10"><button type="submit" class="submit-btn default-btn" name="signup">Buy Now</button> </a>

                                </div>
                            </div>
                        </div>

                <?php }
                } ?>

            </div>
        </div>
    </div>

    <div class="testimonial-area pt-110 pb-95 bg-white mhide">
        <div class="container">
            <div class="testimonial-slider-wrapper">
                <div class="text-carousel text-center">
                    <div class="slider-text">
                        <span class="testi-quote">
                            <img src="assets/img/icon/quote.png" alt="">
                        </span>
                        <p>Initially, I bought an ultrasonic aroma diffuser from him. Wooow! Quality of diffuser is outstanding. I swear, nowhere else we can get such a product. It so elegant and comes with a REMOTE CONTROL. The main part is its pricing. Highly competitive for such a world class diffuser. Many thanks for additional support for selling me THERAPEUTIC GRADE 👌 ESSENTIAL OILS at a best rate. REALLY EXCEEDING THE MARK 👍👍👍👍👍 iam highly satisfied and this is a highly recommended place for all essential oil requirements. Vazhga vazhamudan 🙏</p>
                    </div>
                    <div class="slider-text">
                        <span class="testi-quote">
                            <img src="assets/img/icon/quote.png" alt="">
                        </span>
                        <p>We bought aroma diffuser in 3 different flavors. The quality is good and value for money. We recommend all to buy this product.</p>
                    </div>
                    <div class="slider-text">
                        <span class="testi-quote">
                            <img src="assets/img/icon/quote.png" alt="">
                        </span>
                        <p>Genuine and outstanding quality. Good at fulfilling the customer needs (oil blending).The aroma fragrance which i received are awesome...</p>
                    </div>

                    <div class="slider-text">
                        <span class="testi-quote">
                            <img src="assets/img/icon/quote.png" alt="">
                        </span>
                        <p>I have purchased diffuser and essential oils from Mylal Exports. It's an amazing product, a must buy for every house. Affordable, it's worth every penny spent on it.
                            Diffuser was provided with replacement and service warranty, which is very convenient. The quality of oils is amazing and pure. You can choose to buy organic or non organic essential oils.</p>
                    </div>
                    <div class="slider-text">
                        <span class="testi-quote">
                            <img src="assets/img/icon/quote.png" alt="">
                        </span>
                        <p>Excellent Quality, perfect product delivery timing. Business relationship is good.</p>
                    </div>
                    <div class="slider-text">
                        <span class="testi-quote">
                            <img src="assets/img/icon/quote.png" alt="">
                        </span>
                        <p>I ordered 32 Essential oils. Today i got as soon as i opened my courier really i am cloud nine. Bcoz each and every product packed well without any leakage. For lesser quantity products they pack another one box for safety and lowest amount 1ml-5ml they put into a box which fully unmovable and not leakage. And also wrap in cover. And they send In DTDC courier thats also good service. Thank you so much. I am very happy for these products and excellent packing😍😍😍😍.</p>
                    </div>
                </div>
                <div class="image-carousel">
                    <div class="testi-img">
                        <h4>saravana kumar</h4>
                    </div>
                    <div class="testi-img">
                        <h4>Leo Robinson</h4>
                    </div>
                    <div class="testi-img">
                        <h4>focus industries</h4>
                    </div>

                    <div class="testi-img">
                        <h4>Kavya K</h4>
                    </div>
                    <div class="testi-img">

                        <h4>Aruachalam Dhamodaran</h4>
                    </div>
                    <div class="testi-img">

                        <h4>Hasina Shaj</h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include("sm_footer.php"); ?>
    <script src="<?php echo $url; ?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo $url; ?>assets/js/popper.min.js"></script>
    <script src="<?php echo $url; ?>assets/js/ajax-mail.js"></script>
    <script src="<?php echo $url; ?>assets/js/plugins.js"></script>
    <script src="<?php echo $url; ?>assets/js/main.js"></script>
</body>

<?php

header("Content-Type: application/xml; charset=UTF-8");

require_once __DIR__ . '/smadmin/db/db_connect.php';
require_once __DIR__ . '/smadmin/function/function.php';

$base_url = 'https://sensemeindia.com';

echo '<?xml version="1.0" encoding="UTF-8"?>';
echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';

echo '<url><loc>' . htmlspecialchars(
    $base_url . '/',
    ENT_XML1,
    'UTF-8'
) . '</loc></url>';

$sql = "
    SELECT
        t2.id,
        t1.name AS pname,
        t3.name AS scname,
        t4.name AS mcname
    FROM bb_products AS t1
    INNER JOIN bb_products_stock AS t2
        ON t1.id = t2.parent_id
    INNER JOIN bb_sub_categories AS t3
        ON t1.sc_id = t3.id
    INNER JOIN bb_categories AS t4
        ON t1.mc_id = t4.id
    WHERE t1.active = 1
      AND t2.id > 0
    GROUP BY
        t2.id,
        t1.name,
        t3.name,
        t4.name
    ORDER BY t1.id ASC
";

$result = $con->query($sql);

if ($result) {
    while ($row = $result->fetch_assoc()) {

        $url = build_product_url(
            $base_url,
            $row['mcname'],
            $row['scname'],
            $row['pname'],
            (int)$row['id']
        );

        echo '<url><loc>' .
             htmlspecialchars(
                 $url,
                 ENT_XML1,
                 'UTF-8'
             ) .
             '</loc></url>';
    }
}

echo '</urlset>';

?>
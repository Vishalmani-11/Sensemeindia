<?php
 if(isset($_GET["order_id"]))  
  { 
	 extract($_GET);
require('../pdf/html2pdf.php');
include "../smadmin/db/db_connect.php"; 
include "../smadmin/function/function.php";

$pdf=new PDF();
$pdf->AliasNbPages();
$pdf->SetTitle("invoice");
////add page page automatically for its true parameter

$pdf->SetAutoPageBreak(true, 15);
$pdf->AddPage();
//add images or logo which you want
$pdf->Image('../assets/img/logo/logo.png',85,15,50);
//set font style
$pdf->SetFont('Arial','B',14);
//assign the form post value in a variable and pass it.
     
$order_id = secure_input($con,$_GET["order_id"]); 
/////////////////////////////order details/////////////////////////////////////     
$query = "SELECT * from bb_orders WHERE id = ? ORDER BY orderdate DESC";

if(!$rstmt = $con->prepare($query))
{
	echo $error = "order details preparation failed!".$con->error; exit();
}
	if(!$rstmt->bind_param("i", $order_id))
{
	echo "Param pass failed: (" . $con->errno . ") " . $con->error;exit();
}
	
	if(!$rstmt->execute())
	{
		echo $error = "order details execution failed!".$con->error;	exit();	
		
	}    
    
    if(!$qresult = $rstmt->get_result())
		{
			$error = "Product data listing failed!".$con->error;	exit();				
		}
    else
    {
        $data = $qresult->fetch_assoc();
		$pending_order_id = $data['pending_id'];	
    }

/////////////////////////////product details//////////////////////////////////////////
   
	
$oquery = "SELECT t1.id, t1.orderid, t1.pid, t1.sku, t1.hsc_code, t1.name, t1.category, t1.sub_category, t1.product_type, t1.picture, t1.color, t1.size, t1.qty, t1.price, t1.cost, t1.reviewed, t2.parent_id FROM bb_order_products as t1 INNER JOIN bb_products_stock as t2 ON t1.pid = t2.id WHERE t1.orderid = ?";

	
if(!$orstmt = $con->prepare($oquery))
{
	echo $error = "order details preparation failed!".$con->error;exit();
}
	if(!$orstmt->bind_param("i", $pending_order_id))
{
	echo "Param pass failed: (" . $con->errno . ") " . $con->error;exit();
}
	
	if(!$orstmt->execute())
	{
		echo $error = "order details execution failed!".$con->error;	exit();	
		
	}
	
	if(!$orstmt->store_result())
		{
			echo $error = "order listing execution failed!".$con->error;	exit();				
		}
	
	
	$ornum_of_rows = $orstmt->num_rows;

	if($ornum_of_rows==0)
{
	$ornum_error = "No products available";		
}
	
/////////////////////////////////////////invoice header/////////////////////////////////////////     

$header='INVOICE/CASH MEMO';
$pdf->SetFont('Arial','B',16);
$pdf->SetY(40);     
$pdf->Cell(200,7,$header,0,1,'C');
$pdf->SetFont('Arial','B',10);
$pdf->SetTextColor(0, 0, 0);
$pdf->Ln();
$pdf->Ln();     
$company_address = "MYLAL EXPORTS \nNo. 38, Machampalayam road, \nSundarapuram, Coimbatore, \nTamil Nadu 641607. \nGST Registration No: 33AMDPM8320N1ZW";     
$pdf->MultiCell(95,7,"Sold by",0,'L',false); 
$pdf->SetTextColor(92, 92, 92);     
$pdf->MultiCell(95,7,$company_address,0,'L',false); 
$pdf->SetXY(105,60);     
$order_details = "Invoice date: ".date('D, dS M, Y', strtotime($data['orderdate']))."\n Invoice# :".$order_id;     
$pdf->MultiCell(95,7,$order_details,0,'R',false); 
$pdf->Line(10, 115, 200, 115);     
$pdf->SetXY(10,120);       
$billing = "Billing Address:\n".$data['fname']." ".$data['lname'].", ".$data['address'];     
$pdf->MultiCell(95,7,$billing,0,'L',false);      
$pdf->SetXY(105,120);              
$delivery = "Delivery Address:\n".$data['fname']." ".$data['lname'].", ".$data['address'];     
$pdf->MultiCell(95,7,$delivery,0,'R',false);  
$pdf->Ln();          
$pdf->SetFillColor(0,0,0);
$pdf->SetTextColor(255,255,255);
$pdf->Cell(190,7,"ORDER SUMMARY",1,1,'C', true);  
$pdf->SetTextColor(0, 0, 0);     
   $cdata ='<table border="1"><tr><td width="50" height="60">S.No</td><td width="490" height="60">Description</td><td width="80" height="60">Unit Price</td><td width="50" height="60">Qty</td><td width="90" height="60">Total Price</td></tr>';

     $pdf->WriteHTML("$cdata");  
     
    $pdf->SetTextColor(145, 145, 145);  
	
     $cdata = "";
        $sn = 0;

	$orstmt->bind_result($id, $orderid, $pid, $sku, $hsc, $name, $category, $sub_category, $product_type, $picture, $color, $size, $qty, $price, $cost, $reviewed, $parent_id);
	while ($orstmt->fetch()) 
	{
			$sn = 	$sn + 1;
		$name = ucwords($name);
	
    
		$cdata .='<tr><td width="50" height="50">'.$sn.'</td><td width="490" height="50">'.$name.'('.$sku.')HSC: '.$hsc.'</td>';$cdata .='</td><td width="80" height="50">Rs '.bcdiv($price,1,2).'</td><td width="50" height="50">'.$qty.'</td><td width="90" height="50">Rs '.bcdiv($total = $qty * $price,1,2).'</td></tr>';
                    } 
     
         $pdf->WriteHTML("$cdata");  
     
    $pdf->SetTextColor(0, 0, 0); 
     
     $net_price = $data['mc_gross']*100/118;
     
     $gst = $data['mc_gross'] - $net_price;
     
     $gst2 = $gst/2;
     
    $cdata ='<tr align="center"><td width="670" height="50" colspan="5" align="right">SHIPPING:</td><td width="90" height="50">'; 
     if($data['shipping']>0) { $cdata .='Rs '.$data['shipping']; } else { $cdata .='Free'; }

$cdata .='</td></tr>';     
	 
	 if($COD)
{
$cdata .='<tr><td width="670" height="50"><strong>COD Charges:</strong></td><td width="90" height="50"><strong>Rs 90.00</strong></td></tr>';      	
}
	 
$cdata .='<tr><td width="670" height="50"><strong>TOTAL:(GST inclusive)</strong></td><td width="90" height="50"><strong>Rs '.bcdiv($data['mc_gross'],1,2).'</strong></td></tr>'; 
     
if(strtolower($state) == 'tamil nadu')
{
$cdata .='<tr><td width="760" height="50" colspan="5" >Total GST: Rs '.bcdiv($gst,1,2).'(CGST 9%: Rs '.bcdiv($gst2,1,2).' | SGST 9%: Rs '.bcdiv($gst2,1,2).'</td></tr>';      	
}
	 else
	 {
$cdata .='<tr><td width="760" height="50" colspan="5" >Total IGST 18%: Rs '.bcdiv($gst,1,2).'</td></tr>';      		 
	 }
 
     
$cdata .='</table> ';

     //echo $cdata;
	 				
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////     

/*
$cdata .='<table border="1">
<tr>    <td width="250" height="50">Sur Name: '.$data['payment_status'].'</td><td width="250" height="50">Title: '.$data['payment_status'].'</td><td width="250" height="50">Given names: '.$data['payment_status'].'</strong></td></tr>
    <tr><td width="250" height="50">Gender: '.$data['payment_status'].'</td><td width="250" height="50">Gender Diverse: '.$data['payment_status'].'</td><td width="250" height="50">DOB: '.$data['payment_status'].'</td></tr>
    <tr><td width="375" height="50">Country of Birth: '.$data['payment_status'].'</td><td width="375" height="50">Place of Birth: '.$data['payment_status'].'</td></tr>
	<tr></table>';
*/


//Write HTML to pdf file and output that file on the web browser.

$pdf->WriteHTML("$cdata");  
$pdf->SetFont('Arial','B',6);
$pdf->Output('D','SM_invoice_copy.pdf');
     
     
 }
?>


﻿<?php
include "../config/config.php"; 
include "session_user.php"; 
include "../rrgadmin/db/db_connect.php"; 
require_once '../rrgadmin/admin/class.user_2.php';
include "../rrgadmin/function/function.php";

////////////////////////////////////////////////////////

$query = "SELECT id, bookingDate, propertyName, checkIn, bookingStatus FROM rrg_booking ORDER BY bookingDate DESC";

if(!$stmt = $con->prepare($query))
	{
		$error = "booking listing failed!".$con->error;		
		
	}

	if(!$stmt->execute())
	{
		$error = "booking listing failed!".$con->error;		
		
	}
		if(!$stmt->store_result())
		{
			$error = "booking listing failed!".$con->error;					
		}
	
			$num_of_rows = $stmt->num_rows;

if($num_of_rows==0)
{
	$error = "No booking available";		
}


////////////////////////////////////////////

?>
<!DOCTYPE html>
<!--[if IE 8]><html class="no-js lt-ie9" lang="en"> <![endif]-->
<!--[if gt IE 8]>
<!--><html class="no-js" lang="en"><!--<![endif]-->
<head>

	<meta charset="utf-8">
	<title>Hotels in tirupati, Rooms Photo Gallery</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="theme-color" content="#212121"/>
    <meta name="msapplication-navbutton-color" content="#212121"/>
    <meta name="apple-mobile-web-app-status-bar-style" content="#212121"/>
	<link href="https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet"/>
	<link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i&amp;subset=cyrillic,cyrillic-ext,greek,greek-ext,latin-ext,vietnamese" rel="stylesheet">
	<link rel="stylesheet" href="../css/bootstrap.min.css"/>
	<link rel="stylesheet" href="../css/font-awesome.min.css"/>
	<link rel="stylesheet" href="../css/ionicons.min.css"/>
	<link rel="stylesheet" href="../css/datepicker.css"/>
	<link rel="stylesheet" href="../css/jquery.fancybox.min.css"/>
	<link rel="stylesheet" href="../css/owl.carousel.css"/>
	<link rel="stylesheet" href="../css/owl.transitions.css"/>
	<link rel="stylesheet" href="../css/style.css"/>
	<link rel="stylesheet" href="../css/colors/color.css"/>
	<link rel="icon" type="image/png" href="../favicon.png">
	<link rel="apple-touch-icon" href="../apple-touch-icon.png">
	<link rel="apple-touch-icon" sizes="72x72" href="../apple-touch-icon-72x72.png">
	<link rel="apple-touch-icon" sizes="114x114" href="../apple-touch-icon-114x114.png">
	
	
</head>
<body>	

<!--	<div class="loader">
		<div class="loader__figure"></div>
	</div>-->
	<svg class="hidden">
		<svg id="icon-nav" viewBox="0 0 152 63">
			<title>navarrow</title>
			<path d="M115.737 29L92.77 6.283c-.932-.92-1.21-2.84-.617-4.281.594-1.443 1.837-1.862 2.765-.953l28.429 28.116c.574.57.925 1.557.925 2.619 0 1.06-.351 2.046-.925 2.616l-28.43 28.114c-.336.327-.707.486-1.074.486-.659 0-1.307-.509-1.69-1.437-.593-1.442-.315-3.362.617-4.284L115.299 35H3.442C2.032 35 .89 33.656.89 32c0-1.658 1.143-3 2.552-3H115.737z"/>
		</svg>
	</svg>

	<br>
<?php include("../rr_header.php"); ?>
	
	<div class="section big-15-height over-hide z-bigger">
	
		<div class="parallax parallax-top" style="background-image: url('../img/3.jpg')"></div>
		<div class="dark-over-pages"></div>
	
		<div class="hero-center-section pages">
			<div class="container">
				
			</div>
		</div>
	</div>
	<div class="section padding-top-bottom over-hide background-grey">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-md-8 align-self-center">
					<div class="subtitle with-line text-center mb-4">My Bookings</div>
					<h3 class="text-center padding-bottom-small">Welcome, <?php echo $_SESSION['userName']; ?>!</h3>
				</div>
				<div class="section clearfix"></div>
				<?php include("left.php"); ?>
				<div class="col-lg-8 mt-8 mt-lg-0">
						<?php if(isset($error))
{
	
	?>
				
					<div class="room-box background-white">
						<div class="room-box-in">
	<h5 class="mb-3"><?php echo $error; ?></h5>			</div>
					</div>
				
							<?php } else { ?>
							
      <?php 
	$sn = 0;
	$stmt->bind_result($id, $bookingDate, $propertyName, $checkin, $status);
	while ($stmt->fetch()) 
	{
		

	?>							
					<div class="room-box background-white mb-4">
						<div class="room-box-in">
							
							<div class="col-md-12 mt-4">
					
						<div class="room-per">
							<span class="blue f28"><?php echo $status; ?></span>
						</div>
					
						<div class="room-box-in">
							<h5 class="purple"><?php echo $propertyName; ?></h5>
							<p> Booked on: <?php echo date("d-m-Y",strtotime($bookingDate)); ?> </p>
							<div class="room-icons mt-4 pt-4">
								<span class="blue f28">Check-in: <?php echo date("D jS, M Y",strtotime($checkin)); ?></span>
								<a href="booking_details.php?id=<?php echo $id; ?>" class="ml-4">Manage Booking</a>
								<a href="print_bill.php?id=<?php echo $id; ?>" target="_blank">Print Voucher</a>
							</div>
						</div>
					
				</div>
									</div>
					</div>
				
							<div class="section clearfix"></div>
							
		<?php } } ?>					
				
			</div>		
			</div>	
		</div>		
	</div>

	<div class="section padding-top-bottom-big over-hide">
		<div class="parallax" style="background-image: url('../img/cta.jpg')"></div>
		<div class="section z-bigger">		
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="row justify-content-center">
							<div class="col-md-12 col-xl-12 px-sm-0">
								<div class="col-md-12 align-self-center">
					<div class="subtitle with-line text-center mb-4 color-white">Neat, Clean &amp; Calm</div>
					<h3 class="text-center color-white">Are you looking for homely stay in Tirupati?</h3>
										
				</div>
							</div>
							
						</div>	
					</div>
					
					<div class="col-md-12 text-center pt-3">
									<a class="mt-1 btn btn-primary" href="javscript:">book now</a>
								</div>
					
					
				</div>
			</div>					
		</div>
	</div>
	
	<?php include("../rr_footer.php"); ?>
	
</body>
</html>
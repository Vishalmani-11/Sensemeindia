<?php
include "session_user.php"; 
include "../smadmin/function/config.php";  
include "../smadmin/db/db_connect.php"; 
require_once '../smadmin/admin/class.user_2.php';
include "../smadmin/function/function.php";
?>

<!doctype html>
<html class="no-js" lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Customer Dashboard | SenseMe India</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Favicon -->
        <link rel="shortcut icon" type="image/x-icon" href="../assets/img/favicon.png">

        <!-- All css here -->
        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/css/font-awesome.min.css">
        <link rel="stylesheet" href="../assets/css/ie7.css">
        <link rel="stylesheet" href="../assets/css/plugins.css">
        <link rel="stylesheet" href="../assets/css/style.css">
        <link rel="stylesheet" href="../assets/css/menu/style.css">
        <script src="../assets/js/vendor/modernizr-3.5.0.min.js"></script>
           <script src="../assets/js/vendor/jquery-3.2.1.min.js"></script>
        <script src="../assets/css/menu/script.js"></script>
         <script type="text/javascript">
        
        $(document).ready(function ()
    {
            
        $( "#close_details" ).click(function() {
 $( "#view_order_details" ).fadeOut();
});
       
            
  });
                       
    </script>
    
        
    </head>
    <body>
        
        
  <div id="loadAjax" class="ui-front loader ui-widget-overlay bg-gray opacity-50" style="display:none">
           <img src="../assets/img/loader-light.gif" alt="">
        </div>
    
        
        <!-- Header Area Start -->
         <?php include("../sm_header.php"); ?>
        <div class="wishlist-area table-area pt-80 pb-95 mt-100 mhide">
            <div class="col-lg-8 col-md-7 offset-3">
                <div class="account_dashboard">
                <div class="row">
                     <div class="col-sm-12 col-md-9 col-lg-9 bg-color p-4 mb-15">
                        <!-- Tab panes -->
                        <div class="tab-content dashboard_content p-1">
                                <h4>Welcome <?php echo $_SESSION['userName']; ?>!</h4><?php
                                    
                                    if(isset($_GET['success'])) 
                                        
                                        echo "<h3>".$_GET['success']."</h3><br>";
		{
                                    }
                                    
		$cartno = 0;
		if(isset($_SESSION['cartsingle'])) 
		{
			$cartno = count($_SESSION['cartsingle']);
		}
		if($cartno>0){ echo "<h4>You have ".$cartno." item in your cart, <strong><a href='../checkout.php'>Checkout now</strong></a></h4>"; } else { echo "You have 0 item in your cart. Start shopping now!";	}
                                    ?> <p><br>
From your account dashboard. you can easily check &amp; view your recent orders</a>, manage your account details such as profile, address...</a></p>
                    
                        </div>
                    </div>
                    </div>
                     <div class="row">
                    <div class="col-sm-6 col-md-3 col-lg-4 mt-20">
                        <!-- Nav tabs -->
                        <div class="dashboard_tab_button">
                            <ul role="tablist" class="nav flex-column dashboard-list">
                                <li> <a href="user_dashboard_details.php?view_orders=true" class="nav-link active"><i class="fa fa-chevron-circle-right pr-2 text-white"></i>Orders</a></li>
                                <li> <a href="user_dashboard_details.php?view_wishlist=true" class="nav-link active"><i class="fa fa-chevron-circle-right pr-2 text-white"></i>Wishlist</a></li>
                            </ul>
                            
                        </div>    
                    </div>
                         
                         <div class="col-sm-6 col-md-3 col-lg-4 mt-20">
                        <!-- Nav tabs -->
                        <div class="dashboard_tab_button">
                            <ul role="tablist" class="nav flex-column dashboard-list">
                                <li><a href="user_dashboard_details.php?view_profile=true" class="nav-link active"><i class="fa fa-chevron-circle-right pr-2 text-white"></i>Account details</a></li>
                                <li><a href="logout.php" class="nav-link active"><i class="fa fa-chevron-circle-right pr-2 text-white"></i>logout</a></li>
                            </ul>
                            
                        </div>    
                    </div>
                   
                </div>
            </div>
</div> </div>
          <div class="wishlist-area table-area pt-80 pb-95 mt-20 dhide">
            <div class="col-lg-7 col-md-7 offset-3">
                <div class="account_dashboard">
                <div class="row">
                     <div class="col-sm-12 col-md-9 col-lg-9 bg-color">
                        <!-- Tab panes -->
                        <div class="tab-content dashboard_content p-1">
                                <h4>Welcome <?php echo $_SESSION['userName']; ?>!</h4><?php
                                    
                                    if(isset($_GET['success'])) 
                                        
                                        echo "<h3>".$_GET['success']."</h3><br>";
		{
                                    }
                                    
		$cartno = 0;
		if(isset($_SESSION['cartsingle'])) 
		{
			$cartno = count($_SESSION['cartsingle']);
		}
		if($cartno>0){ echo "<h4>You have ".$cartno." item in your cart, <strong><a href='../checkout.php'>Checkout now</strong></a></h4>"; } else { echo "You have 0 item in your cart. Start shopping now!";	}
                                    ?> 
                    
                        </div>
                    </div>
              
                    <div class="col-sm-12 col-md-3 col-lg-3 mt-20">
                        <!-- Nav tabs -->
                        <div class="dashboard_tab_button">
                            <ul role="tablist" class="nav flex-column dashboard-list">
                                <li> <a href="user_dashboard_details.php?view_orders=true" class="nav-link active"><i class="fa fa-chevron-circle-right pr-2 text-white"></i>Orders</a></li>
                                <li> <a href="user_dashboard_details.php?view_wishlist=true" class="nav-link active"><i class="fa fa-chevron-circle-right pr-2 text-white"></i>Wishlist</a></li>
                                <li><a href="user_dashboard_details.php?view_profile=true" class="nav-link active"><i class="fa fa-chevron-circle-right pr-2 text-white"></i>Account details</a></li>
                                <li><a href="logout.php" class="nav-link active"><i class="fa fa-chevron-circle-right pr-2 text-white"></i>logout</a></li>
                            </ul>
                        </div>    
                    </div>
                   
                </div>
            </div>
</div> </div>
        
          <?php include("../sm_footer.php"); ?>
            <script src="../assets/js/popper.min.js"></script>
        <script src="../assets/js/bootstrap.min.js"></script>
        <script src="../assets/js/plugins.js"></script>
        <script src="../assets/js/ajax-mail.js"></script>
        <script src="../assets/js/main.js"></script>
    </body>
</html>


﻿<?php
include "../config/config.php"; 
include "session_user.php"; 
include "../rrgadmin/db/db_connect.php"; 
require_once '../rrgadmin/admin/class.user_2.php';
include "../rrgadmin/function/function.php";

////////////////////////update/////////////////////////
if(isset($_POST['update']))
{
extract($_POST);	
$id = $_SESSION['userSession'];
$id = secure_input($con,$id);
	$fname = secure_input($con,$fname);
	$lname = secure_input($con,$lname);
	$phone =  secure_integers($phone);
	$city = secure_input($con,$city);
	$country = secure_input($con,$country);	
$pincode = secure_input($con,$zipcode);		
	if($pincode=="")
	{
		$pincode = NULL;
	}

$uquery = "UPDATE rrg_users SET phone = ?, address = ?, city = ?, country = ?, zipcode = ? WHERE id=?";

if(!$ustmt = $con->prepare($uquery))
{
	echo "prepare failed: (" . $con->errno . ") " . $con->error; exit();
}

if(!$ustmt->bind_param("isssii", $phone, $address, $city, $country, $pincode, $id))	
{
	echo "Param pass failed: (" . $con->errno . ") " . $con->error; exit();
}

if($ustmt->execute()) {
	$success= "User details updated successfully!";
	header("location:edit_profile.php?success=".$success);
	$ustmt->close();			
}
else
{
	$error = "User details update failed!".$con->error;
	header("location:edit_profile.php?error=".$error);
	exit();
}
 
}
///////////////////////////////////////////////////////////////////////

$id = $_SESSION['userSession'];
$id = secure_input($con,$id);

$query = "SELECT * FROM rrg_users WHERE id =?";

if(!$stmt = $con->prepare($query))
{
	echo "query failed: (" . $con->errno . ") " . $con->error;
}

if(!$stmt->bind_param("i", $id))
{
	echo "Param pass failed: (" . $con->errno . ") " . $con->error;
}

	if(!$stmt->execute())
	{
		$error = "customer details listing execution failed!".$con->error;		
	}
		if(!$qresult = $stmt->get_result())
		{
			$error = "customer details listing failed!".$con->error;					
		}
		$data = $qresult->fetch_assoc();
		
//////////////////////////////////////////////////////////////
if(isset($_GET['success']))
{
	$message = $_GET['success'];
}
if(isset($_GET['error']))
{
	$message = $_GET['error'];
}


?>

<!DOCTYPE html>
<!--[if IE 8]><html class="no-js lt-ie9" lang="en"> <![endif]-->
<!--[if gt IE 8]>
<!--><html class="no-js" lang="en"><!--<![endif]-->
<head>

	<meta charset="utf-8">
	<title>Customer | Edit profile</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="theme-color" content="#212121"/>
    <meta name="msapplication-navbutton-color" content="#212121"/>
    <meta name="apple-mobile-web-app-status-bar-style" content="#212121"/>
	<link href="https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet"/>
	<link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i&amp;subset=cyrillic,cyrillic-ext,greek,greek-ext,latin-ext,vietnamese" rel="stylesheet">
	<link rel="stylesheet" href="../css/bootstrap.min.css"/>
	<link rel="stylesheet" href="../css/font-awesome.min.css"/>
	<link rel="stylesheet" href="../css/ionicons.min.css"/>
	<link rel="stylesheet" href="../css/datepicker.css"/>
	<link rel="stylesheet" href="../css/jquery.fancybox.min.css"/>
	<link rel="stylesheet" href="../css/owl.carousel.css"/>
	<link rel="stylesheet" href="../css/owl.transitions.css"/>
	<link rel="stylesheet" href="../css/style.css"/>
	<link rel="stylesheet" href="../css/colors/color.css"/>
	<link rel="icon" type="image/png" href="../favicon.png">
	<link rel="apple-touch-icon" href="../apple-touch-icon.png">
	<link rel="apple-touch-icon" sizes="72x72" href="../apple-touch-icon-72x72.png">
	<link rel="apple-touch-icon" sizes="114x114" href="../apple-touch-icon-114x114.png">
	
	
</head>
<body>	

<!--	<div class="loader">
		<div class="loader__figure"></div>
	</div>-->
	<svg class="hidden">
		<svg id="icon-nav" viewBox="0 0 152 63">
			<title>navarrow</title>
			<path d="M115.737 29L92.77 6.283c-.932-.92-1.21-2.84-.617-4.281.594-1.443 1.837-1.862 2.765-.953l28.429 28.116c.574.57.925 1.557.925 2.619 0 1.06-.351 2.046-.925 2.616l-28.43 28.114c-.336.327-.707.486-1.074.486-.659 0-1.307-.509-1.69-1.437-.593-1.442-.315-3.362.617-4.284L115.299 35H3.442C2.032 35 .89 33.656.89 32c0-1.658 1.143-3 2.552-3H115.737z"/>
		</svg>
	</svg>

	<br>
<?php include("../rr_header.php"); ?>
	
	<div class="section big-15-height over-hide z-bigger">
	
		<div class="parallax parallax-top" style="background-image: url('../img/3.jpg')"></div>
		<div class="dark-over-pages"></div>
	
		<div class="hero-center-section pages">
			<div class="container">
				
			</div>
		</div>
	</div>
	<div class="section padding-top-bottom over-hide background-grey">
		<div class="container">
			<div class="row justify-content-center">
										
		<?php 		if(isset($_GET['success'])&&$_GET['success']!="") { 
	
	?>
					<h5><span class='green2'><?php echo $_GET['success']; ?></span></h5>
			<?php 
	
} 
			?>
				
												
		<?php 		if(isset($_GET['error'])&&$_GET['error']!="") { 
	
	?>
					<h5><span class='red'><?php echo $_GET['error']; ?></span></h5>
			<?php 
	
} 
			?>
				<div class="col-md-12 align-self-center text-center">
								
<div class="subtitle with-line text-center mb-4">Edit profile</div>
					<h3 class="text-center padding-bottom-small">Welcome, <?php echo $_SESSION['userName']; ?>!</h3>
				</div>
				<div class="section clearfix"></div>
		<?php include("left.php"); ?>
				<div class="col-lg-8 mt-8 mt-lg-0" data-scroll-reveal="enter bottom move 50px over 0.7s after 0.2s">
					<div class="room-box background-white">
						<div class="container">
			
			<?php if(isset($msg)) echo $msg;  ?>
			<form id="registration" action="" method="POST">
			<div class="row justify-content-center padding-bottom-smaller">
				<div class="col-md-8">
					<h5 class="text-center padding-bottom-small mt-4">Edit Profile</h5>
				</div>
				<div class="section clearfix"></div>
				<div class="col-md-4 ajax-form">
					<input name="fname" readonly value="<?php echo $data['fname']; ?>"  autocomplete="off"/>
				</div>
					<div class="col-md-4 ajax-form">
					<input name="lname" readonly value="<?php echo $data['lname']; ?>"  autocomplete="off"/>
				</div>
				
					<div class="col-md-4 ajax-form">
					<input name="phone" type="tel" value="<?php echo $data['phone']; ?>" placeholder="phone"  pattern="^(0|[1-9][0-9]*)$" title="only numbers allowed" required  autocomplete="off"/>
				</div>
					
				<div class="section clearfix"></div>
			
				<div class="col-md-6 mt-4 mt-md-0 ajax-form">
					<input name="email" value="<?php echo $data['email']; ?>" readonly autocomplete="off"/>
				</div>
				<div class="col-md-6 ajax-form">
					<input name="address" type="text" placeholder="Your address" value="<?php echo $data['address']; ?>"  autocomplete="off"/>
				</div>
					
				<div class="section clearfix"></div>
				<div class="col-md-4 ajax-form">
					<input name="city" type="text" value="<?php echo $data['city']; ?>"  required  autocomplete="off"/>
				</div>
				<div class="col-md-4 ajax-form">
					<input name="country" type="text" value="<?php echo $data['country']; ?>"  required  autocomplete="off"/>
				</div>
					
					<div class="col-md-4 ajax-form">
					<input name="zipcode" type="text" value="<?php echo $data['zipcode']; ?>" placeholder="Zip code"   autocomplete="off"/>
				</div>
				
				<div class="section clearfix"></div>
				<div class="col-md-8 mt-3 ajax-form text-center">
					<input name="id" value="<?php echo $id; ?>" type="hidden">
					<button class="send_message" type="submit" name="update" id="send" data-lang="en"><span>Update</span></button>
				</div>
				<div class="section clearfix"></div>
				
			</div>
			</form>
			
		</div>
					</div>
				</div>
				
			</div>	
		</div>		
	</div>

	<div class="section padding-top-bottom-big over-hide">
		<div class="parallax" style="background-image: url('../img/cta.jpg')"></div>
		<div class="section z-bigger">		
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="row justify-content-center">
							<div class="col-md-12 col-xl-12 px-sm-0">
								<div class="col-md-12 align-self-center">
					<div class="subtitle with-line text-center mb-4 color-white">Neat, Clean &amp; Calm</div>
					<h3 class="text-center color-white">Are you looking for homely stay in Tirupati?</h3>
										
				</div>
							</div>
							
						</div>	
					</div>
					
					<div class="col-md-12 text-center pt-3">
									<a class="mt-1 btn btn-primary" href="javscript:">book now</a>
								</div>
					
					
				</div>
			</div>					
		</div>
	</div>
	
	<?php include("../rr_footer.php"); ?>
	
</body>
</html>
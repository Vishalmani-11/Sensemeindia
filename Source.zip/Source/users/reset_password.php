<?php 
include "../smadmin/function/config.php"; 
require_once '../smadmin/admin/class.user_2.php';
include "../smadmin/function/function.php"; 
require("../smadmin/db/db_connect.php");

$user = new USER();

if($user->is_logged_in())
{
	$user->redirect('user_dashboard.php');
}

if(isset($_POST['reset']))
{
    $email = secure_email($_POST['email']);
    
    
	$uquery = "SELECT id FROM bb_users WHERE email= ? LIMIT 1";
	
    if(!$ustmt = $con->prepare($uquery))
    {
        echo "query failed: (" . $con->errno . ") " . $con->error; exit();
    }

    if(!$ustmt->bind_param("s", $email))
    {
        echo "Param pass failed: (" . $con->errno . ") " . $con->error; exit();
    }

	if(!$ustmt->execute())
	{
		echo $error = "user details execution failed!".$con->error;		 exit();
	}
		if(!$uresult = $ustmt->get_result())
		{
			echo $error = "user details listing failed!".$con->error;		 exit();			
		}
	 
	 $unum_of_rows = $uresult->num_rows;

    if($unum_of_rows==0)
    {
        $msg = "<br><h5><strong>Sorry!</strong> Your email is not registered with us.</h5>";

        header("location:reset_password.php?msg=".$msg);

    }
    else
    {

    	if(!$user_data = $uresult->fetch_assoc())
		{
			echo $udata = "error".$con->error; exit();
		}
    
        $id = base64_encode($user_data['id']);
		$code = md5(uniqid(rand()));
		$tokenstatus = 1;
				
	    $up_query = "UPDATE bb_users SET tokenCode= ?, tokenAc = ? WHERE email = ?";
    
        if(!$up_stmt = $con->prepare($up_query))
        {
            echo $error = "preparation failed!".$con->error; exit();
        }

        if(!$up_stmt->bind_param("sis", $code, $tokenstatus, $email))
        {
            echo "Param pass failed: (" . $con->errno . ") " . $con->error; exit();
        }
	
        if(!$up_stmt->execute())
        {
            echo $error = "Profile update failed!".$con->error.$up_stmt->error;		 exit();

        }
        else
        {
          $message= "Hello , $email<br /><br />You have requested to reset your password, if you did this then just click the following link to reset your password, if not please just ignore this email, <br /><br />Click Following Link To Reset Your Password <br /><br /><a href='https://sensemeindia.com/users/user_new_password.php?id=$id&code=$code'><strong>click here to reset your password</strong></a><br /><br />Thank you :)";
            
            $subject = "SenseMe India Account Password Reset";

            $from = "admin@sensemeindia.com";

        	$user->send_mail($from,$email,$message,$subject);

            $msg = "We've sent an email to <strong>".$email."</strong>. Please click on the password reset link in the email to generate a new password.";

             header("location:reset_password.php?msg=".$msg); exit();
        }
    }
    
    
	
}

?>


<!doctype html>
<html class="no-js" lang="en">
    <head>
        <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-PJDLLCD');</script>
<!-- End Google Tag Manager -->
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Reset Password | SenseMe India</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Favicon -->
        <link rel="shortcut icon" type="image/x-icon" href="../assets/img/favicon.png">

        <!-- All css here -->
        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/css/font-awesome.min.css">
        <link rel="stylesheet" href="../assets/css/ie7.css">
        <link rel="stylesheet" href="../assets/css/plugins.css">
        <link rel="stylesheet" href="../assets/css/style.css">
        <script src="../assets/js/vendor/modernizr-3.5.0.min.js"></script>
           <script src="../assets/js/vendor/jquery-3.2.1.min.js"></script>
    </head>
    <body>
        <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-PJDLLCD"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
        <!-- Header Area Start -->
         <?php include("../sm_header.php"); ?>
        <div class="breadcrumb-area bg-12 text-center">
            <div class="container">
                <h1><span class="green">Customer Login</span></h1>
                <nav aria-label="breadcrumb">
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Customer Login</li>
                    </ul>
                </nav>
            </div>
        </div>
        
          <div class="wishlist-area table-area pt-80 pb-95">
              
            	<?php 		if(isset($message)&&$message!="") { 
	
	?>
			
			<div class='room-box background-grey mb-5 text-center'>
				<div class='room-box-in'>
										<h5><?php echo $message; ?></h5>
									</div></div>
			<?php 
	
}
			?>
               	<?php 		if(isset($_GET['msg'])&&$_GET['msg']!="") { 
	
	?>
			
			<div class='room-box background-grey mb-5 text-center'>
				<div class='room-box-in'>
										<h5><?php echo $_GET['msg']; ?></h5>
									</div></div>
			<?php 
	
}
			?>
            <div class="col-lg-5 col-md-5 offset-4 bg-color p-5">
        <div class="form-pop-up-content">
								<h2 class="pb-30">Reset Password</h2>
								<form id="registration" action="" method="POST">
									<div class="form-box">
										<p>   
                                
                                <input type="email" name="email" required placeholder="E-mail*" class="bg-color2">
                             </p>
                            
									</div>
									
								    <button type="submit" name="reset" class="submit-btn default-btn-2">Reset</button>
								</form>
							</div>
                </div>
        </div>
        
          <?php include("../sm_footer.php"); ?>
        <!-- Footer Area End -->
        <!-- All js here -->
        
        <script src="../assets/js/popper.min.js"></script>
        <script src="../assets/js/bootstrap.min.js"></script>
        <script src="../assets/js/plugins.js"></script>
        <script src="../assets/js/ajax-mail.js"></script>
        <script src="../assets/js/main.js"></script>
    </body>
</html>
<?php include "../smadmin/function/config.php"; 
include "../smadmin/db/db_connect.php"; 
require_once '../smadmin/admin/class.user_2.php';
include "../smadmin/function/function.php";  
require_once 'google-api-php-client--PHP/vendor/autoload.php';
require_once 'google/config.php'; 

$user_login = new USER();


if($user_login->is_logged_in()!="")
{ 
    if(isset($_SESSION['cartsingle'])&&count($_SESSION['cartsingle'])!=0)
	{ 
        $user_login->redirect('../checkout.php'); exit();
            
    }
        else
        {
    $user_login->redirect('user_dashboard.php'); exit();
        }
    
	
}

//////////////////////google login///////////////////////////////////////////////////////////////////////////////////

if(isset($_GET['code'])){ 
     $token = $client->fetchAccessTokenWithAuthCode($_GET['code']);
    $client->setAccessToken($token['access_token']);
    $_SESSION['token'] = $token['access_token']; 
    
    $google_oauth = new Google_Service_Oauth2($client);
    $google_account_info = $google_oauth->userinfo->get();
    //echo $email =  $google_account_info->email;
    //echo $name =  $google_account_info->name;
    
       // Initialize User class 
    $user = new USER(); 
     
    // Getting user profile info 
    $gpUserData = array(); 
    $gpUserData['oauth_uid']  = !empty($google_account_info['id'])?$google_account_info['id']:''; 
    $gpUserData['fname'] = !empty($google_account_info['given_name'])?$google_account_info['given_name']:''; 
    $gpUserData['lname']  = !empty($google_account_info['family_name'])?$google_account_info['family_name']:''; 
    $gpUserData['email']       = !empty($google_account_info['email'])?$google_account_info['email']:''; 
    $gpUserData['gender']       = !empty($google_account_info['gender'])?$google_account_info['gender']:''; 
    $gpUserData['locale']       = !empty($google_account_info['locale'])?$google_account_info['locale']:''; 
    $gpUserData['picture']       = !empty($google_account_info['picture'])?$google_account_info['picture']:''; 
     
    // Insert or update user data to the database 
    $gpUserData['oauth_provider'] = 'google'; 
    
    if($login_result = $user->checkUser($gpUserData))
    {
        
        if(isset($_SESSION['cartsingle'])&&count($_SESSION['cartsingle'])!=0)
	{ 
        $user->redirect('../checkout.php'); exit();
            
    }
        else{
            $user->redirect('user_dashboard.php'); exit();            
        }
    }
    else
    {
        header('location:index.php?nouser');
        exit();
    }
    //$userData = $user->checkUser($gpUserData); 
     
    // Storing user data in the session 
    //$_SESSION['userData'] = $userData; 
     
    // Render user profile data 
   /* if(!empty($userData)){ 
        $output     = '<h2>Google Account Details</h2>'; 
        $output .= '<div class="ac-data">'; 
        $output .= '<img src="'.$userData['picture'].'">'; 
        $output .= '<p><b>Google ID:</b> '.$userData['oauth_uid'].'</p>'; 
        $output .= '<p><b>Name:</b> '.$userData['first_name'].' '.$userData['last_name'].'</p>'; 
        $output .= '<p><b>Email:</b> '.$userData['email'].'</p>'; 
        $output .= '<p><b>Gender:</b> '.$userData['gender'].'</p>'; 
        $output .= '<p><b>Locale:</b> '.$userData['locale'].'</p>'; 
        $output .= '<p><b>Logged in with:</b> Google Account</p>'; 
        $output .= '<p>Logout from <a href="user_logout.php">Google</a></p>'; 
        $output .= '</div>'; 
        echo $output; exit();
          }else{ 
       echo $output = '<h3 style="color:red">Some problem occurred, please try again.</h3>'; exit();
    } */

     
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


if(isset($_POST['login-bb']))
{
	extract($_POST);
	$uname = secure_email($email);
	$uname = strtolower($uname);
	$upass = secure_input($con,$password);
	
	if($user_login->login($uname,$upass))
	{
        
      if(isset($_SESSION['cartsingle'])&&count($_SESSION['cartsingle'])!=0)
	{ 
        $user_login->redirect('../checkout.php'); exit();
            
    }
        else
        {
        header("location:user_dashboard.php"); exit();    
        }
        
		
	}
}

if(isset($_POST['recoverpswd']))
{
	$email = "";
	
	$email = trim($_POST['remail']);
	$email = mysqli_real_escape_string($con,$email);
	
	$stmt = $user_login->runQuery("SELECT uname FROM bb_users WHERE email=:email LIMIT 1");
	$stmt->execute(array(":email"=>$email));
	$row = $stmt->fetch(PDO::FETCH_ASSOC);	
	if($stmt->rowCount() == 1)
	{
		$id = base64_encode($row['adminID']);
		$code = md5(uniqid(rand()));
		$tokenac = 0;
		$stmt = $user_login->runQuery("UPDATE bb_users SET tokenCode=:token, tokenAc=:tokenac WHERE adminEmail=:email");
		$stmt->execute(array(":token"=>$code,":tokenac"=>$tokenac,"email"=>$email));
		
		$message= "
				   Hello , $email
				   <br /><br />
				   We have received a request to reset your password, if you do this then just click the following link to reset your password, if not just ignore this email,
				   <br /><br />
				   Click Following Link To Reset Your Password! 
				   <br /><br />
				   <a href='https://sensemeindia.com/resetpass.php?id=$id&code=$code'>click here to reset your password</a>
				   <br /><br />
				   Thank you!
				   ";
		$subject = "Password Reset";
		$from = "info@htsuite.net";
		$mresult = $user_login->send_mail($from,$email,$message,$subject);
		if($mresult=='success')
		{		
		header("location:index.php?rmsg=$email");		
		}
		else
		{
			exit("error in sending mail".$mresult); 
		}
	}
	else
	{
		header("location:index.php?remsg");				
	}

}
?>
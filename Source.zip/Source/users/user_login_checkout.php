<?php
include "../smadmin/function/config.php"; 
include "../smadmin/db/db_connect.php"; 
require_once '../smadmin/admin/class.user_2.php';
include "../smadmin/function/function.php";  

$user_login = new USER();
if($user_login->is_logged_in()!="")
{
	$user_login->redirect('user_dashboard.php');
}

if(isset($_POST['login-bb']))
{
	extract($_POST);
	$uname = secure_email($email);
	$uname = strtolower($uname);
	$upass = secure_input($con,$password);
	
	if($user_login->login($uname,$upass))
	{
		$user_login->redirect('user_dashboard.php');
	}
}

if(isset($_POST['recoverpswd']))
{
	$email = "";
	
	$email = trim($_POST['remail']);
	$email = mysqli_real_escape_string($con,$email);
	
	$stmt = $user_login->runQuery("SELECT uname FROM bb_users WHERE email=:email LIMIT 1");
	$stmt->execute(array(":email"=>$email));
	$row = $stmt->fetch(PDO::FETCH_ASSOC);	
	if($stmt->rowCount() == 1)
	{
		$id = base64_encode($row['adminID']);
		$code = md5(uniqid(rand()));
		$tokenac = 0;
		$stmt = $user_login->runQuery("UPDATE bb_users SET tokenCode=:token, tokenAc=:tokenac WHERE adminEmail=:email");
		$stmt->execute(array(":token"=>$code,":tokenac"=>$tokenac,"email"=>$email));
		
		$message= "
				   Hello , $email
				   <br /><br />
				   We have received a request to reset your password, if you do this then just click the following link to reset your password, if not just ignore this email,
				   <br /><br />
				   Click Following Link To Reset Your Password! 
				   <br /><br />
				   <a href='https://lms.htsuite.com/lms/resetpass.php?id=$id&code=$code'>click here to reset your password</a>
				   <br /><br />
				   Thank you!
				   ";
		$subject = "Password Reset";
		$from = "info@htsuite.net";
		$mresult = $user_login->send_mail($from,$email,$message,$subject);
		if($mresult=='success')
		{		
		header("location:index.php?rmsg=$email");		
		}
		else
		{
			exit("error in sending mail".$mresult); 
		}
	}
	else
	{
		header("location:index.php?remsg");				
	}

}
?>
<?php
include "session_user.php"; 
include "../smadmin/function/config.php";  
include "../smadmin/db/db_connect.php"; 
require_once '../smadmin/admin/class.user_2.php';
include "../smadmin/function/function.php";
////////////////////////////////update profile//////////////////////////////////////
if(isset($_POST['update_profile']))
{
extract($_POST);	

    $cid = $_SESSION['userSession']; 
    $fname = secure_input($con,$initial); 
    $lname = secure_input($con,$name);
    $state = secure_input($con,$state);
    $address = secure_input($con,$address); 
    $city = secure_input($con,$city); 
    $country = secure_input($con,$country); 
    $zipcode = secure_input($con,$zipcode); 
    
    $up_query = "UPDATE bb_users SET fname = ?, lname = ?, address = ?, city = ?, state = ?, country = ?, zipcode = ? WHERE id = ?";
    
if(!$up_stmt = $con->prepare($up_query))
{
	echo $error = "preparation failed!".$con->error; exit();
}

if(!$up_stmt->bind_param("sssssssi", $fname, $lname, $address, $city, $state, $country, $zipcode, $cid))
{
	echo "Param pass failed: (" . $con->errno . ") " . $con->error; exit();
}
	
	if(!$up_stmt->execute())
	{
		echo $error = "Profile update failed!".$con->error;		 exit();
		
	}
    else
    {
         $success = "<strong>Profile updated successfully!</strong>";
    header("location:user_dashboard.php?&success=".$success);
    }
}
//////////////////////delete from wishlist////////////////////////
if(isset($_GET['wishlist_id'])&&$_GET['wishlist_id']!=''&&isset($_GET['action'])&&$_GET['action']=='remove')
{
extract($_GET);	

    $wishlist_id = secure_input($con,$wishlist_id); 
    
$rw_query = "DELETE FROM wishlist WHERE id = ?";

    if(!$rw_stmt = $con->prepare($rw_query))
{
	echo "Prepare failed: (" . $con->errno . ") " . $con->error; exit();
}

if(!$rw_stmt->bind_param("i", $wishlist_id))
{
	echo "Param pass failed: (" . $con->errno . ") " . $con->error; exit();
}

if(!$rw_stmt->execute()) {
    
	$error = "wishlist update failed!".$con->error; exit();   
    
}
else
{
    $success = "<strong>Product removed from your wishlist</strong>";
    header("location:user_dashboard.php?&success=".$success);
}

} 

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
extract ($_GET);
$cid = $_SESSION['userSession'];
/////////////////////////////////listing orders//////////////////////////////////////////
if($view_orders)
{
$query = "SELECT id, mc_gross, titems, orderdate, orderstatus FROM bb_orders WHERE cid = ? AND order_placed = ? ORDER BY orderdate DESC";



$order_flag = 1;

if(!$ostmt = $con->prepare($query))
{
	echo $error = "categories data listing preparation failed!".$con->error; exit();
}

if(!$ostmt->bind_param("ii", $cid, $order_flag))
{
	echo "Param pass failed: (" . $con->errno . ") " . $con->error; exit();
}
	
	if(!$ostmt->execute())
	{
		echo $error = "categories data listing execution failed!".$con->error;	 exit();	
		
	}
		if(!$ostmt->store_result())
		{
			echo $error = "categories data listing execution failed!".$con->error;	 exit();				
		}
	
	$onum_of_rows = $ostmt->num_rows;

	if($onum_of_rows==0)
{
	$onum_error = "No orders found!";		
}
}
/////////////////////////////////////////list wishlist///////////////////////////    
if($view_wishlist)
{
$cw_query = "SELECT t1.id, t1.pid, t1.price, t1.image, t3.name from wishlist as t1 INNER JOIN bb_products_stock as t2 ON t1.pid = t2.id INNER JOIN bb_products as t3 ON t2.parent_id = t3.id WHERE t1.cid = ?";    

if(!$cw_stmt = $con->prepare($cw_query))
{
	echo "prepare failed:" . $cw_stmt->error;	exit();
}

	if(!$cw_stmt->bind_param("i", $cid))
{
	echo "Param pass failed: (" . $con->errno . ") " . $con->error; exit();
}   

	if(!$cw_stmt->execute())
	{
		echo $error = "wishlist listing failed!".$cw_stmt->error;		exit();
		
	}

		if(!$cw_stmt->store_result())
		{
			echo $error = "categories list failed!".$con->error;	exit();				
		}
	
	$cw_num_of_rows = $cw_stmt->num_rows; 

if($cw_num_of_rows==0)
{
	$cw_error = "No products found in your wishlist! Start adding some!";			
}
}
/////////////////////////////user profile////////////////////////////////////////////
if($view_profile) {

$uquery = "SELECT * from bb_users WHERE id = ?";
	
if(!$ustmt = $con->prepare($uquery))
{
	echo "query failed: (" . $con->errno . ") " . $con->error; exit();
}

if(!$ustmt->bind_param("i", $cid))
{
	echo "Param pass failed: (" . $con->errno . ") " . $con->error; exit();
}

	if(!$ustmt->execute())
	{
		echo $error = "child product details execution failed!".$con->error;		 exit();
	}
		if(!$uresult = $ustmt->get_result())
		{
			echo $error = "child product details listing failed!".$con->error;		 exit();			
		}
	 
	 $unum_of_rows = $uresult->num_rows;

if($unum_of_rows==0)
{
	echo $uerror = "Profile details not found"; exit();		
}
else
{
    
    	if(!$user_data = $uresult->fetch_assoc())
		{
			echo $udata = "error".$con->error; exit();
		}
    
}
}
?>

<!doctype html>
<html class="no-js" lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Customer Dashboard | SenseMe India</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Favicon -->
        <link rel="shortcut icon" type="image/x-icon" href="../assets/img/favicon.png">

        <!-- All css here -->
        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/css/font-awesome.min.css">
        <link rel="stylesheet" href="../assets/css/ie7.css">
        <link rel="stylesheet" href="../assets/css/plugins.css">
        <link rel="stylesheet" href="../assets/css/style.css">
        <link rel="stylesheet" href="../assets/css/menu/style.css">
        <script src="../assets/js/vendor/modernizr-3.5.0.min.js"></script>
           <script src="../assets/js/vendor/jquery-3.2.1.min.js"></script>
        <script src="../assets/css/menu/script.js"></script>
         <script type="text/javascript">
        
        $(document).ready(function ()
    {
            
        $( "#close_details" ).click(function() {
 $( "#view_order_details" ).fadeOut();
});
       
            
  });
                       
    </script>
    
        
    </head>
    <body>
        
        
  <div id="loadAjax" class="ui-front loader ui-widget-overlay bg-gray opacity-50" style="display:none">
           <img src="../assets/img/loader-light.gif" alt="">
        </div>
    
        
        <!-- Header Area Start -->
         <?php include("../sm_header.php"); ?>
        
          <div class="wishlist-area table-area mt-20 dhide p-0">
            <div class="col-lg-7 col-md-7 offset-3">
                <div class="account_dashboard">
                <div class="row">
                    <div class="col-sm-4 col-md-3 col-lg-3">
                        <!-- Nav tabs -->
                        <div class="dashboard_tab_button float-right">
                            <ul role="tablist" class="nav flex-column dashboard-list">
                                <li><a href="user_dashboard.php" class="nav-link active">Back</a></li>                               
                            </ul>
                        </div>    
                    </div>
                   
                </div>
            </div>
</div> </div>
        

          <div class="wishlist-area table-area mt-200">
            <div class="col-lg-7 col-md-7 offset-3">
        <div class="account_dashboard">
                <div class="row">
                    <div class="col-sm-12 col-md-9 col-lg-9 bg-color p-0 border">
                        <!-- Tab panes -->
                        <div class="tab-content dashboard_content">
                          
                            <?php if($view_orders)
{ ?> 
                
                            <div class="active" id="orders">
                                <h4 class="pl-3"> Your Orders</h4>
                                <div>
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th class="pl-2">Order#</th>
                                                <th>Date</th>
                                                <th>Status</th>
                                                <th>Total</th>
                                                <th>Actions</th>	 	 	 	
                                            </tr>
                                        </thead>
                                        <tbody>
                                            
                                            <?php 
                                            if(isset($onum_error)&&$onum_error!="")
                                            { ?>
                                            
                                            <tr>
                                                <td colspan="5"><?php echo $onum_error; ?></td>
                                                </tr>
                                                
                                        <?php } else { 
	$sn = 0;
	$ostmt->bind_result($id, $cost, $items, $orderdate, $orderstatus);
	while ($ostmt->fetch()) 
	{
			$sn = 	$sn + 1;		
	?>
                                            
                                            <tr>
                                                <td class="pl-2">SM<?php echo $id; ?></td>
                                                <td><?php echo date('D - dS M, Y', strtotime($orderdate)); ?></td>
                                                <td><span class="success"><?php echo $orderstatus; ?></span></td>
                                                <td>&#x20b9; <?php echo $cost. " (".$items." item)"; ?> </td>
                                                <td>
                                                    <a href="javascript:;" class="view-order-details" id="<?php echo $id; ?>" title="View details">
                                               View
                                                
                                            </a>    
                                                    
                                                    <?php if($orderstatus=="Delivered")
    {
        ?>
 
                                                   | <a href="order_invoice.php?order_id=<?php echo $id; ?>" target="_blank" title="Download Invoice">Download Invoice</a>        <?php } ?>
                                                    
                                                    </td>
                                            </tr>
                                            
                                            
                                            
                                       <?php } } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <?php } ?>
                
                                                     <?php if($view_wishlist)
{ ?> 
                            <div id="wishlist">
                                 <h4 class="pl-3"> Your Wishlist</h4>
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th width="35%">Product</th>
                                                <th>Image</th>
                                                <th width="25%">Price</th>
                                                <th width="20%">Action</th>	 	 	 	
                                            </tr>
                                        </thead>
                                        <tbody>
                                            
<?php 
                                            if(isset($cw_error)&&$cw_error!="")
                                            { ?>
                                            
                                            <tr>
                                                <td colspan="4" class="text-black-50"><?php echo $cw_error; ?></td>
                                                </tr>
                                                
                                        <?php } else { 
	$sn = 0;
	$cw_stmt->bind_result($id, $pid, $price, $image, $name);
	while ($cw_stmt->fetch()) 
	{
			$sn = 	$sn + 1;		
	?>                                            
                                            
                                            
                                            <tr>
                                                <td><?php echo $name; ?></td>
                                                <td><img src="../smadmin/<?php echo $image; ?>" width="50%"></td>
                                                <td>&#x20b9; <?php echo $price; ?> (When added)</td>
                                                <td><a href="../product-details.php?product_id=<?php echo $pid; ?>" target="_blank" class="view" title="View details">View </a> | <a href="user_dashboard.php?wishlist_id=<?php echo $id; ?>&action=remove" title="Remove item" onclick="return confirm('Are you sure you want to remove this item from your wishlist?');">Remove</a>  </td>
                                            </tr>
                                            
      
                                       <?php } } ?>
                                          
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <?php } ?>

                        <?php if($view_profile)
{
    ?>

                            <div id="account-details" class="p-3">
                                 <h4 class="pl-1 border-bottom pb-1">Update account details</h4>
                                <div class="login mt-20">
                                    <div class="login_form_container">
                                        <div class="account_login_form">
                                            <form id="update-profile" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
                                                 <p>   
                               <label><strong>Initial:</strong><span>*</span></label>
                                <input type="text" name="initial" value="<?php echo $user_data['fname']; ?>" required placeholder="First Name*" class="bg-color2">
                             </p>
                            <p>   
                               <label><strong>Name:</strong><span>*</span></label>
                                <input type="text" name="name" value="<?php echo $user_data['lname']; ?>" required placeholder="Last Name*" class="bg-color2">
                             </p>
                            
                              <p> 
                                <label><strong>Phone No:</strong><span>*</span> (for order details)</label>
                                   <input type="text" name="phone" value="<?php echo $user_data['phone']; ?>" required readonly> </p>
                                </p>
                                     <p>              
                                 <label><strong>Street Address</strong>  <span>*</span>(Default for shipping)</label>
                                 <input type="text" name="address" value="<?php echo $user_data['address']; ?>" required class="bg-color2"> </p>
                                
                             <p>   
                                <label><strong>City</strong>  <span>*</span></label>
                                <input type="text" name="city" value="<?php echo $user_data['city']; ?>" required class="bg-color2">
                             </p>
                                            <p>
                                    <label>State <span>*</span></label>
                                      <select name="state" id="state" class="form-control bg-color2" required>
                                          <?php if(empty($user_data['state']))
{ ?>      
    <option value="">Select State</option>
                                          
<?php } else { ?>          <option value="<?php echo $user_data['state']; ?>"><?php echo $user_data['state']; ?></option>  <?php } ?>              
                                        <option value="Tamil Nadu">Tamil Nadu</option>
                                         <option value="Andhra Pradesh">Andhra Pradesh</option>
<option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
<option value="Arunachal Pradesh">Arunachal Pradesh</option>
<option value="Assam">Assam</option>
<option value="Bihar">Bihar</option>
<option value="Chandigarh">Chandigarh</option>
<option value="Chhattisgarh">Chhattisgarh</option>
<option value="Dadar and Nagar Haveli">Dadar and Nagar Haveli</option>
<option value="Daman and Diu">Daman and Diu</option>
<option value="Delhi">Delhi</option>
<option value="Lakshadweep">Lakshadweep</option>
<option value="Puducherry">Puducherry</option>
<option value="Goa">Goa</option>
<option value="Gujarat">Gujarat</option>
<option value="Haryana">Haryana</option>
<option value="Himachal Pradesh">Himachal Pradesh</option>
<option value="Jammu and Kashmir">Jammu and Kashmir</option>
<option value="Jharkhand">Jharkhand</option>
<option value="Karnataka">Karnataka</option>
<option value="Kerala">Kerala</option>
<option value="Madhya Pradesh">Madhya Pradesh</option>
<option value="Maharashtra">Maharashtra</option>
<option value="Manipur">Manipur</option>
<option value="Meghalaya">Meghalaya</option>
<option value="Mizoram">Mizoram</option>
<option value="Nagaland">Nagaland</option>
<option value="Odisha">Odisha</option>
<option value="Punjab">Punjab</option>
<option value="Rajasthan">Rajasthan</option>
<option value="Sikkim">Sikkim</option>
<option value="Telangana">Telangana</option>
<option value="Tripura">Tripura</option>
<option value="Uttar Pradesh">Uttar Pradesh</option>
<option value="Uttarakhand">Uttarakhand</option>
<option value="West Bengal">West Bengal</option>
</select>     
                         </p>       
                            <p>
                                                <label><strong>Zipcode</strong>  <span>*</span></label>
                                 <input type="text" name="zipcode" value="<?php echo $user_data['zipcode']; ?>" required class="bg-color2"> </p>
                                             <p>   
                                <label><strong>Country</strong>  <span>*</span></label>
                                <input type="text" name="country" value="<?php echo $user_data['country']; ?>" required readonly>
                             </p>
                                                <br>
                                             
                                                <div class="save_button primary_btn default_button text-center">
                                                    <button type="submit" class="default-btn-2 mt-3 mb-2" name="update_profile">Update Profile</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                
                <?php } ?>
                
                        </div>
                    </div>
                </div>
            </div>
                </div>
        </div>
        <div class="wishlist-area table-area pb-60 mhide">
            <div class="col-lg-8 col-md-7 offset-3">
                <div class="account_dashboard">
                     <div class="row">
                    <div class="col-sm-6 col-md-3 col-lg-4 mt-20">
                        <!-- Nav tabs -->
                        <div class="dashboard_tab_button">
                            <ul role="tablist" class="nav flex-column dashboard-list">
                                <li> <a href="user_dashboard_details.php?view_orders=true" class="nav-link active"><i class="fa fa-chevron-circle-right pr-2 text-white"></i>Orders</a></li>
                                <li> <a href="user_dashboard_details.php?view_wishlist=true" class="nav-link active"><i class="fa fa-chevron-circle-right pr-2 text-white"></i>Wishlist</a></li>
                                <li><a href="user_dashboard.php" class="nav-link active"><i class="fa fa-chevron-circle-right pr-2 text-white"></i>Dashboard</a></li>
                            </ul>
                            
                        </div>    
                    </div>
                         
                         <div class="col-sm-6 col-md-3 col-lg-4 mt-20">
                        <!-- Nav tabs -->
                        <div class="dashboard_tab_button">
                            <ul role="tablist" class="nav flex-column dashboard-list">
                                <li><a href="user_dashboard_details.php?view_profile=true" class="nav-link active"><i class="fa fa-chevron-circle-right pr-2 text-white"></i>Account details</a></li>
                                <li><a href="logout.php" class="nav-link active"><i class="fa fa-chevron-circle-right pr-2 text-white"></i>logout</a></li>
                            </ul>
                            
                        </div>    
                    </div>
                   
                </div>
            </div>
</div> </div>
          <?php include("../sm_footer.php"); ?>
        <!-- Footer Area End -->
        <!-- All js here -->
        
        <script src="../assets/js/popper.min.js"></script>
        <script src="../assets/js/bootstrap.min.js"></script>
        <script src="../assets/js/plugins.js"></script>
        <script src="../assets/js/ajax-mail.js"></script>
        <script src="../assets/js/main.js"></script>
    </body>
</html>
<div class="modal" id="view_order_details" tabindex="-1" role="dialog"  aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div id="order-details" class="modal-content">
      <button type="button" id="close_details" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
      <div class="modal_body">
        <div class="container">
          <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
              <div id="show_data">
                
              </div>
            </div>
            
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<script type="text/javascript">
////////////////////////////view order details///////////////////////	
	 $(function() {
		
         $( ".view-order-details" ).click(function() {
			 
			 var cid = $(this).attr("id"); 
             
           $.ajax({  
                url:"fetch_order_details.php",  
                method:"post",  
                data:{cid:cid},
			 beforeSend: function(){
				$('#limage').fadeIn();
			    },
        complete: function(){
				$('#limage').hide();
				},
				success:function(data){  
                //alert(data);
				$('#show_data').html(data);
				$( "#view_order_details" ).fadeIn();
				
                }  
           });  
		   
         });
		 
    });
</script>
 

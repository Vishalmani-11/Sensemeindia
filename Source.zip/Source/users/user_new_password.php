<?php
include "../smadmin/function/config.php";
require("../smadmin/db/db_connect.php");
require_once '../smadmin/admin/class.user_2.php';
require("../smadmin/function/function.php");

$user = new USER();

if(isset($_GET['id'])&&isset($_GET['code']))
{
	$id = base64_decode($_GET['id']);
	$id = secure_input($con, $id);
	$code = secure_input($con,$_GET['code']);
	
    
	$stmt = $user->runQuery("SELECT * FROM bb_users WHERE id=:uid AND tokenCode=:token");
	$stmt->execute(array(":uid"=>$id,":token"=>$code));
	$rows = $stmt->fetch(PDO::FETCH_ASSOC);
	
    
	if($stmt->rowCount() == 1)
	{
		if($rows['tokenAc']==0)
		{ 
				header("location:index.php?codexpired");exit();
        } 
			
		
	}
	else
	{
		
        header("location:index.php?nouser");exit();
				
	}
	
	
}
////////////////////////////////////////////////////////////////////////////////////////
if(isset($_POST['id']) && isset($_POST['code'])&&isset($_POST['reset']))
{
    $id = base64_decode($_POST['id']);
	$id = secure_input($con, $id);
	$code = secure_input($con,$_POST['code']);
	
    
    
	$stmt = $user->runQuery("SELECT * FROM bb_users WHERE id=:uid AND tokenCode=:token");
	$stmt->execute(array(":uid"=>$id,":token"=>$code));
	$rows = $stmt->fetch(PDO::FETCH_ASSOC);
	
    
	if($stmt->rowCount() == 1)
	{
		if($rows['tokenAc']==1)
		{ 
            
		if(isset($_POST['password1']))
		{
		
			$pass = secure_input($con, $_POST['password1']);	
			$cpass = secure_input($con, $_POST['password2']);				
			
			if($cpass!==$pass)
			{
				exit("passwords are not match!");
			}
			else
			{
				$password = $user->hashed($cpass);
				$toAc = 0;
				$stmt = $user->runQuery("UPDATE bb_users SET pwd=:upass, tokenAc=:tAc WHERE id=:uid");
				$stmt->execute(array(":upass"=>$password,":tAc"=>$toAc,":uid"=>$rows['id']));
				header("location:index.php?pwrst"); exit();
			}
		}	
		
		}
		else
			{
				header("location:index.php?codexpired");exit();
			} 
			
		
	}
	else
	{
		header("location:index.php?nouser");	exit();	
	}
	
	
    
}
?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-PJDLLCD');</script>
<!-- End Google Tag Manager -->
    <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>SenseMe India</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Favicon -->
        <link rel="shortcut icon" type="image/x-icon" href="../assets/img/favicon.png">

        <!-- All css here -->
        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/css/font-awesome.min.css">
        <link rel="stylesheet" href="../assets/css/ie7.css">
        <link rel="stylesheet" href="../assets/css/plugins.css">
        <link rel="stylesheet" href="../assets/css/style.css">
        <script src="../assets/js/vendor/modernizr-3.5.0.min.js"></script>
           <script src="../assets/js/vendor/jquery-3.2.1.min.js"></script>
   
</head>

<body>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-PJDLLCD"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
  <div id="loadAjax" class="ui-front loader ui-widget-overlay bg-gray opacity-50" style="display:none">
           <img src="assets/img/loader-light.gif" alt="">
        </div>
    
<?php include("../sm_header.php"); ?>
    <!--breadcrumbs area start-->
           <div class="breadcrumb-area bg-12 text-center">
            <div class="container">
                <h1><span class="green">Customer Login</span></h1>
                <nav aria-label="breadcrumb">
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">My Account</li>
                    </ul>
                </nav>
            </div>
        </div>
      <div class="wishlist-area table-area pt-80 pb-95">
    <div class="customer_login text-center">
        <div class="container">
            <?php if(isset($_GET['msg'])) echo $_GET['msg'];  ?><br>
<br>

            <div class="row">
               <!--login area start-->
                <div class="col-lg-6 col-md-6 offset-3">
                    <div class="account_form register">
                        <h2>Set New Password</h2>
                        <form id="reset" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST" onSubmit="return pacheck()">
                             <p>   
                                <label>Password <span>*</span></label>
                                <input type="password" id="pass11" name="password1" pattern=".{8,}" title="8 characters minimum required" required>
                             </p>
                             <p>   
                                <label>Re-type Password <span>*</span></label>
                                <input type="password" id="pass21" name="password2" pattern=".{8,}" title="8 characters minimum required">
                             </p>                             
                            <div class="login_submit text-center">
                                <input type="hidden" name="id" value="<?php echo $_GET['id']; ?>">
                                <input type="hidden" name="code" value="<?php echo $_GET['code']; ?>">
                                <button type="submit" name="reset">Reset</button>
                            </div>
                        </form>
                        <script type="text/javascript">

function pacheck()
{	
var pa1 = $('#pass11').val();
var pa2 = $('#pass21').val();
 
 
         if(pa1!=""&&pa2!=""&&pa1==pa2)
        {
        return true;
        }
        else
        {
        alert("Passwords not match! please try again!");		
        return false;
        }	
        

}
</script>
                    </div>    
                </div>
            </div>
        </div>    
    </div>
    </div>
   <?php include("sm_footer.php"); ?>
         <script src="../assets/js/popper.min.js"></script>
        <script src="../assets/js/bootstrap.min.js"></script>
        <script src="../assets/js/plugins.js"></script>
        <script src="../assets/js/ajax-mail.js"></script>
        <script src="../assets/js/main.js"></script>

</body>

</html>
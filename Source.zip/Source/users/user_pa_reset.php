<?php 
//include "../smadmin/function/config.php"; 
//include "../smadmin/function/function.php"; 
require_once '../smadmin/admin/class.user_2.php';
require("../smadmin/db/db_connect.php");
$user = new USER();

if($user->is_logged_in())
{
	$user->redirect('user_dashboard.php');
}

if(isset($_POST['Reset']))
{
    $email = "";
	
	$email = trim($_POST['email']);
	$email = mysqli_real_escape_string($con,$email);
	
	$stmt = $user->runQuery("SELECT id FROM bb_users WHERE email=:email LIMIT 1");
    
	if(!$stmt->execute(array(":email"=>$email)))
    {
       echo $error = "updated failed!"; exit();
    }
    
	if(!$row = $stmt->fetch(PDO::FETCH_ASSOC))
    {
        echo $error = "updated failed!"; exit();
    }
    
    
	if($stmt->rowCount() == 1)
	{
		$id = base64_encode($row['id']);
		$code = md5(uniqid(rand()));
		
		$stmt = $user->runQuery("UPDATE bb_users SET tokenCode=:token WHERE email=:email");
		$stmt->execute(array(":token"=>$code,"email"=>$email));
		
		$message= "
				   Hello , $email
				   <br /><br />
				   You have requested to reset your password, if you do this then just click the following link to reset your password, if not please just ignore this email,
				   <br /><br />
				   Click Following Link To Reset Your Password 
				   <br /><br />
				   <a href='http://abletech.in/demo/bb/users/user_pa_new.php?id=$id&code=$code'><strong>click here to reset your password</strong></a>
				   <br /><br />
				   thank you :)
				   ";
		$subject = "Broonly Bay Password Reset";
        
		$from = "info@htsuite.com";
        
		$user->send_mail($from,$email,$message,$subject);
		
		$msg = "<div class='alert alert-success'>
					<button class='close' data-dismiss='alert'>&times;</button>
					We've sent an email to $email.
                    Please click on the password reset link in the email to generate new password. 					
			  	</div>";
	}
	else
	{
		$msg = "<div class='alert alert-danger'>
					<button class='close' data-dismiss='alert'>&times;</button>
					<strong>Sorry!</strong>Your email is not registered with us. 
			    </div>";
	}
}

?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-PJDLLCD');</script>
<!-- End Google Tag Manager -->
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>password reset</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-png" href="../assets/img/favicon.png">
    
    <!-- CSS 
    ========================= -->


    <!-- Plugins CSS -->
    <link rel="stylesheet" href="../assets/css/plugins.css">
    
    <!-- Main Style CSS -->
    <link rel="stylesheet" href="../assets/css/style.css">

    <script src="../assets/js/plugins.js"></script>


    
    
</head>

<body>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-PJDLLCD"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
  <div id="loadAjax" class="ui-front loader ui-widget-overlay bg-gray opacity-50" style="display:none">
           <img src="../assets/img/loader-light.gif" alt="">
        </div>
    
<?php // include("../bb_header.php"); ?>
    <!--breadcrumbs area start-->
    <div class="breadcrumbs_area">
        <div class="container">   
            
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumb_content">
                        <ul>
                            <li><a href="index.php">home</a></li>
                            <li>/</li><li>Forgot Password</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>         
    </div>
    <div class="customer_login text-center">
        <div class="container">
            
            	<?php 		if(isset($message)&&$message!="") { 
	
	?>
			
			<div class='room-box background-grey mb-5 text-center'>
				<div class='room-box-in'>
										<h5><?php echo $message; ?></h5>
									</div></div>
			<?php 
	
}
			?>
            <?php if(isset($msg)) echo $msg;  ?>
            <div class="row">
                <div class="col-lg-6 col-md-6 offset-3">
                    <div class="account_form">
                       <h2>Reset Password</h2>
                      <form id="registration" action="" method="POST">
                            <p>   
                                <label>E-mail <span>*</span></label>
                                <input type="email" name="email" required>
                             </p>
                             
                            <div class="login_submit text-center">
                                <p class="text-center">Please enter your registered email address. You will receive a link to create a new password via email.</p>
                                <button type="submit" name="Reset">RESET</button>
                                
                            </div>

                        </form>
                     </div>    
                </div>
                <!--login area start-->

                <!--register area start-->
                
                <!--register area end-->
            </div>
        </div>    
    </div>
   <?php include("../bb_footer.php"); ?>

</body>

</html>
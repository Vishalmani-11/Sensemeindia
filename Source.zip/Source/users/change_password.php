<?php
include "db/db_connect.php"; 
include "db/session.php";  
include "function/function.php";  
require_once 'admin/class.user.php';
////////////////////////update/////////////////////////
if(isset($_POST['submit']))
{

$user = new USER();

extract($_POST);	

$id = secure_input($con,$id);
$cname = secure_input($con,$cname);
$apswd = secure_input($con,$apswd);
$rapswd = secure_input($con,$rapswd);


		if($apswd!=$rapswd)
			{
			$error = "Passwords not match. Try again!";
			header("location:admin_dashboard.php?error=$error");	exit();			
			}
			else
			{
				$password = $user->hashed($apswd);
				$stmt = $user->runQuery("UPDATE ecrm_employees SET upass=:upass WHERE id=:uid");
				$stmt->execute(array(":upass"=>$password,":uid"=>$id));
				$success= "New password updated successfully!";
				header("location:admin_dashboard.php?success=".$success); exit();
			}

}

//////////////////////////////////////
if(isset($_GET['id']))
{ 
extract($_GET); 

$subparamStr = "id=".$id."&name=".$name;
$hmac = hash_hmac('sha1', $subparamStr, 'JS4#$sdUI'); 						

if($hmac != $pk) 
{
$admin_login = new USER();
$admin_login->logout();
header('Location: index.php?hout');
}
else
{

$id = base64url_decode($id);
$id = secure_input($con,$id);
$name = base64url_decode($name);
$cname = secure_input($con,$name);

$query = "SELECT * FROM ecrm_employees WHERE id = ?";
$stmt = $con->prepare($query);

if(!$stmt = $con->prepare($query))
{
	echo "query failed: (" . $con->errno . ") " . $con->error;
}

if(!$stmt->bind_param("i", $id))
{
	echo "Param pass failed: (" . $con->errno . ") " . $con->error;
}

	if(!$stmt->execute())
	{
		$error = "Employee data details listing execution failed!".$con->error;		
	}
		if(!$qresult = $stmt->get_result())
		{
			$error = "Employee data details listing failed!".$con->error;					
		}

		$data = $qresult->fetch_assoc();
		
		$estatus = $data['estatus'];
}
}

?>
<!DOCTYPE html>
<html>
<head>
    <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-PJDLLCD');</script>
<!-- End Google Tag Manager -->
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
 <title><?php echo $_SESSION['cName']; ?> Admin Area</title>
<meta name="description" content="">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

<!-- Favicons -->

<link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/images/icons/apple-touch-icon-144-precomposed.png">
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/images/icons/apple-touch-icon-114-precomposed.png">
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/images/icons/apple-touch-icon-72-precomposed.png">
<link rel="apple-touch-icon-precomposed" href="assets/images/icons/apple-touch-icon-57-precomposed.png">
<link rel="shortcut icon" href="assets/images/icons/favicon.png">
<script src="editor/ckeditor/ckeditor.js"></script>
<!--[if lt IE 9]>
          <script src="assets/js/minified/core/html5shiv.min.js"></script>
          <script src="assets/js/minified/core/respond.min.js"></script>
        <![endif]-->

<!-- Fides Admin CSS Core -->

<link rel="stylesheet" type="text/css" href="assets/css/minified/aui-production.min.css">

<!-- Theme UI -->

<link id="layout-theme" rel="stylesheet" type="text/css" href="assets/themes/minified/fides/color-schemes/dark-blue.min.css">

<!-- Fides Admin Responsive -->

<link rel="stylesheet" type="text/css" href="assets/themes/minified/fides/common.min.css">
<!-- <link rel="stylesheet" type="text/css" href="../_assets/themes/fides/common.css"> -->

<link id="theme-animations" rel="stylesheet" type="text/css" href="assets/themes/minified/fides/animations.min.css">
<link rel="stylesheet" type="text/css" href="assets/themes/minified/fides/responsive.min.css">

<!-- Fides Admin JS -->

<script type="text/javascript" src="assets/js/minified/aui-production.min.js"></script>
<script type="text/javascript" src="assets/js/minified/core/raphael.min.js"></script>
<script type="text/javascript" src="assets/js/minified/widgets/charts-justgage.min.js"></script>
<script type="text/javascript">
    $(function() {
         $( "#FUPdatepicker" ).datepicker({
            numberOfMonths: 3,
            showButtonPanel: true
          });
 
    });
	
	
</script>
</head>
<body>
    <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-PJDLLCD"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<div id="loading" class="ui-front loader ui-widget-overlay bg-white opacity-100"> <img src="assets/images/loader-dark.gif" alt=""> </div>
<div id="page-wrapper" class="demo-example"> 
  <!-- #page-header -->
  
  <?php include("sidebar.php"); ?>
  <!-- #page-sidebar -->
  <div id="menu-right" class="scrollable-content hidden">
    <div class="toggle-content-open clearfix">
      <div id="g10" class="small-gauge float-left"></div>
      <div id="g11" class="small-gauge float-right"></div>
    </div>
  </div>
  <div id="page-content-wrapper">
            
                <div id="page-title">

<h3>
    <strong><?php echo strtoupper($cname); ?> </strong>- Change Login Password
</h3>
</div><!-- #page-title -->

            
<div id="page-content">
<div class="example-box">
<?php 
			   if(isset($error)){ ?>
             
             <div class="infobox error-bg">
<a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>             
<div class="bg-red large btn info-icon">
                        <i class="glyph-icon icon-remove"></i>
                    </div>
                    <h4 class="infobox-title"><?php echo $error;?></h4>
                    <p>Some error in the database query occured. Please try again!</p>
                </div>
            </div><?php } ?>
            
<?php 
			   if(isset($success)){ ?>
             
             <div class="infobox success-bg">
<a href="#" title="Close Message" class="glyph-icon infobox-close icon-remove"></a>             
                    <h4 class="infobox-title"><?php echo $success;?></h4>
                </div>
            </div><?php } ?>
    <div class="example-code">
<br>
<br>

        <form id="demo-form-2" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" class="col-md-10 center-margin" method="post">
  
           <div class="content-box mrg25B">
                    <h3 class="content-box-header primary-bg">
                        <span>Change Password</span>
                    </h3>
 <div class="content-box-wrapper">
           <div class="form-row">
          <div class="form-label col-md-2">
            <label for="apswd"> Password:<span class="required">*</span> </label>
          </div>
          <div class="form-input col-md-10">
            <div class="form-input-icon"> <i class="glyph-icon icon-unlock-alt ui-state-default"></i>
              <input id="apswd" placeholder="Type new password" data-trigger="keyup" data-rangelength="[8,25]" type="password" data-required="true" data-equalto="#rapswd" name="apswd" class="parsley-validated">
            </div>
          </div>
        </div>
        
           <div class="form-row">
          <div class="form-label col-md-2">
           <label for="rapswd"> Confirm Password:<span class="required">*</span> </label>
          </div>
          <div class="form-input col-md-10">
            <div class="form-input-icon"> <i class="glyph-icon icon-unlock-alt ui-state-default"></i>
              <input id="rapswd" placeholder="Confirm new password" data-trigger="keyup" data-rangelength="[8,25]" type="password" name="rapswd" data-equalto="#apswd" data-required="true" class="parsley-validated">
            </div>
          </div>
        </div>

                </div>
            </div>
            
            <div class="form-row">
                <input type="hidden" name="superhidden" id="superhidden">
				<input type="hidden" name="id" id="id" value="<?php echo $data['id']; ?>">                 
				<input type="hidden" name="cname" id="id" value="<?php echo $cname; ?>">                                 
                <div class="form-input col-md-10 col-md-offset-2">
            
                        <button type="submit" name="submit"  class="btn large primary-bg" onclick="javascript:$(&apos;#demo-form-2&apos;).parsley( &apos;validate&apos; );"><span class="button-content">Update Password</span></button>
&nbsp;
                        <a href="#" class="btn large bg-red" title="" onclick="goBack()">
            <span class="button-content">Cancel</span>
        </a>
                        

                </div>
            </div>

        </form>

    </div>
    
</div>
</div>
</div>
</div>
</body>
</html>

<div id="limage" class="hide"><img src="assets/images/loader-light.gif" alt=""/></div>  

    <div class="hide" id="black-modal-60" title="EMPLOYEE PROFILE">
            <div class="pad10A" id="mdata"></div>
            </div> 
<script type="text/javascript">
 
    $(function() {
		
         $( ".black-modal-60" ).click(function() {
			 
			 var employee_id = $(this).attr("id");  
           $.ajax({  
                url:"EMP_data.php",  
                method:"post",  
                data:{employee_id:employee_id},
				beforeSend: function(){
				$('#limage').fadeIn();
			    },
			    complete: function(){
				$('#limage').hide();
				},
				success:function(data){  
				$('#mdata').html(data);
				$( "#black-modal-60" ).dialog({
				 modal: true,
				 minWidth: 900,
				 minHeight: 200, 
				 dialogClass: "modal-dialog",
				 buttons: {
					   "CLOSE": function() {
						   $( this ).dialog( "close" );
					   }
				   }, 
				 show: "fadeIn" 
			   });
			   $('.ui-widget-overlay').addClass('bg-black opacity-60');
				
                }  
           });  
		   
         });
		 
    });
 
 
</script>

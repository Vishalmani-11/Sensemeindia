<?php  
require_once "../smadmin/function/config.php"; 
require_once '../smadmin/admin/class.user_2.php';
require_once 'google-api-php-client--PHP/vendor/autoload.php';
require_once 'google/config.php'; 

$admin_login = new USER();
$admin_login->logout();
$client->revokeToken();
header('Location:index.php?lout'); exit();
?>
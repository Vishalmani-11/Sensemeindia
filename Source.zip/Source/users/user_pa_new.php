﻿<?php
include "../smadmin/function/config.php";
require("../smadmin/db/db_connect.php");
require_once '../smadmin/admin/class.user_2.php';
require("../smadmin/function/function.php");

$user = new USER();

if(empty($_GET['id']) && empty($_GET['code']))
{
	$user->redirect('index.php');
} 

if(isset($_GET['id']) && isset($_GET['code']))
{
	$id = base64_decode($_GET['id']);
	$id = secure_input($con, $id);
	$code = secure_input($con,$_GET['code']);
	
	$stmt = $user->runQuery("SELECT * FROM bb_users WHERE id=:uid AND tokenCode=:token");
	$stmt->execute(array(":uid"=>$id,":token"=>$code));
	$rows = $stmt->fetch(PDO::FETCH_ASSOC);
	
	if($stmt->rowCount() == 1)
	{
		if($rows['tokenAc']==0)
		{ 
		if(isset($_POST['change_pass']))
		{
		
			$pass = secure_input($con, $_POST['apswd']);	
			$cpass = secure_input($con, $_POST['rapswd']);				
			
			if($cpass!==$pass)
			{
				exit("passwords are not match!");
			}
			else
			{
				$password = $user->hashed($cpass);
				$toAc = 0;
				$stmt = $user->runQuery("UPDATE bb_users SET pwd=:upass, tokenAc=:tAc WHERE id=:uid");
				$stmt->execute(array(":upass"=>$password,":tAc"=>$toAc,":uid"=>$rows['id']));
				header("location:index.php?pwrst");
			}
		}	
		
		}
		else
			{
				header("location:index.php?codexpired");
			} 
			
		
	}
	else
	{
		$msg = "No Account Found, Contact system administrator!";
				
	}
	
	
}

?>
<!DOCTYPE html>
<!--[if IE 8]><html class="no-js lt-ie9" lang="en"> <![endif]-->
<!--[if gt IE 8]>
<!--><html class="no-js" lang="en"><!--<![endif]-->
<head>

	<meta charset="utf-8">
	<title>Hotels in tirupati, Rooms Photo Gallery</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="theme-color" content="#212121"/>
    <meta name="msapplication-navbutton-color" content="#212121"/>
    <meta name="apple-mobile-web-app-status-bar-style" content="#212121"/>
	<link href="https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet"/>
	<link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i&amp;subset=cyrillic,cyrillic-ext,greek,greek-ext,latin-ext,vietnamese" rel="stylesheet">
	<link rel="stylesheet" href="../css/bootstrap.min.css"/>
	<link rel="stylesheet" href="../css/font-awesome.min.css"/>
	<link rel="stylesheet" href="../css/ionicons.min.css"/>
	<link rel="stylesheet" href="../css/datepicker.css"/>
	<link rel="stylesheet" href="../css/jquery.fancybox.min.css"/>
	<link rel="stylesheet" href="../css/owl.carousel.css"/>
	<link rel="stylesheet" href="../css/owl.transitions.css"/>
	<link rel="stylesheet" href="../css/style.css"/>
	<link rel="stylesheet" href="../css/colors/color.css"/>
	<link rel="icon" type="image/png" href="../favicon.png">
	<link rel="apple-touch-icon" href="../apple-touch-icon.png">
	<link rel="apple-touch-icon" sizes="72x72" href="../apple-touch-icon-72x72.png">
	<link rel="apple-touch-icon" sizes="114x114" href="../apple-touch-icon-114x114.png">
	
	
</head>
<body>	

<!--	<div class="loader">
		<div class="loader__figure"></div>
	</div>-->
	<svg class="hidden">
		<svg id="icon-nav" viewBox="0 0 152 63">
			<title>navarrow</title>
			<path d="M115.737 29L92.77 6.283c-.932-.92-1.21-2.84-.617-4.281.594-1.443 1.837-1.862 2.765-.953l28.429 28.116c.574.57.925 1.557.925 2.619 0 1.06-.351 2.046-.925 2.616l-28.43 28.114c-.336.327-.707.486-1.074.486-.659 0-1.307-.509-1.69-1.437-.593-1.442-.315-3.362.617-4.284L115.299 35H3.442C2.032 35 .89 33.656.89 32c0-1.658 1.143-3 2.552-3H115.737z"/>
		</svg>
	</svg>

	<br>
<?php include("../rr_header.php"); ?>
	
	<div class="section big-25-height over-hide z-bigger">
	
		<div class="parallax parallax-top" style="background-image: url('../img/3.jpg')"></div>
		<div class="dark-over-pages"></div>
	
		<div class="hero-center-section pages">
			<div class="container">
				<div class="row justify-content-center">
					<div class="col-12 parallax-fade-top">
						<div class="hero-text">Reset password</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	
<div class="section padding-top z-bigger mb-5">
		<div class="container">
			
						
		<?php 		if(isset($message)&&$message!="") { 
	
	?>
			
			<div class='room-box background-grey mb-5 text-center'>
				<div class='room-box-in'>
										<h5><?php echo $message; ?></h5>
									</div></div>
			<?php 
	
}
			?>
			
			
			<form id="registration" action="user_login_submit.php" method="POST">
			<div class="row justify-content-center padding-bottom-smaller">
				<div class="col-md-8">
					<div class="subtitle with-line text-center mb-4"><a href="../customer_registration.php"><strong>Register</strong></a> | <a href="index.php"><strong>Login</strong></a></div>
					<h3 class="text-center padding-bottom-small">Reset Password</h3>
				</div>
				<div class="section clearfix"></div>
				
				<div class="col-md-8 mt-4 mt-md-0 ajax-form">
					<input name="email" type="text"  placeholder="your E-Mail: *" required autocomplete="off"/>
				</div>
				<div class="section clearfix"></div>
				<div class="col-md-8 mt-4 mt-md-0 ajax-form text-center">
					Please enter your registered email address. You will receive a link to create a new password via email.
				</div>
				<div class="section clearfix"></div>
				<div class="col-md-8 mt-3 ajax-form text-center">
					<button class="send_message" type="submit" name="login" id="send" data-lang="en"><span>Login</span></button>
				</div>
				<div class="section clearfix"></div>
			</div>
			</form>
		</div>	
	</div>
	<div class="section padding-top-bottom-big over-hide">
		<div class="parallax" style="background-image: url('../img/cta.jpg')"></div>
		<div class="section z-bigger">		
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="row justify-content-center">
							<div class="col-md-12 col-xl-12 px-sm-0">
								<div class="col-md-12 align-self-center">
					<div class="subtitle with-line text-center mb-4 color-white">Neat, Clean &amp; Calm</div>
					<h3 class="text-center color-white">Are you looking for homely stay in Tirupati?</h3>
										
				</div>
							</div>
							
						</div>	
					</div>
					
					<div class="col-md-12 text-center pt-3">
									<a class="mt-1 btn btn-primary" href="javscript:">book now</a>
								</div>
					
					
				</div>
			</div>					
		</div>
	</div>
	
	<?php include("../rr_footer.php"); ?>
	
</body>
</html>